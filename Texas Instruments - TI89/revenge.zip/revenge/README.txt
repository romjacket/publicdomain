 REVENGE  by Orion_ [2003]

 3,2 Ko Intro for TI89

 Coded for fun and ASM68k skill improvement
           ���

 I think, this is my last release for TI68k.
 I'm going to learn coding on AtariST (yes, even if we are in 2003 !!)



http://onorisoft.free.fr/
onorisoft@free.fr
