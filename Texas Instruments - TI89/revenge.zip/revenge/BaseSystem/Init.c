// Intro Loading and Init

#include "Common.h"

u8 IS,II;

void checkloadbar(void)
{
  if(!II) { MyBigPix((void*)0x4C00,IS,100-20); IS++; }
  II=(II+1)&7;
}

void Loading(void)
{
  float cc;
  register u16 i asm("d4");
  register u8  j asm("d5"),k asm("d6"),l asm("d7");

  cmd_clrhome();
  DrawStr(52, 68, "Loading", A_NORMAL);
  II=IS=0;

  CosT[0]=255;  cc=0;  for(i=1;i<512;i++) { CosT[i]=(s16)(cos(cc+=0.0122718463)*256);	checkloadbar(); }
  SinT[0]=0;    cc=0;  for(i=1;i<512;i++) { SinT[i]=(s16)(sin(cc+=0.0122718463)*256);	checkloadbar(); }
                cc=0;  for(i=1;i<256;i++) { SinTab[i]=(u8)(cos(cc+=0.05)*256);		checkloadbar(); }
}
