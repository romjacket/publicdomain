/***********************************/
// Common Vars, Def and Extern Data /
/***********************************/

#ifndef Common_H
#define Common_H

#include <tigcclib.h>

#define u8  unsigned char
#define u16 unsigned short
#define u32 unsigned long
#define s8  signed char
#define s16 signed short
#define s32 signed long

typedef struct { s16 x,y,z; } Point3D;

extern s32	mTable,m11,m12,m13,m21,m22,m23,m31,m32,m33,x,y,cosX,cosY,cosZ,sinX,sinY,sinZ,sinYcosX,sinYsinX,xe,ye,ze;
extern u16	nvertex,nvertex1,nvertex2,rX,rY,rZ,dZ;
extern s16	*CosT,*SinT;
extern u8	*myscreen;
extern u8	*SinTab;
extern Point3D	*objdata,*objdata1,*objdata2;

extern void MyBigPix(void* destination asm("a0"), short x asm("d0"), short y asm("d1"));

#endif
