/***********************************************************/
// Moteur 3D Minimal pour petite demo ;) - by Orion_ [2003] /
/***********************************************************/

// Partie en C (parceque j'suis trop mauvais pour coder �a en asm, �a bug de partout sinon :(

//-----------
//- 3D CORE -
//-----------

#include "Common.h"

void BuildRotationMatrix(void)		// by sBibi
{
  cosX=CosT[rX];
  sinX=SinT[rX];
  cosY=CosT[rY];
  sinY=SinT[rY];
  cosZ=CosT[rZ];
  sinZ=SinT[rZ];

  sinYcosX=sinY*cosX;
  sinYsinX=sinY*sinX;

  m11=(cosZ*cosY)>>8;
  m12=(sinZ*cosY)>>8;
  m13=-sinY;
  m21=(cosZ*sinYsinX - (sinZ*cosX<<8))>>16;
  m22=(sinZ*sinYsinX + (cosX*cosZ<<8))>>16;
  m23=(sinX*cosY)>>8;
  m31=(cosZ*sinYcosX + (sinZ*sinX<<8))>>16;
  m32=(sinZ*sinYcosX - (cosZ*sinX<<8))>>16;
  m33=(cosX*cosY)>>8;
}

s32 vx,vy,vz;

void Compute2DProjection(void)		// by sBibi
{
  vx = (m11 * xe) + (m12 * ye) + (m13 * ze);
  vy = (m21 * xe) + (m22 * ye) + (m23 * ze);
  vz = (m31 * xe) + (m32 * ye) + (m33 * ze) + (dZ<<8);

  if(vz) {
    x = (vx<<8) / vz + 80;
    y = (vy<<8) / vz + 50;
  }
}

