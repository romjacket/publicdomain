////////////////////////////////////////
//                                    //
//         F-ZERO for TI68k           //
//           Version 1.00             //
//    Powered by Mode7Engine v1.1     //
//     � 2003-2005 Lionel Anton       //
//                                    //
////////////////////////////////////////

F-ZERO is a futurist race game originally developed by NINTENDO �
You can play with 4 different ships and you must try to be the fastest to win the gold cup at the
grand prix.
You can upgrade your skills by practicing in Time Attack mode, and try to beat your own records.
You can record ghost files and send them to your friends so they can virtually fight against you in
Time Attack.
At last but not least, there is a versus mode where you can challenge your friends using a standard
link cable.
This game is powered by Mode7Engine v1.1 by me (Lionel Anton).


0) Disclaimer :
---------------

Use this software at your own risk, I (Lionel Anton) cannot be held responsible for any damage
caused to your data and/or hardware and for the failure of your studies.
Don't play at school :p

1) System requirements :
------------------------

- a TI68k graphing calculator (TI89, TI89 Titanium, TI92+ or V200)
- 240KB of free flash ROM to install the game (or more to store ghosts), 180KB of free RAM
- Advanced Mathematics Software (AMS) any version or PedroM (Lastest version) by PpHd
- for link play, a standard link cable (not USB), another TI68k and a friend is required

2) Getting started :
--------------------

/!\ Executables are not calc compatible (but all data, save and ghost are) /!\
Transmit all the files and archive them into main directory.
Be sure you have a lot of free RAM (about 180kb)
Launch fzero() from home screen, you're in the game if everything is OK

3) Main menu :
--------------

Here you can choose the mode to play between Grand Prix, Versus or Time Attack.
You can also choose to modify the game Options or to Quit the game.

4) Grand Prix :
---------------

Grand Prix mode is the main mode of F-ZERO, you will challenge 3 other CPU players through 5 circuits.
Points will be given to you at the end of each race if you stay alive for 3 laps. The winner will
receive the gold cup at the end of the grand prix.
There are 3 different classes with increasing difficulty. I recommend you to start in Novice class.
You can unlock things if you get the gold cups in the highest class ;-)

5) Versus :
-----------

In this mode you will challenge a friend with another TI68k and a link cable. You can also include CPU
players if you want (see Options chapter). First you have to decide who will be the master and who will
be the slave. The master decide of the race and if there will be CPUs. The slave can connect to master
ONLY when the master is ready and waiting for the slave to connect.

6) Time Attack :
----------------

In this mode you will try to beat time records from you or your friends. You'll have to choose the course
and the machine and then go the fastest you can.
Ghost files are the exact copy of all the inputs you did in the race. It is possible to play them when you try
to beat a time and it's easier to see if you are in advance or not.
Ghost files can be saved at the end of the race. No confirmation is required and previous ghost file is
overwritten, so be careful.
You can load a ghost file when you choose the circuit.

7) Options :
------------

You can see the keys for your calculator model in the Show Keys menu.
You can change the contrast.
You can select the CPU level and the number of CPU challengers for versus in Link Play menu.
You can disable the auto archiving of the save file.

You can restore default values (Link Play, Auto Archive).

8) Misc :
---------

You can turn ON/OFF the calculator at any time by pressing [ON]

9) In Race :
------------

You can pause the game (except in versus mode) by pressing [ESC]
Try to get in the boosters (on the floor) as much as you can to gain speed.
After completing the first lap you will receive the boost power. You can use a turbo boost but it will consume some
of your energy so be careful when you are in critical status.

10) Staff ghosts :
------------------

If you get a not so bad time in some races in Time Attack mode, you can unlock Staff ghosts that I made.

11) Bug Reports :
-----------------

If you noticed a bug (the calc crashed) or a glitch (something not supposed to be possible) or anything weird,
please report it with as much details as you can to anton_lionel@yahoo.fr
Thanks :)

12) Web Ghosts service :
------------------------

Compare your best times in Time Attack mode with other players in the world !
You can upload your ghost files to this URL : http://fpgforce.dyndns.org/~lionela/
Ghosts will need to be validate by me oncalc so I'll check for uploaded ghosts as frequently as I can (contact me by mail
if I forgot to check your ghost for a week)
you will be able to download world top ranked ghosts !

13) Map editor :
----------------

Since map editing requires a good knowledge of the rules that make a track valid, I did not include this feature
By the way, a map editor oncalc is available in the sources. If you are really motivated, you can try to make your
own map and then send it to me, I'll check it and maybe I'll include it in an additionnal GP in future versions of F-ZERO.
I cannot guarantee that I'll include it if it is not valid or if it is too difficult.
A map editor will be available for PC (Windows) thanks to Pen^2.
I may write a map validator and a GP generator if I get enough demands :)

14) Thanks :
-------------

Special thanks to (alphabetical order) :
ExtendeD, Fisch2, FpgForce, geogeo, JfG, Jonathan_Holbrook, Kevin Kofler, Lionel Debroux, naPO , Pen^2, Pollux, Ximoon
and all the people who helped or encourage me on Ti-Gen www.tigen.org and on yAronet www.yaronet.com

Thanks to JC who designed my website www.tigen.org/lionela

F-ZERO for TI68k by Lionel ANTON � 2003-2005
