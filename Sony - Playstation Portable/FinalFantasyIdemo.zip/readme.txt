~Abtsract~
This demo was compiled for OpenBOR on Tuesday March 03 2009 at 4:30 am, by Nick :D (Nick Pizanias). 

I made this, why? Because I love the original NES Final Fantasy! It was so unique for its time, and is a very deep game despite its simplicity. Plus, it is also started a worldwide famous video game franchise, that has produced some of the greatest gaming experiences made thus far. So, I made this for two reasons: 1) as a tribute to the origin of the series and 2) because I just plain have an addiction to making these things :P!

~Game Modes~
-Story Mode (Classic): Play through the story of Final Fantasy! Features the original NES music for all stages (and WonderSwan music for boss battles)!
-Story Mode (Arranged): The exact same thing as (Classic) mode, only this one features the PSX remixes for all stages!
-Arcade Mode: For quick play. Fight through the main villains of Final Fantasy, arcade style!

~Controls~
This is a ONE BUTTONED MOD! Meaning that you'll play with only ONE BUTTON! And that button is: the Attack button. Of course you still move around with the directional keys, but, that's a given really. 

There are 6 playable characters, and they are divided into two groups: close-range and long-range. Close-range characters actually have to walk up to an enemy and attack it to defeat it, but there is little to no lag inbetween their attacks. Long-range characters can attack from  farther away but have much more lag inbetween their attacks, so are more vulnerable to being hit. 

Push up or down in the Character Select screen to scroll through multiple colors for your character.

~Close-range Characters~
(All close-range characters can attack up to 3 consecutive hits)
-Fighter: The "default" character. You can't go wrong using this guy.
-Thief: Has shorter range than a Fighter, but moves a lot quicker.
-Red Mage: Practically the same as Fighter.
-Black Belt: Practically the same as Fighter.

~Long-range Characters~
(All long-range characters can attack up to 2 consecutive hits)
-Black Mage: Launches a fireball that goes a good distance then disappears. Because of this, he can kill multiple enemies in a row as his fireball travels, but he cannot move until it disappears. 
-White Mage: He can attack just as far as Black Mage can, but his magic is a set distance. What I mean is, it doesn't travel like the BM's fireball. Because of this, it may make him the harder character to play as you have to "aim" with him, but what he has over the Black Mage is shorter attack time, meaning he could almost attack twice in the time it takes the BM to attack once.

~Items~
-Orb: Pick this up to automatically kill all enemies on the screen.
-Crystal: Pick this up to fully heal the player that picked it up.

~OpenBOR Version~
I personally tested this on OpenBOR 2.2038... however, this mod doesn't use many new commands, so it may even work on previous versions (NOTE: This mod does NOT use the Jump button, so pressing the Jump button on older versions may make the game crash). But really, you should always use the latest version available, can't go wrong with that.