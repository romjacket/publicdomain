 _ _____  _               _____            _            _____            _              _____ _                           
(_)  __ \| |             |  __ \          | |          |  __ \          (_)            / ____(_)                          
 _| |__) | | __ _ _   _  | |__) |___   ___| |__   ___  | |__) |_ _ _ __  _  ___ _ __  | |     _ ___  ___  __ _ _   ___  __
| |  ___/| |/ _` | | | | |  _  // _ \ / __| '_ \ / _ \ |  ___/ _` | '_ \| |/ _ \ '__| | |    | / __|/ _ \/ _` | | | \ \/ /
| | |    | | (_| | |_| | | | \ \ (_) | (__| | | |  __/ | |  | (_| | |_) | |  __/ |    | |____| \__ \  __/ (_| | |_| |>  < 
|_|_|    |_|\__,_|\__, | |_|  \_\___/ \___|_| |_|\___| |_|   \__,_| .__/|_|\___|_|     \_____|_|___/\___|\__,_|\__,_/_/\_\
                   __/ |                                          | |                                                     
                  |___/                                           |_|                                                     
  

Code : J3r3mie
Graphisme : NetM@n

iPlay Roche Papier Ciseaux est un Roche Papier Ciseaux (Ou Pierre Feuille Ciseaux pour les fran�ais) sur la PSP. 

Il contient :

	- Mode contre CPU
	- Mode contre un autre joueur mais sur une seule PSP
	- Mode contre un autre joueur en Adhoc*

*Permet de faire qu'une seule partie dans cette version.

Un merci sp�cial � Ac-Portugal pour tous ces testes pour le mode Adhoc.

Visitez mon site web http://J3r3mieDev.e3b.org pour rester au courant de mes homebrews.

J3r3mie