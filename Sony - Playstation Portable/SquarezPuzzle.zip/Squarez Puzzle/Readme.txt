Squarez Puzzle - Developed by Socals, provided by M for Mature [http://mformature.net]

Note: Eboot.PBP for standard 1.0 eboot format while the folders contain the 1.50 formated eboots. Delete the eboot file in Sqpuzzle and replace with the eboot.pbp found in the extracted folder (folder with the folders, this readme and the screenshot) - this should then work with 1.0fw or the later CFW's

Quoted from Socals (Beta Testing Forum - 2005)

Features:
* FrozenIpaq's original idea for puzzle mode and how to move squarez.
* JimShoe's idea of moving the player using d-pad only.
* Yet I added the ability to move them more than once, yet all examples are move once only.

See my examples in the levels folder for how to make levels.

Features:
* in-game editor
* new background graphics

Changes:
* smaller grid, 23x12
* can no longer exit game with START, must use HOME for now. just exited by accident too much when making levels
* when reaching a level with no file, an error is no longer generated. Instead a blank grid is displayed. You can now use the editor to create a level and save it. All levels are saved using the level # displayed on the screen.

Fixes:
* Bug where you couldn't push blocks left at the top of the screen.

Game Commands:
d-pad = control player
SQUARE = prev level
TRIANGLE = next level
R1 = Restart current level
L1 = Level Editor
SELECT = screenshot

(the # of moves is displayed in text over each object - really only applies to walls!)
Editor Commands:
CROSS = drop wall with 1 move
CIRCLE = delete object
SQUARE = remove a move
TRIANGLE = add a move
R1+CROSS = drop player start
R1+CIRCLE = drop win game
SELECT = save game
L1 = Back to game mode

NOTICE! If your creating a new level, and haven't saved it but decide to play it to test it, DO NOT complete the level or you will lose your level since the game will advance to the next level!

Legend (Creating Levels):
. = blank space
P = player starting pos
* = player win pos
0-9 = # of times a wall can be moved (only test 1 so far...)

Use d-pad to move, R1 to reset current level, hold R1+L1 to reset game. Once you beat a lvl you advance to the next level, if it cannot find that level an error will occur and the game will restart from level 1.

Level 1 is FrozenIpaq's 1st shown level and it works out as a good beginner level so...

Level 2 isn't really a level, I just drew some crap for testing and it just happens to be solvable but was mainly done for testing/example.

Object of the game is to move your blue square on top of the "ghost" blue square to win.