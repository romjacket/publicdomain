~~~~~~~~~~~~~~~
~ Asterz V1.2 ~
~~~~~~~~~~~~~~~

A Team Duck Production
--

~ Info ~

Come check out mformature.net. This is where the projects official thread and discussion is located.

Asterz is a shoot-em-up space game partly inspired by the classic hit game "Asteroids", originally released in 1979 by Atari. As you begin to start playing Asterz you'll find that this game primarily involves:

#1 � Dodge the incoming asteroids and enemy ships.
#2 � Destroy the incoming asteroids and enemy ships.
#3 � Pick up the dropped powerups to increase your ammo or give your ship a temporary shield.
and #4 - Don't die!

I hope that this formula makes for some fast paced addictive and fun gameplay.

--

~ Features ~

There are three modes included in this release, the first being Story Mode, the second being Arcade Mode, and the last being Online Play. The Story Mode allows you to progress through 10 unique levels, with each having their own strategies involved in actually completing the level. Arcade Mode allows you to play endlessly and try to rack up as many points as possible. Online Play is a 4 player deathmatch style of gameplay which, you guessed it, is online.

I'm not really sure what originally prompted me to begin working on a space shooter. It was partly because I wanted to test my abilities as far as 3D effects and lighting were concerned by utilizing the official PSPGU. The most obvious thing that you'll notice is that this game is done completely in a 3D world, but the gameplay is being played on a 2D plane. This is something that I would say brings a unique element to the game as very little homebrews currently utilize any sort of 3D rendering.



Version 1.2 sports several new additions. Check out the changelog for a list of them.

--

~ NEW Controls ~

START - Pause Game
Analog - Go in the direction you are pointing at
CROSS - Shoot Selected weapon
LTRIGGER - Barrel Roll to the Left
RTRIGGER - Barrel Roll to the Right
SQUARE - Switch Weapon Left
CIRCLE - Switch Weapon Right

--




A Team Duck Production

Credits:
Programming: 	Slasher
Help: 		XiGency
Network Server: Youresam
GFX: 		Ubersheep
3d Models: 	Cablekevin
