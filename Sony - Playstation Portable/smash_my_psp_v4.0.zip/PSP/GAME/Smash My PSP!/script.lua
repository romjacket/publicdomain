--[[Smash My PSP! v4.0
by zeroXorXdieXskater]]

oldpad = Controls.read()

-- Colors
black = Color.new(0, 0, 0)
white = Color.new(255, 255, 255)
red = Color.new(255, 0, 0)
green = Color.new(0, 255, 0)
blue = Color.new(0, 0, 255)
grey = Color.new(128, 128, 128)
pink = Color.new(255, 104, 104)

browser = {s = 1, fl = System.listDirectory("ms0:/PICTURE"),ls = 1, sp = 10}
browser.nf = table.getn(browser.fl)

function smashtrue()
	smash = true
end

function controlplay()
if pad:cross() and not oldpad:cross() then
	if weapon.img == hammer1 and crackin == 1 then
		hammersnd:play()
		weapon.img = hammer2
		weapon.smashpic = crack1
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
		crackin = 2
	else if weapon.img == hammer1 and crackin == 2 then
		hammersnd:play()
		weapon.img = hammer2
		weapon.smashpic = crack2
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
		crackin = 3
	else if weapon.img == hammer1 and crackin == 3 then
		hammersnd:play()
		weapon.img = hammer2
		weapon.smashpic = crack3
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
		crackin = 4
	else if weapon.img == hammer1 and crackin == 4 then
		hammersnd:play()
		weapon.img = hammer2
		weapon.smashpic = crack4
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
		crackin = 1
	else if weapon.img == hammer2 then
		weapon.img = hammer1

	else if weapon.img == pistol1 then
		gunsnd:play()
		weapon.img = pistol2
		weapon.smashpic = bullet
		fake:blit(weapon.x - math.random(20,30), weapon.y - math.random(10,20), weapon.smashpic)
	else if weapon.img == pistol2 then
		weapon.img = pistol1
	end
	end
	end
	end
	end
	end
	end
end

if pad:start() then
	gamestate = "paused"
end

if pad:l() and pad:r() then
	screen:save("screenshot.png")
end

if pad:cross() then
	smashtrue()
end

if pad:select() then
	gamestate = "browser"

end
end

gamestate = "intro"


-------------------------------------------------while loop
while true do
screen:clear()
pad = Controls.read()



if smash == true then

	if weapon.img == pinkcrayon then
		weapon.smashpic = pinkpaint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
	
	else if weapon.img == bluecrayon then
		weapon.smashpic = bluepaint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)

	else if weapon.img == greencrayon then
		weapon.smashpic = greenpaint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
	
	else if weapon.img == redcrayon then
		weapon.smashpic = redpaint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)

	else if weapon.img == blackcrayon then
		weapon.smashpic = blackpaint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
	
	else if weapon.img == whitecrayon then
		weapon.smashpic = whitepaint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)

	else if weapon.img == greycrayon then
		weapon.smashpic = greypaint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)

	else if weapon.img == smileyprintstamp1 then
		popsnd:play()
		weapon.img = smileyprintstamp2
		weapon.smashpic = smileyprint
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
	else if weapon.img == smileyprintstamp2 then
		weapon.img = smileyprintstamp1

	else if weapon.img == alienstamp1 then
		popsnd:play()
		weapon.img = alienstamp2
		weapon.smashpic = alien
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
	else if weapon.img == alienstamp2 then
		weapon.img = alienstamp1

	else if weapon.img == splatterstamp1 then
		popsnd:play()
		weapon.img = splatterstamp2
		weapon.smashpic = splatter
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
	else if weapon.img == splatterstamp2 then
		weapon.img = splatterstamp1

	else if weapon.img == gun1 then
		gunsnd:play()
		weapon.img = gun2
		weapon.smashpic = bullet
		fake:blit(weapon.x - math.random(0,30), weapon.y - math.random(0,40), weapon.smashpic)
	else if weapon.img == gun2 then
		weapon.img = gun1

	else if weapon.img == multi and colorin == 1 then
		popsnd:play()
		weapon.smashpic = bluedot
		fake:blit(weapon.x - math.random(0,60), weapon.y - math.random(0,60), weapon.smashpic)
		colorin = 2
		
	else if weapon.img == multi and colorin == 2 then
		popsnd:play()
		weapon.smashpic = reddot
		fake:blit(weapon.x - math.random(0,60), weapon.y - math.random(0,60), weapon.smashpic)
		colorin = 3
		
	else if weapon.img == multi and colorin == 3 then
		popsnd:play()
		weapon.smashpic = greendot
		fake:blit(weapon.x - math.random(0,60), weapon.y - math.random(0,60), weapon.smashpic)
		colorin = 1
		
	else if weapon.img == phaser1 then
		phasersnd:play()
		weapon.img = phaser2
		weapon.smashpic = phased
		fake:blit(weapon.x, weapon.y, weapon.smashpic)
	else if weapon.img == phaser2 then
		weapon.img = phaser1



	else if weapon.img == paintcan then
		weapon.smashpic = spray
		fake:blit(weapon.x - math.random(0,20), weapon.y - math.random(0,20), weapon.smashpic)
		fake:blit(weapon.x - math.random(0,20), weapon.y - math.random(0,20), weapon.smashpic)
		fake:blit(weapon.x - math.random(0,20), weapon.y - math.random(0,20), weapon.smashpic)
		fake:blit(weapon.x - math.random(0,20), weapon.y - math.random(0,20), weapon.smashpic)


	else if weapon.img == eraser then
		erasersnd:play()
		fake:fillRect(weapon.x - 40, weapon.y - 40, 40, 40, Color.new(0, 0, 0, 0))
	
	end
	end	
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	end
	
end
smash = false
end

---------------------------------gamestates
if gamestate == "intro" then
title = Image.load("title.png")

screen:clear()
screen:blit(0, 0, title, false)
screen:print(200, 170, "Loading", white)
screen:print(440, 10, "v4.0", white)
screen.flip()
screen.waitVblankStart(20)

--------------------------------------weapons
hammer1 = Image.load( "weapons/hammer1.png" )
hammer2 = Image.load( "weapons/hammer2.png" )
crack1 = Image.load( "weapons/crack1.png" )
crack2 = Image.load( "weapons/crack2.png" )
crack3 = Image.load( "weapons/crack3.png" )
crack4 = Image.load( "weapons/crack4.png" )
pinkcrayon = Image.load( "weapons/pinkcrayon.png" )
pinkpaint = Image.load( "weapons/pinkcolor.png" )
bluecrayon = Image.load( "weapons/bluecrayon.png" )
bluepaint = Image.load( "weapons/bluecolor.png" )
redcrayon = Image.load( "weapons/redcrayon.png" )
redpaint = Image.load( "weapons/redcolor.png" )
greencrayon = Image.load( "weapons/greencrayon.png" )
greenpaint = Image.load( "weapons/greencolor.png" )
whitecrayon = Image.load( "weapons/whitecrayon.png" )
whitepaint = Image.load( "weapons/whitecolor.png" )
blackcrayon = Image.load( "weapons/blackcrayon.png" )
blackpaint = Image.load( "weapons/blackcolor.png" )
greycrayon = Image.load( "weapons/greycrayon.png" )
greypaint = Image.load( "weapons/greycolor.png" )
smileyprintstamp1 = Image.load( "weapons/stamp1.png" )
smileyprintstamp2 = Image.load( "weapons/stamp2.png" )
smileyprint = Image.load( "weapons/smiley.png")
alienstamp1 = Image.load( "weapons/stamp1.png" )
alienstamp2 = Image.load( "weapons/stamp2.png" )
alien = Image.load("weapons/alien.png")
splatterstamp1 = Image.load( "weapons/stamp1.png" )
splatterstamp2 = Image.load( "weapons/stamp2.png" )
splatter = Image.load("weapons/splatter.png")
gun1 = Image.load("weapons/gun1.png")
gun2 = Image.load("weapons/gun2.png")
bullet = Image.load("weapons/bullet.png")
multi = Image.load("weapons/multi.png")
bluedot = Image.load("weapons/bluedot.png")
reddot = Image.load("weapons/reddot.png")
greendot = Image.load("weapons/greendot.png")
phaser1 = Image.load("weapons/phaser1.png")
phaser2 = Image.load("weapons/phaser2.png")
phased = Image.load("weapons/phased.png")
pistol1 = Image.load("weapons/pistol1.png")
pistol2 = Image.load("weapons/pistol2.png")
paintcan = Image.load("weapons/paintcan.png")
spray = Image.createEmpty(2,2)
eraser = Image.load("weapons/eraser.png")
weapon = {}
weapon = { x = 2, y = 50, speed = 4, img = nil, smashpic = nil}
fake = Image.createEmpty(480,272)

--------------------------------------------sounds
gunsnd = Sound.load("sounds/gun.wav", false)
phasersnd = Sound.load("sounds/phaser.wav", false)
popsnd = Sound.load("sounds/pop.wav", false)
hammersnd = Sound.load("sounds/hammer.wav", false)
erasersnd = Sound.load("sounds/eraser.wav", false)

----------------------------------------------backgrounds
default = Image.load("backgrounds/default.jpg")
background = default

backgroundsmenu = Image.load("backgroundsmenu.png")
pausemenu = Image.load("pause.png")
colormenu = Image.load("colormenu.png")
stampsmenu = Image.load("stampsmenu.png")
Resolution = { width = 480, height = 272 }
gamestate = nil

screen:clear()
screen:blit(0, 0, title, false)
screen:print(200, 170, "Loading.", white)
screen:print(440, 10, "v4.0", white)
screen.flip()
screen.waitVblankStart(20)

------------------------------------controls
function moveplayer()
anaX=pad:analogX()
anaY=pad:analogY()
if pad:up() and weapon.y > 0 then
	weapon.y = weapon.y - 2
end

if pad:down() and weapon.y < ( Resolution.height) then
	weapon.y = weapon.y + 2
end

if pad:left() and weapon.x > 0 then
	weapon.x = weapon.x - 2
end

if pad:right() and weapon.x < ( 480) then
	weapon.x = weapon.x + 2
end

if anaY<-50 and weapon.y > 0 then
	weapon.y = weapon.y - 2
end

if anaY>50 and weapon.y < ( Resolution.height ) then
	weapon.y = weapon.y + 2
end

if anaX<-50 and weapon.x > 0 then
	weapon.x = weapon.x - 2
end

if anaX>50 and weapon.x < ( 480 ) then
	weapon.x = weapon.x + 2
end

if anaY<-127 and weapon.y > 0 then
	weapon.y = weapon.y - weapon.speed
end

if anaY>126 and weapon.y < ( Resolution.height ) then
	weapon.y = weapon.y + weapon.speed
end

if anaX<-127 and weapon.x > 0 then
	weapon.x = weapon.x - weapon.speed
end

if anaX>126 and weapon.x < ( 480 ) then
	weapon.x = weapon.x + weapon.speed
end
end

screen:clear()
screen:blit(0, 0, title, false)
screen:print(200, 170, "Loading..", white)
screen:print(440, 10, "v4.0", white)
screen.flip()
screen.waitVblankStart(20)

crackin = 1
colorin = 1
weapon.img = hammer1
menustatus = 1

screen:clear()
screen:blit(0, 0, title, false)
screen:print(200, 170, "Loading...", white)
screen:print(440, 10, "v4.0", white)
screen.flip()
screen.waitVblankStart(50)

gamestate = "play"
end

if gamestate == "play" then
	screen:blit(0,0,background)
	screen:blit(0,0,fake)
	screen:blit(weapon.x,weapon.y,weapon.img)
	moveplayer()
	controlplay()	
end

-----------------------pause
if gamestate == "paused" then
screen:blit(0,0,pausemenu)
	if pad:circle() then
		gamestate = "play"
	end
	if pad:up() then
    		menustatus = menustatus - 1
    		screen.waitVblankStart(4)
	end
	if pad:down() then
    		menustatus = menustatus + 1
    		screen.waitVblankStart(4)
	end
	if pad:left() then
    		menustatus = menustatus - 5
    		screen.waitVblankStart(4)
	end
	if pad:right() then
    		menustatus = menustatus + 5
    		screen.waitVblankStart(4)
	end

color={white,white,white,white,white,white,white,white,white,white,white,white,white,white,white}
color[menustatus]=red

screen:print(50, 50, "Hammer", color[1])
screen:print(50, 60, "Crayon", color[2])
screen:print(50, 70, "Stamp", color[3])
screen:print(50, 80, "Machine Gun", color[4])
screen:print(50, 90, "Pistol Gun", color[5])
screen:print(50, 100, "Multi-Color Gun", color[6])
screen:print(50, 110, "Phaser", color[7])
screen:print(50, 120, "Paint Can", color[8])
screen:print(50, 130, "Eraser", color[9])
screen:print(50, 140, "Reset", color[10])

if menustatus == 1 then
    if pad:cross() and not oldpad:cross() then
    	weapon.img = hammer1
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 2 then
    if pad:cross() then
	menustatus = 1
	gamestate = "delay"
    end
end

if menustatus == 3 then
		if pad:cross() then
		screen.waitVblankStart(10)
		menustatus = 1
		gamestate = "delay3"
		end
end

if menustatus == 4 then
		if pad:cross() then
		screen.waitVblankStart(10)
		weapon.img = gun1
		menustatus = 1
		gamestate = "play"
		end
end

if menustatus == 5 then
		if pad:cross() then
		screen.waitVblankStart(10)
		weapon.img = pistol1
		menustatus = 1
		gamestate = "play"
		end
end

if menustatus == 6 then
		if pad:cross() then
		screen.waitVblankStart(10)
		weapon.img = multi
		menustatus = 1
		gamestate = "play"
		end
end

if menustatus == 7 then
		if pad:cross() then
		screen.waitVblankStart(10)
		weapon.img = phaser1
		menustatus = 1
		gamestate = "play"
		end
end

if menustatus == 8 then
		if pad:cross() then
		screen.waitVblankStart(30)
		menustatus = 1
		gamestate = "delay2"
		end
end

if menustatus == 9 then
		if pad:cross() then
		screen.waitVblankStart(10)
		weapon.img = eraser
		menustatus = 1
		gamestate = "play"
		end
end

if menustatus == 10 then
		if pad:cross() then
		screen.waitVblankStart(10)
		fake:clear()
		menustatus = 1
		gamestate = "play"
		end
end

if menustatus <= 0 then
    menustatus = 10
end
if menustatus >= 11 then
    menustatus = 1
end
end

-------------------------------backgrounds



if gamestate == "colormenu1" then
screen:blit(0,0,colormenu)

	if pad:circle() then
		gamestate = "play"
	end
	if pad:up() then
    		menustatus = menustatus - 1
    		screen.waitVblankStart(4)
	end
	if pad:down() then
    		menustatus = menustatus + 1
    		screen.waitVblankStart(4)
	end

color={white, white, white, white, white, white, white}
color[menustatus]=red
screen:print(50, 50, "Red", color[1])
screen:print(50, 60, "Blue", color[2])
screen:print(50, 70, "Green", color[3])
screen:print(50, 80, "Pink", color[4])
screen:print(50, 90, "White", color[5])
screen:print(50, 100, "Black", color[6])
screen:print(50, 110, "Grey", color[7])

if menustatus == 1 then
    if pad:cross() then
	weapon.img = redcrayon
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 2 then
    if pad:cross() then
	weapon.img = bluecrayon
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 3 then
    if pad:cross() then
	weapon.img = greencrayon
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 4 then
    if pad:cross() then
	weapon.img = pinkcrayon
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 5 then
    if pad:cross() then
	weapon.img = whitecrayon
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 6 then
    if pad:cross() then
	weapon.img = blackcrayon
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 7 then
    if pad:cross() then
	weapon.img = greycrayon
	menustatus = 1
	gamestate = "play"
    end
end


if menustatus <= 0 then
    menustatus = 7
end
if menustatus >= 8 then
    menustatus = 1
end
end	

if gamestate == "colormenu2" then
screen:blit(0,0,colormenu)

	if pad:circle() then
		gamestate = "play"
	end
	if pad:up() then
    		menustatus = menustatus - 1
    		screen.waitVblankStart(4)
	end
	if pad:down() then
    		menustatus = menustatus + 1
    		screen.waitVblankStart(4)
	end

color={white, white, white, white, white, white, white}
color[menustatus]=red
screen:print(50, 50, "Red", color[1])
screen:print(50, 60, "Blue", color[2])
screen:print(50, 70, "Green", color[3])
screen:print(50, 80, "Pink", color[4])
screen:print(50, 90, "White", color[5])
screen:print(50, 100, "Black", color[6])
screen:print(50, 110, "Grey", color[7])

if menustatus == 1 then
    if pad:cross() then
	spray:clear(red)
	weapon.img = paintcan
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 2 then
    if pad:cross() then
	spray:clear(blue)
	weapon.img = paintcan
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 3 then
    if pad:cross() then
	spray:clear(green)
	weapon.img = paintcan
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 4 then
    if pad:cross() then
	spray:clear(pink)
	weapon.img = paintcan
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 5 then
    if pad:cross() then
	spray:clear(white)
	weapon.img = paintcan
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 6 then
    if pad:cross() then
	spray:clear(black)
	weapon.img = paintcan
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 7 then
    if pad:cross() then
	spray:clear(grey)
	weapon.img = paintcan
	menustatus = 1
	gamestate = "play"
    end
end


if menustatus <= 0 then
    menustatus = 7
end
if menustatus >= 8 then
    menustatus = 1
end
end

if gamestate == "stampmenu" then
screen:blit(0,0,stampsmenu)

	if pad:circle() then
		gamestate = "play"
	end
	if pad:up() then
    		menustatus = menustatus - 1
    		screen.waitVblankStart(4)
	end
	if pad:down() then
    		menustatus = menustatus + 1
    		screen.waitVblankStart(4)
	end

color={white, white, white, white, white, white, white}
color[menustatus]=red
screen:print(50, 50, "Smiley Stamp", color[1])
screen:print(50, 60, "Alien Stamp", color[2])
screen:print(50, 70, "Splatter Stamp", color[3])


if menustatus == 1 then
    if pad:cross() then
	weapon.img = smileyprintstamp1
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 2 then
    if pad:cross() then
	weapon.img = alienstamp1
	menustatus = 1
	gamestate = "play"
    end
end

if menustatus == 3 then
    if pad:cross() then
	weapon.img = splatterstamp1
	menustatus = 1
	gamestate = "play"
    end
end


if menustatus <= 0 then
    menustatus = 3
end
if menustatus >= 4 then
    menustatus = 1
end
end

if gamestate == "delay" then
	menustatus = 1
	screen.waitVblankStart(30)
	gamestate = "colormenu1"
end

if gamestate == "delay2" then
	menustatus = 1
	screen.waitVblankStart(30)
	gamestate = "colormenu2"
end

if gamestate == "delay3" then
	menustatus = 1
	screen.waitVblankStart(30)
	gamestate = "stampmenu"
end

if gamestate == "browser" then
screen:blit(0,0,backgroundsmenu)
	System.currentDirectory("ms0:/PICTURE")
	for i = ((browser.ls-1)*browser.sp)+1, browser.ls*browser.sp do
		if browser.nf >= i then
			screen:print(50,((i-((browser.ls-1.5)*browser.sp))*10)-10, browser.fl[i].name,white)
		elseif browser.nf < i then
			break
		end
	end

	screen:print(50,((browser.s-((browser.ls-1.5)*browser.sp))*10)-10, browser.fl[browser.s].name,red)

	if pad:down() and not oldpad:down() then
		browser.s = browser.s + 1
	end
	if pad:up() and not oldpad:up() then
		browser.s = browser.s - 1
	end

	if browser.s > browser.nf then
		browser.s = browser.nf
	elseif browser.s < 1 then
		browser.s = 1
	end
	if browser.s > browser.sp*browser.ls then
		browser.ls = browser.ls + 1
	elseif browser.s < ((browser.ls-1) * browser.sp)+1 then
		browser.ls = browser.ls - 1 browser.s = (browser.ls)*browser.sp
	end

	if pad:cross() and not oldpad:cross() then
		if not browser.fl[browser.s].directory then
			if string.lower(string.sub(browser.fl[browser.s].name, -4)) == (".png" or ".jpg") then
				background = Image.load(browser.fl[browser.s].name)
				fake:clear()
				gamestate = "play"
			

			end
		end
	end
	if pad:circle() and not oldpad:circle() then
		gamestate = "play"
	end
end

screen.waitVblankStart()
screen.flip()
oldpad = pad
end