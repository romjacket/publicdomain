--[[Smash My PSP! v4.0
Created By zeroXorXdieXskater]]

--//What is it?\\--
Smash My PSP! is a game in which you can destroy your PSP main menu in many different ways.

--//What are the controls?\\--
--Use the D-Pad or analog stick to control your weapon
--Press X to use your weapon
--Press start to change your weapons
--Press L and R triggers to take a screenshot
--To reset the background go to weapons, then reset
--Press select to change the background
--To add your own custom background
	-Put a .png image of your choice in ms0:/PICTURE
	-Load the game and press select to get to the backgrounds menu
--press left or right in weapons to scroll by 5 instead of 1

--//Misc.\\--
Using Luaplayer .20
Coded in LuaDevKit

--//Credits\\--
me, zeroXorXdieXskater - coding, some images
google/me/Desktop Destroyer - sprites
n00bionaire - posting my game on qj
evilmana.com - lua codebase
dan369 - testing and help with some coding

--//Changelog\\--
v4.0
-remade all menu backgrounds
-remade title screen
-hammer and pistol are no longer fully automatic
-added stamp menu and seperated the 1 stamp into 3
-the backgrounds menu was replace with a browser that lets you select an image from "ms0:/PICTURE"
-rewrote a lot of code
-increased amount paint can sprays
v3.2
-fixed screenshot function
-added white background
-added spray paint
-added eraser
-added option to change colors for crayon and spray paint
-removed chainsaw
-put all 3 stamps into one weapon that alternates
-modified phaser images slightly
-modified pistol images slightly
-fixed auto fire after weapon selection
v3.1
-changed phaser slightly
-added pistol
-changed loading screen
-recoded alot
-multi color gun fix
-implementing in sound (add more possibly)
v3.0
-added loading screen
-added multi color gun
-added chainsaw
-added ability to scroll faster through weapons with left and right
-added phaser gun
-version number on title screen
-added 3 more "cracks" for the hammer
-O now exits out of menu's
-when you change the background it also resets
-GIF's available in custom backgrounds
-code is now readible and easy to modify
v2.0
-added analog support
-cleaned up folders
-easy to add your own custom backgrounds
-added Patapon 2 screenshot
-added Pop Bean minigame to backgrounds thanks GinoD
-alien and splatter and now in weapons
-machine gun from Desktop Destroyer is now in weapons
v1.0
-added new colors
-change graphics slightly
-increased weapon speed
-added screenshot function
-changed color size
-added option to change backgrounds
-changed weapon selection background
-added smiley stamp weapon