--red = pge.gfx.createcolor(255, 0, 0)
--green = pge.gfx.createcolor(0, 255, 0)
--blue = pge.gfx.createcolor(0, 0, 255)
--white = pge.gfx.createcolor(255, 255, 255)
--black = pge.gfx.createcolor(0, 0, 0)

--pge.delay(10000)

--verdana9 = pge.font.load("verdana.ttf", 9)
--verdana12 = pge.font.load("verdana.ttf", 12)
--verdana18 = pge.font.load("verdana.ttf", 18)
--verdana24 = pge.font.load("verdana.ttf", 24)

--pge.delay(10000)

intro1 = pge.texture.load("intro1.png")
intro2 = pge.texture.load("intro2.png")
intro3 = pge.texture.load("intro3.png")
loading = pge.texture.load("loading.png")
menu_startpic = pge.texture.load("menu_start.png")
menu_helppic = pge.texture.load("menu_help.png")
menu_creditspic = pge.texture.load("menu_credits.png")
helppic = pge.texture.load("help.png")
creditspic = pge.texture.load("credits.png")

pge.delay(10000)

alpha = 1
hud_zoom_x = 0
hud_zoom_y = 0
x_middle = 240
y_middle = 136
intro_alpha = 0
amodifier = 3
whichfunction = 1
whichsound = pge.math.randint(-2, 15)
whichmenupic = 1
whichgamepic = 1
playsound = -10
correctanswer = 0

function intro1f()
	intro1:activate()
	intro1:draweasy(0, 0, 0, intro_alpha)
	
	intro_alpha = intro_alpha + amodifier
	
	if intro_alpha >= 600 then
	amodifier = -3
	end
	
	if intro_alpha <= 1 then
	intro1 = nil
	collectgarbage()
	collectgarbage()
	collectgarbage()
	intro_alpha = 0
	amodifier = 3
	whichfunction = 2
	end
end

function intro2f()
	intro2:activate()
	intro2:draweasy(0, 0, 0, intro_alpha)
	
	intro_alpha = intro_alpha + amodifier
	
	if intro_alpha >= 600 then
	amodifier = -3
	end
	
	if intro_alpha <= 1 then
	intro2 = nil
	collectgarbage()
	collectgarbage()
	collectgarbage()
	intro_alpha = 0
	amodifier = 3
	whichfunction = 0
	end
end

function intro3f()
	intro3:activate()
	intro3:draweasy(0, 0, 0, intro_alpha)
	
	intro_alpha = intro_alpha + amodifier
	
	if intro_alpha >= 600 then
	amodifier = -3
	end
	
	if intro_alpha <= 1 then
	intro3 = nil
	intro_alpha = nil
	collectgarbage()
	collectgarbage()
	collectgarbage()
	whichfunction = 3
	end
end

function menu()
	if alpha <= 255 then
	alpha = alpha + 5
	end
	
	if whichmenupic == 1 then
	menu_startpic:activate()
	menu_startpic:draw(x_middle, y_middle, hud_zoom_x, hud_zoom_y, 0, 0, 480, 272, 0, alpha)
	
	if hud_zoom_x < 480 then
	hud_zoom_x = hud_zoom_x + 20
	x_middle = x_middle - 10
	end
	
	if hud_zoom_x > 480 then
	hud_zoom_x = 480
	x_middle = 0
	end
	
	if hud_zoom_y < 270 then
	hud_zoom_y = hud_zoom_y + 10
	y_middle = y_middle - 5
	end
	
	if hud_zoom_y == 270 then
	hud_zoom_y = 272
	y_middle = 0
	end
	
	if pge.controls.pressed(PGE_CTRL_CROSS) or pge.controls.pressed(PGE_CTRL_START) then
	loading:activate()
	loading:draweasy(0, 0)
	pge.gfx.swapbuffers()
	alpha = 1
	hud_zoom_x = 0
	hud_zoom_y = 0
	x_middle = 240
	y_middle = 136
	intro_alpha = 0
	amodifier = 3
	whichfunction = 1
	whichmenupic = 1
	menu_startpic = nil
	menu_helppic = nil
	menu_creditspic = nil
	helppic = nil
	creditspic = nil
	collectgarbage()
	collectgarbage()
	collectgarbage()
	avgn_intr1 = pge.texture.load("avgn_intr1.png")
	bugs1 = pge.texture.load("bugs1.png")
	bugs2 = pge.texture.load("bugs2.png")
	bugs3 = pge.texture.load("bugs3.png")
	bugs4 = pge.texture.load("bugs4.png")
	bugs5 = pge.texture.load("bugs5.png")
	bugs6 = pge.texture.load("bugs6.png")
	bugs7 = pge.texture.load("bugs7.png")
	drag = pge.texture.load("drag.png")
	rambo = pge.texture.load("rambo.png")
	sega = pge.texture.load("sega.png")
	whichfunction = 4
	end
	
	elseif whichmenupic == 2 then
	menu_helppic:activate()
	menu_helppic:draweasy(0, 0, 0, alpha)
	
	if pge.controls.pressed(PGE_CTRL_CROSS) or pge.controls.pressed(PGE_CTRL_START) then
	alpha = 0
	whichmenupic = 10
	end
	
	elseif whichmenupic == 3 then
	menu_creditspic:activate()
	menu_creditspic:draweasy(0, 0, 0, alpha)
	
	if pge.controls.pressed(PGE_CTRL_CROSS) or pge.controls.pressed(PGE_CTRL_START) then
	alpha = 0
	whichmenupic = 11
	end
	
	elseif whichmenupic == 10 then
	helppic:activate()
	helppic:draweasy(0, 0, 0, alpha)
	
	if pge.controls.pressed(PGE_CTRL_CIRCLE) or pge.controls.pressed(PGE_CTRL_START) then
	alpha = 0
	whichmenupic = 2
	end
	
	if pge.controls.pressed(PGE_CTRL_DOWN) then
	elseif pge.controls.pressed(PGE_CTRL_UP) then
	end
	
	elseif whichmenupic == 11 then
	creditspic:activate()
	creditspic:draweasy(0, 0, 0, alpha)
	
	if pge.controls.pressed(PGE_CTRL_CIRCLE) or pge.controls.pressed(PGE_CTRL_START) then
	alpha = 0
	whichmenupic = 3
	end
	
	if pge.controls.pressed(PGE_CTRL_DOWN) then
	elseif pge.controls.pressed(PGE_CTRL_UP) then
	end
	
	end
	
	if pge.controls.pressed(PGE_CTRL_DOWN) then
		whichmenupic = whichmenupic + 1
		
		if whichmenupic == 4 then
		whichmenupic = 1
		end
	end
	
	if pge.controls.pressed(PGE_CTRL_UP) then
		whichmenupic = whichmenupic - 1
		
		if whichmenupic == 0 then
		whichmenupic = 3
		end
	end
end

function game()
	if alpha <= 255 then
	alpha = alpha + 15
	end
	
	playsound = playsound + 1
	
	if whichgamepic <= 0 then
	whichgamepic = 11
	elseif whichgamepic >= 12 then
	whichgamepic = 1
	end
	
	if whichgamepic == 1 then
	bugs1:activate()
	bugs1:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 2 then
	bugs2:activate()
	bugs2:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 3 then
	bugs3:activate()
	bugs3:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 4 then
	bugs4:activate()
	bugs4:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 5 then
	bugs5:activate()
	bugs5:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 6 then
	bugs6:activate()
	bugs6:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 7 then
	bugs7:activate()
	bugs7:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 8 then
	avgn_intr1:activate()
	avgn_intr1:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 9 then
	drag:activate()
	drag:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 10 then
	rambo:activate()
	rambo:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if whichgamepic == 11 then
	sega:activate()
	sega:draweasy(0, 0, 0, alpha)
	
		if pge.controls.pressed(PGE_CTRL_RTRIGGER) then
		whichgamepic = whichgamepic + 1
		elseif pge.controls.pressed(PGE_CTRL_LTRIGGER) then
		whichgamepic = whichgamepic - 1
		end
	end
	
	if pge.controls.pressed(PGE_CTRL_CROSS) and whichsound == whichgamepic then
	pge.mp3.stop()
	pge.mp3.play("ans_right.mp3")
	pge.mp3.loop(false)
	pge.delay(2000000)
	playsound = -10
	whichsound = pge.math.randint(-2, 15)
	elseif pge.controls.held(PGE_CTRL_CROSS) and whichsound ~= whichgamepic then
	pge.mp3.stop()
	pge.mp3.play("ans_wrong.mp3")
	pge.mp3.loop(false)
	pge.delay(2000000)
	playsound = -10
	end
	
	if whichsound < 1 or whichsound > 11 then
	whichsound = pge.math.randint(-2, 15)
	end
	
	if whichsound == 1 then
	
		if playsound == 1 then
		pge.mp3.play("bugsbunny1.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 2 then
	
		if playsound == 1 then
		pge.mp3.play("bugsbunny2.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 3 then
	
		if playsound == 1 then
		pge.mp3.play("bugsbunny3.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 4 then
	
		if playsound == 1 then
		pge.mp3.play("bugsbunny4.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 5 then
	
		if playsound == 1 then
		pge.mp3.play("bugsbunny5.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 6 then
	
		if playsound == 1 then
		pge.mp3.play("bugsbunny6.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 7 then
	
		if playsound == 1 then
		pge.mp3.play("bugsbunny7.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 8 then
	
		if playsound == 1 then
		pge.mp3.play("avgn_intro.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 9 then
	
		if playsound == 9 then
		pge.mp3.play("dragon1.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 10 then
	
		if playsound == 1 then
		pge.mp3.play("rambo1.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if whichsound == 11 then
	
		if playsound == 1 then
		pge.mp3.play("segacd1.mp3")
		pge.mp3.loop(true)
		end
	end
	
	if pge.controls.pressed(PGE_CTRL_START) then
	loading:activate()
	loading:draweasy(0, 0)
	pge.gfx.swapbuffers()
	pge.mp3.stop()
	avgn_intr1 = nil
	bugs1 = nil
	bugs2 = nil
	bugs3 = nil
	bugs4 = nil
	bugs5 = nil
	bugs6 = nil
	bugs7 = nil
	drag = nil
	rambo = nil
	sega = nil
	collectgarbage()
	collectgarbage()
	collectgarbage()
	menu_startpic = pge.texture.load("menu_start.png")
	menu_helppic = pge.texture.load("menu_help.png")
	menu_creditspic = pge.texture.load("menu_credits.png")
	helppic = pge.texture.load("help.png")
	creditspic = pge.texture.load("credits.png")
	playsound = -10
	whichfunction = 3
	end
end
	
while pge.running() do
	pge.controls.update()
	pge.gfx.startdrawing()
	pge.gfx.clearscreen()
	
	if whichfunction == 0 then
	intro3f()
	elseif whichfunction == 1 then
	intro1f()
	elseif whichfunction == 2 then
	intro2f()
	elseif whichfunction == 3 then
	menu()
	elseif whichfunction == 4 then
	game()
	end
	
	pge.gfx.enddrawing()
	pge.gfx.swapbuffers()
end