Stop at 1000!!
By Light_AleX

VOTE THIS [1] for the QJ Summer Comp!!

COPY THE PSP FOLDER INTO: the root of your memory stick and replace everything.

Introduction
~~~~~~~~~~
This is an extremely simple game where you have to stop a racing counter at exactly 1000.
It is a simple concept but takes time to perfect. 


VOTE THIS [1] for the QJ Summer Comp!!

More Info
~~~~~~~~
This is basically a version two of the original called Count to 1000!!

So what's new??
- Two modes, one is only accessible with a button combo.
- New Graphics
- Distracting audio!!  Haha.

VOTE THIS [1] for the QJ Summer Comp!!

How to play
~~~~~~~~~~

When you are at the menu:
Press '[ ]' (square) for instructions.

OR

Press 'O' (circle) to begin the counter. 	

OR 

Press the button combo for the new mode.

To stop the running counter, press 'O'.

That's it!!

VOTE THIS [1] for the QJ Summer Comp!!


For more FUN!!!
~~~~~~~~~~~~~
Plug it onto the TV if you have a slim and see if your friends or family can do it PRO like you!!


I just had to put the voting all around...

VOTE THIS [1] for the QJ Summer Comp!!

HAVE FUN!!  :)
-Light_AleX

P.S. Now it's time to do something...

