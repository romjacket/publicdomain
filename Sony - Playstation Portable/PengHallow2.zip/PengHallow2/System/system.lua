-- Created By CoderX, Team Matrix
-- GENERAL PUBLIC LICENSE V0.2

function Varables()
-- Sets Up Colors
black = Color.new(0,0,0)
white = Color.new(255,255,255)
bugX = -20
swaper = 0
-- BackGround Images


CrtirBack = Image.load("Images/Crit/BackGround.jpg")
CrtirMain = Image.load("Images/Crit/Crit1.jpg")
Crtir1 = Image.load("Images/Crit/Crit1.jpg")
Crtir2 = Image.load("Images/Crit/Crit2.jpg")
Crtir3 = Image.load("Images/Crit/Crit3.jpg")
Crtir4 = Image.load("Images/Crit/Crit4.jpg")
Crtir5 = Image.load("Images/Crit/Crit5.jpg")
Crtir6 = Image.load("Images/Crit/Crit6.jpg")

MainMenuBackground = Image.load("Images/BackGround1.jpg")
SubMenuBackground = Image.load("Images/Background2.jpg")
Level1Background = Image.load("Images/Background3.png")
Level2Background = Level1Background
Level3Background = Image.load("Images/Background4.jpg")
Level4Background = Image.load("Images/Background5.jpg")
GameOverBackground = Image.load("Images/BackGround6.jpg")

-- Loads Penguins
PenguinOne = Image.load("Images/peng1.png")
heart = Image.load("Images/heart.png")

-- Loads Falling Objects
ObjectType1 = Image.load("Images/rock1.png")
ObjectType2 = Image.load("Images/rock2.png")
ObjectType3 = Image.load("Images/rock3.png")
ObjectType4 = Image.load("Images/rock4.png")
ObjectType5 = Image.load("Images/rock5.png")
ObjectType6 = Image.load("Images/tree1.png")


-- Menu Objects
MenuObj1 = Image.load("Images/Menu/MenuObj1.jpg")
MenuObj2 = Image.load("Images/Menu/MenuObj2.jpg")
MenuObj3 = Image.load("Images/Menu/MenuObj3.jpg")
MenuObj4 = Image.load("Images/Menu/MenuObj4.jpg")
Music.playFile("System/CoderX.it", false)
-- Starts Default Song


-- Decides if levels are to load
Rodent = 1
MainMenuActive = 0
SubMenuActive = 0
LevelOneActive = 0
LevelTwoActive = 0
LevelThreeActive = 0
LevelFourActive = 0
GameOver = 0

-- Loads Random Varables Needed by Menu Structures
Select = 1
Pause = 0
Score = {}
Score[1] = {Num=0, TenTime=0}
ScrolingBackground1 = 0
ScrolingBackground2 = -272

-- Peng Location
PengX = 150
PengY = 100

-- Sets Up the Rocks
Rock = {}
Rock = {}
Rock[1] = {X = -1, Y = -40}
Rock[2] = {X = -41, Y = -40}
Rock[3] = {X = -81, Y = -40}
Rock[4] = {X = -121, Y = -40}
Rock[5] = {X = -161, Y = -40}
Rock[6] = {X = -201, Y = -40}
Rock[7] = {X = -241 , Y = -40}
Rock[8] = {X = -281, Y = -40}
Rock[9] = {X = -321 , Y = -40}
Rock[10] = {X = -361 , Y = -40}
Rock[10] = {X = -401 , Y = -40}
Health = 150

end
Varables()
function PreGame()
if bugX == 500 then
	MainMenuActive = 1
	Rodent = 0
	Music.stop()
	Music.playFile("System/intro.it", true)
end

	if swaper > 10 then
	CrtirMain = Crtir1
	end
	if swaper > 20 then
	CrtirMain = Crtir2
	end
	if swaper > 30 then
	CrtirMain = Crtir3
	end
	if swaper > 40 then
	CrtirMain = Crtir4
	end
	if swaper > 50 then
	CrtirMain = Crtir5
	end
	if swaper > 60 then
	CrtirMain = Crtir6
	end
	if swaper > 70 then
	swaper = 0
	end
	swaper = swaper + 1
	bugX = bugX + 1
end
function SubMenu()
	screen:blit(0,0,SubMenuBackground)
	Health = 150
	if pad:up() and oldpad:up() ~= pad:up() then
		Select = Select - 1
	end
	if pad:down() and oldpad:down() ~= pad:down() then
		Select = Select + 1
	end
	if Select > 4 then
		Select = 1
	elseif Select <= 0 then
		Select = 4
	end
	if Select == 1 then
		screen:blit(223, 26,MenuObj1)
		-- file = io.open("System/Lev1HS.PSP", "r")
		-- hs = file:read("*n")
		-- file:close()
	end
	if Select == 2 then
		screen:blit(223, 72,MenuObj2)
		-- file = io.open("System/Lev2HS.PSP", "r")
		-- hs = file:read("*n")
		-- file:close()
	end
	if Select == 3 then
		screen:blit(223, 126,MenuObj3)
		-- file = io.open("System/Lev3HS.PSP", "r")
		-- hs = file:read("*n")
		-- file:close()
	end
	if Select == 4 then
		screen:blit(222, 178,MenuObj4)
		-- file = io.open("System/Lev4HS.PSP", "r")
		-- hs = file:read("*n")
		-- file:close()
	end
	if pad:square() and Select == 1 then
			Music.stop()
			-- Loads Code for Condition 1
			SubMenuActive = 0
			LevelOneActive = 1
			Music.playFile("System/Lev1/1.mod", true)
	end
			if pad:square() and Select == 2 then
			Music.stop()
			-- Loads Code for Condition 2
			SubMenuActive = 0
			LevelTwoActive = 1
			Music.playFile("System/Lev2/2.mod", true)
		end
		if pad:square() and Select == 3 then
			Music.stop()
			-- Loads Code for Condition 3
			SubMenuActive = 0
			LevelThreeActive = 1
			Music.playFile("System/Lev3/3.s3m", true)
		end
		if pad:square() and Select == 4 then
			Music.stop()
			-- Loads Code for Condition 4
			SubMenuActive = 0
			LevelFourActive = 1
			Music.playFile("System/Lev4/4.mod", true)
		end
		oldpad = pad
		screen:flip()
		screen.waitVblankStart()
end
function GameLev1()

	-- end game method
	game_over = false

	-- Pauses the Game
	if pad:start() then
		Music.stop()
		Pause = 1
	end
	-- Unpauses the Game
	if Pause == 1 then
		if pad:select() then
			Music.resume()
			Pause = 0
		end
	end

	if Pause == 0 then
		if PengY > 270 then
			LevelOneActive = 0
			GameOver = 1
			-- if Score > hs then
				-- file = io.open("System/Lev1HS.psp", "w+")
				-- file:write(Score)
				-- file:close()
				-- hs = Score
			-- end

		end

		if pad:left() then
			PengX = PengX - 5
			if PengX < 30 then
				PengX = 30
			end
		end
		
		if pad:right() then
			PengX = PengX + 5
			if PengX > 390 then
				PengX = 390
			end
		end

		if pad:up() then
			PengY = PengY - 0.8
			if PengY < 0 then
				PengY = 0
			end
		end

		if pad:down() then
			PengY = PengY + 6
			if PengY > 270 then
				Music.stop()
				LevelOneActive = 0
				GameOver = 1
			end
		end
		-- Control lavaBackground motion
		if ScrolingBackground1 >= 272 then
			ScrolingBackground1 = -272
		end
		
		if ScrolingBackground2 >= 272 then
			ScrolingBackground2 = -272
		end
		
		ScrolingBackground1 = ScrolingBackground1 + 4
		ScrolingBackground2 = ScrolingBackground2 + 4	

	--Randomize the Rocks the Rocks

		for i=1,7 do
			if Rock[i].X > 280 then
				Rock[i].Y = math.random(360)
				Rock[i].Y= Rock[i].Y  + 30
				Rock[i].X = -30
				for j=1,7 do
					if ( (i > j) or (i < j)) then
						if ( (Rock[i].X + ObjectType1:height() >= Rock[j].X) and (Rock[i].X <= Rock[j].X + ObjectType1:height()) ) then
							if ( (Rock[i].Y + ObjectType1:width() >= Rock[j].Y) and (Rock[i].Y <= Rock[j].Y + ObjectType1:width()) ) then 
					--	Rock[i].Y = math.random(360)
							end
						end
					end
				end
			end
		end

		--Moves Rocks
		for i=1,7 do
			Rock[i].X = Rock[i].X + 5
		end

		--Colision
		for i=1,7 do
				if PengY+PenguinOne:width()>Rock[i].X and PengX+PenguinOne:width()>Rock[i].Y and PengY<Rock[i].X+ObjectType1:width() and PengX<Rock[i].Y+PenguinOne:width() then
					PengY = PengY + 7
					Health = Health - 1
				end

		end

		--Print Screen
		screen:clear(white)
		screen:blit(0, 0, Level1Background)
		screen:blit(0, ScrolingBackground1, Level1Background)
		screen:blit(0, ScrolingBackground2, Level1Background)
		screen:blit(PengX, PengY, PenguinOne)

		for i=4,7 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType1)
		end
		for i=1,3 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType4)
		end
		screen:print(3, 10, "Score", black)
		screen:print(61, 10, Score[1].Num, black)
		if Health > 118 then
			screen:blit(450, 0, heart)
		end
		if Health > 88 then
			screen:blit(428, 0, heart)
		end
		if Health > 58 then
			screen:blit(406, 0, heart)
		end
		if Health > 28 then
			screen:blit(384, 0, heart)
		end
		screen.waitVblankStart()
		screen.flip()
		Score[1].TenTime = Score[1].TenTime + 1
		if Score[1].TenTime == 10 then
			Score[1].TenTime = 0
			Score[1].Num = Score[1].Num + 1
		end
	end
end
function GameLev2()

	-- end game method
	game_over = false

	-- Pauses the Game
	if pad:start() then
		Music.pause()
		Pause = 1
	end
	-- Unpauses the Game
	if Pause == 1 then
		if pad:select() then
			Music.resume()
			Pause = 0
		end
	end

	if Pause == 0 then
		if PengY > 270 then
			LevelTwoActive = 0
			GameOver = 1
			-- if Score > hs then
				-- file = io.open("System/Lev2HS.psp", "w+")
				-- file:write(Score)
				-- file:close()
				-- hs = Score
			-- end
		end

		if pad:left() then
			PengX = PengX - 5
			if PengX < 30 then
				PengX = 30
			end
		end
		
		if pad:right() then
			PengX = PengX + 5
			if PengX > 390 then
				PengX = 390
			end
		end

		if pad:up() then
			PengY = PengY - 0.8
			if PengY < 0 then
				PengY = 0
			end
		end

		if pad:down() then
			PengY = PengY + 6
			if PengY > 270 then
				Music.stop()
				LevelTwoActive = 0
				GameOver = 1
			end
		end
		-- Control lavaBackground motion
		if ScrolingBackground1 >= 272 then
			ScrolingBackground1 = -272
		end
		
		if ScrolingBackground2 >= 272 then
			ScrolingBackground2 = -272
		end
		
		ScrolingBackground1 = ScrolingBackground1 + 6
		ScrolingBackground2 = ScrolingBackground2 + 6	

	--Randomize the Rocks the Rocks

		for i=1,8 do
			if Rock[i].X > 280 then
				Rock[i].Y = math.random(360)
				Rock[i].Y= Rock[i].Y  + 30
				Rock[i].X = -30
				for j=1,8 do
					if ( (i > j) or (i < j)) then
						if ( (Rock[i].X + ObjectType1:height() >= Rock[j].X) and (Rock[i].X <= Rock[j].X + ObjectType1:height()) ) then
							if ( (Rock[i].Y + ObjectType1:width() >= Rock[j].Y) and (Rock[i].Y <= Rock[j].Y + ObjectType1:width()) ) then 
					--	Rock[i].Y = math.random(360)
							end
						end
					end
				end
			end
		end

		--Moves Rocks
		for i=1,8 do
			Rock[i].X = Rock[i].X + 6
		end

		--Colision
		for i=1,8 do
				if PengY+PenguinOne:width()>Rock[i].X and PengX+PenguinOne:width()>Rock[i].Y and PengY<Rock[i].X+ObjectType1:width() and PengX<Rock[i].Y+PenguinOne:width() then
					PengY = PengY + 7
					Health = Health - 1
				end

		end

		--Print Screen
		screen:clear(white)
		screen:blit(0, 0, Level2Background)
		screen:blit(0, ScrolingBackground1, Level2Background)
		screen:blit(0, ScrolingBackground2, Level2Background)
		screen:blit(PengX, PengY, PenguinOne)
		for i=8,9 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType1)
		end
		for i=4,7 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType4)
		end
		for i=1,3 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType6)
		end
		screen:print(3, 10, "Score", black)
		screen:print(61, 10, Score[1].Num, black)
		if Health > 158 then
			screen:blit(450, 0, heart)
		end
		if Health > 118 then
			screen:blit(428, 0, heart)
		end
		if Health > 78 then
			screen:blit(406, 0, heart)
		end
		if Health > 38 then
			screen:blit(384, 0, heart)
		end
		screen.waitVblankStart()
		screen.flip()
		Score[1].TenTime = Score[1].TenTime + 1
		if Score[1].TenTime == 10 then
			Score[1].TenTime = 0
			Score[1].Num = Score[1].Num + 1
		end
	end
end
function GameLev3()

	-- end game method
	game_over = false

	-- Pauses the Game
	if pad:start() then
		Music.pause()
		Pause = 1
	end
	-- Unpauses the Game
	if Pause == 1 then
		if pad:select() then
			Music.resume()
			Pause = 0
		end
	end

	if Pause == 0 then
		if PengY > 270 then
			LevelThreeActive = 0
			GameOver = 1
			-- if Score > hs then
				-- file = io.open("System/Lev3HS.psp", "w+")
				-- file:write(Score)
				-- file:close()
				-- hs = Score
			-- end
		end

		if pad:left() then
			PengX = PengX - 5
			if PengX < 30 then
				PengX = 30
			end
		end
		
		if pad:right() then
			PengX = PengX + 5
			if PengX > 390 then
				PengX = 390
			end
		end

		if pad:up() then
			PengY = PengY - 0.8
			if PengY < 0 then
				PengY = 0
			end
		end

		if pad:down() then
			PengY = PengY + 6
			if PengY > 270 then
				Music.stop()
				LevelThreeActive = 0
				GameOver = 1
			end
		end
		-- Control lavaBackground motion
		if ScrolingBackground1 >= 272 then
			ScrolingBackground1 = -272
		end
		
		if ScrolingBackground2 >= 272 then
			ScrolingBackground2 = -272
		end
		
		ScrolingBackground1 = ScrolingBackground1 + 7
		ScrolingBackground2 = ScrolingBackground2 + 7	

	--Randomize the Rocks the Rocks

		for i=1,8 do
			if Rock[i].X > 280 then
				Rock[i].Y = math.random(360)
				Rock[i].Y= Rock[i].Y  + 30
				Rock[i].X = -30
				for j=1,5 do
					if ( (i > j) or (i < j)) then
						if ( (Rock[i].X + ObjectType1:height() >= Rock[j].X) and (Rock[i].X <= Rock[j].X + ObjectType1:height()) ) then
							if ( (Rock[i].Y + ObjectType1:width() >= Rock[j].Y) and (Rock[i].Y <= Rock[j].Y + ObjectType1:width()) ) then 
					--	Rock[i].Y = math.random(360)
							end
						end
					end
				end
			end
		end

		--Moves Rocks
		for i=1,8 do
			Rock[i].X = Rock[i].X + 7
		end

		--Colision
		for i=1,8 do
				if PengY+PenguinOne:width()>Rock[i].X and PengX+PenguinOne:width()>Rock[i].Y and PengY<Rock[i].X+ObjectType1:width() and PengX<Rock[i].Y+PenguinOne:width() then
					PengY = PengY + 6
					Health = Health - 1
				end

		end

		--Print Screen
		screen:clear(white)
		screen:blit(0, 0, Level3Background)
		screen:blit(0, ScrolingBackground1, Level3Background)
		screen:blit(0, ScrolingBackground2, Level3Background)
		screen:blit(PengX, PengY, PenguinOne)
		for i=8,9 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType1)
		end
		for i=4,7 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType4)
		end
		for i=1,3 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType6)
		end
		screen:print(3, 10, "Score", black)
		screen:print(61, 10, Score[1].Num, black)
		if Health > 158 then
			screen:blit(450, 0, heart)
		end
		if Health > 118 then
			screen:blit(428, 0, heart)
		end
		if Health > 78 then
			screen:blit(406, 0, heart)
		end
		if Health > 38 then
			screen:blit(384, 0, heart)
		end

		screen.waitVblankStart()
		screen.flip()
		Score[1].TenTime = Score[1].TenTime + 1
		if Score[1].TenTime == 10 then
			Score[1].TenTime = 0
			Score[1].Num = Score[1].Num + 1
		end
	end
end
function GameLev4()


	-- end game method
	game_over = false

	-- Pauses the Game
	if pad:start() then
		Music.pause()
		Pause = 1
	end
	-- Unpauses the Game
	if Pause == 1 then
		if pad:select() then
			Music.resume()
			Pause = 0
		end
	end

	if Pause == 0 then
		if PengY > 270 then
			LevelFourActive = 0
			GameOver = 1
			-- if Score > hs then
				-- file = io.open("System/Lev4HS.psp", "w+")
				-- file:write(Score)
				-- file:close()
				-- hs = Score
			-- end
		end

		if pad:left() then
			PengX = PengX - 5
			if PengX < 30 then
				PengX = 30
			end
		end
		
		if pad:right() then
			PengX = PengX + 5
			if PengX > 390 then
				PengX = 390
			end
		end

		if pad:up() then
			PengY = PengY - 0.8
			if PengY < 0 then
				PengY = 0
			end
		end

		if pad:down() then
			PengY = PengY + 6
			if PengY > 270 then
				Music.stop()
				LevelFourActive = 0
				GameOver = 1
			end
		end
		-- Control lavaBackground motion
		if ScrolingBackground1 >= 272 then
			ScrolingBackground1 = -272
		end
		
		if ScrolingBackground2 >= 272 then
			ScrolingBackground2 = -272
		end
		
		ScrolingBackground1 = ScrolingBackground1 + 8
		ScrolingBackground2 = ScrolingBackground2 + 8	

	--Randomize the Rocks the Rocks

		for i=1,9 do
			if Rock[i].X > 280 then
				Rock[i].Y = math.random(360)
				Rock[i].Y= Rock[i].Y  + 30
				Rock[i].X = -30
				for j=1,9 do
					if ( (i > j) or (i < j)) then
						if ( (Rock[i].X + ObjectType1:height() >= Rock[j].X) and (Rock[i].X <= Rock[j].X + ObjectType1:height()) ) then
							if ( (Rock[i].Y + ObjectType1:width() >= Rock[j].Y) and (Rock[i].Y <= Rock[j].Y + ObjectType1:width()) ) then 
					--	Rock[i].Y = math.random(360)
							end
						end
					end
				end
			end
		end

		--Moves Rocks
		for i=1,9 do
			Rock[i].X = Rock[i].X + 7
		end

		--Colision
		for i=1,9 do
				if PengY+PenguinOne:width()>Rock[i].X and PengX+PenguinOne:width()>Rock[i].Y and PengY<Rock[i].X+ObjectType1:width() and PengX<Rock[i].Y+PenguinOne:width() then
					PengY = PengY + 7
					Health = Health - 1
				end

		end

		--Print Screen
		screen:clear(white)
		screen:blit(0, 0, Level4Background)
		screen:blit(0, ScrolingBackground1, Level4Background)
		screen:blit(0, ScrolingBackground2, Level4Background)
		screen:blit(PengX, PengY, PenguinOne)
		for i=8,9 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType5)
		end
		for i=4,7 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType2)
		end
		for i=1,3 do
			screen:blit(Rock[i].Y, Rock[i].X, ObjectType3)
		end
		screen:print(3, 10, "Score", black)
		screen:print(61, 10, Score[1].Num, black)
		if Health > 158 then
			screen:blit(450, 0, heart)
		end
		if Health > 118 then
			screen:blit(428, 0, heart)
		end
		if Health > 78 then
			screen:blit(406, 0, heart)
		end
		if Health > 38 then
			screen:blit(384, 0, heart)
		end
		screen.waitVblankStart()
		screen.flip()
		Score[1].TenTime = Score[1].TenTime + 1
		if Score[1].TenTime == 10 then
			Score[1].TenTime = 0
			Score[1].Num = Score[1].Num + 1
		end
	end
end
function GameNowOver()
	Music.stop()
	if pad:cross() then
		MainMenuActive = 0
		SubMenuActive = 1
		LevelOneActive = 0
		LevelTwoActive = 0
		LevelThreeActive = 0
		LevelFourActive = 0
		Select = 1
		Pause = 0
		ScrolingBackground1 = 0
		ScrolingBackground2 = -272

		-- Peng Location
		PengX = 150
		PengY = 100

		Rock[1] = {X = -1, Y = -40}
		Rock[2] = {X = -41, Y = -40}
		Rock[3] = {X = -81, Y = -40}
		Rock[4] = {X = -121, Y = -40}
		Rock[5] = {X = -161, Y = -40}
		Rock[6] = {X = -201, Y = -40}
		Rock[7] = {X = -241 , Y = -40}
		Rock[8] = {X = -281, Y = -40}
		Rock[9] = {X = -321 , Y = -40}
		Rock[10] = {X = -361 , Y = -40}
				
		GameOver = 0
		Score[1] = {Num=0, TenTime=0}
		Music.playFile("System/intro.it", true)
	end
	
	screen:blit(0, 0, GameOverBackground, true)
	screen:print(380, 10, Score[1].Num, black)
	screen:print(120, 10, "Still Has Some Bugs!!!", black)
	screen.waitVblankStart(1)
	screen.flip()
	

end
while true do       
-- Loads The contols for the Game
	pad = Controls.read()

-- Loads the Main Menu
	
	if Rodent == 1 then
		PreGame()
		screen:clear(black)
		screen:blit(0,0, CrtirBack, true)
		screen:blit(bugX, 100, CrtirMain, true)
		screen.waitVblankStart(1)
		screen.flip()
	end

	if MainMenuActive == 1 then 
		if pad:cross() then
			MainMenuActive = 0
			SubMenuActive = 1

		end
		screen:blit(0, 0, MainMenuBackground, true)
		screen.waitVblankStart(1)
		screen.flip()
	end
	
	if SubMenuActive == 1 then 
			SubMenu()
	end

	if LevelOneActive == 1 then
		GameLev1()
	end
	if LevelTwoActive == 1 then
		GameLev2()
	end	
	if LevelThreeActive == 1 then
		GameLev3()
	end
	if LevelFourActive == 1 then
		GameLev4()
	end
	if Health < 0 then
		GameOver = 1
	end

	if GameOver == 1 then
		GameNowOver()
	end
	
end
