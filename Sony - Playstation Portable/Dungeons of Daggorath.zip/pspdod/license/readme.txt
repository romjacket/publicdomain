Daggorath PC-Port
Version 0.3
By Richard Hunerlach
November 14, 2002

==========

The copyright for Dungeons of Daggorath is still held by the original author, Douglas J. Morgan.
(c) 1982, DynaMicro

==========

This product makes extensive use of the Simple DirectMedia Layer library, which is licensed under the GNU LGPL.  It also uses the SDL_Mixer library, which likewise is licensed under the GNU LGPL.

You can find the GNU LGPL licence in the file LICENSE.txt in this directory.

The GNU LGPL license applys to SDL and SDL_Mixer, not to the Daggorath PC-Port Project.  It's included here to comply with the license's terms for usage of these two libraries.

You can download a zipped copy of the SDL and SDL_Mixer source code from the same place you downloaded this project:

http://mspencer.net/daggorath/builds/

Rick Hunerlach
November 14, 2002
