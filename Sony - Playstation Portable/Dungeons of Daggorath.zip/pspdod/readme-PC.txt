Daggorath PC-Port
Version 0.3
By Richard Hunerlach
May 16, 2003

Other contributors:
Dan Gendreau: Graphics, sound, and cheat enhancements
Tim Lindner: WAV files
Michael Spencer: Discussion Forum Host
Louis Jordan: Inspirer of the 'Adventure Survivors'
Sputnik: Additional enhancements & bug fixes

==========

The copyright for Dungeons of Daggorath is still held by the original author, Douglas J. Morgan.
(c) 1982, DynaMicro

==========

Change on 5/3/06 by Sputnik:

 - Fixed chance of hitting creatures and getting hit by creatures.  Chances of both were much higher in the PC port than in the original game.  Chances should now be identical.
==========

Changes on 5/2/06 by Sputnik:

 - Fixed bugs related to random mazes:
    - Saved games didn't load correctly.  Ladders would move, and mazes would not always be the same as when saved.  Fixed.
    - Ladders and holes on original would not always be correct.  Fixed.
 - Slightly modified the way doors and secret doors were draw on map with MARKDOORSONMAPS option to look a bit nicer.

==========

Changes on 4/28/06 by Sputnik:

SETOP MARKDOORSONMAPS TRUE
Displays regular and magic/secret doors when the scrolls are used to display the maze.  This option starts working immediately after you set it, and stops immediately if set to false.  It does not require a game restart.  Can also be changed in the ini:

MarkDoorsOnScrollMaps = 1

I had seen the configuration menu in the code, but didn't figure out how to use it until today, when I accidently hit the right arrow key on my keyboard while in the menu ESC brings up.  There was a configuration option for Random Maze already there, but there wasn't an option to turn it on of course.  I modified the menu to allow you to turn the option on or off from it.  Turning it on from the menu will not save it in the ini file unless you select the option to save the options from the menu.

==========

Changes on 4/27/06 by Sputnik:

Several new commands and enhancements have been added.  All the options below can be set to TRUE or FALSE either using the SETOPT command in the game, or by modifying the opts.ini file in the "conf" subdirectory.  Using SETOPT will now automatically save all options in the ini file.  The new in-game commands are as follows:

SETOPT SHIELDFIX TRUE
This fixes the apparent bug in the original game that makes leather and bronze shields give magical protection instead of physical.  With the fix on, leather and bronze shields will instead offer physical protection but no magical protection.  Because most of the monsters that are around when these shields become available deal physical damage, it makes them useful.  This was probably the intent in the original version of the game.  The SHIELDFIX and SND options need at least 2 letters to distinguish between them.  This option won't take affect until a new game is started after it is set.

SETOPT RANDOMMAZE TRUE
This change will generate a new completely random maze for each of the 5 levels each game!  You will also appear in a random place when you start, as will the monsters.  This option won't take affect until a new game is started after it is set.

One thing that always bothered me about the original game was that there was no hole in the ceiling of level 1 where you must have crawled into the dungeon.  When you start a game with the random maze option, you will now notice the hole in the ceiling where you start.  Sorry, no ladder back up to the surface ;-)  Not yet anyway...

In order to insure the hole to the next level aligns with a room on the lower level, and not in the middle of a wall, there will only be 1 hole down to each level (except level 3 of course) when this option is enabled.  It will always have a ladder to climb back up as well.  Because it might be hard to find the 1 hole in 500 rooms in a new random maze with only your pine torch to guide you, you might want to consider enabling the next new option with this one, though it is not required.

SETOPT VISIONSCROLL TRUE
This replaces one of the snakes on level 1 with a 3rd blob, who holds a vision scroll.  This is particularly useful if you use the random maze option above, as there will only be one hole down to the next level (instead of 4 in the original mazes).  This way, you can either find your way down by stumbling across the hole, or by getting the scroll from the extra blob.  This option also makes it easier to reveal the scroll, or you wouldn't be able to use it until level 2 anyway.  It will be slightly harder to reveal than an iron sword, so you will be able to use it if you kill most of the monsters on the first level.  This change will allow you to get slightly more power than you could in the original game, but shouldn't affect the balance much at all.  This option won't take affect until a new game is started after it is set.

SETOPT CRINSTAREGEN TRUE
This option (creatures insta-regen) will make it so that creatures will regen as soon as they die, instead of every 5 minutes after they die like the original.  This will only have an effect if you climb back up a ladder.  Instead of there being a few random monsters when you climb up, there should be all 24 (or however many you killed after setting the option).  Climbing back down after going up will repopulate dead monsters on the lower level as well.  As with the original, the monsters will be random.  The SETCHEAT CRTSCALE cheat will still work with this option as well.  This option starts working immediately after you set it, and stops immediately if set to false.  It does not require a game restart.

SETOPT CRIGNOREOBJECTS TRUE
This nasty little option (creatures ignore objects) is for those who want a challenge!  Instead of happily picking up objects while you beat on them, creatures will instead prioritize fighting back!  They will still pick up objects if you're not in the room with them (except the monsters that never pick any up), but they will not do so if you're in the room with them.  This option eliminates the biggest exploit we all know, love, and use to excess ;-)  This option starts working immediately after you set it, and stops immediately if set to false.  It does not require a game restart.

All the above options save and reload with ZSAVE and ZLOAD, including the randomly generated mazes.  All old save games should still load up and run correctly.  Here are the equivalent ini settings for those do-it-yourselfers:

RandomMaze=1
ShieldFix=1
VisionScroll=1
CreaturesIgnoreObjects=1
CreaturesInstaRegen=1

You can set them to 0 to make them false (the default).  Remember, the game will now automatically update the ini file when using SETOPT, so it will remember your settings.  If you change the settings manually in the ini file, you should probably close the program completely and restart it to make sure it reads them in.  I'm not sure if the RESTART command reads in the ini file.  Happy hunting!

==========

Several new commands have been added to control some recent enhancements added by Dan Gendreau. The new in-game commands are as follows:

The game graphics can be changed to one of the following 3 options:
SETOPT GFX NORMAL - sets the game to the original COCO resolution
SETOPT GFX HIRES  - sets the game graphics to dotted line vectors in 1024x768
SETOPT GFX VECTOR - renders the game graphics as gray-scale line vectors in 1024x768

The game sounds can be set to one of the following 2 modes:
SETOPT SND MONO   - mono sound effects
SETOPT SND STEREO - stereo sound effects

The following cheats are available:
SETCHEAT TORCH    - Infinite torch life
SETCHEAT RING     - Infinite ring charges
SETCHEAT CRTSCALE - Creature regens are scaled by the current dungeon level, so you won't ecounter Wraiths, for example, when returning to level 1.
SETCHEAT REVEAL   - the reveal command always succeeds
SETCHEAT ITEMS    - after you die, the next game will start with an iron sword, bronze shield, seer scroll and lunar torch.
SETCHEAT INVULNERABLE - you will not take damage from monsters or ABYE flasks.
SETCHEAT NONE     - turn off all active cheats

The above commands can also be abbreviated:
For example, SETOPT GFX VECTOR can also be typed as: SO G V
And SETCHEAT TORCH can be shortened to: SC T

You'll need to type at least two letters to distinguish between RING and REVEAL, and also between ITEMS and INVULNERABLE.

There is also a new command RESTART, which cannot be abbreviated, for safety reasons.  It will restart the game on the spot, keeping all the current graphics, sound, and cheat settings intact.  This will be especially useful for the ITEMS cheat, since it doesn't take effect until the next time the game restarts.

The game now starts in STEREO mode by default.

The graphics mode still defaults to the original CoCo low-res mode.  This will eventually be added to the configuration file or the application menu, if that ever gets built.

==========

The 'opts.txt' file in the 'conf' directory must include 3 integers [don't use floats].  The first is a percentage of creature speed (100 makes it the same as the 0.2 speed, 200 would double it, 50 would halve it, etc.  A very small number, like 10, will make the creatures move very fast, but their sounds will still slow them down.).  The second number is the frame rate in milliseconds for the turning animation (currently 20 in version 0.2), and the third is the delay in milliseconds for the player movement animation (crrently 25 in version 0.2).  The player movement is not really an animation.  It just takes a half step, then pauses, then goes the rest of the way (or back if there's a wall there).  The the delay is basically the pause after the half step.

There is a fourth line in the 'opts.txt' file, which takes either a zero for QWERTY keyboards, or one for Dvorak.  It is set to zero (QWERTY) by default.

==========

Games are saved in the 'saved' subdirectory.  There is a default filename for saving and loading, so that ZSAVE by itself will create a file called 'game.dod', and ZLOAD by itself will try to load that file.  If you want, however, you can specify your own filenames, but you can only use the uppercase letters A-Z, and only a single word.  So you might want to use LEVELA, since you can't use LEVEL1.

==========

Because this port uses SDL, the LGPL license text is in an 'sdl' subdirectory, along with a link to download the source if you want it.

==========

To run this program, double click on the 'dodwin.exe' file.  Be careful not to move either of the DLL files, or any of the WAV files (found in the 'sound' directory).  Saved games will be stored in the 'saved' directory, and will automatically be given the '.dod' extension.  Games saved with the previous version won't work with this version.

Everything in the game works except that the built-in game demo is not quite timed correctly.  Things are supposed to work just like the original, so if you find any discrepancies, please post them to the forum.  You can no longer climb up holes.  In previous versions I inadvertantly allowed this, but you never could in the orignal game.  After you kill the wizard, however, and before you incant the final ring, you can climb back up to the fourth level if you want.

The Escape key will exit the program.

The game initializes to an 1024 x 768 screen resolution.  The gutters (top, bottom, and sides) on the screen (if any show) are the same color as the background color of the level you are on.

Some unzipping programs have failed to properly create the subdirectories.  So if you have problems, like the sound doesn't work, make sure you have the three main subdirectories: conf (contains opts.txt), saved (contains game.dod), and sound (contains all the WAV files).

Please post comments, suggestions, and especially any problems, to the Developers forum at:

http://mspencer.net/forum/

Thanks in advance to everyone who uses and tests this version, and to everyone who has and will participate in the Daggorath discussions on the forum.

EXTREMELY SPECIAL THANKS to Dan Gendreau for doing these enhancements!!!

Credits:
Original Port and code maintainer:
	Rick Hunerlach

Graphics, sound and game cheat enhancements:
	Dan Gendreau

WAV files:
	Tim Lindner

May 16, 2003
