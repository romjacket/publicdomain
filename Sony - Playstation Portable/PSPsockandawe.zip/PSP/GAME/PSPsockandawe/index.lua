titre = Image.load("img/titre.jpg")
scorefond = Image.load("img/score.jpg")
fond = Image.load("img/fond.png")
bureau = Image.load("img/bureau.png")
bush = Image.load("img/bush.png")
bush_pos = { x = math.random(-30,260), y = 135 , h = 62, w = 90}
bush_paf = Image.load("img/bush_paf.png")
main = Image.load("img/main.png")
main_pos = { x = 207, y = 229 , h = 43, w = 54}
vitesseMain = 8

scoreaff = Image.load("img/score.png")
tempsaff = Image.load("img/temps.png")
chiffres = {Image.load("img/1.png"),Image.load("img/2.png"),Image.load("img/3.png"),Image.load("img/4.png"),Image.load("img/5.png"),Image.load("img/6.png"),Image.load("img/7.png"),Image.load("img/8.png"),Image.load("img/9.png"),Image.load("img/0.png")}
pointU = 10
pointD = 10
points = 0

page = 1
tempsjeu = 30

chauss = Image.load("img/chauss.png")
chauss_pos = { x = 98, y = 71 , h = 186, w = 180}

chaussMvt = {Image.load("img/chauss.png"),Image.load("img/chauss2.png"),Image.load("img/chauss3.png"),Image.load("img/chauss4.png"),Image.load("img/chauss5.png"),Image.load("img/chauss6.png"),Image.load("img/chauss7.png")}
chaussVit = 70

shoot = false

oldpad = Controls.read()
timerShoot = Timer.new()
timerBush = Timer.new()
chrono = Timer.new()

touchebush = false
marquepoint = false

rouge = Color.new(255,0,0)
vert = Color.new(0,255,0)
blanc = Color.new(255,255,255)

function padMenu()
	pad = Controls.read()
	if pad:start() and oldpad ~= pad then
		page = 2
		pointU = 10
		pointD = 10
		points = 0
		touchebush = false
		bush_pos.x = math.random(-30,260)
		timerBush:reset(0)
		timerBush:start()
		chrono:reset(0)
		chrono:start()
	end
	if pad:select() and oldpad ~= pad then
		System.Quit()
	end
	
	oldpad = pad
	
end

function padJeu()
	pad = Controls.read()
	
	if pad:left() or pad:analogX() < -40 then
		if shoot == false then
			if main_pos.x > 0 then
			main_pos.x = main_pos.x - vitesseMain
			chauss_pos.x = chauss_pos.x - vitesseMain
			end
		end
	end
	
	if pad:right() or pad:analogX() > 40 then
		if shoot == false then
			if main_pos.x < 425 then
			main_pos.x = main_pos.x + vitesseMain
			chauss_pos.x = chauss_pos.x + vitesseMain
			end
		end
	end
	
	if pad:cross() and oldpad ~= pad and timerShoot:time() > chaussVit*8 then
		shoot = true
		timerShoot:reset(0)
		timerShoot:start()
	end

	
	oldpad = pad
end

function bushTouch()
	if main_pos.x >= bush_pos.x + 124 and main_pos.x <= bush_pos.x + 169 and bush_pos.y < 85 then
		touchebush = true

		if pointU == 10 then
			pointU = 1
		else
			if pointU < 10 then
			pointU = pointU + 1
				if pointU == 10 then
					if pointD == 10 then
					pointD = 1
					else
					pointD = pointD + 1
					end
				end
			end
		end
		
		points = points + 1
	end
end

function mouvementBush()
	temps = timerBush:time()
	laps = 50
	debutfin = 30
	attente = 10
	if temps <= laps then
		bush_pos.y = 125
	end
	if temps <= laps*2 and temps > laps then
		bush_pos.y = 115
	end
	if temps <= laps*3 and temps > laps*2 then
		bush_pos.y = 105
	end
	if temps <= laps*4 and temps > laps*3 then
		bush_pos.y = 95
	end
	if temps <= laps*5 and temps > laps*4 then
		bush_pos.y = 85
	end
	if temps <= laps*8 and temps > laps*5 then
		bush_pos.y = 75
	end
	if temps > laps*debutfin then
		bush_pos.y = 85
	end
	if temps > laps*(debutfin+1) then
		bush_pos.y = 95
	end
	if temps > laps*(debutfin+2) then
		bush_pos.y = 105
	end
	if temps > laps*(debutfin+3) then
		bush_pos.y = 115
	end
	if temps > laps*(debutfin+4) then
		bush_pos.y = 125
	end
	if temps > laps*(debutfin+5) then
		bush_pos.y = 135
	end
	if temps > laps*(debutfin+attente) then
		
		touchebush = false
		timerBush:reset(0)
		timerBush:start()
		bush_pos.x = math.random(-30,260)
	end
end


-- BOUCLE PRINCIPALE
while true do
	
	screen:clear()
	
	if page == 1 then
		padMenu()
		screen:blit(0,0,titre)
	end
	
	if page == 2 then
	
		padJeu()
		mouvementBush()
		screen:blit(0,0,fond)
		
		if touchebush then
			screen:blit(bush_pos.x,bush_pos.y,bush_paf)
		else
		screen:blit(bush_pos.x,bush_pos.y,bush)
		end
		
		screen:blit(0,0,bureau)
		
		if shoot then
			afficheTemps = timerShoot:time()
			
			if afficheTemps <= chaussVit then
			screen:blit(chauss_pos.x,chauss_pos.y,chaussMvt[1])
			screen:blit(main_pos.x,main_pos.y+10,main)
			end	
			
			if afficheTemps <= chaussVit*2 and afficheTemps >= chaussVit then
			screen:blit(chauss_pos.x,chauss_pos.y,chaussMvt[2])
			screen:blit(main_pos.x,main_pos.y+20,main)
			end
			
			if afficheTemps <= chaussVit*3 and afficheTemps >= chaussVit*2 then
			screen:blit(chauss_pos.x,chauss_pos.y,chaussMvt[3])
			end
			
			if afficheTemps <= chaussVit*4 and afficheTemps >= chaussVit*3 then
			screen:blit(chauss_pos.x,chauss_pos.y,chaussMvt[4])
			end
			
			if afficheTemps <= chaussVit*5 and afficheTemps >= chaussVit*4 then
			screen:blit(chauss_pos.x,chauss_pos.y,chaussMvt[5])
			end
			if afficheTemps <= chaussVit*6 and afficheTemps >= chaussVit*5 then
			screen:blit(chauss_pos.x,chauss_pos.y,chaussMvt[6])
			end
			if afficheTemps <= chaussVit*7 and afficheTemps >= chaussVit*6 then
			screen:blit(chauss_pos.x,chauss_pos.y,chaussMvt[7])
				if touchebush == false then
				bushTouch()
				end
			end
			if afficheTemps >= chaussVit*8 then
				shoot = false
			end
		else
		screen:blit(chauss_pos.x,chauss_pos.y,chauss)
		screen:blit(main_pos.x,main_pos.y,main)
		end
		
		
		tempscourant = math.floor(chrono:time()/1000)
		if tempscourant<10 then
		tempscourant = "0"..tempscourant
		end
		
		if math.floor(chrono:time()/1000) > tempsjeu then
			page = 3
		end
		
		screen:blit(2,2,tempsaff)
		tempscourant = math.floor(chrono:time()/1000)
		if tempscourant < 10 then
		screen:blit(75,5,chiffres[10])
			if tempscourant > 0 then
			screen:blit(88,5,chiffres[tempscourant])
			else
			screen:blit(88,5,chiffres[10])
			end
		end
		
		if tempscourant < 20 and tempscourant >= 10 then
		screen:blit(75,5,chiffres[1])
			if tempscourant-10 > 0 then
			screen:blit(88,5,chiffres[tempscourant-10])
			else
			screen:blit(88,5,chiffres[10])
			end
		end
		if tempscourant < 30 and tempscourant >= 20 then
		screen:blit(75,5,chiffres[2])
			if tempscourant-20 > 0 then
			screen:blit(88,5,chiffres[tempscourant-20])
			else
			screen:blit(88,5,chiffres[10])
			end
		end

		if tempscourant < 40 and tempscourant >= 30 then
		screen:blit(75,5,chiffres[3])
			if tempscourant-30 > 0 then
			screen:blit(88,5,chiffres[tempscourant-30])
			else
			screen:blit(88,5,chiffres[10])
			end
		end
		
		
		
		screen:blit(373,2,scoreaff)
		screen:blit(450,5,chiffres[pointD])
		screen:blit(463,5,chiffres[pointU])
	
	end
	
	if page == 3 then
		padMenu()
		screen:blit(0,0,scorefond)
		screen:blit(184,178,scoreaff)
		screen:blit(261,181,chiffres[pointD])
		screen:blit(274,181,chiffres[pointU])
	end
	
	screen.flip()
	screen.waitVblankStart()
end 