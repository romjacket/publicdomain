I really wanted to play Laserix 2 again on my 5.00 M33 slim -- Its one
of my favorite homebrew games ever on the PSP. So I did a quick port
of Laserix 2 to PGE (Pheonix Game Engine) the past few days.  Since
the game was implemented originally in Lua, this was not too
difficult. It should run fine on all custom firmwares, greater than
3.xx phat or slim.  PGE is really a great game development platform.
I am very impressed with its performance.
-retrobits 10/24/2009

original readme from fafenstein:
[QUOTE]
Laserix is a flash game created by Jason Storhed, a video game
designer student. This game is just 100% fun and perfect transpose to
PSP !!!!. I have tried it once and became a big fan! After a couple of
days, and few broken PSPs, I finished the 13 levels. Oh no! What am I
gonna do !!! I contacted Jason, to ask for more, but he was busy with
his exams. So guess what, I decided to create my own levels.

Now you can play 52 levels (incuding the 13 orignals masterpiece) and
try to finsih the game. Good Luck and have a blast!!!

Laserix is a laser that should go through all diamonds on the grid.
The only way to do it, is to use mirrors, in the right position and
adjust them to define the right laser path. Laserix is a real "Chinese
puzzle". There is no need for 3D or video. The game is just fun!!!

Thanks again to Jason, who design the game and let me used the source
code to create new levels.

You can see jason site or find the 1st version in flash to play on pc

I would like to say a little thx to lumo and Shine for their sites,
and to Eliotstein and Regis for levels and test.
[/QUOTE]
