--[[
Beware, ugly code ahead!!!
Laserix, Copyright (c) 2005 Jason Storhed <wip3out1907@yahoo.com>
Please do not modify the game if you distribute it.
go sweden! ;)
]]








--map = 16x13
-- tile = 21x21
--tile size = 336x273
--array size = 208
--mirrortype2 default=67.5
System.usbDiskModeActivate()

-- FUNCTIONS



function loadMap(i)

diamondsLoaded=0
objectsLoaded=0

-- bla. i fixArray() VVVV
-- 11,12,13 ska ha sitt v�rde -1 
-- 10 ska ha 13
-- 0 ska bli 14  Allt ggr -1
-- >=0 �r f�r speglar
-- lvl 15 och 13 ska tas bort
--                   ^^^ 

  if i == 1 then
	loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
	cannonAngle=0
	mirrorsTypeA=2
	mirrorsTypeB=0
  end

  if i == 2 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=90
	mirrorsTypeA=2
	mirrorsTypeB=0
  end
  
  if i == 3 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,11,2,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,10,0,0,1,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=180
	mirrorsTypeA=3
	mirrorsTypeB=0
  end

if i == 4 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,1,0,0,0,1,0,0,0,0,0,0,0,0,0,2,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=270
	mirrorsTypeA=3
	mirrorsTypeB=0
  end

if i == 5 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,4,0,1,0,0,0,0,0,0,0,0,0,0,11,3,0,0,0,0,0,0,0,0,0,0,10,0,0,0,11,0,2,0,0,0,0,0,0,0,0}  

	cannonAngle=0
	mirrorsTypeA=2
	mirrorsTypeB=0
  end


if i == 6 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10}

	cannonAngle=90
	mirrorsTypeA=2
	mirrorsTypeB=0
  end
if i == 7 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,1,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,2,0,10,5,2,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,2,0,0,0,0,0,0,0,0,0,3,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,11,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=90
	mirrorsTypeA=5
 	mirrorsTypeB=0
  end
  
if i == 8 then
   loadedMap={0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,4,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,10,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=0
	mirrorsTypeA=5
 	mirrorsTypeB=0
  end 
 
if i == 9 then
   loadedMap={0,0,0,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,5,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,4,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,11,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=135
	mirrorsTypeA=4
 	mirrorsTypeB=1
  end  

if i == 10 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,5,0,2,2,2,2,0,2,2,2,0,0,0,10,0,0,1,0,1,0,0,1,4,5,0,0,0,0,0,0,0,0,5,0,2,2,2,2,0,2,2,2,0,0,0,0,0,3,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0}
	cannonAngle=0
	mirrorsTypeA=4
 	mirrorsTypeB=0
  end 

if i == 11 then
    loadedMap={0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,11,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,1,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,0}

	cannonAngle=90
	mirrorsTypeA=6
 	mirrorsTypeB=0
  end 
 
if i == 12 then
    loadedMap={0,0,2,11,1,10,0,0,0,0,0,1,11,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=315
	mirrorsTypeA=2
 	mirrorsTypeB=2
  end 



if i == 13 then
    loadedMap={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,0,0,0,0,6,1,1,1,6,0,0,0,0,10,11,3,0,0,0,7,0,0,0,0,0,9,0,0,0,3,3,3,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,8,1,1,1,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

	cannonAngle=0
	mirrorsTypeA=1
 	mirrorsTypeB=4
  end 
 
  
   
  
     
       

 fixArray()

end



function save()
	file = io.open("savefile.txt", "w")
	if file then
		file:write(level)
		file:close()
	end
end

function load()
	file = io.open("savefile.txt", "r")
	if file then
		loadedLevel = file:read("*n")
  		file:close()
	end
end



function newLevel()

  
    if level>loadedLevel then
        save()
        loadedLevel=level
    end
    



    levelCleared=false
	 for j=0, 12, 1 do       
   	   for i=0, 15, 1 do    
              diamondsArray[j][i]=0
   	   end
     end

hintImage:clear()
loadMap(level)
if level==9 then
showMsg(2)
end

laserColor1 = Color.new(255, 255, 255)
if level>=1 and level<=5 then
laserColor2 = Color.new(0, 24, 255)
end

if level>=6 and level<=10 then
laserColor2 = Color.new(255, 198, 0)
end

if level>=11 and level<=14 then
laserColor2 = Color.new(32, 168, 0)
end

if level==15 then
laserColor2 = Color.new(238, 69, 142)
end

    if cannonAngle==0 then
            xpos=laserStartX+1
            ypos=laserStartY
    end
    
    if cannonAngle==45 then
            xpos=laserStartX+1
            ypos=laserStartY-1
    end
    
    if cannonAngle==90 then
            xpos=laserStartX
            if level==11 then
            ypos=laserStartY-2
            else
            ypos=laserStartY-1
            end
    end
    
    if cannonAngle==135 then
            xpos=laserStartX-1
            ypos=laserStartY-1
    end

    if cannonAngle==180 then
            xpos=laserStartX-1
            ypos=laserStartY
    end
    
    if cannonAngle==225 then
            xpos=laserStartX-1
            ypos=laserStartY+1
    end
    
    if cannonAngle==270 then
            xpos=laserStartX
            ypos=laserStartY+1
    end
    
    if cannonAngle==315 then
            xpos=laserStartX+1
            ypos=laserStartY+1
    end
    

resetLaser()
updateStaticImage()


end




function fixArray()


local k=0

 for j=0, 12, 1 do 
  map[j]={}
   for i=0, 15, 1 do  
     map[j][i]=loadedMap[k+1]
       if map[j][i]==10 then
            map[j][i]=13
            laserStartX=i
            laserStartY=j
       else 
       if map[j][i]>=11 then
            map[j][i]=map[j][i]-1
       else 
       if map[j][i]==0 then
        map[j][i]=14
       end
       if map[j][i]==4 then
        warpX=i
        warpY=j
       end
          
	if map[j][i]==1 then
	      diamondsArray[j][i]=1
          diamondsLoaded=diamondsLoaded+1      
        end
      end
     end
     
                    if map[j][i]==10 then
                   hintImage:blit(drawStartX+i*21, j*21, objectImage, 189 , 0, 21, 21, true)
                end
     
     
     map[j][i]=map[j][i]*-1
     k=k+1
  end

 end

end



function showMsg(n)

 if n == 0 then
   msgImage:clear()
 end

 if n == 1 then
   msgImage:blit(130, 50, msg_1, 0, 0, 220, 100, true)
 end
 
 if n == 2 then
   msgImage:blit(130, 50, msg_2, 0, 0, 220, 100, true)
 end

message=n
  
end



function shoot()



    shootLoops=shootLoops+1
    if shootLoops<150 and stopLaser~= true then               --and map[xtmp][]
         if map[laserY][laserX]>=0 then
            sound_hit_mirror:play()
            laserAngle=(map[laserY][laserX]*2)-laserAngle
               if laserAngle>=360 then
		           	laserAngle=laserAngle-360
	           end
               if laserAngle<0 then
                    laserAngle=laserAngle+360
	           end

         end
       laserYOld=laserY
       laserXOld=laserX


         	if laserAngle==0 then
		 laserX=laserX+1
		end
         	if laserAngle==45 then
		 laserX=laserX+1
		 laserY=laserY-1
		end
         	if laserAngle==90 then
		 laserY=laserY-1
		end
         	if laserAngle==135 then
		 laserX=laserX-1
		 laserY=laserY-1
		end
         	if laserAngle==180 then
		 laserX=laserX-1
		end
         	if laserAngle==225 then
		 laserX=laserX-1
		 laserY=laserY+1
		end
         	if laserAngle==270 then
		 laserY=laserY+1
		end
         	if laserAngle==315 then
		 laserX=laserX+1
		 laserY=laserY+1
		end        
 


 
 
 
  	if laserX <0 or laserX > 15 or laserY < 0 or laserY > 12 then
   	      stopLaser=true
          laserX=laserXOld  --important!
          laserY=laserYOld
   end











    
      if  map[laserY][laserX]==-11 or map[laserY][laserX]==-2 then
            stopLaser=true
      end     
      
      if  laserAngle~=270 and map[laserY][laserX]==-9 then
            stopLaser=true
      end

      if  laserAngle~=180 and map[laserY][laserX]==-8 then
            stopLaser=true
      end
      
      if  laserAngle~=90 and map[laserY][laserX]==-7 then
            stopLaser=true
      end   
      
      if  laserAngle~=0 and map[laserY][laserX]==-6 then
            stopLaser=true
      end    
      
      
      
      if  map[laserY][laserX]==-5 then
             hitFlash=true
             flashX=laserX
             flashY=laserY
             keyDelay=100  --show animation, reset laser and set keyDelay to 0
             sound_elec:play()
      end  
  
  

       
        if diamondsArray[laserY][laserX]==1 then  --diamond
                diamondsArray[laserY][laserX]=2
                diamonds=diamonds+1        --then check if level is cleared
                sound_diamond:play()
                
           checkMoveBlock()     -- up & down block  Could be VERY slow.. optimize func if anything
              
                
	       if diamonds==diamondsLoaded then
	       levelCleared=true
           end
    	end
                                  




    
  end		--end if





  if stopLaser==true then --Very important
      laserX=laserXOld
      laserY=laserYOld
 end

 drawLaser()
 
       if map[laserY][laserX]==-3 then  --warp
        laserX=warpX
        laserY=warpY
        laserYOld=laserY
        laserXOld=laserX
       end 
	     	


end

function drawLaser()

local xtmp=drawStartX+laserXOld*21+10
local xtmp2=drawStartX+laserX*21+10
local ytmp=laserYOld*21+10
local ytmp2=laserY*21+10


if laserAngle==0 then
    if stopLaser==true then      
        xtmp2=xtmp2+11
    end
end
    
if laserAngle==180 then
    if stopLaser==true then
        xtmp2=xtmp2-10
    end    
end

if laserAngle ==90 then
    if stopLaser==true then
        ytmp2=ytmp2-10
    end        
end                         
       
if laserAngle ==270 then
   if stopLaser==true then
       ytmp2=ytmp2+11
   end    
end 
-- -------------

if laserAngle ==315 then
   if stopLaser==true then
       xtmp2=xtmp2+11  --11
       ytmp2=ytmp2+11  --11
   end    
end 

if laserAngle ==225 then
   if stopLaser==true then
       xtmp2=xtmp2-10
       ytmp2=ytmp2+11
   end    
end 

if laserAngle ==135 then
   if stopLaser==true then
       xtmp2=xtmp2-10
       ytmp2=ytmp2-10
   end   
end 

if laserAngle ==45 then
   if stopLaser==true then
       xtmp2=xtmp2+11
       ytmp2=ytmp2-10 
   end    
end 


    laserImage:drawLine(xtmp, ytmp, xtmp2, ytmp2, laserColor1) --middle. Always drawn

    if laserAngle == 0 or laserAngle == 180 then --outer
        laserImage:drawLine(xtmp, ytmp+1, xtmp2, ytmp2+1, laserColor2)
        laserImage:drawLine(xtmp, ytmp-1, xtmp2, ytmp2-1, laserColor2)
    else
        laserImage:drawLine(xtmp+1, ytmp, xtmp2+1, ytmp2, laserColor2)
        laserImage:drawLine(xtmp-1, ytmp, xtmp2-1, ytmp2, laserColor2)
    end




end


function checkMoveBlock()

    for j=0, 12, 1 do        
        for i=0, 15, 1 do    
                if map[j][i]==-11 then
                      map[j][i]=-12
                      moveBlockChanges=moveBlockChanges+1
                      draw()
                else
                if map[j][i]==-12 then
                      map[j][i]=-11
                      moveBlockChanges=moveBlockChanges+1
                      draw()
                end
                end  
        end
    end 

end


function resetLaser()
-- if laserOn then
	 for j=0, 12, 1 do       
   	   for i=0, 15, 1 do    
             if (diamondsArray[j][i]==2) then
               diamondsArray[j][i]=1
     		 end
   	   end
     end
    if diamonds > 0 then
        for i=0, moveBlockChanges, 1 do
           checkMoveBlock()
        end    
    end
    moveBlockChanges=0
    drawStartX=72
    staticX=0
    diamonds=0
    hitFlash=false
    fx_lighting_frame=0
    stopLaser=false
    levelCleared=false
    laserOn=false
 	laserX=laserStartX
 	laserY=laserStartY
    laserYOld=laserY
    laserXOld=laserX
	shootLoops=0
	laserAngle=cannonAngle
	laserImage:clear()
 --end

end


function update()
x0 = 0
y0 = 0
tmp = map[ypos][xpos]

    if levelCleared==false then    
	pad = Controls.read()
    end


                if hintTime>0 then
                hintTime=hintTime-1
                end



--MESSAGES AND MENUS --MUST be before the other keys
	if pad:cross() and keyDelay==0 then
	      if  message==1 then
	        hintTime=60
	        showMsg(0)
	        keyDelay=7
	      end
	      if  message==2 then
	        showMsg(0)
	        keyDelay=7
	      end
	      
	      
	      if menu==2 then --must be over menu 1
            if tmpLevel<= loadedLevel then
	          level=tmpLevel
	          keyDelay=10
	          menu=0
	          Music.volume( 15 )
              newLevel()
	        end                          --else play error sound
	      end
	      
	      if menu==1 then
            menu=2
	        showMenu()
	        keyDelay=10
	      end
	      
	      if menu==3 then
            menu=1
	        showMenu()
	        keyDelay=10
	      end
	      
	      if  message==3 then
	                  level=1
            newLevel() 
	        showMsg(0)
	        --menu=1
	        --showMenu()
	      end
	      
	      
    end
 
 if menu==2 then   
   	if pad:right() and tmpLevel<maxLevel and keyDelay==0 then   
        sound_menu_click:play() 
		tmpLevel=tmpLevel+1
		gotoMenuX=gotoMenuX-140
 		keyDelay=7  
    end

	if pad:left() and tmpLevel>1 and keyDelay==0 then
	    sound_menu_click:play()
		tmpLevel=tmpLevel-1
		gotoMenuX=gotoMenuX+140
		keyDelay=7
    end
 end
    
   	if pad:circle() and keyDelay==0 then
	      if message==1 then
            showMsg(0)
            keyDelay=7
	      end
    end  
--MESSAGES END






if message==0 then




  if xpos < 15 and keyDelay==0 then
	if pad:right() then  --make aim red if out of array     
              rightPress=true
              xpos=xpos+1
 			  keyDelay=5-acc
              acc=3 
	    else
          	if rightPress==true then       --release
			rightPress=false
            acc=0
                end      
	end
  end


  
  if xpos > 0 and keyDelay==0 then
	if pad:left() then  --make aim red if out of array     
              leftPress=true
              xpos=xpos-1
 			  keyDelay=5-acc
              acc=3 
	    else
          	if leftPress==true then       --release
			leftPress=false
            acc=0
                end      
	end
  end
  
  
  
  if ypos > 0 and keyDelay==0 then
	if pad:up() then  --make aim red if out of array     
              upPress=true
              ypos=ypos-1
 			  keyDelay=5-acc
              acc=3 
	    else
          	if upPress==true then       --release
			upPress=false
            acc=0
                end      
	end
  end  


  if ypos < 12 and keyDelay==0 then
	if pad:down() then  --make aim red if out of array     
              downPress=true
              ypos=ypos+1
 			  keyDelay=5-acc
              acc=3 
	    else
          	if downPress==true then       --release
			downPress=false
            acc=0
                end      
	end
  end  






	if pad:cross() and mirrorsTypeA>0 and keyDelay==0 then
	      if  tmp==-14 or tmp==-10 then 
			      mirrorsTypeA=mirrorsTypeA-1
			      map[ypos][xpos]=90
                  keyDelay=2
                  sound_place_mirror:play()
                  resetLaser()
          end
    end

	if pad:circle() and mirrorsTypeB>0 and keyDelay==0 then
	      if  tmp==-14 or tmp==-10 then 
			      mirrorsTypeB=mirrorsTypeB-1
			      map[ypos][xpos]=22.5
                  keyDelay=2
                  sound_place_mirror:play()
                  resetLaser()
          end
    end    


	if pad:l() and tmp >=0 and keyDelay==0 then   --activ xpos/ypos --TODO Turn every _release_
		tmp=tmp+45
			if tmp>= 360 then
				tmp = tmp -360		
			end
		map[ypos][xpos]=tmp
         keyDelay=4
         resetLaser()
    end


	if pad:r() and tmp >=0 and keyDelay==0 then   --activ xpos/ypos
		tmp=tmp-45
			if tmp < 0 then
				tmp = tmp +360		
			end
                 map[ypos][xpos]=tmp
		 keyDelay=4
		 resetLaser()
    end





	if pad:select() and menu== 0 and keyDelay==0 then
	   showMsg(1)
		 keyDelay=4
    end
    
   	if pad:start() then
   	    if menu==0  and keyDelay==0 then           
               if level>loadedLevel then
               save()
               end
	        menu=1	        
            keyDelay=10
        end   
        
   	    if menu==1  and keyDelay==0 then
	        menu=0
            keyDelay=10
        end   
        
   	    if menu==2  and keyDelay==0 then
	        menu=1
            keyDelay=10
        end   

    end



        


	if pad:square() then
	  	

          	 if mirrorSelected==false then
                            if tmp>=0 then		
				mirrorSelected=true 
				xposActiv=xpos
				yposActiv=ypos
      			    end
	   	   else
  			if tmp==-14 or tmp==-10 then 
  			    map[ypos][xpos]=map[yposActiv][xposActiv]
				map[yposActiv][xposActiv]=-14
				xposActiv=xpos
				yposActiv=ypos
				resetLaser()
				sound_move_mirror:play() 
            end
		 

		 end
         else
          
			mirrorSelected=false
   
        end 


	if pad:triangle() then        --maybe needs keyDelay>0, beacause when flash resets the laser
             trianglePress=true
	    else
          	if trianglePress==true then
			trianglePress=false
                     if laserOn==true then
			resetLaser()
                      else
                        laserOn=true
                     end
                end
      
	end
	

end







	if laserOn then
             shoot()
        end
     

    	if keyDelay>0 then
      		keyDelay=keyDelay-1
    	end






	

end


function drawAim()

 if map[ypos][xpos]==-14 or map[ypos][xpos]==-10 or map[ypos][xpos]>=0 then                       
	screen:blit(drawStartX+xpos*21, ypos*21, aim, 0 , 0, 21, 21, true)
 if mirrorSelected then
 	screen:blit(drawStartX+xposActiv*21, yposActiv*21, aim, 42 , 0, 21, 21, true)
 end 
    else
        screen:blit(drawStartX+xpos*21, ypos*21, aim, 21 , 0, 21, 21, true)
 end 

   
end

function printFont(x,y,number)
    
    if number >= 10 then
    number=number/10
    local decimal=(number-math.floor(number))*10
    number=math.floor(number)
    screen:blit(x, y, font, 11*number, 0, 11, 11, true)
    screen:blit(x+14, y, font, 11*decimal, 0, 11, 11, true)
    else
    screen:blit(x, y, font, 11*number, 0, 11, 11, true)  
    end

end


function showMenu()
       if menu==3 then
       screen:blit(0, 0, endscreen, 0, 0, 480, 272, true)   
       end

       if menu==1 then
       screen:blit(0, 0, menu_background, 0, 0, 480, 272, true) 
               
       end

       if menu==2 then
        screen:blit(0, 0, level_background, 0, 0, 480, 272, true) 
       
       if menuX>gotoMenuX then
        menuX=menuX-20
        end
        
        if menuX<gotoMenuX then
        menuX=menuX+20
        end
                
                for i=1, maxLevel, 1 do
                screen:blit(menuX+(i-1)*140, 35, menu_lvl[i], 0, 0, 120, 80, true)
                   if loadedLevel<i  and loadedLevel<maxLevel then
                      screen:blit(menuX+40+(i-1)*140, 40, lock, 0, 0, 40, 65, true)
                   end
                end
                
      
                
        
      

       end
end





function updateStaticImage()

	staticImage:blit(0, 0, gui, 0, 0, 480, 272, true) 
	staticImage:blit(drawStartX, 0, background, 0, 0, 336, 273, true) 
   
        for j=0, 12, 1 do
             for i=0, 15, 1 do
                if map[j][i]~=-14 and map[j][i]~=-11 and map[j][i]~=-12 and map[j][i]~=-10 then
                    if map[j][i]==-13 then
                      staticImage:blit(drawStartX+i*21, j*21, cannon, cannonAngle*21/45  , 0, 21, 21, true) 
                    else
                      staticImage:blit(drawStartX+i*21, j*21, objectImage, ((map[j][i]*-1)-1)*21 , 0, 21, 21, true) 
                    end
                end
	     end
        end

end

function draw() --also center the image 
 if menu==0 then
    if levelCleared==true then  --fulkod
    staticX=staticX-5
    end    

        
    if staticX < -120 then
        if level<maxLevel then
         Music.volume( 80 )
         level=level+1
         menu=2 --go to the level screen
  	     tmpLevel=tmpLevel+1 --simulate change level
	     gotoMenuX=gotoMenuX-140
         newLevel()
        else
            if level>loadedLevel then
                  save()
            end     
                  loadedLevel=maxLevel
                  --tmpLevel=1
                  level=1
                  --gotoMenuX=menuX      
         keyDelay=10
         newLevel()
         menu=3
         showMenu()
        end 
        
    end    

    screen:blit(0, 0, staticImage, 0 , 0, 480, 272, true) 
  
 
 

	
        for j=0, 12, 1 do
             for i=0, 15, 1 do
                    


                    if map[j][i]>=0 and map[j][i] == math.floor (map[j][i]) then    --DRAW MIRRORS TYPE A
                      screen:blit(drawStartX+i*21, j*21, mirrorsA, (map[j][i]*21)/45 , 0, 21, 21, true)    
                    end 
                    if map[j][i]> 0 and map[j][i] ~= math.floor (map[j][i]) then    --DRAW MIRRORS TYPE B
                     screen:blit(drawStartX+i*21, j*21, mirrorsB, ((map[j][i]-22.5)*21)/45 , 0, 21, 21, true)                                
                    end 
                    if map[j][i]== -11 then    --DRAW DOWN BLOCK
                      screen:blit(drawStartX+i*21, j*21, objectImage, ((map[j][i]*-1)-1)*21 , 0, 21, 21, true) 
                    end 
                    if map[j][i]== -12 then    --DRAW UP BLOCK --STATIC IMAGE FUNKAR D???
                      screen:blit(drawStartX+i*21, j*21, objectImage, ((map[j][i]*-1)-1)*21 , 0, 21, 21, true)     
                    end 
                    if diamondsArray[j][i]==2 then
                    screen:blit(drawStartX+i*21, j*21, fx, 0 , 0, 21, 21, true) 
                    end
                    
                   -- if hintTime>0 then
                     --       if map[j][i]==-10 and math.mod(hintTime,4)==0   then 
                     --          screen:blit(drawStartX+i*21, j*21, objectImage, 189 , 0, 21, 21, true)
                     --       end
                     
                   -- end
                   
                  
             

                  
	     end
        end
        


   drawAim()          
   

    
   screen:blit(0, 0, laserImage, 0 , 0, 480, 272, true)       


                    if hitFlash then
                       if fx_lighting_frame<16 then
                       screen:blit(drawStartX+flashX*21, flashY*21, fx_lighting, fx_lighting_frame*21 , 0, 21, 21, true)
                       fx_lighting_frame=fx_lighting_frame+1
                       stopLaser=true
                       else
                       resetLaser()
                      -- hitFlash=false
                       keyDelay=0
                       levelClearded=false
                       end
                    end

   screen:blit(0, 0, msgImage, 0 , 0, 480, 272, true) 
   
             --GUI
             if message~=3 then
             printFont(418, 12, diamondsLoaded-diamonds)
             printFont(418,62,mirrorsTypeA)
             printFont(418,94,mirrorsTypeB)
             printFont(20,30,level)
             end
             --GUI end


                    if hintTime>0 then
                            if math.mod(hintTime,4)==0   then
                               screen:blit(0, 0, hintImage, 0, 0, 480, 272, true)
                            end
                     
                    end

  else
      showMenu(menu)

  end --if menu==false    
  
    
end


-- INIT BEGIN
background = Image.load("background.png")
objectImage = Image.load("objects.png")
aim = Image.load("aim.png")
cannon = Image.load("cannon.png")
mirrorsA = Image.load("mirrorsA.png")
mirrorsB = Image.load("mirrorsB.png")
gui = Image.load("gui.png")
laser = Image.load("laser1.png")          --depends on level
fx = Image.load("fx.png")
fx_lighting = Image.load("fx_lighting.png") 
msg_1 = Image.load("msg_1.png") 
msg_2 = Image.load("msg_2.png") 
endscreen = Image.load("end.png") 
menu_background = Image.load("menu_background.png") 
lock = Image.load("lock.png")
level_background = Image.load("level_background.png")
font = Image.load("font.png")
staticImage = Image.createEmpty(480, 272)
laserImage = Image.createEmpty(480, 272)
msgImage = Image.createEmpty(480, 272)
levelSelectImage = Image.createEmpty(480, 272)
hintImage = Image.createEmpty(480, 272)


sound_move_mirror = Sound.load("./sound/move_mirror.wav")
sound_place_mirror = Sound.load("./sound/place_mirror.wav")
sound_hit_mirror = Sound.load("./sound/hit_mirror.wav")
sound_elec = Sound.load("./sound/elec.wav")
sound_diamond = Sound.load("./sound/hit_diamond.wav")
sound_menu_click = Sound.load("./sound/menu_click.wav")
Music.playFile("./sound/song_.xm", true)
if menu1_music then
--menu1_music:play() 
end

maxLevel=13

menu_lvl={}
for i=1, maxLevel, 1 do
menu_lvl[i] = Image.load("menu_lvl_"..i..".png")
end






       
 





white = Color.new(255, 255, 255)
black = Color.new(0, 0, 0)


acc=0
downPress=false
upPress=false
rightPress=false
leftPress=false
hintTime=0
message=0
xposActiv=0
yposActiv=0
flashX=0
flashY=0
drawStartX=72 --Where the gameboard is drawn in X (boards left side). 72=middle
keyDelay=0
trianglePress=false
laserOn=false
mirrorSelected=false
shootLoops=0
addLaserLenght=0
laserAngle=0
diamonds=0
moveBlockChanges=0
staticX=0
levelCleared=false
menu=1
menuX=180
gotoMenuX=menuX
load() --loads level
tmpLevel=1
level=1





diamondsArray={}      --must be before loadMap

 for j=0, 12, 1 do       
  diamondsArray[j]={}
   	for i=0, 15, 1 do    
     	  diamondsArray[j][i]=0
   	end
 end




map={}

newLevel()


-- INIT END










while true do
        --if levelCleared==false then
        update()
        --end
         draw()

             




      --   screen:print(0, 100, map[0], white)
	 screen.waitVblankStart()        
	 screen.flip()
        

if levelCleared==false then
	pad = Controls.read()
	if pad:select() and menu==1 then
	Music.stop()
		break
	end
end	
end
