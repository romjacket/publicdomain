--system file
---COLORS
System.usbDiskModeActivate()
System.oaenable()
--colors
red = Color.new(255, 0, 0)
green = Color.new(0, 255, 0)
blue = Color.new(0, 0, 255)
black = Color.new(0, 0, 0)
white = Color.new(255, 255, 255)
grey = Color.new(128, 128, 128)
cyan = Color.new(100, 255, 255)
yellow = Color.new(255, 255, 0)
Big = Font.createProportional()
Big:setPixelSizes(0, 15)
--Images
	menubar=Image.load("system/gfx/menubar.png")
		--planes
		plane_1=Image.load("system/gfx/plane_1.png")
		plane_2=Image.load("system/gfx/plane_2.png")		
		enemy_1=Image.load("system/gfx/enemy_1.png")
		enemy_2=Image.load("system/gfx/enemy_2.png")		
	cloud1=Image.load("system/gfx/cloud1.png")
	cloud2=Image.load("system/gfx/cloud2.png")
	healthbg=Image.load("system/gfx/healthbg.png")
	healthfront=Image.load("system/gfx/healthfront.png")
	--menus
		main_menubg=Image.load("system/gfx/main_menubg.png")
		main_menu_selec1=Image.load("system/gfx/main_menu_selec1.png")
		main_menu_selec2=Image.load("system/gfx/main_menu_selec2.png")
		main_menu_selec3=Image.load("system/gfx/main_menu_selec3.png")
		main_menu_selec4=Image.load("system/gfx/main_menu_selec4.png")
		main_menu_selec5=Image.load("system/gfx/main_menu_selec5.png")
		creditbg=Image.load("system/gfx/creditbg.png")
		hsbg=Image.load("system/gfx/hsbg.png")		
--SFX
beep=Sound.load("system/sfx/beep.wav",false)
shoot1=Sound.load("system/sfx/shoot1.wav",false)
shoot2=Sound.load("system/sfx/shoot2.wav",false)
--FILE LOADING
dofile("system/variables.lua")
dofile("system/engine.lua")
dofile("system/levels.lua")
--MAIN LOOP
while true do 
pad=Controls.read()
anaX=pad:analogX()
anaY=pad:analogY()
screen:clear()
if game.pause=="false" then

	if game.state=="main_menu" then
		Music.stop()
		mainMenu()
	elseif game.state=="credits" then
		creditMenu()
	elseif game.state=="hsmenu" then
		hsMenu()
	elseif game.state=="name" then
		nameMenu()
	elseif game.state=="char" then
		charMenu()
	elseif game.state=="ingame" then 
		if pad:start() and not oldpad:start() then game.pause="true" end
		if game.lvl==1 then
			LVL1()
		elseif game.lvl==2 then
			LVL2()
		end
	end
else
	screen:clear()
	if pad:start() and not oldpad:start() then game.pause="false" end
	screen:print(210,140,"PAUSED",white)
end
--screen:print(0,0,"x:"..player.x.."y:"..player.y,white)











screen.waitVblankStart()
oldpad=pad
--if pad:select() then screen:save("screen.png") end
screen.flip()
end 