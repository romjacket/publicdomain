--levels
function LVL1()

if game.timer >=0 and game.timer <=0 then System.message("Round 1",0) Music.playFile("system/sfx/game_song.it") end
	--scenery
	screen:clear(blue)
	
	--clouds
		for i= 1,4 do 
			if clouds[i].y > 300 then 
				clouds[i].x=math.random(132,298)
				clouds[i].y=math.random(-500,-100)
				
			end
		end
		clouds[1].y=clouds[1].y+player.speed
		clouds[2].y=clouds[2].y+player.speed/2
		clouds[3].y=clouds[3].y+player.speed/2
		clouds[4].y=clouds[4].y+player.speed
		screen:blit(clouds[1].x,clouds[1].y,cloud1)
		screen:blit(clouds[2].x,clouds[2].y,cloud2)
		screen:blit(clouds[3].x,clouds[3].y,cloud1)
		screen:blit(clouds[4].x,clouds[4].y,cloud2)
		game.timer=game.timer+.01
			playerInfo()
			enemies(enemy_1,2)
			playerMov()
			shoot()
		if game.timer > 100 then 
			System.message("Lvl 1 Complete!",0) 
			game.timer=0
			game.lvl=2
			game.timer=0
		end
end 
function LVL2()
if game.timer >=0 and game.timer <=0 then System.message("Round 2",0) Music.playFile("system/sfx/game_song.it") end
	screen:clear(blue)
	
		game.timer=game.timer+.01
		playerInfo()
		enemies(enemy_2,3)
		playerMov()
		shoot()
	if game.timer > 100 then 
		System.message("Lvl 2 Complete! more levels are being made leave feedback!",0) 
		gameRe("Demo end")
	end		
end 