--functions
function playerInfo()
	screen:blit(0,0,menubar)
	screen:blit(480-menubar:width(),0,menubar)

--player_health
	screen:blit(15,190,healthbg)
	screen:blit(15,190,healthfront,0,0,player.health,10)
--score
	screen:print(15,140,"Score:"..player.score,white)
--lives
	screen:print(15,160,"Lives:"..player.lives,white)
--lvl
	screen:print(15,120,"Lvl:"..game.lvl,blue)
	screen:print(15,100,""..player.name,yellow)
--level completion meter
	screen:fillRect(415,100,10,100,red)
	screen:fillRect(414,200-game.timer,12,2,yellow)
	screen:print(427,200-game.timer,""..math.floor(game.timer+.5).."%",blue)
--player dies
	if player.health <= 0 then 
		player.lives=player.lives-1
		player.health=100
	end 
	if player.lives < 0 then
		gameRe("you are dead!")
	end 
end 
function playerMov()
	if anaX < -50 then 
		player.x=player.x-player.speed
	end
	if anaX > 50 then 
		player.x=player.x+player.speed
	end	
		if anaY < -50 then 
			player.y=player.y-player.speed
		end
		if anaY > 50 then 
			player.y=player.y+player.speed
		end
--restrictions
	if player.x < 132 then player.x=132 
	elseif player.x > 348-player.img:width() then player.x = 348-player.img:width() end
		if player.y < 0 then player.y=0 
		elseif player.y > 272-player.img:height() then player.y=272-player.img:height() end
--blit player
		screen:blit(player.x,player.y,player.img)
end 
function shoot()
--shoot
	if bulletnum >= 10 then bulletnum=0 end
	if pad:cross() and not oldpad:cross() then 
		bulletnum=bulletnum+1
		bullet[bulletnum].state="true"
		if player.img==plane_1 then shoot1:play() end
		if player.img==plane_2 then shoot2:play() end
	end
--print shooting bullet
	for i=1,bullets do
		if bullet[i].state=="true" then
			bullet[i].y=bullet[i].y-4
			screen:fillRect(bullet[i].x,bullet[i].y,2,2,black)
		end
		if bullet[i].y < 2 then bullet[i].state="false" end
		if bullet[i].state=="false" then 
			bullet[i].x=player.x+player.img:width()/2
			bullet[i].y=player.y
		end
	end
end 
function enemies(pic,speed)
	for i=1,enemys do
		enemy[i].y=enemy[i].y+speed
	--hurt player
			if enemy[i].y > 300 then 
				enemy[i].x=math.random(132,298)
				enemy[i].y=math.random(-900,-500)
				player.health=player.health-25
				enemy[i].health=100
			end
		screen:blit(enemy[i].x,enemy[i].y,pic)
		screen:fillRect(enemy[i].x+5,enemy[i].y-10,20,3,red)
		screen:fillRect(enemy[i].x+5,enemy[i].y-10,enemy[i].health/5,3,yellow)
		for a=1,10 do
			if bullet[a].state=="true" then
				if (bullet[a].x > enemy[i].x) and (bullet[a].x < enemy[i].x+50)and
				(bullet[a].y > enemy[i].y)and(bullet[a].y < enemy[i].y+30) then
					enemy[i].health=enemy[i].health-player.power
						--screen:print(bullet[a].x,bullet[a].y,"+5pts",white)
						bullet[a].x=player.x
						bullet[a].y=player.y
						bullet[a].state="false"
						player.score=player.score+5	
				end
				if enemy[i].health<=0 then 
						enemy[i].x=math.random(132,298)
						enemy[i].y=math.random(-900,-500)
						enemy[i].health=100
				end
				
			end
		end
	end 
end




function selector(Max)
if selec > Max then selec=1 elseif selec < 1 then selec= Max end
	if pad:up() and not oldpad:up() then
		selec=selec-1
		beep:play()
	end
	if pad:down() and not oldpad:down() then
		selec=selec+1
		beep:play()
	end
end
function mainMenu()
	screen:clear()
	selector(5)
	screen:blit(0,0,main_menubg)
		if selec==1 then 
			screen:blit(30,60,main_menu_selec1)
			if pad:cross() and not oldpad:cross() then game.state="name" selec=1 end
		end
		if selec==2 then 
			screen:blit(30,60,main_menu_selec2)
			if pad:cross() and not oldpad:cross() then 
				game.state="char"
			end
		end
		if selec==3 then 
			screen:blit(30,60,main_menu_selec3)
			if pad:cross() and not oldpad:cross() then 
				game.state="hsmenu"
			end			
		end
		if selec==4 then 
			screen:blit(30,60,main_menu_selec4)
			if pad:cross() and not oldpad:cross() then 
				game.state="credits"
			end
		end
		if selec==5 then 
			screen:blit(30,60,main_menu_selec5)
			if pad:cross() and not oldpad:cross() then System.message("Quit to XMB?",1) end button = System.buttonPressed(1) if button == "yes" then System.Quit() end
		end		
end 
function creditMenu()
	screen:clear()
	screen:blit(0,0,creditbg)
	if credittime > 10 then credittime=0 game.state="main_menu" end
	if pad:circle() and not oldpad:circle() then game.state="main_menu" credittime=0 end
--credits
	credittime=credittime+.01
		screen:print(150,272-(credittime*50),"Coded by:WayWardSon",white)
		screen:print(150,332-(credittime*50),"GFX by:WayWardSon",white)
		screen:print(150,392-(credittime*50),"Powered by: LuaPlayerHM",white)
		screen:print(150,452-(credittime*50),"Thanks for playing!!",yellow)
	
end
function hsMenu()
	screen:clear()
	screen:blit(0,0,hsbg)
	if pad:circle() and not oldpad:circle() then game.state="main_menu" game.timer=0 end
--readfile
	game.timer=game.timer+1
	if game.timer >= 3 and game.timer <= 3 then
		file = io.open("system/data/highscore.txt", "r") 
		sscore = file:read() 
		file:close()
		file = io.open("system/data/names.txt", "r") 
		nname = file:read() 
		file:close()		
	end
		if sscore==nil then
		else
		hS[1]=string.find(sscore,"/1/")
		hS[2]=string.find(sscore,"/2/")	
		hS[3]=string.find(sscore,"/3/")	
		hS[4]=string.find(sscore,"/4/")		
			hSs[1]=string.sub(sscore,hS[1]+3,hS[2]-1)
			hSs[2]=string.sub(sscore,hS[2]+3,hS[3]-1)
			hSs[3]=string.sub(sscore,hS[3]+3,hS[4]-1)
			hSs[4]=string.sub(sscore,hS[4]+3)
		nn[1]=string.find(nname,"/1/")
		nn[2]=string.find(nname,"/2/")	
		nn[3]=string.find(nname,"/3/")	
		nn[4]=string.find(nname,"/4/")		
			nN[1]=string.sub(nname,nn[1]+3,nn[2]-1)
			nN[2]=string.sub(nname,nn[2]+3,nn[3]-1)
			nN[3]=string.sub(nname,nn[3]+3,nn[4]-1)
			nN[4]=string.sub(nname,nn[4]+3)					
		---print score stuff
	screen:print(150,100,"1. "..nN[1]..":"..hSs[1],yellow)
	screen:print(150,140,"2. "..nN[2]..":"..hSs[2],yellow)
	screen:print(150,180,"3. "..nN[3]..":"..hSs[3],yellow)
	screen:print(150,220,"4. "..nN[4]..":"..hSs[4],yellow)		
		end
end 
function nameMenu()
	screen:clear()
		screen:blit(0,0,main_menubg)
		screen:print(35,30,"Player Name Input",yellow)
		selector(2)
		screen:print(30,130,"Name:"..player.name,white)
		screen:print(30,150,"Start Game",white)
		if player.name=="" then player.name="WayWardSon" end
		if pad:circle() and not oldpad:circle() then game.state="main_menu" selec=1 end
		if selec==1 then screen:print(30,130,"Name:"..player.name,blue) 
			if pad:cross() and not oldpad:cross() then
			player.name=System.startOSK("WayWardSon","Player Name Input")
			end
		end
		if selec==2 then screen:print(30,150,"Start Game",blue) 
			if pad:cross() and not oldpad:cross() then
				System.message("Start Game?",1)
			button = System.buttonPressed(1) if button == "yes" then game.state="ingame" game.timer=0 end	
			end
		end		
end
function charMenu()
	screen:clear()
		screen:blit(0,0,main_menubg)
		selector(2)
		if selec==1 then 
			player.img=plane_1 
			screen:print(35,100,"Cobra",white)
			screen:blit(100,120,plane_1)
			screen:print(35,200,"Speed class:2",blue)
			screen:print(35,210,"Weapon class:3",red)
			player.speed=2
			player.power=50
		end
		if selec==2 then 
			player.img=plane_2 
			screen:print(35,100,"P-51d Mustang",white)
			screen:blit(100,120,plane_2)
			screen:print(35,200,"Speed class:3",blue)
			screen:print(35,210,"Weapon class:2",red)
			player.speed=3
			player.power=35
		end
		if pad:cross() and not oldpad:cross() then game.state="main_menu" end
end

function gameRe(Quote)
	--save high scores
		--reading file
		file = io.open("system/data/highscore.txt", "r") 
		sscore = file:read() 
		file:close()
		file = io.open("system/data/names.txt", "r") 
		nname = file:read() 
		file:close()		
		if sscore==nil then
		else
		hS[1]=string.find(sscore,"/1/")
		hS[2]=string.find(sscore,"/2/")	
		hS[3]=string.find(sscore,"/3/")	
		hS[4]=string.find(sscore,"/4/")
			hSs[1]=tonumber(string.sub(sscore,hS[1]+3,hS[2]-1))
			hSs[2]=tonumber(string.sub(sscore,hS[2]+3,hS[3]-1))
			hSs[3]=tonumber(string.sub(sscore,hS[3]+3,hS[4]-1))
			hSs[4]=tonumber(string.sub(sscore,hS[4]+3))
		nn[1]=string.find(nname,"/1/")
		nn[2]=string.find(nname,"/2/")	
		nn[3]=string.find(nname,"/3/")	
		nn[4]=string.find(nname,"/4/")		
			nN[1]=string.sub(nname,nn[1]+3,nn[2]-1)
			nN[2]=string.sub(nname,nn[2]+3,nn[3]-1)
			nN[3]=string.sub(nname,nn[3]+3,nn[4]-1)
			nN[4]=string.sub(nname,nn[4]+3)				
		--writing to file
		
			if player.score > hSs[1] then
				file = io.open("system/data/highscore.txt", "w") 
				file:write("/1/"..player.score.."/2/"..hSs[1].."/3/"..hSs[2].."/4/"..hSs[3]) 
				file:close()
				file = io.open("system/data/names.txt", "w") 
				file:write("/1/"..player.name.."/2/"..nN[1].."/3/"..nN[2].."/4/"..nN[3]) 
				file:close()				
			end
			if player.score > hSs[2] and player.score < hSs[1] then
				file = io.open("system/data/highscore.txt", "w") 
				file:write("/1/"..hSs[1].."/2/"..player.score.."/3/"..hSs[2].."/4/"..hSs[3]) 
				file:close()
				file = io.open("system/data/names.txt", "w") 
				file:write("/1/"..nN[1].."/2/"..player.name.."/3/"..nN[2].."/4/"..nN[3]) 
				file:close()				
			end
			if player.score > hSs[3] and player.score < hSs[2] then
				file = io.open("system/data/highscore.txt", "w") 
				file:write("/1/"..hSs[1].."/2/"..hSs[2].."/3/"..player.score.."/4/"..hSs[3]) 
				file:close()
				file = io.open("system/data/names.txt", "w") 
				file:write("/1/"..nN[1].."/2/"..nN[2].."/3/"..player.name.."/4/"..nN[3]) 
				file:close()				
			end
			if player.score > hSs[4] and player.score < hSs[3] then
				file = io.open("system/data/highscore.txt", "w") 
				file:write("/1/"..hSs[1].."/2/"..hSs[2].."/3/"..hSs[3].."/4/"..player.score) 
				file:close()
				file = io.open("system/data/names.txt", "w") 
				file:write("/1/"..nN[1].."/2/"..nN[2].."/3/"..nN[3].."/4/"..player.name) 
				file:close()				
			end
		end
	--reset everything
		System.message(Quote,0)
		game.state="main_menu"
		player.health=100
		player.lives=2
		game.lvl=1
		game.timer=0
		player.score=0
		player.name="WayWardSon"
		for i=1,enemys do
			enemy[i]={x=math.random(132,298),y=math.random(-900,-500),health=100}
		end 
		for i =1,bullets do
			bullet[i]={x=player.x,y=player.y,state="false"}
		end 
end 
