*******************************************************************************************************************************
							X-Tris 
*******************************************************************************************************************************

Programmed by Samy (alias Gogy).
Released: 2009/03/10






******************************************************************************************************************************
							Installation
*******************************************************************************************************************************

Unzip the archive in the folder GAME or GAMEXXX on your PSP(depending on your configuration, if you don't know put 
it in the Game folder)






******************************************************************************************************************************
							Gameplay
*******************************************************************************************************************************

In the menu you can access to a new game, you can set the level, the kind of game (classic or X-treme), access the
credits or quit.

The keys are very easy:
-LEFT / RIGHT to move the piece
-DOWN to speed up the falling
_LEFT TRIGGER / RIGHT TRIGGER to rotate the piece





******************************************************************************************************************************
							Credits
*******************************************************************************************************************************

Thank you to all you permit developement for the PSP:

- all the guys who reversed and crack the PSP
- all the guys who created firmwares
- Shine for creating the Luaplayer
- InsertWittyName for the development of Phoenix Game Engine Lua (PGE Lua)





******************************************************************************************************************************
							Contact me
*******************************************************************************************************************************
If you are willing to let commentaries (bug reports, support) go on my blog at: 
http://samy-prog.blogspot.com/

Or send me a mail (precise in the object it concerns the PSP) at:
reivax_vet@hotmail.com

