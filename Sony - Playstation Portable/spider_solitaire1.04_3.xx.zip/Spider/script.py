import sys
sys.path.append('./lib')

import main

if __name__ == '__main__':
  lmain = main.tmain()
  lmain.show()
