class tclass:
  @property
  def super(self):
    return self.get_super()

  def get_super(self):
    return None
