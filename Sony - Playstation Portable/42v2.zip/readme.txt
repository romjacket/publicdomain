--------------
      4�
by coolguy5678
--------------

This is a game based on the game "four-square" played all over the world. If the ball goes to your square, you have to hit it so it first bounces in your square and then in someone elses. If you make a mistake, you are out, everyone who was in a lower square moves up, and a new person enters the game in the lowest square (on the bottom-left). The highest square (top-left) is the king square, and if you make a mistake here, you only move to the lowest square, instead of going out.

You are the blue player. You earn points for staying in and playing fast shots. You earn double points when you are in the highest two squares. When you go out, your game ends.

--------------
A note about the rules
--------------

Four-square is played around the world, but the rules vary dramatically depending on where its played - so, don't tell me "the rules are wrong!"

--------------
Controls
--------------

Use the analog/or d-pad to move.
Hold X to charge up your shot.
Release X when the ball is near you to hit it.

The ball is hit outward in the direction of the blue cone on your player. If the ball is far away from you when you release X, the ball will be hit at a shallower trajectory, unless the ball is outside your reach. It takes a while to get used to this, but its easy to play the game once you are used to the feel of the game. Try watching the AI players on the main menu.

--------------
Credits
--------------

Programming - coolguy5678
GFX - coolguy5678
Music - AndrewPotterton of Soundsnap.com
SFX - Soundsnap.com
Font - P. Wiegel

Special thanks to Brunni for writing OSLib.