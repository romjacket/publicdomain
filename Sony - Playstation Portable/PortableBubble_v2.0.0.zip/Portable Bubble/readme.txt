## Portable Bubble v2.0.0,
## by Gefa,
## www.gefa.altervista.org
## Project website: http://gefa.altervista.org/PortableBubble/index.html

What is it?
===========
Its name is Portable bubble, and it is a Puzzle Bubble clone for Sony PSP. It's developed by Germano "Gefa" Fabio. 
The graphich instead is by Ignazzi "Gabbo" Gabriele.
In this game, you are free to select and play a level set or a level generated randomly.
You can also create and/or download new level sets. 

Installation
============
Copy PSP and python directories in the root of your memory stick.

Special Thanks
==============
Ignazzi "Gabbo" Gabriele for the graphic;
sakya who has compiled Stackless Python PSP adding some useful features;
Rui Barbosa Martins for the pybubble script ;-) ;
Frozen Bubble authours for the default level set and sounds.

For any problem, contact me.
