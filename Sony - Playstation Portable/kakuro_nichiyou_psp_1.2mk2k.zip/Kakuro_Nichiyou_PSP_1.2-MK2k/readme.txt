- -- --------------------------------------------------------------------- -- -
Author      MK2k / www.mk2k.net
Name        Kakuro Nichiyou PSP
Version     1.2
Platform    PSP (Custom Firmware)
Dev-Details Developed in C++ using the JGE++ Engine by Dr. Watson
Ingame GFX  Thanks to Dargo / www.mupfelofen.de for the great work on the ingame
            tileset and font
Puzzle Data Credits go to Otto Janko / www.janko.at for his permission to use
            and distribute his Kakuro Puzzles in Kakuro Nichiyou and thanks to
            his collection of other people's free Kakuro Puzzles
- -- --------------------------------------------------------------------- -- -

Kakuro Nichiyou PSP 1.2 is a Game where you can play different Kakuro Puzzles. 

Read this link to get the hang of Kakuro, which is actually the younger brother
of Sudoku: http://en.wikipedia.org/wiki/Kakuro

- -- --------------------------------------------------------------------- -- -
I    Features
- -- --------------------------------------------------------------------- -- -
* Kakuro Nichiyou features 254 hand-picked/created Puzzles from Puzzlemakers all
  over the world. Permission granted by Otto Janko, a great Puzzle collector
  visit his website: www.janko.at
* Play Kakuros by setting numbers in the free fields, you can even make "notes"
  in each field (small numbers from 1..9)
* In Kakuro Nichiyou you can save your current progress to one of 20 different
  save slots.
* Kakuro Nichiyou features a solver which is work in progress. In the current
  state it is able to solve 203 out of the 234 Puzzles completely. It cannot
  find a solution for the other puzzles but gives you the found notes of the
  remaining fields (or maybe just a good laugh =D).

- -- --------------------------------------------------------------------- -- -
II   Installation
- -- --------------------------------------------------------------------- -- -
Copy the Kakuro_Nichiyou_PSP directory to your PSP/GAME direcory on your  memory
stick. Make sure that PSP/GAME is not set to 1.50 Kernel mode. Alternatively use
the PSP/GAME3xx directory on your memory stick (where GAME3xx is GAME390 for
example in CFW M33-2)

- -- --------------------------------------------------------------------- -- -
III  Controls
- -- --------------------------------------------------------------------- -- -
* Menu controls are as follows:
  - D-Pad Up/Down   : select Option
  - D-Pad Left/Right: change Option (if applicable)
  - CROSS           : Apply
  - CIRCLE          : Revert
  
* Ingame Controls:
  - D-Pad Up/Down/Left/Right: Select adjacent fields
  - CROSS                   : On a free field: bring up the number selector for
                                               value input
                              On a hint field (the split field with a sum 
                              number written on it): Let the solver try to solve
                              the current line (horizontally or vertically)
  - SQUARE                  : On a free field: bring up the number selector for
                                               note input
  - CIRCLE                  : On a free field: Delete the current value of the
                                               field. If the value is deleted,
                                               delete the notes on the field.
  - Left Shoulder Trigger   : Exit to Main Menu
  - Right Shoulder Trigger  : Go to Save Menu
  - SELECT                  : Let the solver try to solve the current Kakuro
                              Puzzle
  
* Number Selector Controls
  - D-Pad                   : Select the number
  - CROSS                   : in value selection mode: select the current number
                              and go back to the game
                              in note selection mode: select/deselect the
                              current number
  - CIRCLE                  : in value selection mode: go back to game without
                              selecting any number
                              in note selection mode: go back to game
  - SQUARE                  : in note selection mode: go back to game

- -- --------------------------------------------------------------------- -- -
V    Greets and Shouts
- -- --------------------------------------------------------------------- -- -
Dargo / www.mupfelofen.de
Otto Janko / www.janko.at
Daishi Machida / shinyusha.co.jp
InsertWittyName and everyone at #psp-programming on freenode
oranda / http://www.indiegames.com/blog/
Greg / www.psp-hacks.com
Kojote / www.pdroms.com
Shoesy / www.pspsource.de

- -- --------------------------------------------------------------------- -- -
VI   EOF - Visit www.mk2k.net
- -- --------------------------------------------------------------------- -- -