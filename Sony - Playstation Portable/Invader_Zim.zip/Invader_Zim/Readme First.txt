Lua Player
http://www.luaplayer.org/
IRC: #luaplayer on http://freenode.net/

What is Lua Player (Mod)?
============================
Lua Player is a script player for the Sony PSP. With it, you can run applications written in the language `Lua`. Writing Lua code is both faster and easier than writing for the PSP directly.

It's a Mod, because there are additional functions added.

Install on PSP
============================
Included in the distribution you have downloaded is
 - The LuaPlayer application specific for your PSP version
 - Several sample applications

Installation instructions: 1.5 firmware
	Copy the luaplayer and luaplayer% folders to your (memorystick)/PSP/GAME/
	
Installation instructions: For 1.0 firmware
	Copy the luaplayer folder to your (memorystick)/PSP/GAME/


Finding and installing LuaPlayer apps and games
============================
There's a list of apps and games available at
http://www.luaplayer.org/gallery/

To install them, simply drop the app folder into the /PSP/GAME/luaplayer/Applications/ folder.
