--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 3.68
redline = 7000
final = 3.73
gearratio[1] = 2.95
gearratio[2] = 1.95
gearratio[3] = 1.34
gearratio[4] = 1.00
gearratio[5] = .8
gearratio[6] = 0
tcircumference = 6.81
price = 80000