--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 5.2
redline = 8000
final = 3.54
gearratio[1] = 3.83
gearratio[2] = 2.36
gearratio[3] = 1.69
gearratio[4] = 1.31
gearratio[5] = 1.00
gearratio[6] = .79
tcircumference = 6.73
price = 90000