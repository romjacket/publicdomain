--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 5.0
--redline = unknown
final = 3.44
gearratio[1] = 3.82
gearratio[2] = 2.20
gearratio[3] = 1.52
gearratio[4] = 1.22
gearratio[5] = 1.02
gearratio[6] = .84
tcircumference = 6.53
price = 70000