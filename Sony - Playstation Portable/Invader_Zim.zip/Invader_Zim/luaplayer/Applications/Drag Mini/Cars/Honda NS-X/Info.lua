--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 4.9
redline = 8000
final = 4.62
gearratio[1] = 3.07
gearratio[2] = 1.96
gearratio[3] = 1.43
gearratio[4] = 1.12
gearratio[5] = .91
gearratio[6] = .72
tcircumference = 6.22
price = 115000