--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 3.7
redline = 6000
final = 3.39
gearratio[1] = 3.37
gearratio[2] = 1.99
gearratio[3] = 1.33
gearratio[4] = 1.00
gearratio[5] = .67
gearratio[6] = 0
tcircumference = 6.65
price = 70000