--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 3.4
redline = 8000
final = 2.53
gearratio[1] = 2.94
gearratio[2] = 2.06
gearratio[3] = 1.52
gearratio[4] = 1.18
gearratio[5] = 1.03
gearratio[6] = .91
tcircumference = 6.48
price = 230000