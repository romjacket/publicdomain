--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 3.4
redline = 8000
final = 4.1
gearratio[1] = 3.15
gearratio[2] = 2.18
gearratio[3] = 1.57
gearratio[4] = 1.19
gearratio[5] = .94
gearratio[6] = .76
tcircumference = 3.74
price = 670000