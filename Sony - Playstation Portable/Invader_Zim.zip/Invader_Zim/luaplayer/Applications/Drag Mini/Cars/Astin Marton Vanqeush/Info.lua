--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 4.7
redline = 7000
final = 3.69
gearratio[1] = 2.66
gearratio[2] = 1.78
gearratio[3] = 1.30
gearratio[4] = 1.00
gearratio[5] = .85
gearratio[6] = .70
tcircumference = 7.07
price = 228000