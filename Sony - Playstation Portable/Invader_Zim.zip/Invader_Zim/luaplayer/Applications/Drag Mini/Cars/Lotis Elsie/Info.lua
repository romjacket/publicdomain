--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 5.7
redline = 8000
final = 4.2
gearratio[1] = 2.92
gearratio[2] = 1.75
gearratio[3] = 1.31
gearratio[4] = 1.03
gearratio[5] = .848
gearratio[6] = 0
tcircumference = 6.17
price = 40000