--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 3.4
redline = 7600
final = 4.00
gearratio[1] = 3.15
gearratio[2] = 2.00
gearratio[3] = 1.57
gearratio[4] = 1.31
gearratio[5] = 1.09
gearratio[6] = .97
tcircumference = 5.07
price = 1000000