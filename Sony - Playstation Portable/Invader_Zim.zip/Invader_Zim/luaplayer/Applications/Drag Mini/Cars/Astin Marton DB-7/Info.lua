--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 6.2
redline = 6000
final = 3.50
gearratio[1] = 3.55
gearratio[2] = 2.04
gearratio[3] = 1.40
gearratio[4] = 1.00
gearratio[5] = .74
gearratio[6] = 0
tcircumference = 6.73
price = 160000