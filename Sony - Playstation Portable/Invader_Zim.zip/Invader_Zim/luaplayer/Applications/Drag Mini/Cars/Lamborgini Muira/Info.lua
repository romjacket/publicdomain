--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 5.4
redline = 7500
final = 4.08
gearratio[1] = 2.52
gearratio[2] = 1.735
gearratio[3] = 1.225
gearratio[4] = 1
gearratio[5] = .815
gearratio[6] = 0
tcircumference = 5
price = 70000