--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 5
redline = 7000
final = 4.529
gearratio[1] = 2.785
gearratio[2] = 1.950
gearratio[3] = 1.407
gearratio[4] = 1.031
gearratio[5] = .720
gearratio[6] = 0
tcircumference = 6.63
price = 30000