--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 4.3
redline = 6500
final = 3.31
gearratio[1] = 3.15
gearratio[2] = 1.95
gearratio[3] = 1.52
gearratio[4] = 1.19
gearratio[5] = 1.31
gearratio[6] = 1.03
tcircumference = 6.65
price = 140000