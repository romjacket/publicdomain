--final = final drive ratio of car
--gearratio[6] = gear ratio in 6th gear
--tcircumference = tire circumference

gearratio  = {}
acceleration = 5.1
redline = 7300
final = 3.64
gearratio[1] = 3.23
gearratio[2] = 2.11
gearratio[3] = 1.52
gearratio[4] = 1.19
gearratio[5] = .97
gearratio[6] = .82
tcircumference = 6.82
price = 120000