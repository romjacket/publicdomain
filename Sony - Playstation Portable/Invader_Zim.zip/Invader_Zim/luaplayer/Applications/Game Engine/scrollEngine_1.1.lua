white = Color.new(255,255,255)
pink = Color.new(255,0,255)
green = Color.new(0,255,0)
red = Color.new(255,0,0)

zimleft = Timer.new()
zimright = Timer.new()
zimstandleft = Timer.new()
zimstandright = Timer.new()

Map = {}
Map[1] = { x = 0, y = 0, img = Image.load("map.png") }
Map[2] = { x = 480, y = 0, img = Image.load("map2.png") }
Map[3] = { x = 960, y = 0, img = Image.load("map3.png") }
Map[4] = { x = 1440, y = 0, img = Image.load("map4.png") }
Map[5] = { x = 1920, y = 0, img = Image.load("map5.png") }

player1 = Image.load("WalkRight1.png")
player2 = Image.load("WalkRight2.png")
player3 = Image.load("WalkRight3.png")
player4 = Image.load("WalkRight4.png")
player5 = Image.load("WalkLeft1.png")
player6 = Image.load("WalkLeft2.png")
player7 = Image.load("WalkLeft3.png")
player8 = Image.load("WalkLeft4.png")

ZIMstand1 = Image.load("ZIMstand1.png")
ZIMstand2 = Image.load("ZIMstand2.png")
ZIMstand3 = Image.load("ZIMstand3.png")

ZIMstandLEFT1 = Image.load("ZIMstandLEFT1.png")
ZIMstandLEFT2 = Image.load("ZIMstandLEFT2.png")
ZIMstandLEFT3 = Image.load("ZIMstandLEFT3.png")

Player = {}
Player[1] = { x = 30, y = 100 }

ground = Image.createEmpty(480,10)

currentBullet = 0
direction = "right"

player = {}
player.gravity = 185
player.y = 185
player.x = 50
player.jumpspeed = 10
player.jumpstate = "ground"
playerHeight = 32
playerWidth = 32

--Create a blank image and fill it with green. This will be the bullet.
bullet = Image.createEmpty(4,4)
bullet:clear(green)

block = Image.createEmpty(32,32)
block:clear(green)

function collisionCheck(object)
if (player.x + playerWidth > object.x) and (player.x < object.x + object.width) and (player.y + playerHeight > object.y) and (player.y < object.y + object.height) then
player.x = oldx
player.y = oldy
end
end

--Create Array for Bullets
BulletInfo = {}
for a = 1,5 do
BulletInfo[a] = { pic = bullet , firing = false, direction = "right", x = Player[1].x + 32, y = Player[1].y + 16 }
end

--Functions

function bulletSetup()
--Increase the current bullet by one, or reset it to 1
if currentBullet < 5 then
currentBullet = currentBullet + 1
else
currentBullet = 1
end

if direction == "left" then
BulletInfo[currentBullet].x = Player[1].x
BulletInfo[currentBullet].y = Player[1].y + 16
end
if direction == "right" then
BulletInfo[currentBullet].x = Player[1].x + 32
BulletInfo[currentBullet].y = Player[1].y + 16
end
if direction == "up" then
BulletInfo[currentBullet].x = Player[1].x + 16
BulletInfo[currentBullet].y = Player[1].y
end
if direction == "down" then
BulletInfo[currentBullet].x = Player[1].x + 16
BulletInfo[currentBullet].y = Player[1].y + 32
end

BulletInfo[currentBullet].direction = direction
BulletInfo[currentBullet].firing = true
end

function bulletFire()
for i = 1,5 do
if BulletInfo[i].firing == true then
if BulletInfo[i].direction == "right" then BulletInfo[i].x = BulletInfo[i].x + 10 end
if BulletInfo[i].direction == "left" then BulletInfo[i].x = BulletInfo[i].x - 10 end
if BulletInfo[i].direction == "up" then BulletInfo[i].y = BulletInfo[i].y - 10 end
if BulletInfo[i].direction == "down" then BulletInfo[i].y = BulletInfo[i].y + 10 end
screen:blit(BulletInfo[i].x,BulletInfo[i].y,BulletInfo[i].pic)
end
if BulletInfo[i].x < 0 or BulletInfo[i].x > 480 or BulletInfo[i].y < 0 or BulletInfo[i].y > 272 then
BulletInfo[i].firing = false
end
end
end

function moveMap()

pad = Controls.read()

--**************** Move the first image left and right but stops at x = 0 ************************
if pad:left() and Map[1].x < 0 and player.x == 240 then
Map[1].x =  Map[1].x + 3
end
if player.x == 240 and pad:right() then
Map[1].x =  Map[1].x - 3
end

--**************** Move player so that it wont leave the screen ***********************
if Map[1].x == 0 and Map[2].x == 480 and Map[3].x == 960 and pad:left() and player.x < 241 and player.x > 0 then
player.x = player.x - 2
end

if Map[1].x == 0 and Map[2].x == 480 and Map[3].x == 960 and pad:right() and player.x < 240 then
player.x = player.x + 2
end


-- Move the second image left and right
if pad:left() and Map[2].x < 480 and player.x == 240 then
Map[2].x =  Map[2].x + 3
end
if player.x == 240 and pad:right() then
Map[2].x =  Map[2].x - 3
end

-- Move the last image left and right
if pad:left() and Map[3].x < 960 and player.x == 240 then
Map[3].x =  Map[3].x + 3
end
if player.x == 240 and pad:right() then
Map[3].x =  Map[3].x - 3
end

if pad:left() and Map[4].x < 1440 and player.x == 240 then
Map[4].x =  Map[4].x + 3
end
if player.x == 240 and pad:right() then
Map[4].x =  Map[4].x - 3
end

if pad:left() and Map[5].x < 1920 and player.x == 240 then
Map[5].x =  Map[5].x + 3
end
if player.x == 240 and pad:right() then
Map[5].x =  Map[5].x - 3
end

--stop player moving off the right of the screen
if Map[5].x == 0 and player.x > 239 and player.x < 448 and pad:right() then
player.x = player.x + 2
end
if Map[5].x == 0 and player.x > 240 and pad:left() then
player.x = player.x - 2
end
end

--************** Ends the function and starts the main loop *****************

while true do
oldx = player.x
oldy = player.y

screen:clear()
moveMap()

if pad:triangle() and oldpad:triangle() ~= pad:triangle() then
bulletSetup()
end

bulletFire()

for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end

if pad:right() then
zimWalkState = "moveRight"
end

if pad:left() then
zimWalkState = "moveLeft"
end

--********************** Zim walking states
--********************** Zim Right Animation and Gir
if zimWalkState == "moveRight" then
zimleft:start()
currentTime = zimleft:time()

if not pad:right() then
zimWalkState = "standright"
end

if currentTime > 0 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end

screen:blit(player.x,player.y,player1)
end

if currentTime > 250 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end

screen:blit(player.x,player.y,player2)
end

if currentTime > 500   then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end

screen:blit(player.x,player.y,player3)
end

if currentTime > 750  then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end

screen:blit(player.x,player.y,player4)
end

if currentTime > 1000 then
zimleft:reset(0)
zimleft:start()
end
end


--********** Zim left animation
if zimWalkState == "moveLeft" then
zimleft:start()
currenttime = zimleft:time()

if not pad:left() then
zimWalkState = "standleft"
end

if currenttime > 0 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,player5)
end

if currenttime > 250 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,player6)
end

if currenttime > 500   then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,player7)
end

if currenttime > 750  then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,player8)
end

if currenttime > 1000 then
zimleft:reset(0)
zimleft:start()
end
end


--********************stand Right Animation
if zimWalkState == "standright" then
zimstandright:start()
standrightTime = zimstandright:time()

if standrightTime > 0 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstand1)
end

if standrightTime > 15000 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstand2)
end

if standrightTime > 15250 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstand3)
end

if standrightTime > 20000 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstand2)
end

if standrightTime > 20250 then
zimstandright:reset(0)
zimstandright:start()
end
end


--****************stand Left animation
if zimWalkState == "standleft" then
zimstandleft:start()
standleftTime = zimstandleft:time()

if standleftTime > 0 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstandLEFT1)
end

if standleftTime > 15000 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstandLEFT2)
end

if standleftTime > 15250 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstandLEFT3)
end

if standleftTime > 20000 then
screen:clear()
for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end
screen:blit(player.x,player.y,ZIMstandLEFT2)
end

if standleftTime > 20250 then
zimstandleft:reset(0)
zimstandleft:start()
end
end


--************** Jumping Stuff ***************
if pad:cross() and player.jumpstate == "ground" then player.jumpstate = "jumping" end

if player.jumpstate == "jumping" then
player.jumpspeed = player.jumpspeed - 0.5
player.gravity = player.gravity - player.jumpspeed
end

if player.gravity < 0 then
player.jumpstate = "falling"
end

if player.gravity < 185 and player.jumpstate == "falling" then
player.gravity = player.gravity + (player.jumpspeed + 3)
end

if player.gravity == 185 then
player.jumpspeed = 10
player.jumpstate = "ground"
end

if player.gravity > 185 then player.gravity = 185 end

player.y = player.gravity

--*************** End of Jumping stuff *******************
--*************** screen prints information concerning all objects x position
--to show how it works
screen:print(10,10,"Bullet 1: ".. tostring(BulletInfo[1].firing),green)
screen:print(10,20,"Bullet 2: "..tostring(BulletInfo[2].firing),green)
screen:print(10,30,"Bullet 3: "..tostring(BulletInfo[3].firing),green)
screen:print(10,40,"Bullet 4: "..tostring(BulletInfo[4].firing),green)
screen:print(10,50,"Bullet 5: "..tostring(BulletInfo[5].firing),green)
screen:print(10,60,"Direction: "..direction,green)

if pad:start()then
break
end

screen.waitVblankStart()
screen.flip()
oldpad = pad
end