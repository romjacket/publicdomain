black = Color.new(0,0,0)
red = Color.new(255,0,0) 
blue = Color.new(0,0,255) 
green = Color.new(0,255,0) 

crossHair = { img = Image.createEmpty(10,10), x = 210, y = 100 }
crossHair.img:clear(blue)

player = { img = Image.createEmpty(32,32), x = 210, y = 100 }
player.img:clear(green)

bullet = {} 

for add = 1, 10 do 
bullet[add] = { img = Image.createEmpty(5,5), x = player.x+15, y = player.y+15, fire = false, angle = 0, xMove = 0, yMove = 0, bulletSpeed = 4 }
bullet[add].img:clear(red)
end

pad = Controls.read()

crossPressedLastFrame = false 
currentBullet = 1 

function PlayerControl()

--******************** MOVEMENT OF CURSOR

pad = Controls.read()

if pad:right() then
crossHair.x = crossHair.x + 3
end

if pad:left() then
crossHair.x = crossHair.x - 3
end

if pad:down() then
crossHair.y = crossHair.y + 3
end

if pad:up() then
crossHair.y = crossHair.y - 3
end

--************************* MOVE PLAYER USING ANALOG --

if pad:analogX() >= 100 then
player.x = player.x + 5
end
	
if pad:analogX() <= -99 then
player.x = player.x - 5
end
	
if pad:analogY() >= 100 then
player.y = player.y + 5
end
	
if pad:analogY() <= -99 then
player.y = player.y - 5
end

if pad:cross() then
if not crossPressedLastFrame then
bullet[currentBullet].angle = math.atan2((crossHair.y) - (player.y + 15), (crossHair.x) - (player.x + 15))
bullet[currentBullet].xMove = math.cos(bullet[currentBullet].angle)
bullet[currentBullet].yMove = math.sin(bullet[currentBullet].angle)
bullet[currentBullet].fire = true
currentBullet = currentBullet + 1
end
crossPressedLastFrame = true
else
crossPressedLastFrame = false
end


--***************** FIRE BULLET BASED ON TRAJECTORY

for fire = 1,10 do
if bullet[fire].fire == true then
bullet[fire].x = bullet[fire].x + (bullet[fire].xMove * bullet[fire].bulletSpeed)
bullet[fire].y = bullet[fire].y + (bullet[fire].yMove * bullet[fire].bulletSpeed)
screen:blit(bullet[fire].x, bullet[fire].y, bullet[fire].img)
end
end
	
--***************** REGENARATION --

for regen = 1, 10 do
if bullet[regen].x < 0 or bullet[regen].x > 480 or bullet[regen].y < 0 or bullet[regen].y > 272 then
bullet[regen].fire = false
bullet[regen].x = player.x + 15
bullet[regen].y = player.y +15
end
end

if currentBullet > 10 then
currentBullet = 1
end
end

while true do
screen:clear()
pad = Controls.read()

screen:blit(player.x, player.y, player.img)
screen:blit(crossHair.x, crossHair.y, crossHair.img)

PlayerControl()

screen.waitVblankStart()
screen:flip()
end