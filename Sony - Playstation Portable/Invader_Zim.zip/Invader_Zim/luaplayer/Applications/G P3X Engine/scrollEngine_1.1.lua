red = Color.new(255,0,0)
blue = Color.new(0,0,255)
green = Color.new(0,255,0)

Map = {}
Map[1] = { x = 0, y = 0, img = Image.load("map.png") }
Map[2] = { x = 480, y = 0, img = Image.load("map2.png") }
Map[3] = { x = 960, y = 0, img = Image.load("map3.png") }
Map[4] = { x = 1440, y = 0, img = Image.load("map4.png") }
Map[5] = { x = 1920, y = 0, img = Image.load("map5.png") }

r1 = Image.load("zimr1.png")
r2 = Image.load("zimr2.png")
r3 = Image.load("zimr3.png")
r4 = Image.load("zimr4.png")
r5 = Image.load("zimr5.png")

l1 = Image.load("ziml1.png")
l2 = Image.load("ziml2.png")
l3 = Image.load("ziml3.png")
l4 = Image.load("ziml4.png")
l5 = Image.load("ziml5.png")

u1 = Image.load("up.png")
u2 = Image.load("up.png")
u3 = Image.load("up.png")
u4 = Image.load("up.png")
u5 = Image.load("up.png")

d1 = Image.load("down.png")
d2 = Image.load("down.png")
d3 = Image.load("down.png")
d4 = Image.load("down.png")
d5 = Image.load("down.png")

u = { u1, u2, u3, u4, u5 }
d = { d1, d2, d3, d4, d5 }
l = { l1, l2, l3, l4, l5 }
r = { r1, r2, r3, r4, r5 }

animt = 1

Player = {}
Player[1] = { x = 30, y = 100 }

crossHair = { img = Image.createEmpty(10,10), x = 210, y = 100 }
crossHair.img:clear(blue)

crossPressedLastFrame = false
currentBullet = 1

ground = Image.createEmpty(480,10)

player = {}
player.img = u1
player.d = u
player.gravity = 185
player.y = 185
player.x = 240
player.jumpspeed = 10
player.jumpstate = "ground"
playerHeight = 32
playerWidth = 32

bullet = {}

for add = 1, 10 do
bullet[add] = { img = Image.createEmpty(5,5), x = player.x+15, y = player.y+15, fire = false, angle = 0, xMove = 0, yMove = 0, bulletSpeed = 4 }
bullet[add].img:clear(red)
end

block = Image.createEmpty(32,32)
block:clear(green)

function collisionCheck(object)
if (player.x + playerWidth > object.x) and (player.x < object.x + object.width) and (player.y + playerHeight > object.y) and (player.y < object.y + object.height) then
player.x = oldx
player.y = oldy
end
end

--Functions

function bulletSetup()

--******************** MOVEMENT OF CURSOR

pad = Controls.read()

if pad:right() then
crossHair.x = crossHair.x + 3
end

if pad:left() then
crossHair.x = crossHair.x - 3
end

if pad:down() then
crossHair.y = crossHair.y + 3
end

if pad:up() then
crossHair.y = crossHair.y - 3
end

if pad:cross() then
if not crossPressedLastFrame then
bullet[currentBullet].angle = math.atan2((crossHair.y) - (player.y + 15), (crossHair.x) - (player.x + 15))
bullet[currentBullet].xMove = math.cos(bullet[currentBullet].angle)
bullet[currentBullet].yMove = math.sin(bullet[currentBullet].angle)
bullet[currentBullet].fire = true
currentBullet = currentBullet + 1
end
crossPressedLastFrame = true
else
crossPressedLastFrame = false
end


--***************** FIRE BULLET BASED ON TRAJECTORY

for fire = 1,10 do
if bullet[fire].fire == true then
bullet[fire].x = bullet[fire].x + (bullet[fire].xMove * bullet[fire].bulletSpeed)
bullet[fire].y = bullet[fire].y + (bullet[fire].yMove * bullet[fire].bulletSpeed)
screen:blit(bullet[fire].x, bullet[fire].y, bullet[fire].img)
end
end
	
--***************** REGENARATION --

for regen = 1, 10 do
if bullet[regen].x < 0 or bullet[regen].x > 480 or bullet[regen].y < 0 or bullet[regen].y > 272 then
bullet[regen].fire = false
bullet[regen].x = player.x + 15
bullet[regen].y = player.y +15
end
end

if currentBullet > 10 then
currentBullet = 1
end
end

function moveMap()

pad = Controls.read()

--**************** Move the first image left and right but stops at x = 0 ************************
if pad:left() and Map[1].x < 0 and player.x == 240 then
Map[1].x =  Map[1].x + 3
end
if player.x == 240 and pad:right() then
Map[1].x =  Map[1].x - 3
end

--**************** Move player so that it wont leave the screen ***********************
if Map[1].x == 0 and Map[2].x == 480 and Map[3].x == 960 and pad:left() and player.x < 241 and player.x > 0 then
player.x = player.x - 2
end

if Map[1].x == 0 and Map[2].x == 480 and Map[3].x == 960 and pad:right() and player.x < 240 then
player.x = player.x + 2
end


-- Move the second image left and right
if pad:left() and Map[2].x < 480 and player.x == 240 then
Map[2].x =  Map[2].x + 3
end
if player.x == 240 and pad:right() then
Map[2].x =  Map[2].x - 3
end

-- Move the last image left and right
if pad:left() and Map[3].x < 960 and player.x == 240 then
Map[3].x =  Map[3].x + 3
end
if player.x == 240 and pad:right() then
Map[3].x =  Map[3].x - 3
end

if pad:left() and Map[4].x < 1440 and player.x == 240 then
Map[4].x =  Map[4].x + 3
end
if player.x == 240 and pad:right() then
Map[4].x =  Map[4].x - 3
end

if pad:left() and Map[5].x < 1920 and player.x == 240 then
Map[5].x =  Map[5].x + 3
end
if player.x == 240 and pad:right() then
Map[5].x =  Map[5].x - 3
end

--stop player moving off the right of the screen
if Map[5].x == 0 and player.x > 239 and player.x < 448 and pad:right() then
player.x = player.x + 2
end
if Map[5].x == 0 and player.x > 240 and pad:left() then
player.x = player.x - 2
end
end

--***********ANIMATION FUCTION
function anim()
animt = animt + 1 
if animt > 40 then
animt = 1
end
if animt < 6 then
player.img = player.d[1]
end
if animt > 5 then
player.img = player.d[2]
end
if animt > 10 then
player.img = player.d[3]
end
if animt > 15 then
player.img = player.d[2]
end
if animt > 20 then
player.img = player.d[1]
end
if animt > 25 then
player.img = player.d[4]
end
if animt > 30 then
player.img = player.d[5]
end
if animt > 35 then
player.img = player.d[4]
end
end

--************** Ends the function and starts the main loop *****************

while true do
oldx = player.x
oldy = player.y

screen:clear()
moveMap()

for a = 1,5 do
screen:blit(Map[a].x,Map[a].y,Map[a].img)
end

bulletSetup()

screen:blit(crossHair.x, crossHair.y, crossHair.img)
screen:blit(player.x,player.y,player.img)

if pad:up() then
player.d = u
anim()
end

if pad:down() then
player.d = d
anim()
end

if pad:left() then
player.d = l
anim()
end

if pad:right() then
player.d = r
anim()
end

if pad:start() then
break 
end

--************** Jumping Stuff ***************
if pad:circle() and player.jumpstate == "ground" then player.jumpstate = "jumping" end

if player.jumpstate == "jumping" then
player.jumpspeed = player.jumpspeed - 0.5
player.gravity = player.gravity - player.jumpspeed
end

if player.gravity < 0 then
player.jumpstate = "falling"
end

if player.gravity < 185 and player.jumpstate == "falling" then
player.gravity = player.gravity + (player.jumpspeed + 3)
end

if player.gravity == 185 then
player.jumpspeed = 10
player.jumpstate = "ground"
end

if player.gravity > 185 then player.gravity = 185 end

player.y = player.gravity

--*************** End of Jumping stuff *******************

screen.waitVblankStart()
screen.flip()
oldpad = pad
end