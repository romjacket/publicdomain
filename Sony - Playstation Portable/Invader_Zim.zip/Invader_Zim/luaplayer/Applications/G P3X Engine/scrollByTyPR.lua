function getRemainder(i, j)
   while i >= j do
      i = i - j
   end

   return i
end

function blit(obj)
   screen:blit(obj.x-offset, obj.y, obj.img)
end

function girFollow(followDist, followSpeed)
   if player.x-followDist > gir.x+gir.w then
      gir.x=gir.x+followSpeed
      if player.x-followDist <= gir.x+gir.w then
         gir.x=player.x-followDist-gir.w
         gir.follow=false
      end

   elseif player.x+player.w < gir.x-followDist then
      gir.x=gir.x-followSpeed
      if gir.x-followDist <= player.x+player.w then
         gir.x=player.x+player.w+followDist
         gir.follow=false
      end
   end
end


white=Color.new(255, 255, 255)
black=Color.new(0, 0, 0)
red=Color.new(255, 0, 0)
blue=Color.new(0, 255, 0)
green=Color.new(0, 0, 255)

offset = 0

bg={
   {img=Image.createEmpty(480, 272), x=0},
   {img=Image.createEmpty(480, 272), x=480},
   {img=Image.createEmpty(480, 272), x=480*2},
   {img=Image.createEmpty(480, 272), x=480*3}
   }

bg[1].img:clear(white)
bg[2].img:clear(black)
bg[3].img:clear(white)
bg[4].img:clear(black)

gir={
   img=Image.createEmpty(16, 16),
   x=0, y=256, h=16, w=16,
   follow=false
   }

player={
   img=Image.createEmpty(16, 16),
   x=0, y=256, h=16, w=16
   }

gir.img:clear(blue)
player.img:clear(green)

while true do

   screen:clear()
   pad=Controls.read()

   if pad:right() then
      player.x=player.x+5
      if player.x-offset > 330 then
         offset=offset+5
      end
      if player.x-30 > gir.x+gir.w then
         gir.follow = true
      end
   end

   if pad:left() then
      player.x=player.x-5
      if player.x-offset < 150 then
         offset=offset-5
      end
      if gir.x-30 > player.x+player.w then
         gir.follow = true
      end
   end

   if gir.follow then
      girFollow(5, 3)
   end

   for a=1, table.getn(bg) do
      screen:blit(bg[a].x-(getRemainder(offset, table.getn(bg)*480)), 0, bg[a].img)
   end

   blit(player)
   blit(gir)

   screen.waitVblankStart()
   screen.flip()

   if pad:start() then break end
end