--Add any pre-game stuff here (logos, whatever)
sound = Sound.load("shock.wav",false)
sound2 = Sound.load("comp.wav",false)
sound3 = Sound.load("prov.wav",false)
pad = Controls.read()

dofile("shockzone.lua")

dofile("menu.lua")

numSS = 1 --This will probably be loaded from a file later
function screenShot()
   if pad:select() then
      screen:save("screenshot"..numSS..".png")
      numSS = numSS + 1
   end
end

level = 0 --Level must be 0 to start with main menu
maxLevel = 1 --Number of total levels
levelState = "" --Determins whether to pass to next level

while level >= 0 do --Change level to negative number to quit

   if level == 0 then
      dofile("menu.lua")
      level = menu()
   end

   if level == 1 then
      --dofile("scene1.lua")
      dofile("level1.lua")
      levelState = level1(3, 300, 5, 20000, 180, true)
      dofile("level1clear.lua")
   end

   --add more levels here later

   if levelState == "win" then
      level = level + 1
   elseif levelState == "quit" then
      level = 0
   --elseif levelState == "lose" then
      --do what happens if lose
   end

   if level == 0 or level > maxLevel then
      level = 0 --Add other stuff for winning game here
   end
end

   