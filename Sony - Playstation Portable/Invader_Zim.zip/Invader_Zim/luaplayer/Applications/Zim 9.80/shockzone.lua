sound:play()
fader = Image.createEmpty(480,272)
intro = Image.load("ShockZIMzone-1.png")
alphaValue = 255
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
while true do
screen:clear()
screen:blit(0,0,intro)
screen:blit(0,0,fader)
if alphaValue > 0 then
alphaValue = alphaValue - 100
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
screen.waitVblankStart(120) -- pause so it dosn't fade in and then imdeiatly fade out
while true do
screen:clear()
screen:blit(0,0,intro)
screen:blit(0,0,fader)
if alphaValue < 255 then
alphaValue = alphaValue + 100
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart(30)
end

sound2:play()
fader = Image.createEmpty(480,272)
intro = Image.load("luasplash.png")
alphaValue = 255
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
while true do
screen:clear()
screen:blit(0,0,intro)
screen:blit(0,0,fader)
if alphaValue > 0 then
alphaValue = alphaValue - 200
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
screen.waitVblankStart(120) -- pause so it dosn't fade in and then imdeiatly fade out
while true do
screen:clear()
screen:blit(0,0,intro)
screen:blit(0,0,fader)
if alphaValue < 255 then
alphaValue = alphaValue + 100
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart(30)
sound = nil
sound2 = nil
sound3 = nil
end




