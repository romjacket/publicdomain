Ogg.load("TEST.OGG")

function menu()

zim1 = Image.load("ZIMmenuBLINK1.png")
zim2 = Image.load("ZIMmenuBLINK2.png")
zim3 = Image.load("ZIMmenuBLINK3.png")

bground = Image.load("menu2.png")

counter = Timer.new()
counter:start()
counterMax = math.random(2200, 8000)

while true do

Ogg.play()

screen:clear()
screen:blit(0,0,bground)

timeElapsed = counter:time()

if timeElapsed >= counterMax then
counterMax = math.random(2200, 8000)
counter:reset(0)
counter:start()
end

currentTime = counter:time()
if currentTime > 0 and currentTime < 1500  then
screen:blit(310, 40, zim1)
end

if currentTime > 1500 and currentTime < 1700 then
screen:blit(310,40,zim2)
end

if currentTime > 1700 and currentTime < 1900 then
screen:blit(310,40,zim3)
end

if currentTime > 1900 and currentTime < 2100 then
screen:blit(310,40,zim2)
end

if currentTime > 2100 then
screen:blit(310,40,zim1)
end

if Controls.read():start() then
   break
end

screen.waitVblankStart()
screen.flip()
end

-- menu loop
white = Color.new (255,255,255)

storyMode = Image.load("m1.png")
challengeMode = Image.load("m2.png")
Options = Image.load("m3.png")

storymodeSubIcon1 = Image.load("1.png")
challengemodeSubIcon2 = Image.load("2.png")
OptionsSubIcon3 = Image.load("3.png")

bground = Image.load("Menuscr2.png")

menuState = "storymode"

while true do
screen:clear()
pad = Controls.read()

if menuState == "storymode" then
screen:clear()

screen:blit(0,0,bground)
screen:blit(30,22,storyMode)
screen:blit(86,170,storymodeSubIcon1)

if menuState == "storymode" and pad:cross() then
screen:clear()
Ogg.stop()
return 1
end

if menuState == "storymode" and pad:right() and not oldpad:right() then
menuState = "challengeMode"
end

if menuState == "storymode" and pad:left() and not oldpad:left() then
menuState = "Options"
end
oldpad = pad
end

if menuState == "challengeMode" then
screen:clear()

screen:blit(0,0,bground)
screen:blit(30,22,challengeMode)
screen:blit(190,170,challengemodeSubIcon2)

if menuState == "challengeMode" and pad:cross() then
screen:print(200,100,"test 2",white)
end

if menuState == "challengeMode" and pad:right() and not oldpad:right() then
menuState = "Options"
end

if menuState == "challengeMode" and pad:left() and not oldpad:left() then
menuState = "storymode"
end
oldpad = pad
end

if menuState == "Options" then
screen:clear()

screen:blit(0,0,bground)
screen:blit(30,22,Options)
screen:blit(330,170,OptionsSubIcon3)

if menuState == "Options" and pad:right() and not oldpad:right() then
menuState = "storymode"
end

if menuState == "Options" and pad:left() and not oldpad:left() then
menuState = "challengeMode"
end

if menuState == "Options" and pad:cross() then
screen:print(200,100,"Test 3",white)
end
end

screen.waitVblankStart()
screen.flip()
oldpad = pad
end

end
	
