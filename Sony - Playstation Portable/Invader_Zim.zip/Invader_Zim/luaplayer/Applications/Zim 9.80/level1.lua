function level1(maxRocks, rockChance, startLives, speedTime, endTime, moveSide)


dofile("level1/splash.lua")
dofile("level1/funcs.lua")

math.randomseed(os.time())
time = Timer.new()
time:start()
time:stop()
time:reset()

player = {}
player.x = 0
player.y = 0
player.h = 60
player.w = 94
player.img = Image.load("level1/ship.png")
player.hitImg = Image.load("level1/shipHIT.png")

player.shield = Image.load("level1/shipSHIELD.png")
shield = {
   img = Image.load("level1/SHIELDicon.png"),
   x = 0,
   y = 0,
   have = false,
   use = false,
   timer = Timer.new(),
   onScreen = false
   }
shield.h = shield.img:height()
shield.w = shield.img:width()
player.moveSide = moveSide
player.hit = false
player.hitTimer = Timer.new()

player.hitTimer:start()
player.hitTimer:stop() --Prevents an error of the timer already being something it shouldnt
player.hitTimer:reset()

shield.timer:start()
shield.timer:stop()
shield.timer:reset()

rock = {}
rock.img = {
   Image.load("level1/rockA1.png"),
   Image.load("level1/rockA2.png"),
   Image.load("level1/rockA3.png")
   }
rock.h = rock.img[1]:height()
rock.w = rock.img[1]:width()
rock.num = 0
rock.max = maxRocks
rock.chance = rockChance
rock.speed = speedTime
rock.timer = Timer.new()
rock.Xlimit = 240
rock.acc = 30

lives = {
   Image.load("level1/board5.png"),
   Image.load("level1/board4.png"),
   Image.load("level1/board3.png"),
   Image.load("level1/board2.png"),
   Image.load("level1/board.png"),
   num = startLives
   }

level1bg = {
   img = Image.load("level1/bg.png"),
   x1 = 0,
   x2 = 480,
   offset = 0
   }

prog = {}
prog.bar = {}
prog.arr = {}

prog.bar.img = Image.load("level1/PROGRESSbar.png")
prog.bar.x = 0
prog.bar.y = 0

prog.arr.img = Image.load("level1/PROGRESSpointer.png")
prog.arr.x = 92
prog.arr.y = 8
prog.arr.mid = 7

prog.numDots = 42
prog.dotInt = 7
prog.timeInt = (endTime*1000)/prog.numDots

state = "playing"

time:start()
rock.timer:start()

while state == "playing" do
   pad = Controls.read()

   screen:clear()

   screenShot()

   movePlayer()
   moveRock()

   for a = 1, rock.num do
      colide = rockCollision(a)
      if colide then
         break
      end
   end

   bgScroll()
   shieldFunc()
   blit()
   pause()

   if time:time()/1000 > endTime then
      state = "win"
   end

   if lives.num == 0 then
      dofile("level1/death.lua")
   end

   if pad:start() then
      start = true
   else
      start = false
   end


   screen.flip()
end

return state
end