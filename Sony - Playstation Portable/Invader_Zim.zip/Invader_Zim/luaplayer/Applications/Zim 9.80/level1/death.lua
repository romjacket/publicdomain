fader = Image.createEmpty(480,272)
intro = Image.load("level1/death.png")
alphaValue = 255
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
while true do
screen:clear()
screen:blit(0,0,intro)
screen:blit(0,0,fader)
if alphaValue > 0 then
alphaValue = alphaValue - 5
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
screen.waitVblankStart(60) -- pause so it dosn't fade in and then imdeiatly fade out
while true do
screen:clear()
screen:blit(0,0,intro)
screen:blit(0,0,fader)
if alphaValue < 255 then
alphaValue = alphaValue + 5
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
state = "lose"
end

