--THIS IS A FUNCTIONS FILE FOR LEVEL 1

counter = 0 -- obo

function movePlayer() --READS CONTROLS AND MOVES PLAYER ACCORDINGLY

   if pad:up() and player.y > -30 then
      player.y = player.y - 5
   elseif pad:analogY() < -32 and player.y > -30 then
      player.y = player.y - math.floor(pad:analogY()/-30)
   end

   if pad:down() and player.y < 234 then
      player.y = player.y + 5
   elseif pad:analogY() > 32 and player.y < 234 then
      player.y = player.y + math.floor(pad:analogY()/30)
   end

   --BELLOW TO END OF FUNCTION WAS ADDED AFTER COMPLETION FOR LEFT/RIGHT MOVEMENT
   if player.moveSide then
      if pad:left() and player.x > -30 then
         player.x = player.x - 5
      elseif pad:analogX() < -32 and player.x > -30 then
         player.x = player.x - math.floor(pad:analogX()/-30)
      end

      if pad:right() and player.x < 442 then
         player.x = player.x + 5
      elseif pad:analogX() > 32 and player.x < 442 then
         player.x = player.x + math.floor(pad:analogX()/30)
      end
   end
end


function moveRock()

   local rand=0

   --Create rocks

   rand=math.random(1, rock.chance)

   if ( rock.num < rock.max ) and ( rand==1 or rock.num==0 ) then

      nRock = {}
      nRock.speed = {}
      nRock.dir = {}

      nRock.dir.x = -1
      nRock.dir.y = -1

      rand=math.random(1, 3)

      if rand==1 then --Coming from side
         nRock.x = 480
         nRock.y = math.random(0-rock.h, 272)
      else --Coming from top or bottom
         nRock.x = math.random(rock.Xlimit, 480)
         if rand==2 then --top
            nRock.y = 0-rock.h
            nRock.dir.y = 1
         else --bottom
            nRock.y = 272
            nRock.dir.y = -1
         end
      end

      --Set speed

      local px=math.random(-1*rock.acc, rock.acc)+player.x
      local py=math.random(-1*rock.acc, rock.acc)+player.y
      local rx=math.random(-1*rock.acc, rock.acc)+nRock.x
      local ry=math.random(-1*rock.acc, rock.acc)+nRock.y

      local mx=rx-px
      local my=ry-py

      local dis=math.sqrt(mx^2 + my^2)

      local frac=(time:time()/rock.speed)/dis

      nRock.speed.x=frac*mx
      nRock.speed.y=frac*my

      if nRock.speed.x < 0 then
         nRock.speed.x=nRock.speed.x*-1
      end

      if nRock.speed.y < 0 then
         nRock.speed.y=nRock.speed.y*-1
      end

      if nRock.speed.x < 1 then
         nRock.speed.x=1
      end

      if nRock.speed.y < 1 then
         nRock.speed.x=1
      end

      nRock.anim = 1

      table.insert(rock, nRock)

      rock.num = rock.num+1
   end

   --Move rocks

   for a=1, rock.num do
      rock[a].x=rock[a].x+(rock[a].speed.x*rock[a].dir.x)
      rock[a].y=rock[a].y+(rock[a].speed.y*rock[a].dir.y)
   end

   --Rock Anim

   if rock.timer:time()>=250 then
      for a=1, rock.num do
         rock[a].anim=rock[a].anim+1
         if rock[a].anim==4 then
            rock[a].anim=1
         end
      end
      rock.timer:stop()
      rock.timer:reset()
      rock.timer:start()
   end

   --Remove rocks

   for a=1, rock.num do
      if ( rock[a].x > 480 ) or ( rock[a].x < 0-rock.w ) or ( rock[a].y > 272 ) or ( rock[a].y < 0-rock.h ) then
         table.remove(rock, a)
         rock.num=rock.num-1
         break
      end
   end
end

function rockCollision(rocknum) --THANKS TO EVILMANA. CHECKS IF ROCK IS COLLIDING WITH PLAYER, DELETES ROCK AND LOSE A LIFE.

   if (player.x + player.w > rock[rocknum].x) and (player.x < rock[rocknum].x + rock.w) and (player.y + player.h > rock[rocknum].y) and (player.y < rock[rocknum].y + rock.h) then
      table.remove(rock, rocknum)
      rock.num = rock.num - 1

      if not player.hit then -- obo
         lives.num = lives.num-1
         player.hit = true
         player.hitTimer:start()
      end
      return true
   else
      return false
   end
end

function bgScroll() --TAKES CARE OF MAKING THE BG SCROLL
   if level1bg.offset < 480 then
      level1bg.offset = level1bg.offset+1
   else
      level1bg.offset = 0
   end
if pad:right() or pad:analogX() > 32 then
	level1bg.offset = level1bg.offset+3
else 
	level1bg.offset = level1bg.offset+1
end
end

function blit() --BLITS ALL NECESSARY IMAGES TO THE SCREEN

	screen:blit(level1bg.x1-level1bg.offset, 0, level1bg.img)
	screen:blit(level1bg.x2-level1bg.offset, 0, level1bg.img)
	screen:blit(player.x, player.y, player.img) -- obo

	screen:blit(prog.bar.x, prog.bar.y, prog.bar.img)
	screen:blit( prog.arr.x+((time:time()/prog.timeInt)*prog.dotInt)-prog.arr.mid, prog.arr.y, prog.arr.img)

	if player.hit then
	local speed = 4
	local length = 2000
		if (player.hitTimer:time() < length) then
			if (counter < speed) then
				screen:blit(player.x, player.y, player.hitImg)
			elseif(counter <= speed  * 2) then		
				screen:blit(player.x, player.y, player.img)
			end
		
			if (counter == speed  * 2) then		
				counter = 0 
			end
			counter = counter + 1
			
		else
			screen:blit(player.x, player.y, player.img)
			player.hitTimer:stop()
			player.hitTimer:reset()
			player.hit = false
		end
	end	-- player hit timer
	
	if shield.use then
		screen:blit(player.x, player.y, player.shield)
	end -- end obo

	if rock.num > 0 then --THIS IS ONLY NEEDED IF THE SLIM CHANCE OF A ROCK GOING OFFSCREEN AND HITTING THE PLAYER AT THE SAME TIME
      for a = 1, rock.num do
         screen:blit(rock[a].x, rock[a].y, rock.img[rock[a].anim])
      end
   end

   if lives.num > 0 then
      screen:blit(385, 215, lives[lives.num])
   end

   if shield.have then
      screen:blit(300, 215, shield.img)
   end

   if shield.onScreen then
      screen:blit(shield.x, shield.y, shield.img)
   end
   screen.waitVblankStart()
end

function shieldFunc()

   if shield.use then
      if shield.timer:time() > 10000 then
         shield.timer:stop()
         shield.timer:reset()
         shield.use = false
      end
   end

   if shield.have and pad:cross() then
      shield.use = true
      shield.have = false
      shield.timer:start()
   end

   if shield.onScreen then
      shield.x = shield.x - math.random(5)
      if shield.x < 0-shield.w then
         shield.onScreen = false
      end

   else
      local rand = math.random(5000)
      if rand == 1 then
         shield.x = 480
         shield.y = math.random(272-shield.h)
         shield.onScreen = true
      end
   end

   if (player.x + player.w > shield.x) and (player.x < shield.x + shield.w) and (player.y + player.h > shield.y) and (player.y < shield.y + shield.h) and (not shield.have) and (shield.onScreen) then
      shield.have = true
      shield.onScreen = false
   end

   if shield.use and player.hit and player.hitTimer:time() < 250 then --Last part to prevent using shield right after getting hit
      lives.num = lives.num + 1
      player.hit = false
      shield.use = false
      player.hitTimer:stop()
      player.hitTimer:reset()
      shield.timer:stop()
      shield.timer:reset()
   end
end

function pause()
   if pad:start() and not start then
      time:stop()
      start = true
      local red = Color.new(255, 0, 0)

      while true do
         screen:clear()
         blit()
         screen:print(200, 130, "GAME PAUSED", red)
         screen:print(180, 140, "PRESS SELECT TO QUIT", red)
         screen:print(190, 150, "OR START TO RESUME", red)
         screen.waitVblankStart()
         screen.flip()

         pad = Controls.read()
         if pad:select() then
            state = "quit"
            break
         end
         if pad:start() and not start then
            start = true
            break
         elseif not pad:start() then
            start = false
         end
      end
   end
end