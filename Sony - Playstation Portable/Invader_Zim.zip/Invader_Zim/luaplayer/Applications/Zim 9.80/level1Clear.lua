
level1 = nil
player = nil
rock = nil
lives = nil
level1bg = nil
time = nil

movePlayer = nil
moveRock = nil
rockCollision = nil
bgScroll = nil
blit = nil
shield = nil
shieldFunc = nil