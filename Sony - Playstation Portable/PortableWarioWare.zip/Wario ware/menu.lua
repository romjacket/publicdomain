function musique()
son = Sound.load("sound/selection.wav")
local sound = son
voice = sound:play()
end

font = Font.load("font/font.ttf")
font:setPixelSizes(12,24)



credits = Image.load("images/cricon.png")
selection = Image.load("images/seicon.png")
aleatoire = Image.load("images/alicon.png")
menu = Image.load("images/menu.png")
quitter = Image.load("images/quitter.png")
selecteur = Image.load("images/selecteur.png")

oldpad = Controls.read()

choix = 1

while true do
screen:clear()

pad = Controls.read()

screen:blit(0,0,menu)

if choix == 4 and pad:left() and oldpad:left() ~= pad:left() then
choix = 3
end

if choix == 2 and pad:left() and oldpad:left() ~= pad:left() then
choix = 1
end

if choix == 3 and pad:up() and oldpad:up() ~= pad:up() then
choix = 1
end

if choix == 4 and pad:up() and oldpad:up() ~= pad:up() then
choix = 2
end

if choix == 1 and pad:right() and oldpad:right() ~= pad:right() then
choix = 2
end

if choix == 1 and pad:down() and oldpad:down() ~= pad:down() then
choix = 3
end

if choix == 3 and pad:right() and oldpad:right() ~= pad:right()  then
choix = 4
end

if choix == 2 and pad:down() and oldpad:down() ~= pad:down() then
choix = 4
end




if choix == 1 then
screen:blit(34,80,selecteur)
if pad:cross() and oldpad:cross() ~= pad:cross() then
musique()
dofile("modeselection/menuselectionjeux.lua")
voice:stop()
end
end

if choix == 2  then
screen:blit(245,80,selecteur)
if pad:cross() and oldpad:cross() ~= pad:cross() then
musique()
dofile("modealeatoire/prochainement.lua")
voice:stop()
end
end

if choix == 3  then
screen:blit(34,150,selecteur)
if pad:cross() and oldpad:cross() ~= pad:cross() then
musique()
dofile("credits.lua")
voice:stop()
end
end


if choix == 4  then
screen:blit(245,150,selecteur)
if pad:cross() and oldpad:cross() ~= pad:cross() then
musique()
System.Quit()
voice:stop()
end
end

screen:blit(45,90,selection)
screen:blit(255,90,aleatoire)
screen:blit(45,160,credits)
screen:blit(275,153,quitter)

if System.getTime(5) =="pm" then
screen:fontPrint(font,480-(8*6),268,(System.getTime(1)+12)..":"..System.getTime(2),Color.new(0,0,0))
else    
screen:fontPrint(font,480-(8*6),268,System.getTime(1)..":"..System.getTime(2),Color.new(0,0,0))
end



oldpad = pad
screen.waitVblankStart()
screen.flip()
end



credits = nil
selection = nil
aleatoire = nil
menu = nil
quitter = nil
selecteur = nil


