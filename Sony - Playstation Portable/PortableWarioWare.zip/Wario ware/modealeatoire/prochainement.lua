statut = 1

while true do
screen:clear()

pad = Controls.read()

if statut == 1 then
System.message("Ce mode de jeu n'est pas disponible pour le moment mais le sera dans une prochaine version",0)
break
end


screen.waitVblankStart()
screen.flip()
end
