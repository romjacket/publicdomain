
font = Font.load("font/font.ttf")
font:setPixelSizes(12,24)




Image1 = Image.load ("images/anim1.png")
Image2 = Image.load ("images/anim2.png")
 

oldpad = Controls.read()

minuteur = Timer.new()
minuteur:start()

while true do
screen:clear()

pad = Controls.read()

currentTime = minuteur:time()
 

if currentTime < 450 then
screen:blit (0,0,Image1)
end
 
if currentTime > 450 then
screen:blit(0,0,Image2)
end
 
if currentTime > 900 then
minuteur:stop()
minuteur:reset(0)
minuteur:start()
end
 

if pad:start() and oldpad:start() ~= pad:start() then
dofile("menu.lua")
end


if System.getTime(5) =="pm" then
screen:fontPrint(font,480-(8*6),268,(System.getTime(1)+12)..":"..System.getTime(2),Color.new(0,0,0))
else    
screen:fontPrint(font,480-(8*6),268,System.getTime(1)..":"..System.getTime(2),Color.new(0,0,0))
end



oldpad = pad
screen.waitVblankStart()
screen.flip()
end


Image1 = nil
Image2 = nil