
function musique()
son = Sound.load("sound/boum.wav")
local sound = son
voice = sound:play()
end



minuteur = Timer.new()
minuteur:start()


texteminijeux1 = Image.load("modeselection/minijeux1/texte.png")
souris = Image.load("modeselection/minijeux1/curs.png")
tetewario = Image.load("modeselection/minijeux1/tetewario1.png")
gagne = Image.load("modeselection/minijeux1/gagne.png")
perdu = Image.load("modeselection/minijeux1/perdu.png")
bombe1 = Image.load("modeselection/minijeux1/bombe1.png")
bombe2 = Image.load("modeselection/minijeux1/bombe2.png")
bombe3 = Image.load("modeselection/minijeux1/bombe3.png")
bombe4 = Image.load("modeselection/minijeux1/bombe4.png")
bombe5 = Image.load("modeselection/minijeux1/bombe5.png")
bombe6 = Image.load("modeselection/minijeux1/bombe6.png")
bombe7 = Image.load("modeselection/minijeux1/bombe7.png")
un = Image.load("modeselection/minijeux1/bun.png")
deux = Image.load("modeselection/minijeux1/bdeux.png")
trois = Image.load("modeselection/minijeux1/btrois.png")
boum = Image.load("modeselection/minijeux1/boum.png")

sourisx = 190
sourisy = 120
vitesse = 1.2

niveau = 50


oldpad = Controls.read()

while true do 
screen:clear()

pad = Controls.read()

currentTime = minuteur:time()
timer = currentTime/1000
m_timer = (math.floor(timer)-15)

if pad:up()  and sourisy >= 0 then
sourisy = sourisy - vitesse
end
if pad:down() and sourisy <= 255 then
sourisy = sourisy + vitesse
end
if pad:right() and sourisx <= 470 then
sourisx = sourisx + vitesse
end
if pad:left()  and sourisx >= 0 then
sourisx = sourisx - vitesse
end

if m_timer >= -15 and m_timer < -10 then
screen:blit(20,30,texteminijeux1)
end


if m_timer >= -10 and m_timer < 0 then
screen:blit(0,0,tetewario)
screen:blit(sourisx,sourisy,souris)
screen:fillRect(10,4,niveau,20,Color.new(255,255,0,255))
if pad:cross() and oldpad:cross() ~= pad:cross() and sourisx < 206 and sourisx > 108 and sourisy < 186 and sourisy > 129 then
niveau = niveau + 10
end
if not pad:cross() and not oldpad:cross() ~= not pad:cross() and sourisx < 206 and sourisx > 108 and sourisy < 186 and sourisy > 129 then
niveau = niveau - 5
end
end

if m_timer >= 0 and niveau >= 280 then 
screen:blit(0,0,gagne)
if m_timer == 6 then
System.memclean() 
voice:stop()
dofile("menu.lua")
end
end
if m_timer >= 0 and niveau <= 279 then
screen:blit(0,0,perdu)
if m_timer == 6 then
System.memclean()
voice:stop()
dofile("menu.lua")
end
end

if m_timer == -10 then
screen:blit(0,200,bombe1)
end

if m_timer == -9 then
screen:blit(0,200,bombe2)
end

if m_timer == -8 then
screen:blit(0,200,bombe3)
end

if m_timer == -7 then
screen:blit(0,200,bombe4)
end

if m_timer == -6 then
screen:blit(0,200,bombe5)
end

if m_timer == -5 then
screen:blit(0,200,bombe6)
end

if m_timer == -4 then
screen:blit(0,200,bombe7)
end

if m_timer == -3 then
screen:blit(0,200,bombe7)
screen:blit(2,170,trois)
end

if m_timer == -2 then
screen:blit(0,200,bombe7)
screen:blit(2,170,deux)
end

if m_timer == -1 then
screen:blit(0,200,bombe7)
screen:blit(2,170,un)
end

if m_timer == 0 then
screen:blit(0,200,boum)
musique()
end


oldpad = pad
screen.waitVblankStart()
screen.flip()
end



texteminijeux1 = nil
souris = nil
tetewario = nil
gagne = nil
perdu = nil
bombe1 = nil
bombe2 = nil
bombe3 = nil
bombe4 = nil
bombe5 = nil
bombe6 = nil
bombe7 = nil
son = nil
un = nil
deux = nil
trois = nil
boum = nil
