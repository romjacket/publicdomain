sccnt = 1
function musique()
son = Sound.load("sound/boum.wav")
local sound = son
voice = sound:play()
end


rouge = Color.new(255,0,0)
	  bleu = Color.new(0,0,255)

minuteur = Timer.new()
minuteur:start()


victoire = Image.load("modeselection/minijeux3/victoire.png")
souris = Image.load("modeselection/minijeux3/tape.png")
back = Image.load("modeselection/minijeux3/back.png")
mos = Image.load("modeselection/minijeux3/mos.png")
texteminijeux1 = Image.load("modeselection/minijeux3/texte.png")
gagne = Image.load("modeselection/minijeux3/gagne.png")
perdu = Image.load("modeselection/minijeux3/perdu.png")
bombe1 = Image.load("modeselection/minijeux3/bombe1.png")
bombe2 = Image.load("modeselection/minijeux3/bombe2.png")
bombe3 = Image.load("modeselection/minijeux3/bombe3.png")
bombe4 = Image.load("modeselection/minijeux3/bombe4.png")
bombe5 = Image.load("modeselection/minijeux3/bombe5.png")
bombe6 = Image.load("modeselection/minijeux3/bombe6.png")
bombe7 = Image.load("modeselection/minijeux3/bombe7.png")
un = Image.load("modeselection/minijeux3/bun.png")
deux = Image.load("modeselection/minijeux3/bdeux.png")
trois = Image.load("modeselection/minijeux3/btrois.png")
boum = Image.load("modeselection/minijeux3/boum.png")
splash = Image.load("modeselection/minijeux3/splash.png")

sourisx = 190
sourisy = 120
vitesse = 4.5

niveau = 50

oldpad = Controls.read()

appuie = 0
score = 0

while true do 
screen:clear()



currentTime = minuteur:time()
timer = currentTime/1000
m_timer = (math.floor(timer)-15)



if m_timer >= -15 and m_timer < -10 then
screen:blit(20,30,texteminijeux1)
end



if m_timer >= -10 and m_timer < 0 then

if pad:select() then
screen:save("screen"..sccnt..".png")
sccnt=sccnt+1
end

pad = Controls.read()

if pad:up()  and sourisy >= 0 then
sourisy = sourisy - vitesse
end
if pad:down() and sourisy <= 255 then
sourisy = sourisy + vitesse
end
if pad:right() and sourisx <= 470 then
sourisx = sourisx + vitesse
end
if pad:left()  and sourisx >= 0 then
sourisx = sourisx - vitesse
end

screen:blit(0,0,back)

if appuie == 0 and score == 0 then
	  screen:blit(240,135,mos )
	  if pad:cross() and sourisx < 290 and sourisx > 240 and sourisy < 185 and sourisy > 135 then
	  screen:blit(240,135,splash )
	  appuie = 1 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 1 and score == 1 then 
	  
	  screen:blit(100,25,mos)
	  if pad:cross() and sourisx < 150 and sourisx > 100 and sourisy < 75 and sourisy > 25 then
	  screen:blit(100,25,splash)
	  appuie = 2 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 2 and score == 2 then 
	  
	  screen:blit(18,135,mos )
	  if pad:cross() and sourisx < 68 and sourisx > 18 and sourisy < 185 and sourisy > 135 then
	  screen:blit(18,135,splash )
	  
	  appuie = 3 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 3 and score == 3 then 
	  
	  screen:blit(269,155,mos )
	  if pad:cross() and sourisx < 319 and sourisx > 269 and sourisy < 205 and sourisy > 155 then
	  screen:blit(269,155,splash )
	  appuie = 4
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 4 and score == 4 then 
	  
	  screen:blit(134,226,mos )
	  if pad:cross() and sourisx < 184 and sourisx > 134 and sourisy < 276 and sourisy > 226 then
	  screen:blit(134,226,splash )
	  appuie = 5
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 5 and score == 5 then 
	  screen:blit(165,57,mos)
	  if pad:cross() and sourisx < 215 and sourisx > 165 and sourisy < 107 and sourisy > 57 then
	   screen:blit(165,57,splash)
	  appuie = 6
	  score = score + 1
	  end 
	  end
	  if appuie == 6 and score == 6 then 
	  
	  screen:blit(240,135,mos )
	  if pad:cross() and sourisx < 290 and sourisx > 240 and sourisy < 185 and sourisy > 135 then
	  screen:blit(240,135,splash)
	  appuie = 7
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 7 and score == 7 then 
	  
	  screen:blit(288,112,mos )
	  if pad:cross() and sourisx < 338 and sourisx > 288 and sourisy < 162 and sourisy > 112 then
	  screen:blit(288,112,splash )
	  appuie = 8
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 8 and score == 8 then 
	  
	  screen:blit(68,199,mos )
	 if pad:cross() and sourisx < 118 and sourisx > 68 and sourisy < 249 and sourisy > 199 then
	 screen:blit(68,199,splash )
	  appuie = 9
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 9 and score == 9 then 
	  
	  screen:blit(118,156,mos )
	  if pad:cross() and sourisx < 268 and sourisx > 118 and sourisy < 206 and sourisy > 156 then
	    screen:blit(118,156,splash )
	  appuie = 10
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 10 and score == 10 then 
	  
	  screen:blit(211,44,mos )
	  if pad:cross() and sourisx < 261 and sourisx > 211 and sourisy < 94 and sourisy > 44 then
	  screen:blit(211,44,splash )
	  appuie = 11 
	  score = score + 1
	  end 
	  end
	  
	   if appuie == 11 and score == 11 then 
	   screen:blit(10,20,mos )
	   if pad:cross() and sourisx < 60 and sourisx > 10 and sourisy < 70 and sourisy > 20 then
	   screen:blit(10,20,splash )
	   appuie = 12 
	   score = score + 1
	   end 
	   end
	  
	   if appuie == 12 and score == 12 then 
	  
	   screen:blit(56,110,mos )
	   if pad:cross() and sourisx < 106 and sourisx > 56 and sourisy < 160 and sourisy > 110 then
	    screen:blit(56,110,splash )
	   appuie = 13
	   score = score + 1
	   end 
	   end
	  
	   if appuie == 13 and score == 13 then 
	  
	   screen:blit(239,59,mos )
	   if pad:cross() and sourisx < 289 and sourisx > 239 and sourisy < 109 and sourisy > 59 then
	    screen:blit(239,59,splash )
	   appuie = 14
	   score = score + 1
	   end 
	   end
	  
	  if appuie == 14 and score == 14 then 
	  
	  screen:blit(146,135,mos )
	  if pad:cross() and sourisx < 196 and sourisx > 146 and sourisy < 185 and sourisy > 135 then
	  screen:blit(146,135,splash)
	  appuie = 15 
	   score = score + 1
	  end 
	  end
	  
	  if appuie == 15 and score == 14 then 
	  
	   screen:blit(247,135,mos )
	   if pad:cross() and sourisx < 297 and sourisx > 247 and sourisy < 185 and sourisy > 135 then
	   screen:blit(247,135,splash )
	   appuie = 16
	   score = score + 1
	   end 
	   end 




if score == 0 then
screen:print(15,3,"Score : 0",bleu)
end
 
if score == 1 then
screen:print(15,3,"Score :1",bleu)
end
 
if score == 2 then
screen:print(15,3,"Score :2",bleu)
end
	
	if score == 3 then
screen:print(15,3,"Score : 3",bleu)
end

if score == 4 then
screen:print(15,3,"Score :4",bleu)
end

if score == 5 then
screen:print(15,3,"Score : 5",bleu)
end

if score == 6 then
screen:print(15,3,"Score : 6",rouge)
end

if score == 7 then
screen:print(15,3,"Score :7",rouge)
end

if score == 8 then
screen:print(15,3,"Score : 8",rouge)
end

if score == 9 then
screen:print(15,3,"Score :9",rouge)
end

if score == 10 then
screen:print(15,3,"Score : 10",rouge)
end

if score == 11 then
screen:print(15,3,"Score : 11",rouge)
end

if score == 12 then
screen:print(15,3,"Score : 12",rouge)
end

if score == 13 then
screen:print(15,3,"Score : 13",rouge)
end

if score == 14 then
screen:print(15,3,"Score : 15",rouge)
end

if score == 15 then
screen:print(15,3,"Score : 15",rouge)
end
screen:blit(sourisx,sourisy,souris)
end




if m_timer == -10 then
screen:blit(0,200,bombe1)
end

if m_timer == -9 then
screen:blit(0,200,bombe2)
end

if m_timer == -8 then
screen:blit(0,200,bombe3)
end

if m_timer == -7 then
screen:blit(0,200,bombe4)
end

if m_timer == -6 then
screen:blit(0,200,bombe5)
end

if m_timer == -5 then
screen:blit(0,200,bombe6)
end

if m_timer == -4 then
screen:blit(0,200,bombe7)
end

if m_timer == -3 then
screen:blit(0,200,bombe7)
screen:blit(2,170,trois)
end

if m_timer == -2 then
screen:blit(0,200,bombe7)
screen:blit(2,170,deux)
end

if m_timer == -1 then
screen:blit(0,200,bombe7)
screen:blit(2,170,un)
end


if m_timer == 0 then
musique()
screen:blit(0,200,boum)
end


if m_timer >= 0 and score == 11 then
screen:blit(240,160,victoire)
if m_timer == 6 then 
System.memclean()
voice:stop()
dofile("menu.lua")
end
end
if m_timer >= 0 and score <= 9 then
screen:blit(0,0,perdu)
if m_timer == 6 then
System.memclean()
voice:stop()
dofile("menu.lua")
end
end



oldpad = pad
screen.waitVblankStart()
screen.flip()
end


texteminijeux1 = nil
souris = nil
gagne = nil
perdu = nil
bombe1 = nil
bombe2 = nil
bombe3 = nil
bombe4 = nil
bombe5 = nil
bombe6 = nil
bombe7 = nil
un = nil
deux = nil
trois = nil
boum = nil
back = nil
mos = nil 

