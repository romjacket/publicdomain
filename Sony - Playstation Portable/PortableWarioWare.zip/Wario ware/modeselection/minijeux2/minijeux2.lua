
function musique()
son = Sound.load("sound/boum.wav")
local sound = son
voice = sound:play()
end

	  rouge = Color.new(255,0,0)
	  bleu = Color.new(0,0,255)
	  
	  minuteur = Timer.new()
      minuteur:start()
		
	  victoire = Image.load("modeselection/minijeux2/victoire.png")
	  
	  croix = Image.load("modeselection/minijeux2/croix.png")
      carre = Image.load("modeselection/minijeux2/carre.png")
	  rond = Image.load("modeselection/minijeux2/rond.png")
      triangle = Image.load("modeselection/minijeux2/triangle.png")
	  
	  --bombe 
	  
	    bombe1 = Image.load("modeselection/minijeux2/bombe1.png")
		bombe2 = Image.load("modeselection/minijeux2/bombe2.png")
		bombe3 = Image.load("modeselection/minijeux2/bombe3.png")
		bombe4 = Image.load("modeselection/minijeux2/bombe4.png")
		bombe5 = Image.load("modeselection/minijeux2/bombe5.png")
		bombe6 = Image.load("modeselection/minijeux2/bombe6.png")
		bombe7 = Image.load("modeselection/minijeux2/bombe7.png")
	    press =  Image.load("modeselection/minijeux2/press.png")
		un = Image.load("modeselection/minijeux2/bun.png")
		deux = Image.load("modeselection/minijeux2/bdeux.png")
		trois = Image.load("modeselection/minijeux2/btrois.png")
		boum = Image.load("modeselection/minijeux2/boum.png")
	  
	  
	  
	  
	  
	  appuie = 0
	  score = 0
	  
	  while true do
	  screen:clear()
	  
	  currentTime = minuteur:time() 
	  timer = currentTime/950
	  m_timer = (math.floor(timer)-15)
	  
	  if m_timer >= -15 and m_timer < -10 then
	  screen:blit(0,0,press)
	  end
	
	  
	  if m_timer >= -10 and m_timer < 0 then
	  pad = Controls.read()
	  
	  
	  if appuie == 0 and score == 0 then
	  screen:blit(240,135,croix )
	  if pad:cross() then 
	  
	  appuie = 1 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 1 and score == 1 then 
	  screen:blit(240,135,carre )
	  if pad:square() then 
	   
	  appuie = 2 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 2 and score == 2 then 
	  screen:blit(240,135,rond )
	  if pad:circle() then
	  
	  appuie = 3 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 3 and score == 3 then 
	  screen:blit(240,135,triangle )
	  if pad:triangle() then 
	   
	  appuie = 4
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 4 and score == 4 then 
	  screen:blit(240,135,croix )
	  if pad:cross() then
	   
	  appuie = 5
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 5 and score == 5 then 
	  screen:blit(240,135,rond)
	  if pad:circle() then
	   
	  appuie = 6
	  score = score + 1
	  end 
	  end
	  if appuie == 6 and score == 6 then 
	  screen:blit(240,135,carre )
	  if pad:square() then
	   
	  appuie = 7
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 7 and score == 7 then 
	  screen:blit(240,135,rond )
	  if pad:circle() then
	  
	  appuie = 8
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 8 and score == 8 then 
	  screen:blit(240,135,triangle )
	  if pad:triangle() then
	   
	  appuie = 9
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 9 and score == 9 then 
	  screen:blit(240,135,croix )
	  if pad:triangle() then
	    
	  appuie = 10
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 10 and score == 10 then 
	  screen:blit(240,135,carre )
	  if pad:square() then
	   
	  appuie = 11 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 11 and score == 11 then 
	  screen:blit(240,135,triangle )
	  if pad:triangle() then
	   
	  appuie = 12 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 12 and score == 12 then 
	  screen:blit(240,135,croix )
	  if pad:cross() then
	   
	  appuie = 13
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 13 and score == 13 then 
	  screen:blit(240,135,carre )
	  if pad:square() then
	   
	  appuie = 14
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 14 and score == 14 then 
	  screen:blit(240,135,rond )
	  if pad:circle() then
	   
	  appuie = 15 
	  score = score + 1
	  end 
	  end
	  
	  if appuie == 15 and score == 14 then 
	  screen:blit(240,135,carre )
	  if pad:square() then
	   
	  appuie = 16
	  score = score + 1
	  end 
	  end

	  

		
if score == 0 then
screen:print(15,3,"Score : 0",bleu)
end
 
if score == 1 then
screen:print(15,3,"Score :1",bleu)
end
 
if score == 2 then
screen:print(15,3,"Score :2",bleu)
end
	
	if score == 3 then
screen:print(15,3,"Score : 3",bleu)
end

if score == 4 then
screen:print(15,3,"Score :4",bleu)
end

if score == 5 then
screen:print(15,3,"Score : 5",bleu)
end

if score == 6 then
screen:print(15,3,"Score : 6",rouge)
end

if score == 7 then
screen:print(15,3,"Score :7",rouge)
end

if score == 8 then
screen:print(15,3,"Score : 8",rouge)
end

if score == 9 then
screen:print(15,3,"Score :9",rouge)
end

if score == 10 then
screen:print(15,3,"Score : 10",rouge)
end

if score == 11 then
screen:print(15,3,"Score : 11",rouge)
end

if score == 12 then
screen:print(15,3,"Score : 12",rouge)
end

if score == 13 then
screen:print(15,3,"Score : 13",rouge)
end

if score == 14 then
screen:print(15,3,"Score : 15",rouge)
end

if score == 15 then
screen:print(15,3,"Score : 15",rouge)
end
end

if m_timer == -10 then
screen:blit(0,200,bombe1)
end

if m_timer == -9 then
screen:blit(0,200,bombe2)
end

if m_timer == -8 then
screen:blit(0,200,bombe3)
end

if m_timer == -7 then
screen:blit(0,200,bombe4)
end

if m_timer == -6 then
screen:blit(0,200,bombe5)
end

if m_timer == -5 then
screen:blit(0,200,bombe6)
end

if m_timer == -4 then
screen:blit(0,200,bombe7)
end

if m_timer == -3 then
screen:blit(0,200,bombe7)
screen:blit(2,170,trois)
end

if m_timer == -2 then
screen:blit(0,200,bombe7)
screen:blit(2,170,deux)
end

if m_timer == -1 then
screen:blit(0,200,bombe7)
screen:blit(2,170,un)
end

if m_timer == 0 then
musique()
screen:blit(0,200,boum)
end


if m_timer >= 0 and score == 15 then
screen:blit(240,160,victoire)
if m_timer == 6 then
System.memclean()
voice:stop() 
dofile("menu.lua")
end
end
if m_timer >= 0 and score <= 14 then
screen:print(0,0,"perdu",rouge)
if m_timer == 6 then
System.memclean()
voice:stop()
dofile("menu.lua")
end
end


screen.flip()
screen.waitVblankStart()
end 



  victoire = nil
	  
	  croix = nil 
      carre = nil
	  rond = nil
      triangle = nil
	  
	    bombe1 = nil
		bombe2 = nil
		bombe3 = nil
		bombe4 = nil
		bombe5 = nil
		bombe6 = nil
		bombe7 = nil
	  
		un = nil 
		deux = nil
		trois = nil
		boum = nil
		press = nil