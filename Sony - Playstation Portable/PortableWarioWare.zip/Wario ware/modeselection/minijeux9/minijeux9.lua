rouge = Color.new(255,0,0)
bleu = Color.new(0,0,255)
green=Color.new(0,255,0)
white = Color.new(255,255,255)


bullet = Image.load("modeselection/minijeux9/ball.png")
gagne = Image.load("modeselection/minijeux9/gagne.png")
perdu =  Image.load("modeselection/minijeux9/perdu.png")
player = Image.load("modeselection/minijeux9/pis.png")

cible1 = Image.load("modeselection/minijeux9/cible1.png")
cible2 = Image.load("modeselection/minijeux9/cible2.png")
cible3 = Image.load("modeselection/minijeux9/cible3.png")
cible4 = Image.load("modeselection/minijeux9/cible4.png")
cible5 = Image.load("modeselection/minijeux9/cible5.png")
cible6 = Image.load("modeselection/minijeux9/cible6.png")
cible7 = Image.load("modeselection/minijeux9/cible7.png")
cible8 = Image.load("modeselection/minijeux9/cible8.png")
tir = Image.load("modeselection/minijeux9/tir.png")
    bombe1 = Image.load("modeselection/minijeux9/bombe1.png")
		bombe2 = Image.load("modeselection/minijeux9/bombe2.png")
		bombe3 = Image.load("modeselection/minijeux9/bombe3.png")
		bombe4 = Image.load("modeselection/minijeux9/bombe4.png")
		bombe5 = Image.load("modeselection/minijeux9/bombe5.png")
		bombe6 = Image.load("modeselection/minijeux9/bombe6.png")
		bombe7 = Image.load("modeselection/minijeux9/bombe7.png")
		un = Image.load("modeselection/minijeux9/bun.png")
		deux = Image.load("modeselection/minijeux9/bdeux.png")
		trois = Image.load("modeselection/minijeux9/btrois.png")
		boum = Image.load("modeselection/minijeux9/boum.png")
fond  = Image.load("modeselection/minijeux9/fond.png")

function musique()
son = Sound.load("sound/boum.wav")
local sound = son
voice = sound:play()
end


function musique1()
son = Sound.load("modeselection/minijeux9/pouf.wav")
local sound = son
voice = sound:play()
end

 minuteur = Timer.new()
 minuteur:start()

cible1x = 140
cible1y = 110

cible2x = 20
cible2y = 110

cible3x = 250
cible3y = 110

cible4x = 320
cible4y = 110

cible5x = 50
cible5y = 110


cible6x = 360
cible6y = 110


cible7x = 240
cible7y = 110


cible8x = 310
cible8y = 110

oldpad = Controls.read()
currentBullet = 0
direction = "right"


Player = {}
Player[1] = { x = 249, y = 200 }

BulletInfo = {}

for a = 1,5 do
BulletInfo[a] = { pic = bullet , firing = false, direction = "right", x = Player[1].x + 32,
y = Player[1].y + 16 }
end

function bulletSetup()
--Increase the current bullet by one, or reset it to 1
if currentBullet < 5 then
currentBullet = currentBullet + 1
else
currentBullet = 1
end
if direction == "left" then
BulletInfo[currentBullet].x = Player[1].x
BulletInfo[currentBullet].y = Player[1].y + 16
end
if direction == "right" then
BulletInfo[currentBullet].x = Player[1].x + 32
BulletInfo[currentBullet].y = Player[1].y + 16
end

if direction == "up" then
BulletInfo[currentBullet].x = Player[1].x + 16
BulletInfo[currentBullet].y = Player[1].y
end
 
BulletInfo[currentBullet].direction = direction
BulletInfo[currentBullet].firing = true
voice:stop()
end

function bulletFire()
for i = 1,5 do
if BulletInfo[i].firing == true then
if BulletInfo[i].direction == "right" then BulletInfo[i].x = BulletInfo[i].x + 10 end
if BulletInfo[i].direction == "left" then BulletInfo[i].x = BulletInfo[i].x - 10 end
if BulletInfo[i].direction == "up" then BulletInfo[i].y = BulletInfo[i].y - 10 end
screen:blit(BulletInfo[i].x,BulletInfo[i].y,BulletInfo[i].pic)
end
if BulletInfo[i].x < 0 or BulletInfo[i].x > 480 or BulletInfo[i].y < 190 or BulletInfo[i].y > 272 then BulletInfo[i].firing = false end
end
end


function movePlayer()
pad = Controls.read()
if pad:left() then
Player[1].x = Player[1].x - 3
direction = "left"
end
if pad:right() then
Player[1].x = Player[1].x + 3
direction = "right"
end
if pad:up() then
direction = "up"
end
end

statut = 1
score = 1

while true do
	 screen:clear()
	 
	   currentTime = minuteur:time() 
	  timer = currentTime/950
	  m_timer = (math.floor(timer)-15)
	  
	  if m_timer >= -15 and m_timer < -10 then
	  screen:blit(0,0,tir)
	  end
	  
	  if m_timer >= -10 and m_timer < 0 then
	  screen:blit(0,0,fond)
	  pad = Controls.read()
	  if pad:start() then
	  System.message("X pour tirer sur les cibles ",0)
	  end
	  
	 screen:blit(Player[1].x, Player[1].y, player)
	  
	  
	 
	  
	  
	  
	  if pad:cross() then
	  bulletFire()
	  end
	  -- les statuts 
	if statut == 1 and pad:cross() and Player[1].x < 210 and Player[1].x > 110 then
    statut = statut+1
	score = score +1
	end
	
	if statut == 2 and pad:cross() and Player[1].x < 100 and Player[1].x > 1 then
    statut = statut+1
	score = score +1
	end
	
	if statut == 3 and pad:cross() and Player[1].x < 310 and Player[1].x > 220 then
    statut = statut+1
	score = score +1
	end
 
   if statut == 4 and pad:cross() and Player[1].x < 460 and Player[1].x > 310 then
    statut = statut+1
	score = score +1
	end
	
	if statut == 5 and pad:cross() and Player[1].x < 220 and Player[1].x > 40 then
    statut = statut+1
	score = score +1
	end
	
	if statut == 6 and pad:cross() and Player[1].x < 500 and Player[1].x > 362 then
    statut = statut+1
	score = score +1
	end
	
	if statut == 7 and pad:cross() and Player[1].x < 360 and Player[1].x > 230 then
    statut = statut+1
	score = score +1
	end
	
    if statut == 8 and pad:cross() and Player[1].x < 450 and Player[1].x > 270 then
    statut = statut+1
	score = score +1
	end
	
 
 
if pad:cross()  then
musique1()
bulletSetup()
end


movePlayer()
 
bulletFire()

if statut == 1 then
screen:blit(cible1x,cible1y,cible1)
end

if statut == 2 then
screen:blit(cible2x,cible2y,cible2)
end

if statut == 3 then
screen:blit(cible3x,cible3y,cible3)
end

if statut == 4 then
screen:blit(cible4x,cible4y,cible4)
end

if statut == 5 then
screen:blit(cible5x,cible5y,cible5)
end

if statut == 6 then
screen:blit(cible6x,cible6y,cible6)
end

if statut == 7 then
screen:blit(cible7x,cible7y,cible7)
end

if statut == 8 then
screen:blit(cible8x,cible8y,cible8)
end

if score == 0 then
screen:print(15,3,"Score : 0",bleu)
end
 
if score == 1 then
screen:print(15,3,"Score :1",bleu)
end
 
if score == 2 then
screen:print(15,3,"Score :2",bleu)
end
	
if score == 3 then
screen:print(15,3,"Score : 3",bleu)
end

if score == 4 then
screen:print(15,3,"Score :4",bleu)
end

if score == 5 then
screen:print(15,3,"Score : 5",bleu)
end

if score == 6 then
screen:print(15,3,"Score : 6",rouge)
end

if score == 7 then
screen:print(15,3,"Score :7",rouge)
end

if score == 8 then
screen:print(15,3,"Score : 8",rouge)
end
end

if m_timer == -10 then
screen:blit(0,200,bombe1)
end

if m_timer == -9 then
screen:blit(0,200,bombe2)
end

if m_timer == -8 then
screen:blit(0,200,bombe3)
end

if m_timer == -7 then
screen:blit(0,200,bombe4)
end

if m_timer == -6 then
screen:blit(0,200,bombe5)
end

if m_timer == -5 then
screen:blit(0,200,bombe6)
end

if m_timer == -4 then
screen:blit(0,200,bombe7)
end

if m_timer == -3 then
screen:blit(0,200,bombe7)
screen:blit(2,170,trois)
end

if m_timer == -2 then
screen:blit(0,200,bombe7)
screen:blit(2,170,deux)
end

if m_timer == -1 then
screen:blit(0,200,bombe7)
screen:blit(2,170,un)
end

if m_timer == 0 then
musique()
screen:blit(0,200,boum)
end

if m_timer >= 0 and score == 8 then
screen:blit(0,0,gagne)
if m_timer == 6 then
System.memclean()
voice:stop() 
dofile("modeselection/menuselectionjeux.lua")
end
end
if m_timer >= 0 and score <= 7 then
screen:blit(0,0,perdu)
if m_timer == 6 then
System.memclean()
voice:stop()
dofile("modeselection/menuselectionjeux.lua")
end
end


 
screen.waitVblankStart()
screen.flip()
oldpad = pad
end 
