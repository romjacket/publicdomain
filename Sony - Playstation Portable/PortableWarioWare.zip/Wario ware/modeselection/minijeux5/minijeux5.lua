function musique()
son = Sound.load("sound/boum.wav")
local sound = son
voice = sound:play()
end

rouge = Color.new(255,0,0)
	  bleu = Color.new(0,0,255)

minuteur = Timer.new()
minuteur:start()

gagne = Image.load("modeselection/minijeux5/gagne.png")
perdu = Image.load("modeselection/minijeux5/perdu.png")
bombe1 = Image.load("modeselection/minijeux5/bombe1.png")
bombe2 = Image.load("modeselection/minijeux5/bombe2.png")
bombe3 = Image.load("modeselection/minijeux5/bombe3.png")
bombe4 = Image.load("modeselection/minijeux5/bombe4.png")
bombe5 = Image.load("modeselection/minijeux5/bombe5.png")
bombe6 = Image.load("modeselection/minijeux5/bombe6.png")
bombe7 = Image.load("modeselection/minijeux5/bombe7.png")
un = Image.load("modeselection/minijeux5/bun.png")
deux = Image.load("modeselection/minijeux5/bdeux.png")
trois = Image.load("modeselection/minijeux5/btrois.png")
boum = Image.load("modeselection/minijeux5/boum.png")
press = Image.load("modeselection/minijeux5/texte.png")

-- la tv 
tv = Image.load("modeselection/minijeux5/tv.png")
tv1 = Image.load("modeselection/minijeux5/tv1.png")
tv2 = Image.load("modeselection/minijeux5/tv2.png")
tv3 = Image.load("modeselection/minijeux5/tv3.png")
tv4 = Image.load("modeselection/minijeux5/tv4.png")
tv5 = Image.load("modeselection/minijeux5/tv5.png")
tv6 = Image.load("modeselection/minijeux5/tv6.png")

tel = Image.load("modeselection/minijeux5/tel.png")

victoire = Image.load("modeselection/minijeux5/gagne.png")

	  statut = 0
          stat = 0
	  chaine = 0
	  score = 0
	  appuie = 0

oldpad = Controls.read()
	  
	  while true do
	  screen:clear()
	  
	  currentTime = minuteur:time() 
	  timer = currentTime/950
	  m_timer = (math.floor(timer)-15)
	  
	  if m_timer >= -15 and m_timer < -10 then
	  screen:blit(0,0,press)
	  end
	
	  
	  if m_timer >= -10 and m_timer < 0 then
	  pad = Controls.read()
	  screen:blit(200,120,tv )
	  
	 if pad:r() and oldpad:r() ~= pad:r()  and stat < 7 then
         stat = stat +1
         end
         if pad:l() and oldpad:l() ~= pad:l() and stat > 1 then
         stat = stat -1
         end

if stat == 1 then
screen:blit(200,120,tv1)
screen:blit(240,200,tel)
end
if stat == 2 then
screen:blit(200,120,tv2)
screen:blit(240,200,tel)
if chaine == 3 and pad:cross() and oldpad:cross() ~= pad:cross() then 
statut = 1 
end
if chaine == 6 and pad:cross() and oldpad:cross() ~= pad:cross() then 
statut = 1 
end
end
if stat == 3 then
screen:blit(200,120,tv3)
screen:blit(240,200,tel)
if chaine == 1 and pad:cross() and oldpad:cross() ~= pad:cross() then 
statut = 1
end
end
if stat == 4 then
screen:blit(200,120,tv4)
screen:blit(240,200,tel)
if chaine == 4 and pad:cross() and oldpad:cross() ~= pad:cross() then 
statut = 1 
end
end
if stat == 5 then
screen:blit(200,120,tv5)
screen:blit(240,200,tel)
if chaine == 2 and pad:cross() and oldpad:cross() ~= pad:cross() then 
statut = 1 
end
end
if stat == 6 then
screen:blit(200,120,tv6)
screen:blit(240,200,tel)
if chaine == 0 and pad:cross() and oldpad:cross() ~= pad:cross() then 
statut = 1 
end
if chaine == 5 and pad:cross() and oldpad:cross() ~= pad:cross() then 
statut = 1 
end
end

     
	  
	  -- Qeul chaine de tv gagne 

if statut == 1 then
chaine = chaine + 1
score = score + 1
statut = 0
end
	  
	
	  
	  
	  

		
if chaine == 0 then
screen:print(15,3,"Trouve la chaine : M6 ",bleu)
end
 
if chaine == 1 then
screen:print(15,3,"Trouve la chaine france 3 ",bleu)
end
 
if chaine == 2 then
screen:print(15,3,"Trouve la chaine ARTE ",bleu)
end
	
if chaine == 3 then
screen:print(15,3,"Trouve la chaine  France 2 ",bleu)
end

if chaine == 4 then
screen:print(15,3,"Trouve la chaine france 3 ",bleu)
end

if chaine == 5 then
screen:print(15,3,"Trouve la chaine M6",bleu)
end

if chaine == 6 then
screen:print(15,3,"Trouve la chaine France 2 ",rouge)
end



-- Le score

if score == 0 then
screen:print(15,20,"Score : 0",bleu)
end
 
if score == 1 then
screen:print(15,20,"Score :1",bleu)
end
 
if score == 2 then
screen:print(15,20,"Score :2",bleu)
end
	
	if score == 3 then
screen:print(15,20,"Score : 3",bleu)
end

if score == 4 then
screen:print(15,20,"Score :4",bleu)
end

if score == 5 then
screen:print(15,20,"Score : 5",bleu)
end

if score == 6 then
screen:print(15,20,"Score : 6",rouge)
end
end



if m_timer == -10 then
screen:blit(0,200,bombe1)
end

if m_timer == -9 then
screen:blit(0,200,bombe2)
end

if m_timer == -8 then
screen:blit(0,200,bombe3)
end

if m_timer == -7 then
screen:blit(0,200,bombe4)
end

if m_timer == -6 then
screen:blit(0,200,bombe5)
end

if m_timer == -5 then
screen:blit(0,200,bombe6)
end

if m_timer == -4 then
screen:blit(0,200,bombe7)
end

if m_timer == -3 then
screen:blit(0,200,bombe7)
screen:blit(2,170,trois)
end

if m_timer == -2 then
screen:blit(0,200,bombe7)
screen:blit(2,170,deux)
end

if m_timer == -1 then
screen:blit(0,200,bombe7)
screen:blit(2,170,un)
end

if m_timer == 0 then
musique()
screen:blit(0,200,boum)
end

if System.memclean() then
		victoire = nil	  
	    bombe1 = nil
		bombe2 = nil
		bombe3 = nil
		bombe4 = nil
		bombe5 = nil
		bombe6 = nil
		bombe7 = nil
	  
		un = nil 
		deux = nil
		trois = nil
		boum = nil
		press = nil
		
		tv = nil
		tv1 = nil
		tv2 = nil
		tv3 = nil
		tv4 = nil
		tv5 = nil
		tv6 = nil
		tel = nil
		end


if m_timer >= 0 and score == 6 then
screen:blit(240,160,victoire)
if m_timer == 6 then
System.memclean()
voice:stop() 
dofile("menu.lua")
end
end
if m_timer >= 0 and score <= 5 then
screen:print(240,100,"Perdu",rouge)
if m_timer == 6 then
System.memclean()
voice:stop()
dofile("menu.lua")
end
end

oldpad = pad
screen.flip()
screen.waitVblankStart()
end 




	    
