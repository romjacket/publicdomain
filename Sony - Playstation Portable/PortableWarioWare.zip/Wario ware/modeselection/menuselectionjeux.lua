
menu = Image.load("images/menuselectionjeux.png")
icone1 = Image.load("modeselection/icones/icone1.png")
icone2 = Image.load("modeselection/icones/icone2.png")
icone3 = Image.load("modeselection/icones/icone3.png")
icone4 = Image.load("modeselection/icones/icone4.png")
icone5 =Image.load("modeselection/icones/icone5.png")
icone6 =Image.load("modeselection/icones/icone6.png")
icone7 = Image.load("modeselection/icones/icone7.png")
icone8 = Image.load("modeselection/icones/icone8.png")
icone9 = Image.load("modeselection/icones/icone9.png")
icone10 = Image.load("modeselection/icones/icone10.png")

souris = Image.load("modeselection/minijeux1/curs.png")


sourisx = 190
sourisy = 120
vitesse = 1.5

x = 0
y = 0

icone1x = 10
icone1y = 20

icone2x = 110
icone2y = 20

icone3x = 210 
icone3y = 20 

icone4x = 310 
icone4y = 20

icone5x = 10
icone5y = 60

icone6x = 310
icone6y = 60

icone7x = 110
icone7y = 60

icone8x = 210
icone8y = 60

icone9x = 10
icone9y = 100

icone10x = 110
icone10y = 100

oldpad = Controls.read()



while true do
screen:clear()

pad = Controls.read()

screen:blit(x,y,menu)


if pad:up()  and sourisy >= 0 then
sourisy = sourisy - vitesse
end
if pad:down() and sourisy <= 255 then
sourisy = sourisy + vitesse
end
if pad:right() and sourisx <= 470 then
sourisx = sourisx + vitesse
end
if pad:left()  and sourisx >= 0 then
sourisx = sourisx - vitesse
end

if System.memclean() then
menu = nil
icone1 = nil
icone2 = nil
icone3 = nil
icone4 = nil
icone5 = nil
icone6 = nil
icone7 = nil
icone8 = nil
icone9 = nil
souris = nil
end

if pad:circle() then
System.memclean()
dofile("menu.lua")
System.memclean()
end

-- Premiere ligne

if pad:cross() and sourisx < 89 and sourisx > 9 and sourisy < 65 and sourisy > 20 then
System.memclean()
dofile("modeselection/minijeux1/minijeux1.lua")
System.memclean()
end

if pad:cross() and sourisx < 190 and sourisx > 110 and sourisy < 60 and sourisy > 20 then
System.memclean()
dofile("modeselection/minijeux2/minijeux2.lua")
System.memclean()
end

if pad:cross() and sourisx < 290 and sourisx > 210 and sourisy < 60 and sourisy > 20 then
System.memclean()
dofile("modeselection/minijeux3/minijeux3.lua")
System.memclean()
end

if pad:cross() and sourisx < 390 and sourisx > 310 and sourisy < 60 and sourisy > 20 then
System.memclean()
dofile("modeselection/minijeux4/minijeux4.lua")
System.memclean()
end

if pad:cross() and sourisx < 490 and sourisx > 410 and sourisy < 60 and sourisy > 20 then
System.memclean()
dofile("modeselection/minijeux5/minijeux5.lua")
System.memclean()
end

-- Deusieme ligne du tableau

if pad:cross() and sourisx < 89 and sourisx > 9 and sourisy < 105 and sourisy > 60 then
System.memclean()
dofile("modeselection/minijeux5/minijeux5.lua")
System.memclean()
end

if pad:cross() and sourisx < 390 and sourisx > 310 and sourisy < 100 and sourisy > 60 then
System.memclean()
dofile("modeselection/minijeux6/minijeux6.lua")
System.memclean()
end


if pad:cross() and sourisx < 190 and sourisx > 110 and sourisy < 100 and sourisy > 60 then
System.memclean()
dofile("modeselection/minijeux7/minijeux7.lua")
System.memclean()
end


if pad:cross() and sourisx < 290 and sourisx > 210 and sourisy < 100 and sourisy > 60 then
System.memclean()
dofile("modeselection/minijeux8/minijeux8.lua")
System.memclean()
end

-- Trosieme ligne 

if pad:cross() and sourisx < 89 and sourisx > 9 and sourisy < 140 and sourisy > 100 then
System.memclean()
dofile("modeselection/minijeux9/minijeux9.lua")
System.memclean()
end

if pad:cross() and sourisx < 190 and sourisx > 110 and sourisy < 140 and sourisy > 100 then
System.memclean()
dofile("modeselection/minijeux10/minijeux10.lua")
System.memclean()
end






screen:blit(icone1x,icone1y,icone1)
screen:blit(icone2x,icone2y,icone2)
screen:blit(icone3x,icone3y,icone3)
screen:blit(icone4x,icone4y,icone4)
screen:blit(icone5x,icone5y,icone5)
screen:blit(icone6x,icone6y,icone6)
screen:blit(icone7x,icone7y,icone7)
screen:blit(icone8x,icone8y,icone8)
screen:blit(icone9x,icone9y,icone9)
screen:blit(icone10x,icone10y,icone10)
screen:blit(sourisx,sourisy,souris)

oldpad = pad


screen.waitVblankStart()
screen.flip()
end

