-- Chargement des couleurs
blanc = Color.new(255,255,255)
bleu = Color.new(0,0,255)
gris = Color.new(100,100,100)
rouge = Color.new(255,0,0)

function musique()
son = Sound.load("sound/boum.wav")
local sound = son
voice = sound:play()
end


minuteur = Timer.new()
minuteur:start()




bombe1 = Image.load("modeselection/minijeux7/bombe1.png")
bombe2 = Image.load("modeselection/minijeux7/bombe2.png")
bombe3 = Image.load("modeselection/minijeux7/bombe3.png")
bombe4 = Image.load("modeselection/minijeux7/bombe4.png")
bombe5 = Image.load("modeselection/minijeux7/bombe5.png")
bombe6 = Image.load("modeselection/minijeux7/bombe6.png")
bombe7 = Image.load("modeselection/minijeux7/bombe7.png")
un = Image.load("modeselection/minijeux7/bun.png")
deux = Image.load("modeselection/minijeux7/bdeux.png")
trois = Image.load("modeselection/minijeux7/btrois.png")
boum = Image.load("modeselection/minijeux7/boum.png")

gagne = Image.load("modeselection/minijeux7/gagne.png")
perdu = Image.load("modeselection/minijeux7/perdu.png")



couleur = Color.new(math.random(0,255),math.random(0,255),math.random(0,255))

oldpad = Controls.read()

-- Fonctions contour + centrage texte
function print(y,texte,couleur,couleur2)
	screen:print(240 - string.len(texte)*8/2+1,y,texte,couleur)
	screen:print(240 - string.len(texte)*8/2+1,y-1,texte,couleur)
	screen:print(240 - string.len(texte)*8/2,y-1,texte,couleur)
	screen:print(240 - string.len(texte)*8/2-1,y-1,texte,couleur)
	screen:print(240 - string.len(texte)*8/2-1,y,texte,couleur)
	screen:print(240 - string.len(texte)*8/2-1,y+1,texte,couleur)
	screen:print(240 - string.len(texte)*8/2,y+1,texte,couleur)
	screen:print(240 - string.len(texte)*8/2+1,y+1,texte,couleur)
	
	screen:print(240 - string.len(texte)*8/2,y,texte,couleur2)
end

-- Tableau de la souris
souris = { }
souris.img = Image.createEmpty(5,5) -- On cr�er une image de 5 pixels de largeur et 5 pixel de hauteur (5*5)
souris.x = 480/2 - souris.img:width() /2 -- On place notre souris pile au milieur sur l'axe des X
souris.y = 272/2 - souris.img:height() /2 -- On place notre souris pile au milieu sur l'axe des Y
souris.img:clear(blanc) -- On donne la couleur blanche � notre souris

-- Tableau des l'ic�nes
icone = { }
icone[1] = { x = 0, y = 0, img = 0 }
icone[2] = { x = 0, y = 0, img = 0 }
icone[3] = { x = 0, y = 0, img = 0 }

for i = 1, 3 do -- Pour les trois ic�nes
	icone[i].img = Image.createEmpty(30,30) -- On cr�er 3 image de 30 pixels de largeur et 30 pixels de hauteur (30*30)
	icone[i].x = math.random(0,(480-icone[i].img:width())) -- On place chaque ic�ne al�atoirement sur l'axe X
	icone[i].y = math.random(30,(232-icone[i].img:height())) -- On place chaque ic�ne al�atoirement sur l'axe Y
	icone[i].img:clear(blanc) -- On met la couleur blanche aux trois ic�nes
end

n_icone = math.random(1,3)

score = 5
selecteur = 0

statu = menu
statut = rien
-- Boucle principale
while true do
	screen:clear() -- On nettoie l'�cran de couleur noir pas d�faut
	pad = Controls.read() -- On active la lecture des touches
	
	if statu == menu then
		screen:print(30,30,"Commencer a jouer", blanc)
		screen:print(30,45,"Credits", blanc)
		screen:print(30,60,"Retourner au menu", blanc)
		
		if pad:up() and not oldpad:up() and selecteur ~= 0 then selecteur = selecteur -1 end
		if pad:down() and not oldpad:down() and selecteur ~= 2 then selecteur = selecteur +1 end
		
		if selecteur == 0 then screen:print(10,30,">", blanc) screen:print(30,30,"Commencer a jouer", rouge) screen:print(30+string.len("Commencer a jouer")*8+10,30,"<", blanc)
		elseif selecteur == 1 then screen:print(10,45,">", blanc) screen:print(30,45,"Credits", rouge) screen:print(30+string.len("Credits")*8+10,45,"<", blanc)
		elseif selecteur == 2 then screen:print(10,60,">", blanc) screen:print(30,60,"Retourner au Menu", rouge) screen:print(30+string.len("Retourner au Menu")*8+10,60,"<", blanc) end
		
		if pad:cross() and not oldpad:cross() and selecteur == 0 then
			statu = jeu
			n_icone = math.random(1,3)
			couleur = Color.new(math.random(0,255),math.random(0,255),math.random(0,255))
			icone[1].x = math.random(0,(480-icone[1].img:width()))
			icone[1].y = math.random(0,(232-icone[1].img:height()))
			icone[2].x = math.random(0,(480-icone[2].img:width()))
			icone[2].y = math.random(0,(232-icone[2].img:height()))
			icone[3].x = math.random(0,(480-icone[3].img:width()))
			icone[3].y = math.random(0,(232-icone[3].img:height()))
		elseif pad:cross() and not oldpad:cross() and selecteur == 1 then
			statu = credits
		elseif pad:cross() and not oldpad:cross() and selecteur == 2 then
			dofile("modeselection/menuselectionjeux.lua")
		end
	end
	
	if statu == jeu then
	currentTime = minuteur:time()
    timer = currentTime/1000
    m_timer = (math.floor(timer)-10)
		-- D�placement de l'ic�ne gr�ce � la souris (pad:ross())
		for i = 1, 3 do -- Pour les trois ic�nes
			-- Variables pour collisions
			collisionx = icone[i].x
			collisiony = icone[i].y
			
			screen:blit(icone[i].x,icone[i].y,icone[i].img) -- On affiche les trois ic�nes
			
			if (souris.x + souris.img:width() > icone[i].x) and (icone[i].x + icone[i].img:width() > souris.x) and (souris.y + souris.img:height() > icone[i].y) and (icone[i].y + icone[i].img:height() > souris.y) then -- Si la souris 'rencontre' l'une des trois ic�nes
				if i == 1 then icone[1].img:clear(couleur) screen:print(icone[1].x+icone[1].img:width()/2-3,icone[1].y+icone[1].img:height()/2-3,"1", blanc) end -- Si i est �gal � 1, on met la couleur bleu � l'ic�ne 1
				if i == 2 then icone[2].img:clear(couleur) screen:print(icone[2].x+icone[2].img:width()/2-3,icone[2].y+icone[2].img:height()/2-3,"2", blanc) end -- Si i est �gal � 2, on met la couleur rouge � l'ic�ne 2
				if i == 3 then icone[3].img:clear(couleur) screen:print(icone[3].x+icone[3].img:width()/2-3,icone[3].y+icone[3].img:height()/2-3,"3", blanc) end -- Si i est �gal � 3, on met la couleur grise � l'ic�ne 3
				
				if pad:cross() and not oldpad:cross() then -- Si on appuie sur X
					if i ~= n_icone then
						score = score -1
						n_icone = math.random(1,3)
						couleur = Color.new(math.random(0,255),math.random(0,255),math.random(0,255))
						icone[1].x = math.random(0,(480-icone[1].img:width()))
						icone[1].y = math.random(0,(232-icone[1].img:height()))
						icone[2].x = math.random(0,(480-icone[2].img:width()))
						icone[2].y = math.random(0,(232-icone[2].img:height()))
						icone[3].x = math.random(0,(480-icone[3].img:width()))
						icone[3].y = math.random(0,(232-icone[3].img:height()))
					elseif i == n_icone then 
						score = score +1
						n_icone = math.random(1,3)
						couleur = Color.new(math.random(0,255),math.random(0,255),math.random(0,255))
						icone[1].x = math.random(0,(480-icone[1].img:width()))
						icone[1].y = math.random(0,(232-icone[1].img:height()))
						icone[2].x = math.random(0,(480-icone[2].img:width()))
						icone[2].y = math.random(0,(232-icone[2].img:height()))
						icone[3].x = math.random(0,(480-icone[3].img:width()))
						icone[3].y = math.random(0,(232-icone[3].img:height()))
					end
					-- if math.abs(pad:analogX()) > 25 then icone[i].x = icone[i].x + pad:analogX() /25 end -- On d�place l'ic�ne en X
					-- if math.abs(pad:analogY()) > 25 then icone[i].y = icone[i].y + pad:analogY() /25 end -- On d�place l'ic�ne en Y
				end
			else -- Sinon
				icone[i].img:clear(blanc) -- On remet l'un des icon�ne s�lectionn�s en blanc
			end
			
			
			
			-- Collisions entre chaque ic�nes
			if (icone[1].x + icone[1].img:width() > icone[2].x) and (icone[2].x + icone[2].img:width() > icone[1].x) and (icone[1].y + icone[1].img:height() > icone[2].y) and (icone[2].y + icone[2].img:height() > icone[1].y) then
				icone[i].x = collisionx
				icone[i].y = collisiony
			elseif (icone[2].x + icone[2].img:width() > icone[3].x) and (icone[3].x + icone[3].img:width() > icone[2].x) and (icone[2].y + icone[2].img:height() > icone[3].y) and (icone[3].y + icone[3].img:height() > icone[2].y) then
				icone[i].x = collisionx
				icone[i].y = collisiony
			elseif (icone[3].x + icone[3].img:width() > icone[1].x) and (icone[1].x + icone[1].img:width() > icone[3].x) and (icone[3].y + icone[3].img:height() > icone[1].y) and (icone[1].y + icone[1].img:height() > icone[3].y) then
				icone[i].x = collisionx
				icone[i].y = collisiony
			end
			
			-- Collisions de l'ic�ne sur les bords de l'�cran
			if icone[i].x <= 0 then icone[i].x = 0 elseif icone[i].x >= 480 - icone[i].img:width() then icone[i].x = 480 - icone[i].img:width() end -- Collisions sur X = 0 et X = 480
			if icone[i].y <= 30 then icone[i].y = 30 elseif icone[i].y >= 232 - icone[i].img:height() then icone[i].y = 232 - icone[i].img:height() end -- Collisions sur Y = 0 et Y = 272
		
			if pad:start() and not oldpad:start() then -- Si on appuie sur la touche star alors...
				icone[i].x = math.random(0,(480-icone[i].img:width())) -- On change l'emplacement des ic�nes sur l'axe X
				icone[i].y = math.random(0,(232-icone[i].img:height())) -- On change l'emplacement des ic�nes sur l'axe Y
				n_icone = math.random(1,3) -- On change le nombre al�atoirement
				couleur = Color.new(math.random(0,255),math.random(0,255),math.random(0,255)) -- On change la couleur al�atoirement
			end
		end
		
	
		print(10,"Vous devez trouver l'icone numero "..n_icone, couleur, blanc) -- On affiche le num�ro al�atoire
		print(212,"Votre score est de "..score, couleur, blanc ) -- On affiche le score
		
		screen:drawLine(0,30,480,30, blanc) -- On affiche une ligne
		screen:drawLine(0,232,480,232, blanc) -- Idem
		
		screen:blit(souris.x,souris.y,souris.img) -- On affiche la souris
		
		-- D�placement de notre souris
		if math.abs(pad:analogX()) > 25 then souris.x = souris.x + pad:analogX() /25 end -- D�placement de la souris sur l'axe des X
		if math.abs(pad:analogY()) > 25 then souris.y = souris.y + pad:analogY() /25 end -- D�placement de la souris sur l'axs des Y
		
		-- Collisions de la souris sur les bords de l'�cran
		if souris.x <= 0 then souris.x = 0 elseif souris.x >= 480 - souris.img:width() then souris.x = 480 - souris.img:width() end -- Collisions sur X = 0 et X = 480
		if souris.y <= 30 then souris.y = 30 elseif souris.y >= 232 - souris.img:height() then souris.y = 232 - souris.img:height() end -- Collisions sur Y = 0 et Y = 272
	end
    
	 

	if statut == perdu	and pad:start() and not oldpad:start() then -- Si on appuie sur start alors...
			statu = jeu -- On passe au jeu
			
			for i = 1, 3 do -- Pour les trois ic�nes
				icone[i].x = math.random(0,(480-icone[i].img:width())) -- On le place al�atoirement sur l'�cran en X
				icone[i].y = math.random(0,(232-icone[i].img:height())) -- On le place al�atoirement sur l'�cran en Y
			end
			
			score = 5 -- On remet le score � 5
			n_icone = math.random(1,3) -- On change le nombre
			couleur = Color.new(math.random(0,255),math.random(0,255),math.random(0,255)) -- On change la couleur
		end
		 
		
	if statut == gagne and	 pad:start() and not oldpad:start() then -- Si on appuie sur start alors...
			statu = jeu -- On passe au jeu
			
			for i = 1, 3 do -- Pour les trois ic�nes
				icone[i].x = math.random(0,(480-icone[i].img:width())) -- On le place al�atoirement sur l'�cran en X
				icone[i].y = math.random(30,(232-icone[i].img:height())) -- On le place al�atoirement sur l'�cran en Y
			end
			
			score = 5 -- On remet le score � 5
			n_icone = math.random(1,3) -- On change le nombre
			couleur = Color.new(math.random(0,255),math.random(0,255),math.random(0,255)) -- On change la couleur

	end
	
	
		
if m_timer == -10 then
screen:blit(0,200,bombe1)
end

if m_timer == -9 then
screen:blit(0,200,bombe2)
end

if m_timer == -8 then
screen:blit(0,200,bombe3)
end

if m_timer == -7 then
screen:blit(0,200,bombe4)
end

if m_timer == -6 then
screen:blit(0,200,bombe5)
end

if m_timer == -5 then
screen:blit(0,200,bombe6)
end

if m_timer == -4 then
screen:blit(0,200,bombe7)
end

if m_timer == -3 then
screen:blit(0,200,bombe7)
screen:blit(2,170,trois)
end

if m_timer == -2 then
screen:blit(0,200,bombe7)
screen:blit(2,170,deux)
end

if m_timer == -1 then
screen:blit(0,200,bombe7)
screen:blit(2,170,un)
end

if m_timer == 0 then
musique()
screen:blit(0,200,boum)
end

if m_timer == 0 and score >= 8 then
statut = gagne
end


if m_timer == 0 and score <= 7 then
statut = perdu
end

if m_timer == 6 then
System.memclean()
voice:stop() 
dofile("menu.lua")
System.memclean()
end


	
if m_timer == 6  then
System.memclean()
voice:stop()
dofile("menu.lua")
System.memclean()
end

if statut == gagne then
pad = false 
oldpad = false
screen:blit(0,0,gagne)
end
if statut == perdu then
pad = false
oldpad = false
screen:blit(0,0,perdu)
end





	if statu == credits then
		print(130,"The All Team ;)", rouge, blanc)
		
		if pad:start() and not oldpad:start() then
			statu = menu
		end
	end


	

if System.memclean() then
		victoire = nil  
	    bombe1 = nil
		bombe2 = nil
		bombe3 = nil
		bombe4 = nil
		bombe5 = nil
		bombe6 = nil
		bombe7 = nil
	  
		un = nil 
		deux = nil
		trois = nil
		boum = nil
		gagne = nil
		perdu = nil
		end



	
	-- Fermeture de la boucle
		oldpad = pad
	screen.flip()
	screen.waitVblankStart()
end	
