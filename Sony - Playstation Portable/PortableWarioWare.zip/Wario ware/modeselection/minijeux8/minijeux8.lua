blanc = Color.new(255,255,255)
bleu = Color.new(0,0,255)
gris = Color.new(100,100,100)
rouge = Color.new(255,0,0)

function musique()
son = Sound.load("sound/boum.wav")
local sound = son
voice = sound:play()
end

bombe1 = Image.load("modeselection/minijeux8/bombe1.png")
bombe2 = Image.load("modeselection/minijeux8/bombe2.png")
bombe3 = Image.load("modeselection/minijeux8/bombe3.png")
bombe4 = Image.load("modeselection/minijeux8/bombe4.png")
bombe5 = Image.load("modeselection/minijeux8/bombe5.png")
bombe6 = Image.load("modeselection/minijeux8/bombe6.png")
bombe7 = Image.load("modeselection/minijeux8/bombe7.png")
un = Image.load("modeselection/minijeux8/bun.png")
deux = Image.load("modeselection/minijeux8/bdeux.png")
trois = Image.load("modeselection/minijeux8/btrois.png")
boum = Image.load("modeselection/minijeux8/boum.png")

-- les portes 

p1 = Image.load("modeselection/minijeux8/p1.png")
p2 = Image.load("modeselection/minijeux8/p2.png")
p3 = Image.load("modeselection/minijeux8/p3.png")

wariodos = Image.load("modeselection/minijeux8/wariodos.png")
argent = Image.load("modeselection/minijeux8/argent.png")
argent2 = Image.load("modeselection/minijeux8/argent2.png")
argent3 = Image.load("modeselection/minijeux8/argent3.png")
souris = Image.load("modeselection/minijeux8/curs.png")
victoire = Image.load("modeselection/minijeux8/victoire.png")
ec = Image.load("modeselection/minijeux8/ec.png")
press = Image.load("modeselection/minijeux8/press.png")
perdu = Image.load("modeselection/minijeux8/perdu.png")

minuteur = Timer.new()
minuteur:start()

sourisx = 190
sourisy = 120
vitesse = 4

x = 0
y = 0

statut = 0
score = 0

while true do
screen:clear()
	  
	  
	  currentTime = minuteur:time() 
	  timer = currentTime/950
	  m_timer = (math.floor(timer)-15)
	  
	  if m_timer >= -15 and m_timer < -10 then
	  screen:blit(0,0,press)
	  end
	
if m_timer >= -10 and m_timer < 0 then

pad = Controls.read()

if pad:up()  and sourisy >= 0 then
sourisy = sourisy - vitesse
end
if pad:down() and sourisy <= 255 then
sourisy = sourisy + vitesse
end
if pad:right() and sourisx <= 470 then
sourisx = sourisx + vitesse
end
if pad:left()  and sourisx >= 0 then
sourisx = sourisx - vitesse
end
	  screen:blit(241,222,wariodos)
	  
	  screen:blit(50,120,p1)
	  screen:blit(183,120,p2)
	  screen:blit(316,120,p3)
	  screen:blit(sourisx,sourisy,souris)
	  



-- les statuts

if statut == 0 then
score = 0
end

if statut == 1 then
score = 1
screen:blit(200,10,argent)
end

if statut == 2 then
score = 2
screen:blit(200,10,argent2)
end

if statut == 3 then
score = 3
screen:blit(200,10,argent3)
end


if score == 0 then
screen:print(15,3,"Score : 0",bleu)
end
 
if score == 1 then
screen:print(15,3,"Score :1",bleu)
end
 
if score == 2 then
screen:print(15,3,"Score :2",bleu)
end

if score == 3 then
screen:print(15,3,"Score :3",bleu)
end
	

--if pad:cross() and score ==1 then	
	
	
	
-- statut 0

if pad:cross() and statut == 0  and sourisx < 180 and sourisx > 50 and sourisy < 218 and sourisy > 120  then
statut = 1
end
if pad:cross() and statut == 0 and  sourisx < 314 and sourisx > 183 and  sourisy < 218 and  sourisy > 120  then
score = score - 1
screen:blit(241,222,ec)
end
if pad:cross() and statut == 0 and sourisx < 449 and sourisx > 316 and sourisy < 218 and sourisy > 120  then
score = score - 1
screen:blit(241,222,ec)
end


-- statut 1 

if pad:cross() and statut == 1 and sourisx < 449 and sourisx > 316 and sourisy < 218 and sourisy > 120 then
statut = 2
end
if pad:cross() and statut == 1 and  sourisx < 314 and sourisx > 183 and  sourisy < 218 and  sourisy > 120  then
score = score - 1
screen:blit(241,222,ec)
end
if pad:cross() and statut == 1  and sourisx < 180 and sourisx > 50 and sourisy < 218 and sourisy > 120 then
score = score - 1
screen:blit(241,222,ec)
end

-- statut 3

if pad:cross() and statut == 2 and  sourisx < 314 and sourisx > 183 and  sourisy < 218 and  sourisy > 120  then
statut = 3
end
if pad:cross() and statut == 2 and sourisx < 449 and sourisx > 316 and sourisy < 218 and sourisy > 120  then
score = score - 1
screen:blit(241,222,ec)
end
if pad:cross() and statut == 2 and sourisx < 180 and sourisx > 50 and sourisy < 218 and sourisy > 120 then
score = score - 1
screen:blit(241,222,ec)
end
end  



if m_timer == -10 then
screen:blit(0,200,bombe1)
end

if m_timer == -9 then
screen:blit(0,200,bombe2)
end

if m_timer == -8 then
screen:blit(0,200,bombe3)
end

if m_timer == -7 then
screen:blit(0,200,bombe4)
end

if m_timer == -6 then
screen:blit(0,200,bombe5)
end

if m_timer == -5 then
screen:blit(0,200,bombe6)
end

if m_timer == -4 then
screen:blit(0,200,bombe7)
end

if m_timer == -3 then
screen:blit(0,200,bombe7)
screen:blit(2,170,trois)
end

if m_timer == -2 then
screen:blit(0,200,bombe7)
screen:blit(2,170,deux)
end

if m_timer == -1 then
screen:blit(0,200,bombe7)
screen:blit(2,170,un)
end

if m_timer == 0 then
musique()
screen:blit(0,200,boum)
end



	  
if m_timer >= 0 and score == 3 then
screen:blit(0,0,victoire)
if m_timer == 6 then
System.memclean()
voice:stop() 
dofile("modeselection/menuselectionjeux.lua")
end
end
if m_timer >= 0 and score <= 2 then
screen:blit(0,0,perdu)
if m_timer == 6 then
System.memclean()
voice:stop()
dofile("modeselection/menuselectionjeux.lua")
end
end

if System.memclean() then
		victoire = nil	  
	    bombe1 = nil
		bombe2 = nil
		bombe3 = nil
		bombe4 = nil
		bombe5 = nil
		bombe6 = nil
		bombe7 = nil
	  
		un = nil 
		deux = nil
		trois = nil
		boum = nil
		
		wariodos = nil
		argent = nil
		argent2 = nil
		argent3 = nil
		p1 = nil
		p2 = nil
		p3 = nil
		souris = nil
		ec = nil
		end

screen.flip()
screen.waitVblankStart()
for tempo = 1, 2000 do 
max = tempo + 1
end
end 	  

