System.memclean()
vert = Color.new(0,255,0)
noir = Color.new(0,0,0)
blanc = Color.new(255,255,255)
rouge = Color.new(255,0,0)
bleu = Color.new(0,0,255)
violet = Color.new(255,0,255)
cyan = Color.new(0,255,255)
jaune = Color.new(255,255,0)
white = Color.new(0,0,0)
green = Color.new(0,255,0)


statut_standing = {}
statut_standing[1] = {xs=17, y=5, lg=30, h=33, n=4}
statut_standing[2] = {xs=57, y=5, lg=30, h=33, n=4}
statut_standing[3] = {xs=93, y=5, lg=30, h=33, n=4}
statut_standing[4] = {xs=127, y=5, lg=30, h=33, n=4}

statut_droite = {}
statut_droite[1] = {xs=17, y=94, lg=26, h=33, n=4}
statut_droite[2] = {xs=57, y=94, lg=26, h=33, n=4}
statut_droite[3] = {xs=93, y=94, lg=26, h=33, n=4}
statut_droite[4] = {xs=127, y=94, lg=26, h=33, n=4}


statut_gauche = {}
statut_gauche[1] = {xs=17, y=136, lg=26, h=33, n=4}
statut_gauche[2] = {xs=57, y=136, lg=26, h=33, n=4}
statut_gauche[3] = {xs=93, y=136, lg=26, h=33, n=4}
statut_gauche[4] = {xs=127, y=136, lg=26, h=33, n=4}


statut_dos = {}
statut_dos[1] = {xs=17, y=50, lg=30, h=33, n=5}
statut_dos[2] = {xs=57, y=50, lg=30, h=33, n=5}
statut_dos[3] = {xs=93, y=50, lg=30, h=33, n=5}
statut_dos[4] = {xs=127, y=50, lg=30, h=33, n=5}
statut_dos[5] = {xs=169, y=50, lg=30, h=33, n=5}



labyrinthe = Image.load("modeselection/minijeux6/labyrinthes.png")
wario = Image.load("modeselection/minijeux6/spriteswario.png")
masque = Image.load("modeselection/minijeux6/mlabyrinthes.png")



compteur_statut = 1 
compteur_statut1 = 1
compteur_statut2 = 1
compteur_statut3 = 1
mapx = 0
mapy = 0
positionx = 210
positiony = 20
oldx = positionx
oldy = positiony

function test()
couleur = masque:pixel(1,1)
if couleur == vert then
positionx = oldx
positiony = oldy
end
end
 
while fin ~= 1 do
screen:clear()

screen:blit(mapx,mapy,masque)
screen:blit(mapx,mapy,labyrinthe)



pad = Controls.read()


if pad:up() then
compteur_statut3 = compteur_statut3 +1
oldy = positiony
oldx = positionx
positiony = positiony - 3
test()
statut = "up"
mapy = mapy + 3
end
if pad:down() then
oldy = positiony
oldx = positionx
positiony = positiony +3
test()
compteur_statut = compteur_statut +1
statut = "down"
mapy = mapy - 3
end
if pad:left() then
oldy = positiony
oldx = positionx
positionx = positionx - 3
test()
compteur_statut2 = compteur_statut2 +1
statut = "left"
mapx = mapx + 3
end
if pad:right() then
oldy = positiony
oldx = positionx
positionx = positionx + 3
test()
compteur_statut1 = compteur_statut1 +1
statut = "right"
mapx = mapx - 3
end

function deplacement1()
if compteur_statut == 1 then
screen:blit(positionx, positiony-(statut_standing[compteur_statut].h),wario, statut_standing[compteur_statut].xs, statut_standing[compteur_statut].y, statut_standing[compteur_statut].lg, statut_standing[compteur_statut].h)
end
if compteur_statut == 2 then
screen:blit(positionx,positiony-(statut_standing[compteur_statut].h),wario, statut_standing[compteur_statut].xs, statut_standing[compteur_statut].y, statut_standing[compteur_statut].lg, statut_standing[compteur_statut].h)
end
if compteur_statut == 3 then
screen:blit(positionx,positiony-(statut_standing[compteur_statut].h),wario, statut_standing[compteur_statut].xs, statut_standing[compteur_statut].y, statut_standing[compteur_statut].lg, statut_standing[compteur_statut].h)
end
end

if compteur_statut == 4 then
screen:blit(positionx, positiony-(statut_standing[compteur_statut].h),wario, statut_standing[compteur_statut].xs, statut_standing[compteur_statut].y, statut_standing[compteur_statut].lg, statut_standing[compteur_statut].h)
compteur_statut = 1
end







function deplacement2()
if compteur_statut1 == 1 then
screen:blit(positionx, positiony-(statut_droite[compteur_statut1].h),wario, statut_droite[compteur_statut1].xs, statut_droite[compteur_statut1].y, statut_droite[compteur_statut1].lg, statut_droite[compteur_statut1].h)
end
if compteur_statut1 == 2 then
screen:blit(positionx,positiony-(statut_droite[compteur_statut1].h),wario, statut_droite[compteur_statut1].xs, statut_droite[compteur_statut1].y, statut_droite[compteur_statut1].lg, statut_droite[compteur_statut1].h)
end
if compteur_statut1 == 3 then
screen:blit(positionx,positiony-(statut_droite[compteur_statut1].h),wario, statut_droite[compteur_statut1].xs, statut_droite[compteur_statut1].y, statut_droite[compteur_statut1].lg, statut_droite[compteur_statut1].h)
end
end

if compteur_statut1 == 4 then
screen:blit(positionx, positiony-(statut_droite[compteur_statut1].h),wario, statut_droite[compteur_statut1].xs, statut_droite[compteur_statut1].y, statut_droite[compteur_statut1].lg, statut_droite[compteur_statut1].h)
compteur_statut1 = 1
end



function deplacement3()
if compteur_statut2 == 1 then
screen:blit(positionx,positiony-(statut_gauche[compteur_statut2].h),wario, statut_gauche[compteur_statut2].xs, statut_gauche[compteur_statut2].y, statut_gauche[compteur_statut2].lg, statut_gauche[compteur_statut2].h)
end
if compteur_statut2 == 2 then
screen:blit(positionx,positiony-(statut_gauche[compteur_statut2].h),wario, statut_gauche[compteur_statut2].xs, statut_gauche[compteur_statut2].y, statut_gauche[compteur_statut2].lg, statut_gauche[compteur_statut2].h)
end
if compteur_statut2 == 3 then
screen:blit(positionx,positiony-(statut_gauche[compteur_statut2].h),wario, statut_gauche[compteur_statut2].xs, statut_gauche[compteur_statut2].y, statut_gauche[compteur_statut2].lg, statut_gauche[compteur_statut2].h)
end
end

if compteur_statut2 == 4 then
screen:blit(positionx, positiony-(statut_gauche[compteur_statut2].h),wario, statut_gauche[compteur_statut2].xs, statut_gauche[compteur_statut2].y, statut_gauche[compteur_statut2].lg, statut_gauche[compteur_statut2].h)
compteur_statut2 = 1
end




function deplacement4()
if compteur_statut3 == 1 then
screen:blit(positionx,positiony-(statut_dos[compteur_statut3].h),wario, statut_dos[compteur_statut3].xs, statut_dos[compteur_statut3].y, statut_dos[compteur_statut3].lg, statut_dos[compteur_statut3].h)
end
if compteur_statut3 == 2 then
screen:blit(positionx,positiony-(statut_dos[compteur_statut3].h),wario, statut_dos[compteur_statut3].xs, statut_dos[compteur_statut3].y, statut_dos[compteur_statut3].lg, statut_dos[compteur_statut3].h)
end
if compteur_statut3 == 3 then
screen:blit(positionx,positiony-(statut_dos[compteur_statut3].h),wario, statut_dos[compteur_statut3].xs, statut_dos[compteur_statut3].y, statut_dos[compteur_statut3].lg, statut_dos[compteur_statut3].h)
end
if compteur_statut3 == 4 then
screen:blit(positionx, positiony-(statut_dos[compteur_statut3].h),wario, statut_dos[compteur_statut3].xs, statut_dos[compteur_statut3].y, statut_dos[compteur_statut3].lg, statut_dos[compteur_statut3].h)
end
end

if compteur_statut3 == 5 then
screen:blit(positionx,positiony-(statut_dos[compteur_statut3].h),wario, statut_dos[compteur_statut3].xs, statut_dos[compteur_statut3].y, statut_dos[compteur_statut3].lg, statut_dos[compteur_statut3].h)
compteur_statut3 = 1
end

if statut == "down" then 
deplacement1()
end

if statut == "right" then 
deplacement2()
end


if statut == "left" then 
deplacement3()
end

if statut == "up" then 
deplacement4()
end

if System.memclean() then
labyrinthe = nil
wario = nil
mlabyrinthe = nil
victoire = nil 
end

System.memclean()
-- condtions victoire 

if positionx and positiony and positiony >=  301 then
screen:print(100,200," Vous etes sorti ! Bravo",rouge)
end

screen.waitVblankStart()
screen.flip()

for tempo = 1, 2000 do 
max = tempo + 1
end
end


