b1 = Color.new(255,0,0)
b2 = Color.new(10,253,20)
b3 = Color.new(30,245,40)
b4 = Color.new(0,0,255)
b5 = Color.new(70,227,80)
b6 = Color.new(0,0,255)
b7 = Color.new(110,236,120)
b8 = Color.new(130,245,140)
b9 = Color.new(150,253,160)
b10 = Color.new(170,255,180)

bk =  Image.load("images/AllTeam.png" )

font = Font.load("font/fontc.ttf")
font:setPixelSizes(25,25)

CreditsY = 272

while true do
screen:clear()
pad = Controls.read() 

CreditsY = CreditsY - 2

screen:blit(0,0,bk)

screen:fontPrint(font,50,CreditsY+10,"The All Team vous souhaite un bon jeu",b1)
screen:fontPrint(font,145,CreditsY+30,"Team constitue de :",b2)
screen:fontPrint(font,155,CreditsY+50,"Codeur",b3)
screen:fontPrint(font,155,CreditsY+70,"Jade2293",b4)
screen:fontPrint(font,155,CreditsY+90,"Sandy62120",b6)
screen:fontPrint(font,145,CreditsY+110,"Graphiste/ Semi-codeur :",b7)
screen:fontPrint(font,155,CreditsY+130,"ThOom",b8)
screen:fontPrint(font,155,CreditsY+150,"Contribeur Id�e/ Codeur : ",b3)
screen:fontPrint(font,155,CreditsY+170,"Ac - Portugal",b4)
screen:fontPrint(font,155,CreditsY+190,"Beethovans",b6)
screen:fontPrint(font,155,CreditsY+210,"The All Team",b9)

if System.memclean() then
bk = nil
font = nil
end

if CreditsY <= (-220) then
System.memclean()
dofile("menu.lua")
System.memclean()
end




screen.waitVblankStart()
screen.flip()
end
