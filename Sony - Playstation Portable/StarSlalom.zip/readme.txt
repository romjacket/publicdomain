This is an unofficial clone of JetSlalom by MR-C for the PSP. (With a StarFox twist)

This release uses no code or resources form the original game.

Install:
Copy the StarSlalom folder to PSP/GAME or PSP/GAME150 on your PSP.

Notes:
Since this still uses the old luaplayer 0.16 for speed, it requires the 1.5 kernel. If you want, you could try running it with a modded luaplayer, but it might not run full-speed.

The code is a bit weirdly designed, I don't really know what I was thinking at the time.

You can use whatever you want from the code for whatever you want, but I would appreciate you not bytecoding it and giving me a shout as to what it will be used for.

Credits:
"Br�dy (Blood Drip)" for Arwing 3D model (http://sketchup.google.com/3dwarehouse/details?mid=ff572293ac98f874b1bb33592cef0aea)
"Greatfox" for background music (http://www.geocities.com/Hollywood/Theater/1870/)
PSProgrammer for logo graphic help (Even though I eventually didn't go with his images)
Merick for Gu Image Blitting code
The developer/s of luaplayer 0.16 (Shine and Nevyn)

Contact:
If you need anything, send me a message on the QJ forums, or email me at nielkie@gmail.com

Disclaimer:
THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.