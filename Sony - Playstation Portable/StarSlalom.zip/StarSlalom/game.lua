--System.usbDiskModeActivate()

dofile("Gu.lua")
dofile("ArwingModel.lua")

white = Color.new(255, 255, 255)
black = Color.new(0,0,0)
red = Color.new(255,0,0)
green = Color.new(0,255,0)
darkgreen = Color.new(65,198,75)
darkergreen = Color.new(0,140,69)
blue = Color.new(0,0,255)
yellow = Color.new(255, 255, 0)
pink = Color.new(252, 15, 192)
pinkred = Color.new(255,168,168)
lightblue = Color.new(0, 193, 234)
grey = Color.new(128,128,128)

pinkblue = Color.new(204, 201, 218)
green2 = Color.new(142, 200, 72)

plainyellow = Color.new(242, 223, 206)
greenbrown = Color.new(122, 220, 69)

skyblue = Color.new(129, 171, 209)
green3 = Color.new(55, 130, 7)

--[[
function System.checkFile(fileN)
	local files = System.listDirectory()
	for i, file in files do
		if file.name == fileN then
			return true
		end
	end
	return false
end
]]--

Pylons = {tempTimer = 0, direction = 0, gap = 20, pos = 0, movTimer = 0, mingap = 6}
Pylons.Colours = {pink,blue,yellow,red}

function Pylons.new(x)
	local ins = {}
	ins.x = x -- math.randon(-30,30)
--	ins.x = 0 --DEBUG-------------------------------------------------------------
	ins.distance = -27 -- -50
	ins.colour = Pylons.Colours[math.random(4)]
	table.insert(Pylons,ins)
end

function Pylons.spawn()
	if Game.level == 4 then
		Pylons.tempTimer = Pylons.tempTimer + 1
		if Pylons.tempTimer >= 4 then
			if Pylons.gap > Pylons.mingap then
				Pylons.gap = Pylons.gap - 0.25
			else
				Pylons.movTimer = Pylons.movTimer + 1
				if Pylons.movTimer == 20 then
					Pylons.direction = 0.75
				elseif Pylons.movTimer == 80 then
					Pylons.direction = -0.75
				elseif Pylons.movTimer == 105 then
					Pylons.direction = 0.5
				elseif Pylons.movTimer == 130 then
					Pylons.direction = -0.1
				elseif Pylons.movTimer == 150 then
					Pylons.direction = 0.75
				elseif Pylons.movTimer == 190 then
					Pylons.direction = -0.05
				elseif Pylons.movTimer == 215 then
					Pylons.direction = -0.74
				elseif Pylons.movTimer == 240 then
					Pylons.direction = 0.2
				elseif Pylons.movTimer == 255 then
					Pylons.direction = -0.78
				elseif Pylons.movTimer == 275 then
					Pylons.direction = 0
				end
			end
			Pylons.tempTimer = 0
			Pylons.pos = Pylons.pos + Pylons.direction
			Pylons.new(Pylons.pos + (Pylons.gap / 2))
			Pylons.new(Pylons.pos - (Pylons.gap / 2))
		end
	else
		if math.random(Game.occurence) == 1 then
			Pylons.new(math.random(-30,30))
		end
	end
end

function Pylons.moveClip()
	local mod = (0.2 * (Background.rotation / 0.523))
	for i=1,table.getn(Pylons) do
		if Pylons[i] ~= nil then
		
			Pylons[i].distance = Pylons[i].distance + Game.speed
			--Pylons[i].x = Pylons[i].x - (0.2 * (Background.rotation / math.rad(30)))
			Pylons[i].x = Pylons[i].x - mod

			if Pylons[i].distance > 0 then
				table.remove(Pylons,i)
			end
		end
	end
	
	if Game.level == 4 then
		Pylons.pos = Pylons.pos - mod
	end
end

function Pylons.collision()
	for i=1,table.getn(Pylons) do
		--[[
		if Pylons[i].distance >= -3 and Pylons[i].distance < -2 then

			if (Background.rotation == 0) and Pylons[i].x > -1.4 and Pylons[i].x < 1.4 then
				collision = true
			elseif (Background.rotation > 0) and Pylons[i].x > -1.5 and Pylons[i].x < 1 then
				collision = true
			elseif (Background.rotation < 0) and Pylons[i].x > -1 and Pylons[i].x < 1.5 then
				collision = true
			end
			]]--
		if (Pylons[i].distance >= -3 and Pylons[i].distance < -1.6) then
			if math.abs(Background.rotation) <= 0.1 then
				return math.abs(Pylons[i].x) <= 0.8 or
						(
							(math.abs(Pylons[i].x) >= 0.8 and math.abs(Pylons[i].x) <= 1.2) and Pylons[i].distance >= -1.8
						)
			elseif (Background.rotation >= -0.3 and Background.rotation <= -0.1) then
				return 	(Pylons[i].x <= 0.8 and Pylons[i].x >= -0.4) or
						(
							(Pylons[i].x >= -0.7 and Pylons[i].x <= 1.5) and Pylons[i].distance >= -1.8
						)
			elseif (Background.rotation >= 0.1 and Background.rotation <= 0.3) then
				return 	(Pylons[i].x >= -0.8 and Pylons[i].x <= 0.4) or
						(
							(Pylons[i].x <= 0.7 and Pylons[i].x >= -1.5) and Pylons[i].distance >= -1.8
						)
			elseif (Background.rotation >= 0.3 and Background.rotation <= 0.523) then
				return 	(Pylons[i].x >= -1 and Pylons[i].x <= 0.2) or
						(
							(Pylons[i].x <= 0.4 and Pylons[i].x >= -1.5) and Pylons[i].distance >= -1.8
						)
			elseif (Background.rotation <= -0.3 and Background.rotation >= -0.523) then
				return 	(Pylons[i].x <= 1 and  Pylons[i].x >= -0.2) or
						(
							(Pylons[i].x >= -0.4 and Pylons[i].x <= 1.5) and Pylons[i].distance >= -1.8
						)
			end
		end
	end
	return false
end

function Pylons.blit()
	GuDrawPylons()
end

Ship = {
	--pic = Image.load("data/ship.png")
	model = GuCreateColModel(arwing, 0.008)
}
function Ship.controls()
	if pad:left() or pad:l() then
		--Background.rotation = Background.rotation - math.rad(1.2)
--		Background.rotation = Background.rotation - 0.0209
		Background.rotation = Background.rotation - 0.025
	end
	if pad:right() or pad:r() then
--		Background.rotation = Background.rotation + 0.0209
		Background.rotation = Background.rotation + 0.025
	end
--	if Background.rotation > math.rad(30) then
	if Background.rotation > 0.523 then
		Background.rotation = 0.523
	elseif Background.rotation < -0.523 then
		Background.rotation = -0.523
	end
end
function Ship.blit()
	--GuBlit(0,-0.5,-3,Ship.pic,0,0,0,1.8)
	GuDrawCOLModel(Ship.model,0,-0.5,-3,90 + (5 * (math.abs(Background.rotation) / 0.523)), 180 + (10 * (-Background.rotation / 0.523)), 90 + (5 * (-Background.rotation / 0.523)))
end

Background = {
	Color1 = lightblue,
	Color2 = green,
	rotation = 0}

function Background.blit()
	GuDrawBackground(Background.Color1,Background.Color2,Background.rotation)
end

function Background.stabalise()
	if Background.rotation ~= 0 and not pad:left() and not pad:right() and not pad:l() and not pad:r() then
		--if Background.rotation > math.rad(0.5) then
		if Background.rotation > 0.0087 then
			Background.rotation = Background.rotation - 0.0087
		elseif Background.rotation < -0.0087 then
			Background.rotation = Background.rotation + 0.0087
		else
			Background.rotation = 0
		end
	end
end

Background.lights = {allignment = 0,seperation = 5, vsep = 25}

function Background.lights.new(x)
	table.insert(Background.lights,{x = x, z = -45, colour = white})
end

function Background.lights.spawnInit()
	for i=-3,3 do
		for j=2,6 do
			--Background.lights.new(Background.lights.allignment + Background.lights.seperation * i)
			Background.lights.new(Background.lights.seperation * i)
			Background.lights[table.getn(Background.lights)].z = -45 + (j-1) * (Game.speed * Background.lights.vsep)
		end
	end
end

function Background.lights.moveClip()
	Background.lights.allignment = Background.lights.allignment - (0.2 * (Background.rotation / 0.523))
	
	if Background.lights.allignment > Background.lights.seperation then
		Background.lights.allignment = Background.lights.allignment - Background.lights.seperation
	elseif Background.lights.allignment < -Background.lights.seperation then
		Background.lights.allignment = Background.lights.allignment + Background.lights.seperation
	end	
	
	for i=1,table.getn(Background.lights) do
		--Background.lights[i].x = Background.lights[i].x - (0.2 * (Background.rotation / 0.523))

		Background.lights[i].z = Background.lights[i].z + Game.speed
		
		if Background.lights[i].z >= 0 then --or Background.lights[i].x < -30 or Background.lights[i].x > 30
		--	table.remove(Background.lights,i)
			Background.lights[i].z = -45
		end
	end
end

function Background.lights.blit()
	GuDrawLights(Background.lights)
end

Special = {}
function Special.printCentered(y,text,colour,target)
	target = target or screen
	colour = colour or Color.new(0,0,0)
	target:print(240 - (string.len(text) * 8) / 2,y,text,colour)	
end
function Special.printRight(y,text,colour,target)
	target = target or screen
	colour = colour or Color.new(0,0,0)
	target:print(480 - string.len(text) * 8,y,text,colour)
end

Menu = {logo = Image.load("logo.png")}
function Menu.printText()
	Special.printCentered(200,"Press START to start")
	Special.printRight(252, "All Time Best: " .. Game.bestEver, Game.textColour)
	Special.printRight(262,"Best: " .. Game.best)
end

Game = {
	frametimer = Timer.new(),
	fps = 0,
	best = 0,
	bestEver = 0,
	state = "Menu",
--	state = "Game",
	distance = 0,
	breakOut = false,
	speed = 0.4,
	occurence = 5,
	occdiv = 1,
	level = 1,
	textColour = black
}
	
function Game.difficulty()
	if Game.level == 1 and Game.distance > 2000 then
		Game.occurence = 4
--		Game.speed = 0.45
		Background.Color1 = pinkred
		Background.Color2 = darkgreen
		Game.level = 2
	elseif Game.level == 2 and Game.distance > 4000 then
		Game.occurence = 3
--		Game.speed = 0.5
		Background.Color1 = black
		Background.Color2 = darkergreen
		Game.textColour = white
		Game.level = 3
	elseif Game.level == 3  and Game.distance > 6000 then
		Background.Color1 = pinkblue
		Background.Color2 = green2
		Game.textColour = black
		Pylons.new(-Pylons.gap / 2)
		Pylons.new(Pylons.gap / 2)
		Game.level = 4
	elseif Game.level == 4 and Game.distance > 7500 then
		Game.occurence = 2
		Background.Color1 = plainyellow
		Background.Color2 = greenbrown
		Game.level = 5
	elseif Game.level == 5 and Game.distance > 10000 then
		Game.occurence = 1
		Background.Color1 = skyblue
		Background.Color2 = green3
		Game.level = 6
	end
end

function Game.reset()
	Game.distance = 0
	Game.speed = 0.4
	Game.occurence = 5
	Game.occdiv = 1
	Game.level = 1
	Game.textColour = black
	Background.rotation = 0
	Background.Color1 = lightblue
	Background.Color2 = green
	
	for i=1,table.getn(Background.lights) do
		table.remove(Background.lights,1)
	end
	
	Background.lights.timer = 0
	Background.lights.allignment = 0
	
	Background.lights.spawnInit()
	
	Pylons.Colours = {pink,blue,yellow,red}
	Pylons.tempTimer = 0
	Pylons.direction = 0
	Pylons.gap = 20
	Pylons.pos = 0
	for i=1,table.getn(Pylons) do
		table.remove(Pylons,1)
	end
	
	collectgarbage()
end

function Game.HUD()
	screen:print(1, 10, "Level: " .. Game.level, Game.textColour)
	Special.printRight(10,"Score: " .. math.floor(Game.distance / 2),Game.textColour)
	Special.printRight(252, "All Time Best: " .. Game.bestEver, Game.textColour)
	Special.printRight(262,"Best: " .. Game.best, Game.textColour)
end

--[[
function Game.readBest()
	local olddir = System.currentDirectory()
	System.currentDirectory("../../../SAVEDATA")
	if not System.checkFile("JetSlalom") then
		System.currentDirectory(olddir)
		return 0
	else
		System.currentDirectory("JetSlalom")
		local file = io.open("data.bin","r")
		local best = file:read("*n")
		file:close()
		System.currentDirectory(olddir)
		return best
	end
end
function Game.writeBest()
	local olddir = System.currentDirectory()
	System.currentDirectory("../../../SAVEDATA")
	if not System.checkFile("JetSlalom") then
		System.createDirectory("JetSlalom")
		pic1 = io.open(olddir .. "data/pic1.png","rb")
		pic1wirte = io.open("JetSlalom/pic1.png","wb")
		pic1wirte:write(pic1:read())
		pic1:close()
		pic1write:close()
		
		icon0 = io.open(olddir .. "data/icon0.png","rb")
		icon0wirte = io.open("JetSlalom/icon0.png","wb")
		icon0wirte:write(icon0:read())
		icon0:close()
		icon0write:close()
		
		--writePARAM.SFO
	end
	System.currentDirectory("JetSlalom")
	local file = io.open("data.bin","w")
	file:write(Game.best)
	file:close()
	System.currentDirectory(olddir)
end
]]--

function Game.readBest()
	local file = io.open("data.bin", "r")
	return tonumber(file:read("*a"))
end

function Game.writeBest(best)
	local file = io.open("data.bin", "w")
	file:write(best)
end

function Game.debugControls() ---DEBUG-------------------------------------------------------------
	if pad:l() then
		Background.rotation = Background.rotation + 0.0175
	end
	if pad:r() then
		Background.rotation = Background.rotation - 0.0175 --math.rad(1)
	end
	if pad:left() then
		Pylons[1].x = Pylons[1].x - 0.1
	end
	if pad:right() then
		Pylons[1].x = Pylons[1].x + 0.1
	end
	if pad:up() then
		Pylons[1].distance = Pylons[1].distance + 0.1
	end
	if pad:down() then
		Pylons[1].distance = Pylons[1].distance - 0.1
	end
end

function Game.debug() ---DEBUG-------------------------------------------------------------
	--screen:print(10,10,"X: " .. Pylons[1].x,Game.textColour)
	--screen:print(10,20,"Dist: " .. Pylons[1].distance,Game.textColour)
	screen:print(10,30,"Lev: " .. Game.level,Game.textColour)
	screen:print(10,40,"Speed: " .. Game.speed,Game.textColour)
	screen:print(10,50,"Occ: " .. Game.occurence,Game.textColour)
	screen:print(10,60,"Dis: " .. Game.distance,Game.textColour)
	screen:print(10,70,"Rot: " .. Background.rotation,Game.textColour)
	screen:print(10,80,"Num: " .. table.getn(Pylons),Game.textColour)
	screen:print(10,90,"Pos: " .. Pylons.pos,Game.textColour)

	
	if Pylons.collision() then
		screen:print(10,100,"Coll: true",Game.textColour)
	else
		screen:print(10,100,"Coll: false",Game.textColour)
	end
	
	screen:print(10,110,"Lights: " .. table.getn(Background.lights),Game.textColour)
end

Game.bestEver = Game.readBest()
Music.playFile("corneria.XM", true)

Background.lights.spawnInit()

Game.frametimer:start()

Game.loop = {
	["Game"] = function()
		pad = Controls.read()
		--if pad:start() then Game.breakOut = true end
		
		screen:clear(white)
		local frametime = Game.frametimer:time()
		if frametime ~= 0 then
			Game.fps = 1000 / frametime
		end
		Game.frametimer:reset()
		Game.frametimer:start()
		
		Game.distance = Game.distance + 1
		
		--Game.debugControls() --DEBUG-------------------------------------------------------------
		Ship.controls()
		
		Background.stabalise()
		
		Pylons.spawn()
		Pylons.moveClip()

		Background.lights.moveClip()
		
		start_gu()---------GU BEGIN---------
		
		Background.blit()
		Background.lights.blit()
		
		Pylons.blit()
		
		Ship.blit()
		
		Gu.end3d()---------GU END---------
		
		Game.HUD()
		
		--Game.debug() --DEBUG-------------------------------------------------------------

		if Pylons.collision() then
	--	if false then
			screen:print(200, 136,"GAME OVER", Game.textColour)
			Game.HUD()
			screen.waitVblankStart()
			screen.flip()
			screen.waitVblankStart(120)
--			Game.breakOut = true
			if math.floor(Game.distance / 2) > Game.best then
				Game.best = math.floor(Game.distance / 2)
			end
			if Game.best > Game.bestEver then
				Game.bestEver = Game.best
				Game.writeBest(Game.bestEver)
			end
			Game.reset()
			Game.state = "Menu"
		end
		--[[
		if pad:select() then
			Game.reset()
			Game.state = "Menu"
		end		
		]]--
		Game.difficulty()
		
		--if pad:select() then screen:save("ms0:/PICTURE/JetSlalomScreen.png") end
		
		--screen.waitVblankStart(3)
		screen.flip()
	end,
	["Menu"] = function()
		pad = Controls.read()
		
		screen:clear(white)
		
		Pylons.spawn()
		Pylons.moveClip()
	
		--Background.lights.spawn()	
		Background.lights.moveClip()
		
		start_gu()
		
		Background.blit()
		
		Background.lights.blit()
		
		Pylons.blit()
		
		GuBlit( 0, 0.14, -0.5, Menu.logo, 0, 0, 0, 0.25)
		
		Gu.end3d()
		
		Menu.printText()
		
		if pad:start() then Game.reset() Game.state = "Game" end
		--if pad:note() then screen:save("ms0:/PICTURE/JetSlalomScreen.png") end
		
		--screen.waitVblankStart(3)
		screen.flip()
	end
}

--Pylons.new(0) ---DEBUG-------------------------------------------------------------

math.randomseed(os.time())
while true do
	Game.loop[Game.state]()
	if Game.breakOut then break end
end