function start_gu(fov) -- starts the gu for drawing with the GuBlit function, 
--if you dont put anything in the () when calling this function the fov will default to 50

	if fov == nil then fov = 50 end
	Gu.start3d()
	Gu.clearDepth(0);
	Gu.clear(Gu.COLOR_BUFFER_BIT+Gu.DEPTH_BUFFER_BIT)
	Gum.matrixMode(Gu.PROJECTION)
	Gum.loadIdentity()
	Gum.perspective(fov, 480/272, 0.5, 1000)
	Gum.matrixMode(Gu.VIEW)
	Gum.loadIdentity()
	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	Gu.enable(Gu.BLEND)
	Gu.blendFunc(Gu.ADD, Gu.SRC_ALPHA, Gu.ONE_MINUS_SRC_ALPHA, 0, 0)
end

function GuBlit(bx, by, bz, img, xrot, yrot, zrot, size)
	local w = img:width()/2
	local h = img:height()/2
	
	xrot = math.rad(xrot)
	yrot = math.rad(yrot)
	zrot = math.rad(zrot)

	if size == nil then size = 1 else size = size / 100 end
	
	local imagetile = {
		-- top section
		{ .5,  .5,   0,   0,  0},
		{  0,   0,  -w*size,   h*size,  0},
		{  1,   0,   w*size,   h*size,  0},
		-- right section
		{0.5, 0.5,   0,   0,  0},
		{  1,   0,   w*size,   h*size,  0},
		{  1,   1,   w*size,  -h*size,  0},
		-- bottom section
		{0.5, 0.5,   0,   0,  0},
		{  1,   1,   w*size,  -h*size,  0},
		{  0,   1,  -w*size,  -h*size,  0},
		-- left section
		{0.5, 0.5,   0,   0,  0},
		{  0,   1,  -w*size,  -h*size,  0},
		{  0,   0,  -w*size,   h*size,  0},   
		}
	
	Gu.enable(Gu.TEXTURE_2D);
	Gu.texImage(img)
	Gu.texFunc(Gu.TFX_MODULATE, Gu.TCC_RGBA)
	Gu.texFilter(Gu.LINEAR, Gu.LINEAR)
	Gu.texScale(1, 1)
	Gu.texOffset(0, 0)
	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	Gum.translate(bx, by, bz);
	Gum.rotateXYZ(xrot, yrot, zrot)
	Gum.drawArray(Gu.TRIANGLES, Gu.TEXTURE_32BITF+Gu.VERTEX_32BITF+Gu.TRANSFORM_3D, imagetile)
end

function GuCreateColModel(model, scale)
	local Fmodel = {}
	for i,ver in ipairs(model.m) do
		table.insert(Fmodel,
			{
				model.c[ver[1]], 
				model.v[ver[2] + 1][1] * scale, 
				model.v[ver[2] + 1][2] * scale, 
				model.v[ver[2] + 1][3] * scale
			}
		)
	end
	
	return Fmodel
end

function GuDrawCOLModel(model, x, y, z, rotx, roty, rotz)
	x = x or 0
	y = y or 0
	z = z or 0
	rotx = rotx or 0
	roty = roty or 0
	rotz = rotz or 0
	
	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	Gum.translate(x, y, z) --Won't work :-p, too lazy to change collision algo.
	Gu.disable(Gu.TEXTURE_2D)
	Gum.rotateXYZ(math.rad(rotx), math.rad(roty), math.rad(rotz))
	Gum.drawArray(Gu.TRIANGLES, Gu.COLOR_8888+Gu.VERTEX_32BITF+Gu.TRANSFORM_3D, model)
end

function GuDrawPylons()
	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	local triangles = {}
	for i,pylon in ipairs(Pylons) do
		table.insert(triangles,{pylon.colour,pylon.x + -0.5,-1,pylon.distance})
		table.insert(triangles,{pylon.colour,pylon.x + 0,1,pylon.distance})
		table.insert(triangles,{pylon.colour,pylon.x + 0.5,-1,pylon.distance})
	end
	Gum.translate(0, 0.2, 0)
	Gu.disable(Gu.TEXTURE_2D)
	Gum.rotateXYZ(0, 0, Background.rotation)
	Gum.drawArray(Gu.TRIANGLES, Gu.COLOR_8888+Gu.VERTEX_32BITF+Gu.TRANSFORM_3D, triangles)
end

function GuDrawLights(lights)
	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	local array = {}

	for i,light in ipairs(lights) do
		local x = light.x + Background.lights.allignment
		table.insert(array,{white,x - 2,-1,light.z})
		table.insert(array,{white,x + 2,-1,light.z})
	end
	
	Gum.translate(0, 0.2, 0)
	Gu.disable(Gu.TEXTURE_2D)
	Gum.rotateXYZ(0, 0, Background.rotation)
	
	Gum.drawArray(Gu.LINES, Gu.COLOR_8888+Gu.VERTEX_32BITF+Gu.TRANSFORM_3D, array)
end

function GuDrawBackground(Colour1,Colour2,rotation)
	local cpoint = {x = 240,y = 136}
	local point1 = {x = cpoint.x + 300 * math.cos(rotation - math.pi),y = cpoint.y + 300 * math.sin(rotation - math.pi)}
	local point2 = {x = cpoint.x + 300 * math.cos(rotation),y = cpoint.y + 300 * math.sin(rotation)}
--	screen:drawLine(point1.x,point1.y,point2.x,point2.y,Colour1)
	
	local triangles = {
		{Colour1,-243,139,0},
		{Colour1,243,139,0},
		{Colour1,point1.x - 240,point1.y - 136,0},
		
		{Colour1,point1.x - 240,point1.y - 136,0},
		{Colour1,243,139,0},
		{Colour1,point2.x - 240,point2.y - 136,0},
		
		{Colour2,-243,-139,0},
		{Colour2,point1.x - 240,point1.y - 136,0},
		{Colour2,point2.x - 240,point2.y - 136,0},

		{Colour2,-243,-139,0},
		{Colour2,point2.x - 240,point2.y - 136,0},
		{Colour2,243,-139,0}
	}
	
	Gum.matrixMode(Gu.MODEL)
	Gum.loadIdentity()
	Gum.translate(0, 0, -294);
	Gu.disable(Gu.TEXTURE_2D)
	Gum.drawArray(Gu.TRIANGLES, Gu.COLOR_8888+Gu.VERTEX_32BITF+Gu.TRANSFORM_3D, triangles)
end