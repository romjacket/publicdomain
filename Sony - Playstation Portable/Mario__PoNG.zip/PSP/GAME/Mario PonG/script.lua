back = Image.load("menu.png")

while true do
screen:blit(0,0,back)
pad = Controls.read()
Mp3me.load("hello.mp3") 
if pad:cross() then
dofile("choix.lua")
end

if pad:circle() then
dofile("credit.lua")
end

Mp3me.play()
screen.flip()
screen.waitVblankStart()
end 