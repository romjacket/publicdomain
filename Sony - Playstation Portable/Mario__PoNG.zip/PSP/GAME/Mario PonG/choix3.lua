choix = Image.load("choix3.png")

while true do
pad = Controls.read()
screen:blit(0,0,choix)

if pad:cross() then
dofile("difficile.lua")
end

if pad:up() then
dofile("choix2.lua")
end


screen.flip()
screen.waitVblankStart()
end 