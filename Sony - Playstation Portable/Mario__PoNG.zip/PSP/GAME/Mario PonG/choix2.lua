choix = Image.load("choix2.png")

while true do
pad = Controls.read()
screen:blit(0,0,choix)

if pad:cross() then
dofile("moyen.lua")
end

if pad:up() then
dofile("choix.lua")
end

if pad:down() then
dofile("choix3.lua")
end
screen.flip()
screen.waitVblankStart()
end 