choix = Image.load("choix.png")

while true do
pad = Controls.read()
screen:blit(0,0,choix)

if pad:cross() then
dofile("facile.lua")
end

if pad:down() then
dofile("choix2.lua")
end

screen.flip()
screen.waitVblankStart()
end 