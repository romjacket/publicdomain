Raquette1 = { x = 0, y = 111, vit = 3, score = "0", image = Image.load("images/raquette1.png") }
Raquette2 = { x = 450, y = 111, vit = 3, score = "0", image = Image.load("images/raquette2.png") }
Balle = { x = 240 , y = 136 , vitessex = 3, vitessey = -3 , image = Image.load("images/balle.png") }
status = "Menu"
fond = Image.load("fond.png")
fondc = Image.load("coll.png")
back = Image.load("back.png")
pause = Image.load("pause.png")
c1 = Image.load("c1.png")
blanc = Color.new(255,255,255)
bleu = Color.new(0,183,239)
bleuf = Color.new(0,0,255)
function affjeu()
screen:print(227,7,Raquette1.score.." - "..Raquette2.score,bleu)  --Scores
screen:blit(Raquette1.x,Raquette1.y,Raquette1.image)
screen:blit(Raquette2.x,Raquette2.y,Raquette2.image)
screen:blit(Balle.x,Balle.y,Balle.image)
end

sccnt=1

function deplaceraquettes()

if pad:down() then Raquette1.y = Raquette1.y + 3 end
if pad:up() then Raquette1.y = Raquette1.y -  3 end

if pad:cross() then Raquette2.y = Raquette2.y + Raquette2.vit end
if pad:triangle() then Raquette2.y = Raquette2.y - Raquette2.vit end
 
if Raquette1.y >= 272-Raquette1.image:height() then Raquette1.y = 272-Raquette1.image:height() end
if Raquette1.y <= 0 then Raquette1.y = 0 end
if Raquette2.y >= 272-Raquette2.image:height() then Raquette2.y = 272-Raquette1.image:height() end
if Raquette2.y <= 0 then Raquette2.y = 0 end

end

while true do
 
pad = Controls.read()
screen:clear()

if status == "Menu" then
screen:blit(0,0,c1)
if pad:cross() then status = "Jeu" end
end

if  status == "Jeu" then
screen:blit(0,0,fond)
screen:blit(0,0,fondc)
screen:blit(0,0,back)
affjeu()
deplaceraquettes()
 
Balle.x = Balle.x + Balle.vitessex
Balle.y = Balle.y + Balle.vitessey
if couleur ~= bleuf == false then y = y + 2 end
if (Balle.y + Balle.image:height() > Raquette1.y) and (Balle.y < Raquette1.y + Raquette1.image:height()) and (Balle.x < Raquette1.x+Raquette1.image:width()) then
Balle.x = Raquette1.x + Raquette1.image:width()
Balle.vitessex = 3
end

if pad:select() then
screen:save("ms0:/PSP/PHOTO/"..sccnt..".png")
sccnt=sccnt+1 end

if (Balle.x + Balle.image:width() > Raquette2.x) and (Balle.y + Balle.image:height() > Raquette2.y) and (Balle.y < Raquette2.y + Raquette2.image:height()) then
Balle.x = Raquette2.x - Balle.image:width()
Balle.vitessex = -3
end

if Balle.y < 0 then Balle.vitessey = 3 end
if Balle.y + Balle.image:height() > 272 then Balle.vitessey = -3 end

if Balle.x < 0 then
Raquette2.score = Raquette2.score + 1
Balle.vitessex = 3
end
 
if Balle.x+Balle.image:width() > 480 then
Raquette1.score = Raquette1.score + 1
Balle.vitessex = -3
end
 
if pad:start() then
status = "Pause"
end

end

if status == "Pause" then
affjeu()
screen:blit(0,0,pause)
if pad:circle() then
status = "Jeu"
end
end
 

screen.waitVblankStart()
screen.flip()
end 