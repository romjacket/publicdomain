page = {"start","langue","menu","option","decor","perso","cible","jeu","score","scorepage"}
pagePos = 1
pageNbr = 10

startFond = Image.load("img/start.jpg")
startFond1 = Image.load("img/start1.png")
startFond2 = Image.load("img/start2.png")

bg = Image.load("img/bg.jpg")

langue = {"deutsh","english","espanol","francais"}
languePos = 1
langueNbr = 4
langueImgJ = {Image.load("img/de/langue_j.png"),Image.load("img/eng/langue_j.png"),Image.load("img/esp/langue_j.png"),Image.load("img/fr/langue_j.png")}
langueImgO = {Image.load("img/de/langue_o.png"),Image.load("img/eng/langue_o.png"),Image.load("img/esp/langue_o.png"),Image.load("img/fr/langue_o.png")}
langueDrapeau = {Image.load("img/de/drapeau.jpg"),Image.load("img/eng/drapeau.jpg"),Image.load("img/esp/drapeau.jpg"),Image.load("img/fr/drapeau.jpg")}



menu = {"jouer", "options","records","quitter"}
menuPos = 1
menuNbr = 4
menuImgAllJ = {Image.load("img/de/menu1_j.png"),Image.load("img/de/menu2_j.png"),Image.load("img/de/menu3_j.png"),Image.load("img/de/menu4_j.png")}
menuImgEngJ = {Image.load("img/eng/menu1_j.png"),Image.load("img/eng/menu2_j.png"),Image.load("img/eng/menu3_j.png"),Image.load("img/eng/menu4_j.png")}
menuImgEspJ = {Image.load("img/esp/menu1_j.png"),Image.load("img/esp/menu2_j.png"),Image.load("img/esp/menu3_j.png"),Image.load("img/esp/menu4_j.png")}
menuImgFrJ = {Image.load("img/fr/menu1_j.png"),Image.load("img/fr/menu2_j.png"),Image.load("img/fr/menu3_j.png"),Image.load("img/fr/menu4_j.png")}
menuImgJ = {menuImgAllJ,menuImgEngJ,menuImgEspJ,menuImgFrJ}

menuImgAllO = {Image.load("img/de/menu1_o.png"),Image.load("img/de/menu2_o.png"),Image.load("img/de/menu3_o.png"),Image.load("img/de/menu4_o.png")}
menuImgEngO = {Image.load("img/eng/menu1_o.png"),Image.load("img/eng/menu2_o.png"),Image.load("img/eng/menu3_o.png"),Image.load("img/eng/menu4_o.png")}
menuImgEspO = {Image.load("img/esp/menu1_o.png"),Image.load("img/esp/menu2_o.png"),Image.load("img/esp/menu3_o.png"),Image.load("img/esp/menu4_o.png")}
menuImgFrO = {Image.load("img/fr/menu1_o.png"),Image.load("img/fr/menu2_o.png"),Image.load("img/fr/menu3_o.png"),Image.load("img/fr/menu4_o.png")}
menuImgO = {menuImgAllO,menuImgEngO,menuImgEspO,menuImgFrO}

option = {"temps","langue","retour"}
optionPos = 1
optionNbr = 3
optionImgAllJ = {Image.load("img/de/option1_j.png"),Image.load("img/de/option2_j.png"),Image.load("img/de/option3_j.png")}
optionImgEngJ = {Image.load("img/eng/option1_j.png"),Image.load("img/eng/option2_j.png"),Image.load("img/eng/option3_j.png")}
optionImgEspJ = {Image.load("img/esp/option1_j.png"),Image.load("img/esp/option2_j.png"),Image.load("img/esp/option3_j.png")}
optionImgFrJ = {Image.load("img/fr/option1_j.png"),Image.load("img/fr/option2_j.png"),Image.load("img/fr/option3_j.png")}
optionImgJ = {optionImgAllJ,optionImgEngJ,optionImgEspJ,optionImgFrJ}

optionImgAllO = {Image.load("img/de/option1_o.png"),Image.load("img/de/option2_o.png"),Image.load("img/de/option3_o.png")}
optionImgEngO = {Image.load("img/eng/option1_o.png"),Image.load("img/eng/option2_o.png"),Image.load("img/eng/option3_o.png")}
optionImgEspO = {Image.load("img/esp/option1_o.png"),Image.load("img/esp/option2_o.png"),Image.load("img/esp/option3_o.png")}
optionImgFrO = {Image.load("img/fr/option1_o.png"),Image.load("img/fr/option2_o.png"),Image.load("img/fr/option3_o.png")}
optionImgO = {optionImgAllO,optionImgEngO,optionImgEspO,optionImgFrO}


decorPos = 1
decorNbr = 10
decorImg1 = {Image.load("img/de/decor1.png"),Image.load("img/eng/decor1.png"),Image.load("img/esp/decor1.png"),Image.load("img/fr/decor1.png")}
decorImg2 = {Image.load("img/de/decor2.png"),Image.load("img/eng/decor2.png"),Image.load("img/esp/decor2.png"),Image.load("img/fr/decor2.png")}

decorFond = {Image.load("img/fond1.jpg"),Image.load("img/fond2.jpg"),Image.load("img/fond3.jpg"),Image.load("img/fond4.jpg"),Image.load("img/fond5.jpg"),Image.load("img/fond6.jpg"),Image.load("img/fond7.jpg"),Image.load("img/fond8.jpg"),Image.load("img/fond9.jpg"),Image.load("img/fond10.jpg")}

decorFondMini = {Image.load("img/fondmini/fond1.jpg"),Image.load("img/fondmini/fond2.jpg"),Image.load("img/fondmini/fond3.jpg"),Image.load("img/fondmini/fond4.jpg"),Image.load("img/fondmini/fond5.jpg"),Image.load("img/fondmini/fond6.jpg"),Image.load("img/fondmini/fond7.jpg"),Image.load("img/fondmini/fond8.jpg"),Image.load("img/fondmini/fond9.jpg"),Image.load("img/fondmini/fond10.jpg")}


perso = {"cartman","stan","kyle","kenny"}
persoPos = 1
persoNbr = 4
persoImg = {Image.load("img/de/perso.png"),Image.load("img/eng/perso.png"),Image.load("img/esp/perso.png"),Image.load("img/fr/perso.png")}
persoSelect = {Image.load("img/perso1.png"),Image.load("img/perso2.png"),Image.load("img/perso3.png"),Image.load("img/perso4.png")}
personnage = {Image.load("img/cartman.png"),Image.load("img/stan.png"),Image.load("img/kyle.png"),Image.load("img/kenny.png")}

ciblePos = 1
cibleNbr = 12
cibleImg = {Image.load("img/cible/1.png"),Image.load("img/cible/2.png"),Image.load("img/cible/3.png"),Image.load("img/cible/4.png"),Image.load("img/cible/5.png"),Image.load("img/cible/6.png"),Image.load("img/cible/7.png"),Image.load("img/cible/8.png"),Image.load("img/cible/9.png"),Image.load("img/cible/10.png"),Image.load("img/cible/11.png"),Image.load("img/cible/12.png")}
cibleImg1 = {Image.load("img/de/cible1.png"),Image.load("img/eng/cible1.png"),Image.load("img/esp/cible1.png"),Image.load("img/fr/cible1.png")}
cibleImg2 = {Image.load("img/de/cible2.png"),Image.load("img/eng/cible2.png"),Image.load("img/esp/cible2.png"),Image.load("img/fr/cible2.png")}
 
affscoreImg = {Image.load("img/de/affscore.png"),Image.load("img/eng/affscore.png"),Image.load("img/esp/affscore.png"),Image.load("img/fr/affscore.png")}
afftempsImg = {Image.load("img/de/afftemps.png"),Image.load("img/eng/afftemps.png"),Image.load("img/esp/afftemps.png"),Image.load("img/fr/afftemps.png")}

pausemenuImg = {Image.load("img/de/menupause.png"),Image.load("img/eng/menupause.png"),Image.load("img/esp/menupause.png"),Image.load("img/fr/menupause.png")}

affichescoreImg1 = {Image.load("img/de/affichescore1.png"),Image.load("img/eng/affichescore1.png"),Image.load("img/esp/affichescore1.png"),Image.load("img/fr/affichescore1.png")}
affichescoreImg2 = {Image.load("img/de/affichescore2.png"),Image.load("img/eng/affichescore2.png"),Image.load("img/esp/affichescore2.png"),Image.load("img/fr/affichescore2.png")}
affichescoreImg3 = {Image.load("img/de/affichescore3.png"),Image.load("img/eng/affichescore3.png"),Image.load("img/esp/affichescore3.png"),Image.load("img/fr/affichescore3.png")}
affichescoreImg4 = {Image.load("img/de/affichescore4.png"),Image.load("img/eng/affichescore4.png"),Image.load("img/esp/affichescore4.png"),Image.load("img/fr/affichescore4.png")}

nbr = {Image.load("img/nbr/1.png"),Image.load("img/nbr/2.png"),Image.load("img/nbr/3.png"),Image.load("img/nbr/4.png"),Image.load("img/nbr/5.png"),Image.load("img/nbr/6.png"),Image.load("img/nbr/7.png"),Image.load("img/nbr/8.png"),Image.load("img/nbr/9.png"),Image.load("img/nbr/0.png")}

nbrmini = {Image.load("img/nbrmini/1.png"),Image.load("img/nbrmini/2.png"),Image.load("img/nbrmini/3.png"),Image.load("img/nbrmini/4.png"),Image.load("img/nbrmini/5.png"),Image.load("img/nbrmini/6.png"),Image.load("img/nbrmini/7.png"),Image.load("img/nbrmini/8.png"),Image.load("img/nbrmini/9.png"),Image.load("img/nbrmini/0.png")}


scorepageImg = Image.load("img/scorepage.png")
scorepageImg1 = {Image.load("img/de/scorepage1.png"),Image.load("img/eng/scorepage1.png"),Image.load("img/esp/scorepage1.png"),Image.load("img/fr/scorepage1.png")}
scorepageImg2 = {Image.load("img/de/scorepage2.png"),Image.load("img/eng/scorepage2.png"),Image.load("img/esp/scorepage2.png"),Image.load("img/fr/scorepage2.png")}


tempsJeu = {30,60}
tempsJeuPos = 1
tempsJeuNbr = 2
tempsJeuImgJ = {Image.load("img/30sj.png"), Image.load("img/60sj.png")}
tempsJeuImgO = {Image.load("img/30so.png"), Image.load("img/60so.png")}
flecheg = Image.load("img/flecheg.png")
fleched = Image.load("img/fleched.png")

gris = Color.new(180,180,180)
blanc = Color.new(255,255,255)
rouge = Color.new(255,0,0)

vitMin = 2
vitMax = 4
yMin = 10
yMax = 210

score = 0
vie = 100
vmvt = 3
personnage_retour_pos = 530
meilleurScore = false
showpda = false
pause = false

chrono = Timer.new()
oldpad = Controls.read()

arme = Image.load("img/gantboxe.png")
arme_pos = { x = 68, y = 172 , h = 30, w = 50}
personnage_pos = { x = 0, y = 100 , h = 96, w = 106}
cible1_pos = { x = 440, y = math.random(yMin,yMax) , v = math.random(vitMin,vitMax), h = 51, w = 43}
cible2_pos = { x = 440, y = math.random(yMin,yMax) , v = math.random(vitMin,vitMax), h = 51, w = 43}
cible3_pos = { x = 440, y = math.random(yMin,yMax) , v = math.random(vitMin,vitMax), h = 51, w = 43}


function remiseZero()
	chrono:reset(0)
	chrono:start()
	personnage_pos.x = 0
	personnage_pos.y = 100	
	arme_pos.x = 68
	arme_pos.y = 172
	cible1_pos.x = 440
	cible2_pos.x = 440
	cible3_pos.x = 440
	score = 0
	pause = false
	meilleurScore = false
end


function moveCible(obj)
	if obj.x > -60 then
		obj.x = obj.x - obj.v
		else
		obj.x = personnage_retour_pos
		obj.y = math.random(yMin,yMax)
		obj.v = math.random(vitMin,vitMax)
		if score ~= 0 then
			score = score - 1
		end
	end
end
function personnageTape(object)
	if persoPos == 1 then
		if (arme_pos.y-13 + arme_pos.h > object.y) and (arme_pos.y-13 < object.y + object.h) and (arme_pos.x+15 < object.x + object.w) and (arme_pos.x+15 + arme_pos.w > object.x) and maintenu then
				object.x = personnage_retour_pos
				object.y = math.random(yMin,yMax)
				object.v = math.random(vitMin,vitMax)
				score = score + 1
		end
	else
		if (arme_pos.y + arme_pos.h > object.y) and (arme_pos.y < object.y + object.h) and (arme_pos.x < object.x + object.w) and (arme_pos.x + arme_pos.w > object.x) and maintenu then
				object.x = personnage_retour_pos
				object.y = math.random(yMin,yMax)
				object.v = math.random(vitMin,vitMax)
				score = score + 1
		end
	end
end


function padStart()
	pad = Controls.read()
	if pad:start() then
		pagePos = 2
	end
	oldpad = pad
end

function padLangue()
	pad = Controls.read()
	if pad:cross()   and oldpad ~= pad then
		pagePos = 3
	end
	if pad:down()  and oldpad ~= pad then
		if languePos < langueNbr then
			languePos = languePos + 1
			else
			languePos = 1
		end
	end
	
	if pad:up()  and oldpad ~= pad then
		if languePos > 1 then
			languePos = languePos - 1
			else
			languePos = langueNbr
		end
	end
	oldpad = pad
end

function padMenu()
	pad = Controls.read()
	if pad:cross()  and oldpad ~= pad then
		if menuPos == 1 then
			pagePos = 5
		end
		if menuPos == 2 then
			pagePos = 4
		end
		if menuPos == 3 then
			pagePos = 10
		end
		if menuPos == 4 then
			System.Quit()
		end
	end
	if pad:down()  and oldpad ~= pad then
		if menuPos < menuNbr then
			menuPos = menuPos + 1
			else
			menuPos = 1
		end
	end
	
	if pad:up()  and oldpad ~= pad then
		if menuPos > 1 then
			menuPos = menuPos - 1
			else
			menuPos = menuNbr
		end
	end
	oldpad = pad
end


function padOption()
	pad = Controls.read()
	if pad:cross()  and oldpad ~= pad then
		if optionPos == 1 then
			--pagePos = 5
		end
		if optionPos == 2 then
			--pagePos = 4
		end
		if optionPos == 3 then
			pagePos = 3
		end
	end
	if pad:down()  and oldpad ~= pad then
		if optionPos < optionNbr then
			optionPos = optionPos + 1
			else
			optionPos = 1
		end
	end
	
	if pad:up()  and oldpad ~= pad then
		if optionPos > 1 then
			optionPos = optionPos - 1
			else
			optionPos = optionNbr
		end
	end
	
	if pad:right()  and oldpad ~= pad then
		if option[optionPos] == "langue" then
			if languePos < langueNbr then
				languePos = languePos + 1
				else
				languePos = 1
			end
		end
		if option[optionPos] == "temps" then
			if tempsJeuPos < tempsJeuNbr then
				tempsJeuPos = tempsJeuPos + 1
				else
				tempsJeuPos = 1
			end
		end
	end
	
	if pad:left()  and oldpad ~= pad then
		if option[optionPos] == "langue" then
			if languePos > 1 then
				languePos = languePos - 1
				else
				languePos = langueNbr
			end
		end
		if option[optionPos] == "temps" then
			if tempsJeuPos > 1 then
				tempsJeuPos = tempsJeuPos - 1
				else
				tempsJeuPos = tempsJeuNbr
			end
		end
	end
	
	oldpad = pad
end


function padDecor()
	pad = Controls.read()
	if pad:cross()  and oldpad ~= pad then
		pagePos = 6
	end
	if pad:circle()  and oldpad ~= pad then
		pagePos = 3
	end
	if pad:right()  and oldpad ~= pad then
		if decorPos < decorNbr then
			decorPos = decorPos + 1
			else
			decorPos = 1
		end
	end
	
	if pad:left()  and oldpad ~= pad then
		if decorPos > 1 then
			decorPos = decorPos - 1
			else
			decorPos = decorNbr
		end
	end
	oldpad = pad
end



function padPerso()
	pad = Controls.read()
	if pad:cross()  and oldpad ~= pad then
		pagePos = 7
	end
	if pad:circle()  and oldpad ~= pad then
		pagePos = 5
	end
	if pad:right()  and oldpad ~= pad then
		if persoPos < persoNbr then
			persoPos = persoPos + 1
			else
			persoPos = 1
		end
	end
	
	if pad:left()  and oldpad ~= pad then
		if persoPos > 1 then
			persoPos = persoPos - 1
			else
			persoPos = persoNbr
		end
	end
	oldpad = pad
end

function padCible()
	pad = Controls.read()
	if pad:cross()  and oldpad ~= pad then
		--LANCEMENT DU JEU
		pagePos = 8
		remiseZero()
	end
	if pad:circle()  and oldpad ~= pad then
		pagePos = 6
	end
	if pad:right()  and oldpad ~= pad then
		if ciblePos < cibleNbr then
			ciblePos = ciblePos + 1
			else
			ciblePos = 1
		end
	end
	
	if pad:left()  and oldpad ~= pad then
		if ciblePos > 1 then
			ciblePos = ciblePos - 1
			else
			ciblePos = cibleNbr
		end
	end
	oldpad = pad
end

function padJeu()
	pad = Controls.read()
	if pad:cross() then
		showpda = true
		maintenu = true
		else
		showpda = false
		maintenu = false
	end
	if oldpad == pad then
		maintenu = false
	end
	
	if pad:left() then
		personnage_pos.x = personnage_pos.x - vmvt
		arme_pos.x = arme_pos.x - vmvt
	end
	if pad:analogX() < -40 then
		personnage_pos.x = personnage_pos.x - vmvt
		arme_pos.x = arme_pos.x - vmvt
	end
	if pad:right() then
		personnage_pos.x = personnage_pos.x + vmvt
		arme_pos.x = arme_pos.x + vmvt
	end
	if pad:analogX() > 40 then
		personnage_pos.x = personnage_pos.x + vmvt
		arme_pos.x = arme_pos.x + vmvt
	end
	if pad:up() then
		personnage_pos.y = personnage_pos.y - vmvt
		arme_pos.y = arme_pos.y - vmvt
	end
	if pad:analogY() < -40 then
		personnage_pos.y = personnage_pos.y - vmvt
		arme_pos.y = arme_pos.y - vmvt
	end
	if pad:down() then
		personnage_pos.y = personnage_pos.y + vmvt
		arme_pos.y = arme_pos.y + vmvt
	end
	if pad:analogY() > 40 then
		personnage_pos.y = personnage_pos.y + vmvt
		arme_pos.y = arme_pos.y + vmvt
	end
	if pad:start() and oldpad ~= pad then
		if pause then
			pause = false
			else
			pause = true
		end
	end
	oldpad = pad
end

function padScore()
	pad = Controls.read()
	if pad:start()  and oldpad ~= pad then
		--LANCEMENT DU JEU
		remiseZero()
		pagePos = 8
	end
	if pad:circle()  and oldpad ~= pad then
		pagePos = 3
	end
	oldpad = pad
end

function padScorepage()
	pad = Controls.read()
	if pad:circle()  and oldpad ~= pad then
		pagePos = 3
	end
	oldpad = pad
end
-----------------------------------
-- BOUCLE PRINCIPALE
---------------------------------

while true do
	screen:clear() 

	-- PAGE DE DEMARRAGE
	if page[pagePos] == "start" then
		padStart()
		screen:blit(0,0,startFond)
		temps = chrono:time()
		afficheTemps = temps
		if afficheTemps <= 250 then
			clign = true
			else
			if afficheTemps <= 500 then
				clign = false
				else
				chrono:reset(0)
				chrono:start()
			end
		end
		if clign then
			screen:blit(380,245,startFond1)
			else
			screen:blit(380,245,startFond2)
		end
		
	end
	
	
	-- SELECTION LANGUE
	if page[pagePos] == "langue" then
	
		padLangue()
		screen:blit(0,0,bg)
		
		for i=1,langueNbr do
			if i == 1 then
				if languePos == i then
					screen:blit(200,85,langueImgO[i])
					else
					screen:blit(200,85,langueImgJ[i])
				end
				else
				if languePos == i then
					screen:blit(200,20*i+85-20,langueImgO[i])
					else
					screen:blit(200,20*i+85-20,langueImgJ[i])
				end
			end
			
		end
	
	end
	
	-- Menu 
	if page[pagePos] == "menu" then
	
		padMenu()
		screen:blit(0,0,bg)
		
		for i=1,menuNbr do
			if i == 1 then
				if menuPos == i then
					screen:blit(196,85,menuImgO[languePos][i])
					else
					screen:blit(196,85,menuImgJ[languePos][i])
				end
				else
				if menuPos == i then
					screen:blit(196,20*i+85-20,menuImgO[languePos][i])
					else
					screen:blit(196,20*i+85-20,menuImgJ[languePos][i])
				end
			end
		end
	end

	
		
	-- Option 
	if page[pagePos] == "option" then
		padOption()
		screen:blit(0,0,bg)
		screen:blit(286,112,langueDrapeau[languePos])
		
		for i=1,optionNbr do
			if i == 1 then
				if optionPos == i then
					screen:blit(170,85,optionImgO[languePos][i])
					else
					screen:blit(170,85,optionImgJ[languePos][i])
				end
				else
				if optionPos == i then
					screen:blit(170,25*i+85-25,optionImgO[languePos][i])
					else
					screen:blit(170,25*i+85-25,optionImgJ[languePos][i])
				end
			end
		end
		
		if option[optionPos] == "temps" then
			screen:blit(280,86,tempsJeuImgO[tempsJeuPos])
			else
			screen:blit(280,86,tempsJeuImgJ[tempsJeuPos])
		end
		
	end
		
	if page[pagePos] == "decor" then
		padDecor()
		screen:blit(0,0,bg)
		screen:blit(170,86,decorImg1[languePos])
		screen:blit(290,237,decorImg2[languePos])
		screen:blit(200,110,decorFondMini[decorPos])
		screen:blit(164,123,flecheg)
		screen:blit(309,125,fleched)
		
		
	end
	
	if page[pagePos] == "perso" then
		padPerso()
		screen:blit(0,0,bg)
		screen:blit(160,83,persoImg[languePos])
		if persoPos == 1 then
			posX = 80
			posY = 140
			elseif persoPos == 2 then
			posX = 212
			posY = 137
			elseif persoPos == 3 then
			posX = 295
			posY = 140
			elseif persoPos == 4 then
			posX = 230
			posY = 5
		end
		screen:blit(posX,posY,persoSelect[persoPos])
		screen:blit(164,123,flecheg)
		screen:blit(309,125,fleched)
	end
	
	if page[pagePos] == "cible" then
		padCible()
		screen:blit(0,0,bg)
		if persoPos == 1 then
			posX = 80
			posY = 140
			elseif persoPos == 2 then
			posX = 212
			posY = 137
			elseif persoPos == 3 then
			posX = 295
			posY = 140
			elseif persoPos == 4 then
			posX = 230
			posY = 5
		end
		screen:blit(posX,posY,persoSelect[persoPos])
		screen:blit(180,86,cibleImg1[languePos])
		screen:blit(292,240,cibleImg2[languePos])
		screen:blit(220,110,cibleImg[ciblePos])
		screen:blit(164,123,flecheg)
		screen:blit(309,125,fleched)
	end
	
	if page[pagePos] == "jeu"  and pause == false then
		oldx = personnage_pos.x
		oldy = personnage_pos.y
		padJeu()
		screen:blit(0,0,decorFond[decorPos])
		personnageTape(cible1_pos)
		personnageTape(cible2_pos)
		personnageTape(cible3_pos)
		moveCible(cible1_pos)
		moveCible(cible2_pos)
		moveCible(cible3_pos)
		screen:blit(cible1_pos.x,cible1_pos.y,cibleImg[ciblePos])
		screen:blit(cible2_pos.x,cible2_pos.y,cibleImg[ciblePos])
		screen:blit(cible3_pos.x,cible3_pos.y,cibleImg[ciblePos])
		screen:blit(personnage_pos.x,personnage_pos.y,personnage[persoPos])
		if showpda then
			if persoPos == 1 then
				screen:blit(arme_pos.x+15,arme_pos.y-13,arme)
			else
				screen:blit(arme_pos.x,arme_pos.y,arme)
			end
		end
		
		screen:blit(3,3,affscoreImg[languePos])
		screen:blit(395,3,afftempsImg[languePos])
		
		afficheScore = score
		if afficheScore < 10 then
			afficheScore = "0" .. afficheScore
		end
		
		if langue[languePos] == "espanol" then
		scoreX = 63
		else
		scoreX = 55
		end
		
		if score ~= 0 and score < 10 then
			screen:blit(scoreX,3,nbrmini[10])
			screen:blit(scoreX+8,3,nbrmini[score])
		else
			if score == 0 then
				screen:blit(scoreX,3,nbrmini[10])
				screen:blit(scoreX+8,3,nbrmini[10])
			end
			if score > 9 then
				a = string.byte(afficheScore,1) - 48
				b = string.byte(afficheScore,2) - 48
				if b == 0 then
					b=10
				end
				screen:blit(scoreX,3,nbrmini[a])
				screen:blit(scoreX+8,3,nbrmini[b])
			end
			if score > 99 then
				a = string.byte(afficheScore,1) - 48
				b = string.byte(afficheScore,2) - 48
				c = string.byte(afficheScore,3) - 48
				if b == 0 then
					b=10
				end
				if c == 0 then
					c=10
				end
				screen:blit(scoreX,3,nbrmini[a])
				screen:blit(scoreX+8,3,nbrmini[b])
				screen:blit(scoreX+16,3,nbrmini[c])
			end
		end
		
		
		temps = chrono:time()
		tempsArrondi = math.floor(temps/1000)
		timeX = 455
		
		if tempsArrondi ~= 0 and tempsArrondi < 10 then
			screen:blit(timeX,5,nbrmini[10])
			screen:blit(timeX+8,5,nbrmini[tempsArrondi])
		else
			if tempsArrondi == 0 then
				screen:blit(timeX,5,nbrmini[10])
				screen:blit(timeX+8,5,nbrmini[10])
			end
			if tempsArrondi > 9 then
				a = string.byte(tempsArrondi,1) - 48
				b = string.byte(tempsArrondi,2) - 48
				if b == 0 then
					b=10
				end
				screen:blit(timeX,5,nbrmini[a])
				screen:blit(timeX+8,5,nbrmini[b])
			end
		end
		
		
		
		
		if temps >= tempsJeu[tempsJeuPos]*1000 then
		pagePos = pagePos + 1
		end
	else
		if page[pagePos] == "jeu" then
			chrono:stop()
			screen:blit(0,0,bg)
			screen:blit(165,84,pausemenuImg[languePos])
			pad = Controls.read()
			if pad:start() and oldpad ~= pad then
				if pause then
					pause = false
					chrono:start()
					else
					pause = true
				end
			end
			if pad:circle() and oldpad ~= pad then
				pagePos = 3
			end
			oldpad = pad
		end
	end
	
	if page[pagePos] == "score" then
		padScore()
		screen:blit(0,0,bg)
		screen:blit(165,90,affichescoreImg1[languePos])
		
		if tempsJeuPos == 1 then
			file = io.open("best30.txt", "r")
		end
		if tempsJeuPos == 2 then
			file = io.open("best60.txt", "r")
		end
		bestScore = file:read("*n")
		file:close()
		
		if score > bestScore then
			if tempsJeuPos == 1 then
				file = io.open("best30.txt", "w")
			end
			if tempsJeuPos == 2 then
				file = io.open("best60.txt", "w")
			end
			file:write(score)
			file:close()
			meilleurScore = true
		end
		
		if meilleurScore then
			screen:blit(165,124,affichescoreImg3[languePos])
		else
			screen:blit(165,124,affichescoreImg2[languePos])
			
			afficheBestScore = bestScore
			if afficheBestScore < 10 then
				afficheBestScore = "0" .. afficheBestScore
			end
			if langue[languePos] == "english" then
			scorepetitX = 280
			else
			scorepetitX = 286
			end
			scorepetitY = 133
			epaceChiffrePetit = 8
			
			if bestScore ~= 0 and bestScore < 10 then
				screen:blit(scorepetitX,scorepetitY,nbrmini[10])
				screen:blit(scorepetitX+epaceChiffrePetit,scorepetitY,nbrmini[bestScore])
			else
				if bestScore == 0 then
					screen:blit(scorepetitX,scorepetitY,nbrmini[10])
					screen:blit(scorepetitX+epaceChiffrePetit,scorepetitY,nbrmini[10])
				end
				if bestScore > 9 then
					a = string.byte(afficheBestScore,1) - 48
					b = string.byte(afficheBestScore,2) - 48
					if b == 0 then
						b=10
					end
					screen:blit(scorepetitX,scorepetitY,nbrmini[a])
					screen:blit(scorepetitX+epaceChiffrePetit,scorepetitY,nbrmini[b])
				end
				if bestScore > 99 then
					a = string.byte(afficheBestScore,1) - 48
					b = string.byte(afficheBestScore,2) - 48
					c = string.byte(afficheBestScore,3) - 48
					if b == 0 then
						b=10
					end
					if c == 0 then
						c=10
					end
					screen:blit(scorepetitX,scorepetitY,nbrmini[a])
					screen:blit(scorepetitX+epaceChiffrePetit,scorepetitY,nbrmini[b])
					screen:blit(scorepetitX+(epaceChiffrePetit*2),scorepetitY,nbrmini[c])
				end
			end
		end
		
		
		screen:blit(103,247,affichescoreImg4[languePos])
		afficheScore = score
		if afficheScore < 10 then
			afficheScore = "0" .. afficheScore
		end
		
		
		scoreX = 280
		scoreY = 103
		epaceChiffre = 12
		
		if score ~= 0 and score < 10 then
			screen:blit(scoreX,scoreY,nbr[10])
			screen:blit(scoreX+epaceChiffre,scoreY,nbr[score])
		else
			if score == 0 then
				screen:blit(scoreX,scoreY,nbr[10])
				screen:blit(scoreX+epaceChiffre,scoreY,nbr[10])
			end
			if score > 9 then
				a = string.byte(afficheScore,1) - 48
				b = string.byte(afficheScore,2) - 48
				if b == 0 then
					b=10
				end
				screen:blit(scoreX,scoreY,nbr[a])
				screen:blit(scoreX+epaceChiffre,scoreY,nbr[b])
			end
			if score > 99 then
				a = string.byte(afficheScore,1) - 48
				b = string.byte(afficheScore,2) - 48
				c = string.byte(afficheScore,3) - 48
				if b == 0 then
					b=10
				end
				if c == 0 then
					c=10
				end
				screen:blit(scoreX,scoreY,nbr[a])
				screen:blit(scoreX+epaceChiffre,scoreY,nbr[b])
				screen:blit(scoreX+(epaceChiffre*2),scoreY,nbr[c])
			end
		end
		
		
	end
	
	if page[pagePos] == "scorepage" then
		padScorepage()
		screen:blit(0,0,bg)
		screen:blit(165,80,scorepageImg1[languePos])
		screen:blit(365,242,scorepageImg2[languePos])
		screen:blit(165,112,scorepageImg)
		
		file30 = io.open("best30.txt", "r")
		bestScore30 = file30:read("*n")
		file30:close()	
		file60 = io.open("best60.txt", "r")
		bestScore60 = file60:read("*n")
		file60:close()
		
		
		bestScore30X = 255
		bestScore30Y = 115
		bestScore60X = 255
		bestScore60Y = 137
		epaceChiffre = 12
		
		
		if bestScore30 ~= 0 and bestScore30 < 10 then
			screen:blit(bestScore30X,bestScore30Y,nbr[10])
			screen:blit(bestScore30X+epaceChiffre,bestScore30Y,nbr[bestScore30])
		else
			if bestScore30 == 0 then
				screen:blit(bestScore30X,bestScore30Y,nbr[10])
				screen:blit(bestScore30X+epaceChiffre,bestScore30Y,nbr[10])
			end
			if bestScore30 > 9 then
				a = string.byte(bestScore30,1) - 48
				b = string.byte(bestScore30,2) - 48
				if b == 0 then
					b=10
				end
				screen:blit(bestScore30X,bestScore30Y,nbr[a])
				screen:blit(bestScore30X+epaceChiffre,bestScore30Y,nbr[b])
			end
			if bestScore30 > 99 then
				a = string.byte(bestScore30,1) - 48
				b = string.byte(bestScore30,2) - 48
				c = string.byte(bestScore30,3) - 48
				if b == 0 then
					b=10
				end
				if c == 0 then
					c=10
				end
				screen:blit(bestScore30X,bestScore30Y,nbr[a])
				screen:blit(bestScore30X+epaceChiffre,bestScore30Y,nbr[b])
				screen:blit(bestScore30X+(epaceChiffre*2),bestScore30Y,nbr[c])
			end
		end
		
		if bestScore60 ~= 0 and bestScore60 < 10 then
			screen:blit(bestScore60X,bestScore60Y,nbr[10])
			screen:blit(bestScore60X+epaceChiffre,bestScore60Y,nbr[bestScore60])
		else
			if bestScore60 == 0 then
				screen:blit(bestScore60X,bestScore60Y,nbr[10])
				screen:blit(bestScore60X+epaceChiffre,bestScore60Y,nbr[10])
			end
			if bestScore60 > 9 then
				a = string.byte(bestScore60,1) - 48
				b = string.byte(bestScore60,2) - 48
				if b == 0 then
					b=10
				end
				screen:blit(bestScore60X,bestScore60Y,nbr[a])
				screen:blit(bestScore60X+epaceChiffre,bestScore60Y,nbr[b])
			end
			if bestScore60 > 99 then
				a = string.byte(bestScore60,1) - 48
				b = string.byte(bestScore60,2) - 48
				c = string.byte(bestScore60,3) - 48
				if b == 0 then
					b=10
				end
				if c == 0 then
					c=10
				end
				screen:blit(bestScore60X,bestScore60Y,nbr[a])
				screen:blit(bestScore60X+epaceChiffre,bestScore60Y,nbr[b])
				screen:blit(bestScore60X+(epaceChiffre*2),bestScore60Y,nbr[c])
			end
		end
		
		
	end
	 
	screen.waitVblankStart()
	screen.flip()

end
