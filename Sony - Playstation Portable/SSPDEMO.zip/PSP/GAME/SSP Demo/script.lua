Loading = Image.load("Picture/Loading.png")
screen:clear()
screen:blit(0,0,Loading)
screen.flip()
screen.waitVblankStart()
--------------
-- Pictures --
--------------

Menu = Image.load("Picture/Menu.png")
Curs = Image.load("Picture/Curs.png")


selector = 1

----------
-- Menu --
----------

while true do
screen:clear()
pad = Controls.read()

screen:blit(0,0,Menu)

if pad:down() and not oldpad:down() then selector = selector +1
elseif pad:up() and not oldpad:up() then selector = selector -1
end
 
if selector < 1 then selector = 6 
elseif selector > 6 then selector = 1 end 

if selector == 1 then screen:blit(20,55,Curs) end
if selector == 2 then screen:blit(20,87,Curs) end
if selector == 3 then screen:blit(20,119,Curs) end
if selector == 4 then screen:blit(20,149,Curs) end
if selector == 5 then screen:blit(20,180,Curs) end
if selector == 6 then screen:blit(20,210,Curs) end

if pad:circle() and not oldpad:circle() and selector == 1 then
dofile("Coming.lua")
file:close()
end

if pad:circle() and not oldpad:circle() and selector == 2 then
dofile("Selectyourcharacter.lua")
file:close()
end

if pad:circle() and not oldpad:circle() and selector == 3 then
dofile("Ori.lua")
file:close()
end

if pad:circle() and not oldpad:circle() and selector == 4 then
dofile("Graph.lua")
file:close()
end

if pad:circle() and not oldpad:circle() and selector == 5 then
dofile("Credit.lua")
file:close()
end

if pad:circle() and not oldpad:circle() and selector == 6 then
System.Quit()
end


oldpad = pad
screen.waitVblankStart()
screen.flip()
pad = nil
end 