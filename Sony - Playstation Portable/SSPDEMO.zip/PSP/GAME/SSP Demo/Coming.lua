Loading = Image.load("Picture/Loading.png")
screen:clear()
screen:blit(0,0,Loading)
screen.flip()
screen.waitVblankStart()

--------------
-- Pictures --
--------------

Coming = Image.load("Picture/Coming.png")
----------
-- Menu --
----------

while true do
screen:clear()
pad = Controls.read()
screen:blit(0,0,Coming)
if pad:circle() and not oldpad:circle() then
dofile("script.lua")
file:close()
end

oldpad = pad
screen.waitVblankStart()
screen.flip()
pad = nil
end 