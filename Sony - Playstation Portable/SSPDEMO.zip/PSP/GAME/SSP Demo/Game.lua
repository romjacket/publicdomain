Loading = Image.load("Picture/Loading.png")
screen:clear()
screen:blit(0,0,Loading)
screen.flip()
screen.waitVblankStart()

--------------
--- Colors ---
--------------

vert =Color.new(0,255,0)
blanc = Color.new(255,255,255)

-------------
--- Girl ----
-------------

---Normal
-- Stance
Stand01 = Image.load("Girl/Stand01.png")
Stand02 = Image.load("Girl/Stand02.png")
Stand03 = Image.load("Girl/Stand03.png")

-- Walk
Walk01 = Image.load("Girl/Walk01.png")
Walk02 = Image.load("Girl/Walk02.png")
Walk03 = Image.load("Girl/Walk03.png")

-- Run
Run01 = Image.load("Girl/Run01.png")
Run02 = Image.load("Girl/Run02.png")

-- Jump
Jump01 = Image.load("Girl/Jump01.png")
Jump02 = Image.load("Girl/Jump02.png")

-- Fall
Fall = Image.load("Girl/Fall.png")

-- Hit
Hit01 = Image.load("Girl/Hit01.png")

---Reverse
-- Stance
RevStand01 = Image.load("Girl/RevStand01.png")
RevStand02 = Image.load("Girl/RevStand02.png")
RevStand03 = Image.load("Girl/RevStand03.png")

-- Walk
RevWalk01 = Image.load("Girl/RevWalk01.png")
RevWalk02 = Image.load("Girl/RevWalk02.png")
RevWalk03 = Image.load("Girl/RevWalk03.png")

-- Run
RevRun01 = Image.load("Girl/RevRun01.png")
RevRun02 = Image.load("Girl/RevRun02.png")

-- Jump
RevJump01 = Image.load("Girl/RevJump01.png")
RevJump02 = Image.load("Girl/RevJump02.png")

-- Fall
RevFall = Image.load("Girl/RevFall.png")

-- Hit
RevHit01 = Image.load("Girl/RevHit01.png")

-- Other images
mod = Image.createEmpty(10,10)

sol = Image.load("Picture/sol.png")
sol2 = Image.load("Picture/sol2.png")
sol3 = Image.load("Picture/sol3.png")

Vide = Image.createEmpty(480,272)

Life = Image.load("Picture/Life.png")

--------------
-- Fonctions -
--------------

floor = {}
floor.x = 0
floor.y = 0
floor.img = sol

floor2 = {}
floor2.x = 0
floor2.y = 0
floor2.img = sol2

floor3 = {}
floor3.x = 0
floor3.y = 0
floor3.img = sol3

player = {}
player.img = mod
player.walk = 0
player.run = 0
player.gravity = 180
player.y = 180
player.x = 215
player.jumpspeed = 12
player.jumpstate = "floor"
player.statut = "stance"


-------------------
---- Game Loop ----
-------------------



minuteur = Timer.new()

minuteur:start()


while true do
pad = Controls.read()
screen:clear()

--------------
---- Pads ----
--------------

if pad:left() then 
player.walk = player.walk - 1
player.x = player.x - 1
player.statut = "left"
minuteur:reset(0)
elseif pad:right() then
player.walk = player.walk + 1
player.x = player.x + 1
player.statut = "right"
minuteur:reset(0)
end 


if pad:cross() and not oldpad:cross() and player.jumpstate == "floor" then 
player.jumpstate = "jumping" 
player.statut = "Jumping"
end 

if pad:r() and player.jumpstate == "floor" and player.statut == "left" then 
player.run = player.run - 2
player.x = player.x - 2
player.statut = "left runing"
elseif pad:r() and player.jumpstate == "floor" and player.statut == "right" then 
player.run = player.run + 2
player.x = player.x + 2
player.statut = "right runing"
end 

if pad:right() and pad:r() and (player.jumpstate == "jumping" or player.jumpstate == "falling") then
player.x = player.x + 4
elseif pad:left() and pad:r() and (player.jumpstate == "jumping" or player.jumpstate == "falling") then
player.x = player.x - 4
end

if pad:start() and not oldpad:start() then 
dofile("script.lua")
file:close()
end 

-----------
-- Timer --
-----------

currentTime = minuteur:time()
minuteur:start()

if currentTime >= 980 then 
minuteur:reset(0)
minuteur:start()
end 


--------------
---- Jump ----
--------------

if player.jumpstate == "jumping" and pad:right() == false and pad:left() == false  then 
player.jumpspeed = player.jumpspeed - 0.5
player.gravity = player.gravity - player.jumpspeed 
elseif player.jumpstate == "jumping" and pad:right() then 
player.jumpspeed = player.jumpspeed - 0.5
player.gravity = player.gravity - player.jumpspeed 
player.x = player.x + 2
elseif player.jumpstate == "jumping" and pad:left() then 
player.jumpspeed = player.jumpspeed - 0.5
player.gravity = player.gravity - player.jumpspeed 
player.x = player.x - 2
end 

if player.jumpspeed < 0 then 
player.jumpstate = "falling"
player.statut = "falling"
end

if player.gravity < 180 and player.jumpstate == "falling" and pad:right() == false and pad:left() == false then 
player.gravity = player.gravity  + (player.jumpspeed + 3) 
player.jumpspeed = player.jumpspeed + 0.4
elseif player.gravity < 180 and player.jumpstate == "falling" and pad:right() then 
player.gravity = player.gravity  + (player.jumpspeed + 3) 
player.jumpspeed = player.jumpspeed + 0.4
player.x = player.x + 2
elseif player.gravity < 180 and player.jumpstate == "falling" and pad:left() then 
player.gravity = player.gravity  + (player.jumpspeed + 3) 
player.jumpspeed = player.jumpspeed + 0.4
player.x = player.x - 2
end 

if player.gravity == 180 then 
player.jumpspeed = 12
player.jumpstate = "floor"
player.img = mod
end

if player.gravity > 180 then player.gravity = 180 end

player.y = player.gravity

if player.statut == "left" then
player.run = 0
elseif player.statut == "right" then
player.run = 0
end 

------------------
-- Images moves --
------------------

-- jump

if player.jumpstate == "jumping" and player.statut == "left" then 
player.img = RevJump02
end 

if player.jumpstate == "jumping" and player.statut == "right" then 
player.img = Jump02
end 

if player.jumpstate == "falling" and player.statut == "left" then 
player.img = RevFall
end 

if player.jumpstate == "falling" and player.statut == "right" then 
player.img = Fall
end 

-- walk

if player.walk >=1 and player.walk <= 45 and pad:left() and player.jumpstate == "floor" then player.walk = 0
elseif player.walk <=-1 and player.walk >= -45 and pad:right() and player.jumpstate == "floor" then player.walk = 0
end 

if player.walk <= -1 and player.walk >= -5 and player.jumpstate == "floor" then player.img = RevWalk01
elseif player.walk <= -5 and player.walk >= -10 and player.jumpstate == "floor" then player.img = RevWalk02
elseif player.walk <= -10 and player.walk >= -15 and player.jumpstate == "floor" then player.img = RevWalk03
elseif player.walk <= -15 and player.walk >= -20 and player.jumpstate == "floor" then player.img = RevWalk02
elseif player.walk <= -20 and player.walk >= -25 and player.jumpstate == "floor" then player.img = RevWalk01
elseif player.walk <= -25 and player.walk >= -30 and player.jumpstate == "floor" then player.img = RevWalk02
elseif player.walk <= -30 and player.walk >= -35 and player.jumpstate == "floor" then player.img = RevWalk03
elseif player.walk <= -35 and player.walk >= -45 and player.jumpstate == "floor" then player.img = RevWalk02
elseif player.walk >= 1 and player.walk <= 5 and player.jumpstate == "floor" then player.img = Walk01
elseif player.walk >= 5 and player.walk <= 10 and player.jumpstate == "floor" then player.img = Walk02
elseif player.walk >= 10 and player.walk <= 15 and player.jumpstate == "floor" then player.img = Walk03
elseif player.walk >= 15 and player.walk <= 20 and player.jumpstate == "floor" then player.img = Walk02
elseif player.walk >= 20 and player.walk <= 25 and player.jumpstate == "floor" then player.img = Walk01
elseif player.walk >= 25 and player.walk <= 30 and player.jumpstate == "floor" then player.img = Walk02
elseif player.walk >= 30 and player.walk <= 35 and player.jumpstate == "floor" then player.img = Walk03
elseif player.walk >= 35 and player.walk <= 45 and player.jumpstate == "floor" then player.img = Walk02
end

if player.walk < -40 then player.walk = -1
elseif player.walk > 40 then player.walk = 1 end



-- run

if player.run <= -2 and player.run >= -10 and player.jumpstate == "floor" then player.img = RevRun01
elseif player.run <= -10 and player.run >= -20 and player.jumpstate == "floor" then player.img = RevRun02
elseif player.run >= 2 and player.run <= 10 and player.jumpstate == "floor" then player.img = Run01
elseif player.run >= 10 and player.run <= 20 and player.jumpstate == "floor" then player.img = Run02
end 

if player.run < -18 then player.run = -1
elseif player.run > 18 then player.run = 1 end

if player.run >=1 and player.run <= 20 and pad:left() and player.jumpstate == "floor" then player.run = 0
elseif player.run <=-1 and player.run >= -20 and pad:right() and player.jumpstate == "floor" then player.run = 0
end 

-- stance

if currentTime >= 0 and currentTime <= 250 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand01
elseif currentTime >= 250 and currentTime <= 500 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand02
elseif currentTime >= 500 and currentTime <= 750 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand03
elseif currentTime >= 750 and currentTime <= 1000 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand02
elseif currentTime >= 0 and currentTime <= 250 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "right" or player.statut == "right runing") then player.img = Stand01
elseif currentTime >= 250 and currentTime <= 500 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "right" or player.statut == "right runing") then player.img = Stand02
elseif currentTime >= 500 and currentTime <= 750 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "right" or player.statut == "right runing") then player.img = Stand03
elseif currentTime >= 750 and currentTime <= 1000 and player.jumpstate == "floor" and minuteur:start() and pad:right() == false and pad:left() == false and (player.statut == "right" or player.statut == "right runing") then player.img = Stand02
end

if currentTime >= 0 and currentTime <= 250 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand01
elseif currentTime >= 250 and currentTime <= 500 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand02
elseif currentTime >= 500 and currentTime <= 750 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand03
elseif currentTime >= 750 and currentTime <= 1000 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "left" or player.statut == "left runing") then player.img = RevStand02
elseif currentTime >= 0 and currentTime <= 250 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "right" or player.statut == "right runing") then player.img = Stand01
elseif currentTime >= 250 and currentTime <= 500 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "right" or player.statut == "right runing") then player.img = Stand02
elseif currentTime >= 500 and currentTime <= 750 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "right" or player.statut == "right runing") then player.img = Stand03
elseif currentTime >= 750 and currentTime <= 1000 and player.jumpstate == "floor" and minuteur:start() and pad:right() and pad:left() and (player.statut == "right" or player.statut == "right runing") then player.img = Stand02
end



-- Colision

if player.x >= 230 and pad:right() and player.statut == "right" then
player.x = 230 
floor.x = floor.x - 2
end 

if player.x <= 200 and pad:left() and player.statut == "left" then
player.x = 200
floor.x = floor.x + 2
end 

if player.x >= 230 and pad:right() and player.statut == "right runing" then
player.x = 230 
floor.x = floor.x - 4
end 

if player.x <= 200 and pad:left() and player.statut == "left runing" then
player.x = 200
floor.x = floor.x + 4
end 


if player.x >= 230 and pad:right() and (player.jumpstate == "jumping" or player.jumpstate == "falling") then
player.x = 230 
floor.x = floor.x - 2
end 

if player.x <= 200 and pad:left() and (player.jumpstate == "jumping" or player.jumpstate == "falling") then
player.x = 200
floor.x = floor.x + 2
end 

if player.x >= 230 and pad:right() and (player.jumpstate == "jumping" or player.jumpstate == "falling") and pad:r() then
player.x = 230 
floor.x = floor.x - 4
end 

if player.x <= 200 and pad:left() and (player.jumpstate == "jumping" or player.jumpstate == "falling") and pad:r() then
player.x = 200
floor.x = floor.x + 4
end 

if floor.x >= 0 then
floor.x = 0
end 

if floor.x <= -770 then
floor.x = -770
end 

floor2.x = floor.x + 480

floor3.x = floor.x + 960



---------------
--- Screens ---
---------------


screen:blit(floor.x,floor.y,floor.img)
screen:blit(floor2.x,floor2.y,floor2.img)
screen:blit(floor3.x,floor3.y,floor3.img)
screen:blit(player.x,player.y,player.img)
screen:blit(0,0,Life)

oldy=player.y
oldx=player.x
oldpad=pad
screen.waitVblankStart()
screen.flip()
pad=nil
end 