Loading = Image.load("Picture/Loading.png")
screen:clear()
screen:blit(0,0,Loading)
screen.flip()
screen.waitVblankStart()

--------------
-- Pictures --
--------------

Training = Image.load("Picture/Training rinna.png")
Trainingnot = Image.load("Picture/Training not.png")
selector = 1
----------
-- Menu --
----------

while true do
screen:clear()
pad = Controls.read()
screen:blit(0,0,Training)

if pad:down() and not oldpad:down() then selector = selector +1
elseif pad:up() and not oldpad:up() then selector = selector -1
end
 
if selector < 1 then selector = 2 
elseif selector > 2 then selector = 1 end 

if selector == 1 then screen:blit(0,0,Training) end
if selector == 2 then screen:blit(0,0,Trainingnot) end

if pad:circle() and not oldpad:circle() and selector == 1 then
dofile("Game.lua")
file:close()
end

if pad:circle() and not oldpad:circle() and selector == 2 then
dofile("script.lua")
file:close()
end

oldpad = pad
screen.waitVblankStart()
screen.flip()
pad = nil
end 