//
// Plantilla de proyecto de NDS
//


// Includes devKitPro
#include <nds.h>
#include <fat.h>

// Includes C++
#include <stdio.h>
#include <string.h>
#include <unistd.h>


// Includes propios
#include "nf_lib.h"

#define MAXSPRITES 25	// Numero de Sprites en pantalla (5 - 100) (0 al 3 <- personajes)


// Declara funciones
void _InitFat(void);	// Inicializa la FAT
void _InitBgs(void);	// Inicializa y carga los fondos
void _InitSpr(void);	// Inicializa y carga los sprites

	
// Main
int main(void) {

	// Inicializa la FAT
	_InitFat();
	NF_SetRootFolder("NFlib");	// Define la carpeta ROOT de la FAT

	// Inicializa las 2D
	NF_Set2D(0, 0);				// Modo 2D_0 en la pantalla superior
	NF_Set2D(1, 0);				// Modo 2D_0 en la pantalla inferior

	// Inicializa y carga los fondos
	_InitBgs();

	// Inicializa y carga los sprites
	_InitSpr();



	// Declara variables generales
	u8 n = 0;
	u8 s = 0;
	s16 z = 0;
	s8 bright = -16;

	
	// Declara variables para el Scroll
	s16 x0[2];		// X plano 0
	s16 x1[2];		// X plano 1
	s16 x2[2];		// X plano 2
	s16 y0[2];		// Y plano 0
	s16 y1[2];		// Y plano 1
	s16 y2[2];		// Y plano 2
	s8 ix[2];		// Velocidad base
	s8 iy[2];

	// Inicializala las variables del Scroll
	for (n = 0; n < 2; n ++) {
		x0[n] = 0;
		x1[n] = 0;
		x2[n] = 0;
		y0[n] = 0;
		y1[n] = 0;
		y2[n] = 0;
	}
	ix[0] = 3;
	ix[1] = 1;
	iy[0] = 1;
	iy[1] = 1;


	// Declara variables de sprites 
	s16 sp_x[2][MAXSPRITES];
	s16 sp_y[2][MAXSPRITES];
	s8 sp_mx[2][MAXSPRITES];
	s8 sp_my[2][MAXSPRITES];
	bool sp_hflip[2][MAXSPRITES];
	bool sp_vflip[2][MAXSPRITES];
	bool make_sprite;
	bool del_sprite;
	u8 counter;
	s16 sprnum;
	s16 angle[32];
	s8 rotspeed [32];
	s16 scale[32];
	s8 scalespeed[32];


	// Inicializa las variables de sprite
	for (s = 0; s < 2; s ++) {
		for (n = 0; n < MAXSPRITES; n ++) {
			sp_x[s][n] = (rand() % 222);
			sp_y[s][n] = (rand() % 158);
			sp_mx[s][n] = ((rand() % 4) + 1);
			sp_my[s][n] = ((rand() % 4) + 1);
			sp_hflip[s][n] = false;
			sp_vflip[s][n] = false;
		}
	}
	make_sprite = false;
	del_sprite = true;
	counter = 0;
	sprnum = (MAXSPRITES - 1);
	for (n = 0; n < 32; n ++) {
		angle[n] = (rand() % 512);
		rotspeed[n] = (rand() % 11) - 5;
		scale[n] = (rand() % 384);
		scalespeed[n] = (rand() % 11) - 5;
	}


	// Declara variables Sprite (Personajes)
	s16 pj_x[4];
	s16 pj_y[4];
	s16 pj_move[4];
	u8 pj_frame[4];
	u8 pj_counter[4];
	u8 pj_animation[4];

	// Inicializa las variables de Sprite
	pj_x[0] = 10;
	pj_y[0] = 96;
	pj_move[0] = 1;
	pj_frame[0] = 0;
	pj_counter[0] = 0;
	pj_animation[0] = 15;

	pj_x[1] = 80;
	pj_y[1] = 96;
	pj_move[1] = 2;
	pj_frame[1] = 2;
	pj_counter[1] = 0;
	pj_animation[1] = 12;

	pj_x[2] = 150;
	pj_y[2] = 96;
	pj_move[2] = 1;
	pj_frame[2] = 4;
	pj_counter[2] = 0;
	pj_animation[2] = 9;

	pj_x[3] = 180;
	pj_y[3] = 96;
	pj_move[3] = 2;
	pj_frame[3] = 6;
	pj_counter[3] = 0;
	pj_animation[3] = 6;

	// Control del pad
	u16 keypad = 0;


	// Bucle principal
	while(1) {		// Repite para siempre

		// Calcula el desplazamiento de los fondos (automatico)
			/*
			y0[0] += iy[0];
			if (y0[0] < 1 || y0[0] > 1790) {
				iy[0] *= -1;
			}

			x0[0] += ix[0];
			if (x0[0] < 3 || x0[0] > 1788) {
				ix[0] *= -1;
			}
			*/
			
		
			// Lee el pad (Calcula el desplazamiento de los fondos (manual))
			
			scanKeys();
			keypad = keysHeld();
			if (keypad & KEY_UP) {
				y0[0] -= 2;
				if (y0[0] < 1) y0[0] = 1;
			}
			if (keypad & KEY_DOWN) {
				y0[0] += 2;
				if (y0[0] > 1790) y0[0] = 1790;
			}
			if (keypad & KEY_LEFT) {
				x0[0] -= 2;
				if (x0[0] < 1) x0[0] = 1;
			}
			if (keypad & KEY_RIGHT) {
				x0[0] += 2;
				if (x0[0] > 1790) x0[0] = 1790;
			}
			

			// Posicion del resto de capas
			x1[0] = (int)(x0[0] / 1.5);
			x2[0] = (int)(x1[0] / 1.5);
			y1[0] = (int)(y0[0] / 1.5);
			y2[0] = (int)(y1[0] / 1.5);


		// Calcula el desplazamiento X de los fondos (infinitos)
			x0[1] += ix[1];
			if (x0[1] < 1 || x0[1] > 1662) {
				ix[1] *= -1;
			}
			x1[1] = (int)(x0[1] / 1.5);
			x2[1] = (int)(x1[1] / 1.5);

		// Calcula las posiciones de los sprites y el flip
		for (s = 0; s < 2; s ++) {
			for (n = 0; n < MAXSPRITES; n ++) {
				sp_x[s][n] += sp_mx[s][n];
				if (sp_x[s][n] < -32 || sp_x[s][n] > 222) {
					sp_mx[s][n] *= -1;
					sp_hflip[s][n] = !sp_hflip[s][n];
					NF_HflipSprite(s, (n + 5), sp_hflip[s][n]);
				}
				sp_y[s][n] += sp_my[s][n];
				if (sp_y[s][n] < -32 || sp_y[s][n] > 158) {
					sp_my[s][n] *= -1;
					sp_vflip[s][n] = !sp_vflip[s][n];
					NF_VflipSprite(s, (n + 5), sp_vflip[s][n]);
				}
				NF_MoveSprite(s, (n + 5), sp_x[s][n], sp_y[s][n]); 
			}
		}

		// Calcula la posicion de los personajes y su flip
		for (n = 0; n < 4; n ++) {
			pj_x[n] += pj_move[n];
			if (pj_x[n] < 5 || pj_x[n] > 185) {
				pj_move[n] *= -1;
			}
			NF_MoveSprite(0, n, pj_x[n], pj_y[n]);
			NF_MoveSprite(1, n, pj_x[n], pj_y[n]);
			if (pj_move[n] < 0) {
				NF_HflipSprite(0, n, true);
				NF_HflipSprite(1, n, true);
			} else {
				NF_HflipSprite(0, n, false);
				NF_HflipSprite(1, n, false);
			}
			// Animacion Pantalla inferior (Todos los frames en la VRAM)
			pj_counter[n] ++;
			if (pj_counter[n] > pj_animation[n]) {
				pj_counter[n] = 0;
				pj_frame[n] ++;
				if (pj_frame[n] > 11) {
					pj_frame[n] = 0;
				}
				NF_SpriteFrame(1, n, pj_frame[n]);
			}
		}

		// Animacion patalla superior (Todos los frames en RAM, solo se copia en la VRAM el frame necesario)
		NF_SpriteFrame(0, 0, pj_frame[0]);
		// // Con solo animar qualquier Sprite que use ese Grafico, todos los demas que lo compartan
		// // tambien cambiaran de frame


		// Borra o crea secuencialmente los sprites
		counter ++;
		if (counter == 15) {
			// Borra Sprites
			if (del_sprite && (counter == 15)) {
				counter = 0;
				NF_DeleteSprite(0, (sprnum + 5));
				NF_DeleteSprite(1, (sprnum + 5));
				sprnum --;
				if (sprnum < 0) {
					sprnum = 0;
					del_sprite = false;
					make_sprite = true;
				}
			}

			// Crea Sprites
			if (make_sprite && (counter == 15)) {
				counter = 0;
				z =  (rand() % 5);
				NF_CreateSprite(0, (sprnum + 5), z, z, sp_x[0][sprnum], sp_y[0][sprnum]);
				NF_SpriteLayer(0, (sprnum + 5), (rand() % 4));
				z =  (rand() % 5);
				NF_CreateSprite(1, (sprnum + 5), z, z, sp_x[1][sprnum], sp_y[1][sprnum]);
				NF_SpriteLayer(1, (sprnum + 5), (rand() % 4));
				sprnum ++;
				if (sprnum == MAXSPRITES) {
					sprnum = (MAXSPRITES - 1);
					del_sprite = true;
					make_sprite = false;
				}
			}
		}

		// Rotacion y escalado del Sprite
		/*
		for (n = 0; n < 32; n ++) {
			angle[n] += rotspeed[n];
			if (angle[n] > 512) angle[n] -= 512;
			if (angle[n] < -512) angle[n] += 512;
			scale[n] += scalespeed[n];
			if (scale[n] < 32 || scale[n] > 384) {
				scalespeed[n] *= -1;
			}
			NF_SpriteRotScale(0, n, angle[n], scale[n], scale[n]);
		}
		*/

		// Manda el array de OAM al OAM
		NF_SpriteOamSet(0);		// Pantalla superior
		NF_SpriteOamSet(1);		// Pantalla inferior

		//Calcula el nuevo valor del Brillo
		bright ++;
		if (bright > 0) bright = 0;

		swiWaitForVBlank();		// Espera al sincronismo vertical

		oamUpdate(&oamMain);	// Actualiza a VRAM el OAM Principal
		oamUpdate(&oamSub);		// Actualiza a VRAM el OAM Secundario

		// Aplica el brillo
		setBrightness(3, bright);

		// Scroll en ambas pantallas
		for (n = 0; n < 2; n ++) {
			NF_ScrollBg(n, 0, x0[n], y0[n]);
			NF_ScrollBg(n, 1, x1[n], y1[n]);
			NF_ScrollBg(n, 2, x2[n], y2[n]);
		}

	
	}

	return 0;

}



// Inicializa la FAT
void _InitFat(void) {

	// Inicializa el sistema FAT


	if (fatInitDefault()) {		// Intenta inicializar la FAT
		// Conseguido, continua
		chdir("fat:/");

	} else {

		// Fallo. Deten el programa
		consoleDemoInit();	// Inicializa la consola de texto
		iprintf("Fat Init Error.\n");
		iprintf("Abnormal termination.\n");
		// Bucle infinito. Fin del programa
		while(1) {
			swiWaitForVBlank();
		}
	}

}



// Inicializa y carga los fondos 2D
void _InitBgs(void) {

	// Inicializaciones
	NF_InitTiledBgBuffers();	// Inicializa los buffers para almacenar fondos
	NF_InitTiledBgSys(0);		// Inicializa los fondos Tileados para la pantalla superior
	NF_InitTiledBgSys(1);		// Iniciliaza los fondos Tileados para la pantalla inferior

	// Carga el archivo desde la FAT
	NF_LoadTiledBg(	"layer3",	// Nombre de archivo
					"moon",		// Nombre que le das al fondo
					256,		// Ancho del fondo en pixeles
					256			// Alto del fondo en pixeles
					);

	NF_LoadTiledBg("largebg1", "mylarge1", 2048, 256);	// Carga el fondo en la capa 1
	NF_LoadTiledBg("largebg2", "mylarge2", 1536, 256);	// Carga el fondo en la capa 2
	NF_LoadTiledBg("largebg3", "mylarge3", 1024, 256);	// Carga el fondo en la capa 3

	NF_LoadTiledBg("verylarge1", "bg0", 2048, 2048);	// Carga el fondo en la capa 1 (Inf)
	NF_LoadTiledBg("verylarge2", "bg1", 1536, 1536);	// Carga el fondo en la capa 2 (Inf)
	NF_LoadTiledBg("verylarge3", "bg2", 1024, 1024);	// Carga el fondo en la capa 3 (Inf)


	// Crea los fondos
	NF_CreateTiledBg(	0,		// Pantalla de destino
						3,		// Numero de capa donde colocaras el fondo
						"moon"	// Nombre del fondo
						);


	NF_CreateTiledBg(0, 2, "bg2");
	NF_CreateTiledBg(0, 1, "bg1");
	NF_CreateTiledBg(0, 0, "bg0");

	NF_CreateTiledBg(1, 3, "moon");
	NF_CreateTiledBg(1, 0, "mylarge1");
	NF_CreateTiledBg(1, 1, "mylarge2");
	NF_CreateTiledBg(1, 2, "mylarge3");

}



// Inicializa y carga los sprites
void _InitSpr(void) {

	u8 n = 0;
	u16 z = 0;


	// Inicializaciones
	NF_InitSpriteBuffers();		// Inicializa los Buffers de Sprites
	NF_InitSpriteSys(0);		// Inicializa los Sprites para la pantalla 0
	NF_InitSpriteSys(1);		// Inicializa los Sprites para la pantalla 1

	// Carga los graficos y paletas de los Sprites
	NF_LoadSpriteGfx(	"bola",		// Nombre de archivo
						0,			// Id. (slot) en RAM
						32,			// Ancho en pixeles
						32			// Alto en pinxeles
						);

	NF_LoadSpritePal(	"bola",		// Nombre de archivo
						0			// Id. (slot) en RAM de la paleta
						);

	NF_LoadSpriteGfx("ds", 1, 32, 32);
	NF_LoadSpritePal("ds", 1);
	NF_LoadSpriteGfx("calabera1", 2, 64, 64);
	NF_LoadSpritePal("calabera1", 2);
	NF_LoadSpriteGfx("calabera2", 3, 64, 64);
	NF_LoadSpritePal("calabera2", 3);
	NF_LoadSpriteGfx("calabera3", 4, 64, 64);
	NF_LoadSpritePal("calabera3", 4);

	// Carga un Gfx animado
	NF_LoadSpriteGfx("personaje", 5, 64, 64);
	NF_LoadSpritePal("personaje", 5);

	// Transfiere los datos cargados a la VRAM
	for (n = 0; n < 6; n ++) {

		NF_VramSpriteGfx(	0,		// Pantalla de destino
							n,		// Id (slot) del Gfx en RAM
							n,		// Id (slot) del Gfx en VRAM
							true	// Manten los frames adicionales de la animacion en RAM
							);

		NF_VramSpriteGfx(1, n, n, false);	// En esta, copia todos los frames de la animacion en VRAM

		NF_VramSpritePal(	0,	// Pantalla de destino
							n,	// Id (slot) de la paleta en RAM
							n	// N� de la paleta en VRAM (0 - 15)
							);
		NF_VramSpritePal(1, n, n);

	}

	// Crea los sprites
	for (n = 0; n < MAXSPRITES; n ++) {
		z =  (rand() % 5);
		NF_CreateSprite(	0,	// Pantalla de destino
							(n + 5),	// Numero de Sprite
							z,	// N� de grafico (Id en VRAM)
							z,	// N� de la paleta (0 - 15)
							0,	// Coordenada X
							0	// coordenada Y
							);
		z =  (rand() % 5);
		NF_CreateSprite(1, (n + 5), z, z, 0, 0);
	}


	// Crea el Sprite del Personaje
	for (n = 0; n < 4; n ++) {
		NF_CreateSprite(0, n, 5, 5, 100, 96);
		NF_CreateSprite(1, n, 5, 5, 100, 96);
	}


	// Define la capa sobre la que se dibujaran y si se rotaran
	for (n = 0; n < MAXSPRITES; n ++) {
		NF_SpriteLayer(	0,				// Pantalla de destino
						(n + 5),		// N� de Sprite (0 - 127)
						(rand() % 4)	// Capa sobre la que se dibujara (0 - 3)
						);

		NF_EnableSpriteRotScale(	0,				// Pantalla
									(n + 5),		// N� de Sprite
									(rand() % 32),	// Id de rotScale
									true			// Habilita el "double size"?
									);

		NF_SpriteLayer(1, (n + 5), (rand() % 4));

	}

	NF_SpriteLayer(0, 1, 1);
	NF_SpriteLayer(0, 3, 1);
	NF_SpriteLayer(1, 1, 1);
	NF_SpriteLayer(1, 3, 1);



}

