//
// Plantilla de proyecto de NDS
//


// Includes devKitPro
#include <nds.h>
#include <fat.h>

// Includes C++
#include <stdio.h>
#include <string.h>
#include <unistd.h>


// Includes propios
#include "nf_lib.h"


// Declara funciones
void _InitFat(void);	// Inicializa la FAT
void _InitBgs(void);	// Inicializa y carga los fondos
void _InitText(void);	// Inicializa y carga los textos
	
// Main
int main(void) {

	// Inicializa la FAT
	_InitFat();
	NF_SetRootFolder("NFlib");	// Define la carpeta ROOT de la FAT

	// Inicializa las 2D
	NF_Set2D(0, 0);				// Modo 2D_0 en la pantalla superior
	NF_Set2D(1, 0);				// Modo 2D_0 en la pantalla inferior

	// Inicializa y carga los fondos
	_InitBgs();

	// Inicializa y carga las fuentes y textos
	_InitText();

	char mytext[32];
	u32 myvar = 0;

	s16 x = 0;
	s8 i = 1;


	// Bucle principal
	while(1) {		// Repite para siempre

		myvar ++;
		sprintf(mytext,"Contador: %d", myvar);
		NF_WriteText(0, 0, 1, 5, mytext);
		NF_WriteText(0, 1, 1, 5, mytext);
		NF_WriteText(0, 2, 1, 5, mytext);

		x += i;
		if (x < -100 || x > 0) i *= -1;

		NF_UpdateTextLayers();		// Actualiza las capas de texto

		swiWaitForVBlank();			// Espera al sincronismo vertical

		/*
		NF_ScrollBg(0, 0, x, 0);
		NF_ScrollBg(0, 1, 0, x);
		NF_ScrollBg(0, 2, x, x);
		*/

	}

	return 0;

}



// Inicializa la FAT
void _InitFat(void) {

	// Inicializa el sistema FAT


	if (fatInitDefault()) {		// Intenta inicializar la FAT
		// Conseguido, continua
		chdir("fat:/");

	} else {

		// Fallo. Deten el programa
		consoleDemoInit();	// Inicializa la consola de texto
		iprintf("Fat Init Error.\n");
		iprintf("Abnormal termination.\n");
		// Bucle infinito. Fin del programa
		while(1) {
			swiWaitForVBlank();
		}
	}

}



// Inicializa y carga los fondos 2D
void _InitBgs(void) {

	// Inicializaciones
	NF_InitTiledBgBuffers();	// Inicializa los buffers para almacenar fondos
	NF_InitTiledBgSys(0);		// Inicializa los fondos Tileados para la pantalla superior
	NF_InitTiledBgSys(1);		// Iniciliaza los fondos Tileados para la pantalla inferior

	// Carga el archivo desde la FAT
	NF_LoadTiledBg(	"layer3",	// Nombre de archivo
					"moon",		// Nombre que le das al fondo
					256,		// Ancho del fondo en pixeles
					256			// Alto del fondo en pixeles
					);

	// Crea los fondos
	NF_CreateTiledBg(	0,		// Pantalla de destino
						3,		// Numero de capa donde colocaras el fondo
						"moon"	// Nombre del fondo
						);

	NF_CreateTiledBg(1, 3, "moon");

}



// Inicializa y carga los textos
void _InitText(void) {

	// Inicializa los buffers para almacenar textos
	NF_InitTextBuffers();
	NF_InitTextSys(0);

	// Carga las fuentes desde la FAT
	NF_LoadTextFont("default",	// Nombre del archivo sin extension (.FNT)
					"normal",	// Nombre que le damos a la fuente cargada
					0			// Carga la fuente segun rotacion (0 normal)
					);

	NF_LoadTextFont("default", "right", 1);
	NF_LoadTextFont("default", "left", 2);


	

	NF_CreateTextLayer(0,		// Pantalla
					0,			// Capa
					0,			// Rotacion
					"normal"	// Nombre de la fuente
					);

	NF_CreateTextLayer(0, 1, 1, "right");
	NF_CreateTextLayer(0, 2, 2, "left");

	NF_WriteText(0, 0, 1, 1, "Hola Mundo!");
	NF_WriteText(0, 0, 1, 3, "Hello World!");

	NF_WriteText(0, 1, 1, 1, "Hola Mundo!");
	NF_WriteText(0, 1, 1, 3, "Hello World!");

	NF_WriteText(0, 2, 1, 1, "Hola Mundo!");
	NF_WriteText(0, 2, 1, 3, "Hello World!");


}
