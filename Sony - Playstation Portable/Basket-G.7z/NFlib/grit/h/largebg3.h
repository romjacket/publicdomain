
//{{BLOCK(largebg3)

//======================================================================
//
//	largebg3, 1024x256@8, 
//	+ palette 256 entries, not compressed
//	+ 166 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 128x32 
//	Total size: 512 + 10624 + 8192 = 19328
//
//	Time-stamp: 2009-05-12, 02:02:53
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LARGEBG3_H
#define GRIT_LARGEBG3_H

#define largebg3TilesLen 10624
extern const unsigned int largebg3Tiles[2656];

#define largebg3MapLen 8192
extern const unsigned short largebg3Map[4096];

#define largebg3PalLen 512
extern const unsigned short largebg3Pal[256];

#endif // GRIT_LARGEBG3_H

//}}BLOCK(largebg3)
