
//{{BLOCK(largebg1)

//======================================================================
//
//	largebg1, 2048x256@8, 
//	+ palette 256 entries, not compressed
//	+ 250 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 256x32 
//	Total size: 512 + 16000 + 16384 = 32896
//
//	Time-stamp: 2009-05-12, 02:02:53
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LARGEBG1_H
#define GRIT_LARGEBG1_H

#define largebg1TilesLen 16000
extern const unsigned int largebg1Tiles[4000];

#define largebg1MapLen 16384
extern const unsigned short largebg1Map[8192];

#define largebg1PalLen 512
extern const unsigned short largebg1Pal[256];

#endif // GRIT_LARGEBG1_H

//}}BLOCK(largebg1)
