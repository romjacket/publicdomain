
//{{BLOCK(largebg2)

//======================================================================
//
//	largebg2, 1536x256@8, 
//	+ palette 256 entries, not compressed
//	+ 289 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 192x32 
//	Total size: 512 + 18496 + 12288 = 31296
//
//	Time-stamp: 2009-05-12, 02:02:53
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LARGEBG2_H
#define GRIT_LARGEBG2_H

#define largebg2TilesLen 18496
extern const unsigned int largebg2Tiles[4624];

#define largebg2MapLen 12288
extern const unsigned short largebg2Map[6144];

#define largebg2PalLen 512
extern const unsigned short largebg2Pal[256];

#endif // GRIT_LARGEBG2_H

//}}BLOCK(largebg2)
