//
// Plantilla de proyecto de NDS
//


// Includes devKitPro
#include <nds.h>
#include <fat.h>

// Includes C++
#include <stdio.h>
#include <string.h>
#include <unistd.h>


// Includes propios
#include "nf_lib.h"


// Declara funciones
void _InitFat(void);	// Inicializa la FAT
void _InitBgs(void);	// Inicializa y carga los fondos
void _InitSpr(void);	// Inicializa y carga los sprites
void _InitText(void);	// Inicializa y carga los textos
void _InitCmaps(void);	// Inicializa y carga los mapas de colisiones


	
// Main
int main(void) {

	// Inicializa la FAT
	_InitFat();
	NF_SetRootFolder("NFlib");	// Define la carpeta ROOT de la FAT

	// Inicializa las 2D
	NF_Set2D(0, 0);				// Modo 2D_0 en la pantalla superior
	NF_Set2D(1, 0);				// Modo 2D_0 en la pantalla inferior

	// Inicializa y carga los fondos
	_InitBgs();

	// Inicializa y carga los sprites
	_InitSpr();

	// Inicializa y carga las fuentes y textos
	_InitText();
	char mytext[32];

	// Inicializa y carga los mapas de colision
	_InitCmaps();

	// Inicializa la lectura del keypad
	u16 keys = 0;

	// Coordenadas Globales
	s16 x = 128;
	s16 y = 96;
	s16 spr_x = 0;
	s16 spr_y = 0;
	s16 bg_x = 0;
	s16 bg_y = 0;





	// Bucle principal
	while(1) {		// Repite para siempre

		// Lee el teclado
		scanKeys();
		keys = keysHeld();
		if (keys & KEY_UP) y --;
		if (keys & KEY_DOWN) y ++;
		if (keys & KEY_LEFT) x --;
		if (keys & KEY_RIGHT) x ++;

		// Limites del movimiento
		if (x < 0) x = 0;
		if (x > 767) x = 767;
		if (y < 0) y = 0;
		if (y > 511) y = 511;

		// Posicion del fondo
		bg_x = (x - 128);
		if (bg_x < 0) bg_x = 0;
		if (bg_x > 512) bg_x = 512;
		bg_y = (y - 96);
		if (bg_y < 0) bg_y = 0;
		if (bg_y > 320) bg_y = 320;

		// Posicion del Sprite
		spr_x = (x - bg_x) - 4;
		spr_y = (y - bg_y) - 4;
		NF_MoveSprite(1, 0, spr_x, spr_y);

		// Imprime la posicion del cursor
		sprintf(mytext,"x:%d  y:%d ", x, y);
		NF_WriteText(0, 0, 1, 1, mytext);

		// Imprime el n� de tile
		switch (NF_GetTile(0, x, y)) {
			case 0:
				sprintf(mytext,"Tile: Vacio / Void  ");
				break;
			case 1:
				sprintf(mytext,"Tile: Rojo / Red    ");
				break;
			case 2:
				sprintf(mytext,"Tile: Verde / Green ");
				break;
			case 3:
				sprintf(mytext,"Tile: Azul / Blue   ");
				break;
		}
		NF_WriteText(0, 0, 1, 3, mytext);

		NF_UpdateTextLayers();			// Actualiza las capas de texto
		NF_SpriteOamSet(1);				// Actualiza el Array del OAM

		swiWaitForVBlank();				// Espera al sincronismo vertical

		oamUpdate(&oamSub);				// Actualiza a VRAM el OAM Secundario

		NF_ScrollBg(1, 2, bg_x, bg_y);	// Actualiza el scroll 

	}

	return 0;

}



// Inicializa la FAT
void _InitFat(void) {

	// Inicializa el sistema FAT


	if (fatInitDefault()) {		// Intenta inicializar la FAT
		// Conseguido, continua
		chdir("fat:/");

	} else {

		// Fallo. Deten el programa
		consoleDemoInit();	// Inicializa la consola de texto
		iprintf("Fat Init Error.\n");
		iprintf("Abnormal termination.\n");
		// Bucle infinito. Fin del programa
		while(1) {
			swiWaitForVBlank();
		}
	}

}



// Inicializa y carga los fondos 2D
void _InitBgs(void) {

	// Inicializaciones
	NF_InitTiledBgBuffers();	// Inicializa los buffers para almacenar fondos
	NF_InitTiledBgSys(0);		// Inicializa los fondos Tileados para la pantalla superior
	NF_InitTiledBgSys(1);		// Iniciliaza los fondos Tileados para la pantalla inferior

	// Carga el archivo desde la FAT
	NF_LoadTiledBg(	"layer3",	// Nombre de archivo
					"moon",		// Nombre que le das al fondo
					256,		// Ancho del fondo en pixeles
					256			// Alto del fondo en pixeles
					);
	NF_LoadTiledBg("colmap", "boxes", 768, 512);

	// Crea los fondos
	NF_CreateTiledBg(	0,		// Pantalla de destino
						3,		// Numero de capa donde colocaras el fondo
						"moon"	// Nombre del fondo
						);

	NF_CreateTiledBg(1, 3, "moon");
	NF_CreateTiledBg(1, 2, "boxes");

}



// Inicializa y carga los textos
void _InitText(void) {

	// Inicializa los buffers para almacenar textos
	NF_InitTextBuffers();
	NF_InitTextSys(0);

	// Carga las fuentes desde la FAT
	NF_LoadTextFont("default",	// Nombre del archivo sin extension (.FNT)
					"normal",	// Nombre que le damos a la fuente cargada
					0			// Carga la fuente segun rotacion (0 normal)
					);

	NF_CreateTextLayer(0,		// Pantalla
					0,			// Capa
					0,			// Rotacion
					"normal"	// Nombre de la fuente
					);

}



// Inicializa y carga los sprites
void _InitSpr(void) {

	// Inicializaciones
	NF_InitSpriteBuffers();		// Inicializa los Buffers de Sprites
	NF_InitSpriteSys(1);		// Inicializa los Sprites para la pantalla 1

	// Carga los graficos y paletas de los Sprites
	NF_LoadSpriteGfx(	"puntero",		// Nombre de archivo
						0,				// Id. (slot) en RAM
						8,				// Ancho en pixeles
						8				// Alto en pinxeles
						);

	NF_LoadSpritePal(	"puntero",		// Nombre de archivo
						0				// Id. (slot) en RAM de la paleta
						);

	NF_VramSpriteGfx(	1,		// Pantalla de destino
						0,		// Id (slot) del Gfx en RAM
						0,		// Id (slot) del Gfx en VRAM
						false	// Manten los frames adicionales de la animacion en RAM
						);

	NF_VramSpritePal(	1,		// Pantalla de destino
						0,		// Id (slot) de la paleta en RAM
						0		// N� de la paleta en VRAM (0 - 15)
						);

	NF_CreateSprite(	1,		// Pantalla de destino
						0,		// Numero de Sprite
						0,		// N� de grafico (Id en VRAM)
						0,		// N� de la paleta (0 - 15)
						124,	// Coordenada X
						92		// coordenada Y
						);

	NF_SpriteLayer(		1,		// Pantalla de destino
						0,		// n� de sprite
						0		// Capa
						);

}



// Inicializa y carga los mapas de colision
void _InitCmaps(void) {

	// Inicializaciones
	NF_InitCmapBuffers();
	
	// Carga el mapa de colisiones
	NF_LoadColisionMap(	"cmap",		// Archivo de mapas de colision (*.cmap)
						0,			// n� de slot donde almacenarlo
						768,		// Ancho del mapa en pixeles
						512			// Alto del mapa en pixeles
						);

}