#ifndef __NF_BASIC_H__
#define __NF_BASIC_H__

#ifdef __cplusplus
extern "C" {
#endif





	// NightFox LIB - Include de funciones basicas
	// Requiere DevkitARM R25
	// Codigo por NightFox
	// http://blogs.gamefilia.com/knightfox
	// Version BETA 1



	// Includes devKitPro
	#include <nds.h>





	// Define la variable global NF_ROOTFOLDER
	extern char NF_ROOTFOLDER[32];



	// Funcion NF_Error();
	void NF_Error(u16 code, const char* text, u32 value);
	// Errores para debug. Detiene el sistema e informa del error
	// 101: Fichero no encontrado
	// 102: Memoria insuficiente
	// 103: No quedan Slots libres
	// 104: Fondo no encontrado
	// 105: Fondo no creado
	// 106: Fuera de rango
	// 107: Insuficientes bloques contiguos en VRAM (Tiles)
	// 108: Insuficientes bloques contiguos en VRAM (Maps)
	// 109: Id ocupada (ya esta en uso)
	// 110: Id no cargada (en RAM)
	// 111: Id no en VRAM
	// 112: Sprite no creado
	// 113:	Memoria VRAM insuficiente
	// 114: La capa de Texto no existe
	// 115:	Medidas del fondo no compatibles (no son multiplos de 256)



	// Funcion NF_SetRootFolder();
	void NF_SetRootFolder(const char* folder);
	// Define el nombre de la carpeta que se usara como "root" si se usa la FAT





#ifdef __cplusplus
}
#endif


#endif