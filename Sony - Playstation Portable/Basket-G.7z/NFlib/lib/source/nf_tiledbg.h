#ifndef __NF_TILEDBG_H__
#define __NF_TILEDBG_H__

#ifdef __cplusplus
extern "C" {
#endif





	// NightFox LIB - Include de Fondos con tiles
	// Requiere DevkitARM R25
	// Codigo por NightFox
	// http://blogs.gamefilia.com/knightfox
	// Version BETA 1





	// Includes devKitPro
	#include <nds.h>





	// Define los slots maximos para los fondos
	#define NF_SLOTS_TBG 32

	// Define los bancos de Mapas y Tiles
	#define NF_BANKS_TILES 8	// (1 banks = 16kb)	Cada banco de tiles puede alvergar 8 bancos de Mapas
	#define NF_BANKS_MAPS 16	// (1 bank = 2kb)	Usar multiplos de 8. Cada set de 8 bancos consume 1 banco de tiles
	// Por defecto Tiles = 8, Mapas = 16
	// Esto nos deja 6 bancos de 16kb para tiles
	// y 16 bancos de 2kb para mapas

	// Define los Buffers para almacenar los fondos
	extern char* NF_BUFFER_BGTILES[NF_SLOTS_TBG];
	extern char* NF_BUFFER_BGMAP[NF_SLOTS_TBG];
	extern char* NF_BUFFER_BGPAL[NF_SLOTS_TBG];


	// Define estructura para almacenar la info de los fondos
	typedef struct {
		char name[32];		// Nombre del fondo
		u32 tilesize;		// Tama�o del Tileset
		u32 mapsize;		// Tama�o del Map
		u32 palsize;		// Tama�o de la Paleta
		u16 width;			// Ancho del fondo
		u16 height;			// Altura del fondo
		bool available;		// Disponibilidat del Slot
	} NF_TYPE_TBG_INFO;
	extern NF_TYPE_TBG_INFO NF_TILEDBG[NF_SLOTS_TBG];	// Datos de los fondos

	// Define estructura para almacenar la info de los fondos en pantalla
	typedef struct {
		u8 tilebase;		// Bloque de inicio en VRAM del Tileset
		u8 tileblocks;		// Bloques usados por el Tileset
		u8 mapbase;			// Bloque de inicio en VRAM del Map
		u8 mapblocks;		// Bloques usados por el Map
		u16 bgwidth;		// Ancho del fondo
		u16 bgheight;		// Altura del fondo
		u16 mapwidth;		// Ancho del mapa
		u16 mapheight;		// Altura del mapa
		u8 bgtype;			// Tipo de mapa
		u8 bgslot;			// Buffer de graficos usado (NF_BUFFER_BGMAP)
		u8 blockx;			// Bloque de mapa (horizontal)
		u8 blocky;			// bloque de mapa (vertical)
		bool created;		// Flag de si esta creado
	} NF_TYPE_TBGLAYERS_INFO;
	// El hardware de la DS no permite mapas mayores de 512x512
	// Asi que informaremos si nuestor mapa lo gestionara el hardware si es menor o 
	// igual a 512x512, o usaremos nuestro motor de Tile Swaping
	// bgtype 0: Normal (maximo 512 x 512)
	// bgtype 1: >512 x 256
	// bgtype 2: 256 x >512
	// bgtype 3: >512 x >512
	extern NF_TYPE_TBGLAYERS_INFO NF_TILEDBG_LAYERS[2][4];	//[screen][layer]



	// Define el array de bloques libres
	extern u8 NF_TILEBLOCKS[2][NF_BANKS_TILES];
	extern u8 NF_MAPBLOCKS[2][NF_BANKS_MAPS];



	// Funcion NF_InitTiledBgBuffers();
	void NF_InitTiledBgBuffers(void);
	// Inicializa los buffers y estructuras de control para usar los fondos "tileados"
	// Se debe usar antes de cargar o usar cualquier fondo
	// No uses esta funcion mas de una vez en tu codigo



	// Funcion NF_ResetTiledBgBuffers();
	void NF_ResetTiledBgBuffers(void);
	// Borra todos los buffers y reinicia las estructuras de fondos "tileados"
	// Usala para los cambios de nivel y similares



	// Funcion NF_InitTiledBgSys();
	void NF_InitTiledBgSys(u8 screen);
	// Inicializa las variables de control de tiles, mapas y paletas
	// Asigna 128kb de RAM para fondos tileados
	// Se debe especificar la pantalla (0 o 1)



	// Funcion NF_LoadTiledBg();
	void NF_LoadTiledBg(const char* file, const char* name,  u16 width, u16 height);
	// Carga un fondo tileado desde FAT
	// Debes de especificar el archivo que se cargara (sin extension) y el nombre
	// que le quieres dar y las medidas en pixeles



	// Funcion NF_UnloadTiledBg();
	void NF_UnloadTiledBg(const char* name);
	// Borra de la RAM un fondo cargado con NF_LoadTiledBg();
	// Debes especificar el nombre que le diste al fondo



	// Funcion NF_CreateTiledBg();
	void NF_CreateTiledBg(u8 screen, u8 layer, const char* name);
	// Crea un fondo con los parametros dados, indicale la pantalla, capa y nombre



	// Funcion NF_DeleteTiledBg();
	void NF_DeleteTiledBg(u8 screen, u8 layer);
	// Borra un fondo de la memoria VRAM
	// Debes especificar la pantalla y numero de capa





#ifdef __cplusplus
}
#endif


#endif