#ifdef __cplusplus
extern "C" {
#endif





	// NightFox LIB - Funciones basicas y de Debug
	// Requiere DevkitARM R25
	// Codigo por NightFox
	// http://blogs.gamefilia.com/knightfox
	// Version BETA 1



	// Includes devKitPro
	#include <nds.h>

	// Includes C++
	#include <stdio.h>

	// Includes propios
	#include "nf_basic.h"



	// Define la variable global NF_ROOTFOLDER
	char NF_ROOTFOLDER[32];



	// Funcion NF_Error();
	void NF_Error(u16 code, const char* text, u32 value ) {

		consoleDemoInit();		// Inicializa la consola de texto
		consoleClear();			// Borra la pantalla

		u32 n = 0;	// Variables de uso general

		// Captura el codigo de error
		switch (code) {

			case 101:	// Fichero no encontrado
				iprintf("File %s not found.\n", text);
				break;

			case 102:	// Memoria insuficiente
				iprintf("Out of memory.\n");
				iprintf("%d bytes\n", value);
				iprintf("can't be allocated.\n");
				break;

			case 103:	// No quedan Slots libres
				iprintf("Out of %s slots.\n", text);
				iprintf("All %d slots are in use.\n", value);
				break;

			case 104:	// Fondo no encontrado
				iprintf("Tiled Bg %s\n", text);
				iprintf("not found.\n");
				break;

			case 105:	// Fondo no creado
				iprintf("Background number %d\n", value);
				iprintf("on screen %s is\n", text);
				iprintf("not created.\n");
				break;

			case 106:	// Fuera de rango
				iprintf("%s Id out\n", text);
				iprintf("of range (%d max).\n", value);
				break;

			case 107:	// Insuficientes bloques contiguos en VRAM (Tiles)
				n = (int)((value * 16384) / 1024);
				iprintf("Can't allocate %d\n", value);
				iprintf("blocks of tiles for\n");
				iprintf("%s background\n", text);
				iprintf("Free %dkb of VRAM or try to\n", n);
				iprintf("reload all Bg's again\n");
				break;

			case 108:	// Insuficientes bloques contiguos en VRAM (Maps)
				n = (int)((value * 2048) / 1024);
				iprintf("Can't allocate %d\n", value);
				iprintf("blocks of maps for\n");
				iprintf("%s background\n", text);
				iprintf("Free %dkb of VRAM or try to\n", n);
				iprintf("reload all Bg's again\n");
				break;

			case 109:	// Id ocupada
				iprintf("%s Id.%d\n", text, value);
				iprintf("is already in use.\n");
				break;

			case 110:	// Id no cargada
				iprintf("%s\n", text);
				iprintf("%d not loaded.\n", value);
				break;

			case 111:	// Id no en VRAM
				iprintf("%s\n", text);
				iprintf("%d not in VRAM.\n", value);
				break;

			case 112:	// Sprite no creado
				iprintf("Sprite number %d\n", value);
				iprintf("on screen %s is\n", text);
				iprintf("not created.\n");
				break;

			case 113:	// Memoria VRAM insuficiente
				iprintf("Out of VRAM.\n");
				iprintf("%d bytes for %s\n", value, text);
				iprintf("can't be allocated.\n");
				break;

			case 114:	// La capa de Texto no existe
				iprintf("Text layer on screen.\n");
				iprintf("n�%d don't exist.\n", value);
				break;

			case 115:	// Medidas del fondo no compatibles (no son multiplos de 256)
				iprintf("Tiled Bg %s\n", text);
				iprintf("has wrong size.\n");
				iprintf("Your bg sizes must be\n");
				iprintf("dividable by 256 pixels.\n");
				break;

		}

		iprintf("Error code %d.\n", code);		// Imprime el codigo de error

		// Deten la ejecucion del programa
		while (1) {
			swiWaitForVBlank();
		}

	}



	// Funcion NF_SetRootFolder();
	void NF_SetRootFolder(const char* folder) {
		sprintf(NF_ROOTFOLDER, "%s", folder);
	}





#ifdef __cplusplus
}
#endif