#ifndef __NF_TEXT_H__
#define __NF_TEXT_H__

#ifdef __cplusplus
extern "C" {
#endif





	// NightFox LIB - Include de Textos
	// Requiere DevkitARM R25
	// Codigo por NightFox
	// http://blogs.gamefilia.com/knightfox
	// Version BETA 1





	// Includes devKitPro
	#include <nds.h>



	// Define el n� de caracteres que tiene la fuente
	#define NF_TEXT_FONT_CHARS 100


	// Define la estructura de control de textos
	typedef struct {
		char* buffer;	// Buffer para almacenar el texto
		u8 rotation;	// Rotacion del texto
		bool exist;		// Existe la capa de texto?
		bool update;	// Tienes que actualizar la capa?
	} NF_TYPE_TEXT_INFO;
	extern NF_TYPE_TEXT_INFO NF_TEXT[2][4];		// Datos de las capas de texto



	// Funcion NF_InitTextBuffers();
	void NF_InitTextBuffers(void);
	// Inicializa los buffers de texto
	// Usa esta funcion solo 1 vez en tu codigo si tienes que usar texto



	// Funcion NF_InitTextSys();
	void NF_InitTextSys(u8 screen);
	// Inicializa el sistema de Texto para la pantalla dada



	// Funcion NF_LoadTiledBg();
	void NF_LoadTextFont(const char* file, const char* name, u8 rotation);
	// Carga una fuente para usar como texto
	// La fuente se cargara en un slot libre de fondos tileados
	// Debes especificar el archivos sin extension y un nombre para referenciarla
	// En caso de que la fuente tenga los sets de rotacion a izquierda y derecha,
	// especificar 1 o 2 en el parametro "rot". 0 carga la fuente sin rotacion



	// Funcion NF_UnloadTiledBg();
	void NF_UnloadTextFont(const char* name);
	// Borra un fuente cargada en RAM
	// Esta funcion simplemente llama a NF_UnloadTiledBg(); para su borrado



	// Funcion NF_CreateTextLayer();
	void NF_CreateTextLayer(u8 screen, u8 layer, u8 rotation, const char* name);
	// Crea un fondo tileado para usarlo con texto
	// Esta funcion simplemente llama a NF_CreateTiledBg(); para su creacion



	// Funcion NF_DeleteTextLayer();
	void NF_DeleteTextLayer(u8 screen, u8 layer);
	// Borra un fondo usado como capa de texto y sus buffers y variables asociadas



	// Funcion NF_WriteText();
	void NF_WriteText(u8 screen, u8 layer, u8 x, u8 y, const char* text);
	// Escribe un texto en el buffer de texto de la pantalla y capa seleccionada



	// Funcion NF_UpdateTextLayers();
	void NF_UpdateTextLayers(void);
	// Copia el buffer de texto a la VRAM en las capas que sea necesario
	// realizar una actualizacion





#ifdef __cplusplus
}
#endif


#endif