#ifdef __cplusplus
extern "C" {
#endif





	// NightFox LIB - Funciones de Textos
	// Requiere DevkitARM R25
	// Codigo por NightFox
	// http://blogs.gamefilia.com/knightfox
	// Version BETA 1



	// Includes devKitPro
	#include <nds.h>
	#include <fat.h>

	// Includes C++
	#include <stdio.h>
	#include <string.h>
	#include <unistd.h>

	// Includes propios
	#include "nf_basic.h"
	#include "nf_2d.h"
	#include "nf_tiledbg.h"
	#include "nf_text.h"




	// Define los buffers para almacenar las capas de texto
	NF_TYPE_TEXT_INFO NF_TEXT[2][4];



	// Funcion NF_InitTextBuffers();
	void NF_InitTextBuffers(void) {
		u8 n = 0;
		for (n = 0; n < 4; n ++) {
			NF_TEXT[0][n].buffer = NULL;	// Inicializa los punteros de texto de la pantalla superior
			NF_TEXT[1][n].buffer = NULL;	// Inicializa los punteros de texto de la pantalla inferior
		}
	}



	// Funcion NF_InitTextSys();
	void NF_InitTextSys(u8 screen) {

		u8 n = 0;

		// Reinicia los buffers y variables
		for (n = 0; n < 4; n ++) {
			free(NF_TEXT[screen][n].buffer);	// Vacia el buffer
			NF_TEXT[screen][n].buffer = NULL;	// Resetea el puntero
			NF_TEXT[screen][n].rotation = 0;	// Rotacion a 0 (ninguna)
			NF_TEXT[screen][n].exist = false;	// Marcalo como no existente
			NF_TEXT[screen][n].update = false;	// No es necesario actualizarlo
		}
		
	}



	// Funcion NF_LoadTiledBg();
	void NF_LoadTextFont(const char* file, const char* name, u8 rotation) {

		// Busca un slot libre
		u8 n = 0;
		u8 slot = 255;
		for (n = 0; n < NF_SLOTS_TBG; n ++) {		// Busca en todos los slots
			if (NF_TILEDBG[n].available) {			// Si esta libre
				NF_TILEDBG[n].available = false;	// Marcalo como en uso
				slot = n;							// Guarda el slot a usar
				n = NF_SLOTS_TBG;					// Deja de buscar
			}
		}
		// Si no hay ningun slot libre, error
		if (slot == 255) {
			NF_Error(103, "Tiled Bg", NF_SLOTS_TBG);
		}

		// Vacia los buffers que se usaran
		free(NF_BUFFER_BGMAP[slot]);		// Buffer para los mapas
		NF_BUFFER_BGMAP[slot] = NULL;
		free(NF_BUFFER_BGTILES[slot]);		// Buffer para los tiles
		NF_BUFFER_BGTILES[slot] = NULL;
		free(NF_BUFFER_BGPAL[slot]);		// Buffer para los paletas
		NF_BUFFER_BGPAL[slot] = NULL;

		// Declara los punteros a los ficheros
		FILE* file_id;

		// Variable para almacenar el path al archivo
		char filename[256];

		// Carga el archivo .FNT
		sprintf(filename, "%s/%s.fnt", NF_ROOTFOLDER, file);
		file_id = fopen(filename, "rb");
		if (file_id) {	// Si el archivo existe...
			// Obten el tama�o del archivo
			NF_TILEDBG[slot].tilesize = (NF_TEXT_FONT_CHARS << 6);		// 100 caracteres x 64 bytes
			// Reserva el espacio en RAM
			NF_BUFFER_BGTILES[slot] = (char*) calloc (NF_TILEDBG[slot].tilesize, sizeof(char));
			if (NF_BUFFER_BGTILES[slot] == NULL) {		// Si no hay suficiente RAM libre
				NF_Error(102, NULL, NF_TILEDBG[slot].tilesize);
			}
			// Lee el archivo y ponlo en la RAM
			fread (NF_BUFFER_BGTILES[slot], 1, 64, file_id);	// Lee el primer caracter (64 bytes)
			// ((((NF_TEXT_FONT_CHARS - 1) * 64) * rotation) + 64)
			fseek(file_id, ((((NF_TEXT_FONT_CHARS - 1) << 6) * rotation) + 64), SEEK_SET);			// Y posicionate en esa posicion de archivo
			fread ((NF_BUFFER_BGTILES[slot] + 64), 1, (NF_TILEDBG[slot].tilesize - 64), file_id);	// Lee el resto de caracteres de la fuente
		} else {	// Si el archivo no existe...
			NF_Error(101, filename, 0);
		}
		fclose(file_id);		// Cierra el archivo
		// swiWaitForVBlank();		// Espera al cierre del archivo (Usar en caso de corrupcion de datos)

		// Crea un archivo .MAP vacio en RAM 
		NF_TILEDBG[slot].mapsize = 2048;	// Mapa basico de 32x32 tiles (2kb)
		// Reserva el espacio en RAM
		NF_BUFFER_BGMAP[slot] = (char*) calloc (NF_TILEDBG[slot].mapsize, sizeof(char));
		if (NF_BUFFER_BGMAP[slot] == NULL) {		// Si no hay suficiente RAM libre
			NF_Error(102, NULL, NF_TILEDBG[slot].mapsize);
		}
		// Y ponlo a 0
		memset(NF_BUFFER_BGMAP[slot], 0, NF_TILEDBG[slot].mapsize);

		// Carga el archivo .PAL
		sprintf(filename, "%s/%s.pal", NF_ROOTFOLDER, file);
		file_id = fopen(filename, "rb");
		if (file_id) {	// Si el archivo existe...
			// Obten el tama�o del archivo
			fseek(file_id, 0, SEEK_END);
			NF_TILEDBG[slot].palsize = ftell(file_id);
			rewind(file_id);
			// Reserva el espacio en RAM
			NF_BUFFER_BGPAL[slot] = (char*) calloc (NF_TILEDBG[slot].palsize, sizeof(char));
			if (NF_BUFFER_BGPAL[slot] == NULL) {		// Si no hay suficiente RAM libre
				NF_Error(102, NULL, NF_TILEDBG[slot].palsize);
			}
			// Lee el archivo y ponlo en la RAM
			fread (NF_BUFFER_BGPAL[slot], 1, NF_TILEDBG[slot].palsize, file_id);
		} else {	// Si el archivo no existe...
			NF_Error(101, filename, 0);
		}
		fclose(file_id);		// Cierra el archivo
		// swiWaitForVBlank();		// Espera al cierre del archivo (Usar en caso de corrupcion de datos)

		// Guarda el nombre del Fondo
		sprintf(NF_TILEDBG[slot].name, "%s", name);

		// Y las medidas
		NF_TILEDBG[slot].width = 256;
		NF_TILEDBG[slot].height = 256;

	}



	// Funcion NF_UnloadTiledBg();
	void NF_UnloadTextFont(const char* name) {
		NF_UnloadTiledBg(name);
	}



	// Funcion NF_CreateTextLayer();
	void NF_CreateTextLayer(u8 screen, u8 layer, u8 rotation, const char* name) {

		// Crea un  fondo para usarlo como capa de texto
		NF_CreateTiledBg(screen, layer, name);

		// Reinicia el buffer (sobreescribelo)
		free(NF_TEXT[screen][layer].buffer);	// Borra el buffer
		NF_TEXT[screen][layer].buffer = NULL;	// Reinicia el puntero

		// Crea el buffer de texto correspondiente
		NF_TEXT[screen][layer].buffer = (char*) calloc (2048, sizeof(char));	// 2kb reservados
		if (NF_TEXT[screen][layer].buffer == NULL) {		// Si no hay suficiente RAM libre
			NF_Error(102, NULL, 2048);
		}

		// Y ponlo a 0
		memset(NF_TEXT[screen][layer].buffer, 0, 2048);

		// Guarda si el texto debe ser rotado
		NF_TEXT[screen][layer].rotation = rotation;

		// Y marcalo como creado
		NF_TEXT[screen][layer].exist = true;

	}



	// Funcion NF_DeleteTextLayer();
	void NF_DeleteTextLayer(u8 screen, u8 layer) {

		// Verifica si la capa de texto de destino existe
		if (!NF_TEXT[screen][layer].exist) {
			NF_Error(114, NULL, screen);
		}

		// Borra el fondo usado como capa de texto
		NF_DeleteTiledBg(screen, layer);

		// Reinicia el buffer (sobreescribelo)
		free(NF_TEXT[screen][layer].buffer);	// Borra el buffer
		NF_TEXT[screen][layer].buffer = NULL;	// Reinicia el puntero

		// Guarda si el texto debe ser rotado
		NF_TEXT[screen][layer].rotation = 0;

		// Y marcalo como creado
		NF_TEXT[screen][layer].exist = false;

	}



	// Funcion NF_WriteText();
	void NF_WriteText(u8 screen, u8 layer, u8 x, u8 y, const char* text) {

		// Verifica si la capa de texto de destino existe
		if (!NF_TEXT[screen][layer].exist) {
			NF_Error(114, NULL, screen);
		}

		u16 n = 0;					// Variable de uso general

		u16 tsize = 0;				// Almacena el numero de letras
		tsize = strlen(text);		// Calcula el numero de letras del texto
		u16 string[tsize];			// Define el buffer temporal

		u32 bsize = 0;				// Tama�o del buffer temporal
		bsize = sizeof(string);		// Y el tama�o del buffer temporal

		// Almacena en el buffer temporal el valor de los caracteres
		for (n = 0; n < tsize; n ++) {
			string[n] = ((int)(text[n])) - 32;	// Resta 32 al valor entrado
		}

		// Variable para calcular el desplazamiento en el buffer
		u16 move = 0;	// Desplazamiento en el buffer
		s8 rx = 0;		// X real
		s8 ry = 0;		// Y real
		u16 temp[1];	// Buffer temporal de 2 bytes para la letra

		// Escribe los datos en el buffer de texto, segun la rotacion
		switch (NF_TEXT[screen][layer].rotation) {

			case 0:		// Sin rotacion
				// Traspasa las coordenadas virtuales a las reales
				rx = x;
				ry = y;
				// Copia el texto al buffer letra a letra
				for (n = 0; n < tsize; n ++) {
					// Calcula la posicion del buffer donde insertar el texto
					move = ((rx + (ry << 5)) << 1);	// ((x + (y * 32)) * 2)
					// Copiala al buffer de texto
					temp[0] = string[n];
					if ((move + 2) < 2048) {
						memcpy((NF_TEXT[screen][layer].buffer + move), temp, 2);
					}
					// Siguiente letra
					rx ++;
					if (rx > 31) {		// Si llegas al final de linea,
						rx = 0;			// salto de linea
						ry ++;
						if (ry > 23) {	// Si estas en la ultima linea,
							ry = 0;		// vuelve a la primera
						}
					}
				}
				break;


			case 1:		// Rotacion 90� a la derecha
				// Traspasa las coordenadas virtuales a las reales
				rx = (31 - y);
				ry = x;
				// Copia el texto al buffer letra a letra
				for (n = 0; n < tsize; n ++) {
					// Calcula la posicion del buffer donde insertar el texto
					move = ((rx + (ry << 5)) << 1);	// ((x + (y * 32)) * 2)
					// Copiala al buffer de texto
					temp[0] = string[n];
					if ((move + 2) < 2048) {
						memcpy((NF_TEXT[screen][layer].buffer + move), temp, 2);
					}
					// Siguiente letra
					ry ++;
					if (ry > 23) {		// Si llegas al final de linea,
						ry = 0;			// salto de linea
						rx --;
						if (rx < 0) {	// Si estas en la ultima linea,
							rx = 31;	// vuelve a la primera
						}
					}
				}
				break;


			case 2:		// Rotacion 90� a la izquierda
				// Traspasa las coordenadas virtuales a las reales
				rx = y;
				ry = (23 - x);
				// Copia el texto al buffer letra a letra
				for (n = 0; n < tsize; n ++) {
					// Calcula la posicion del buffer donde insertar el texto
					move = ((rx + (ry << 5)) << 1);	// ((x + (y * 32)) * 2)
					// Copiala al buffer de texto
					temp[0] = string[n];
					if ((move + 2) < 2048) {
						memcpy((NF_TEXT[screen][layer].buffer + move), temp, 2);
					}
					// Siguiente letra
					ry --;
					if (ry < 0) {		// Si llegas al final de linea,
						ry = 23;		// Salto de linea
						rx ++;
						if (rx > 31) {	// Si llegas a la ultima linea
							rx = 0;		// vuelve a la primera
						}
					}
				}
				break;

		}

		// Marca esta capa de texto para actualizar
		NF_TEXT[screen][layer].update = true;

	}



	// Funcion NF_UpdateTextLayers();
	void NF_UpdateTextLayers(void) {

		// Variables
		u32 adress = 0;
		u8 screen = 0;
		u8 layer = 0;

		// Verifica si se tiene que actualizar la capa de texto
		for (screen = 0; screen < 2; screen ++) {		// Bucle de pantalla
			for (layer = 0; layer < 4; layer ++) {		// Bucle de capas

				if (NF_TEXT[screen][layer].update) {	// Si estas marcado para actualizar, hazlo

					// Calcula el puntero de VRAM, segun la pantalla
					if (screen == 0) {	// (VRAM_A)
						adress = (0x6000000) + (NF_TILEDBG_LAYERS[screen][layer].mapbase << 11);
					} else {			// (VRAM_C)
						adress = (0x6200000) + (NF_TILEDBG_LAYERS[screen][layer].mapbase << 11);
					}
					// Copia el buffer de Texto a la VRAM
					memcpy((void*)adress, NF_TEXT[screen][layer].buffer, 2048);
					// Y marcala como actualizada
					NF_TEXT[screen][layer].update = false;

				}

			}
		}

	}





#ifdef __cplusplus
}
#endif
