-- set clock frequency  at  333Mhz
ClockFrequency = 1
--mode debug
Debug = 0
--Editeur Actif
Editeur = 0
--Afficher l'intro
Intro = 1
--Afficher le menu ?
Menu = 1
--jouer une musique de fond ?
Musique = 1
--Jouer les  les son FX (tir, explosion...)
SFX = 1
--Autosauvegarde
AUTOSAVE = 1
