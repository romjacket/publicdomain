-- A simple test script
-- print(10,50,"Lua test program by pjeff")


-- Une fonction Lua simple
function funcName()
	--print(10,65,"LUA test de fonction")

end

