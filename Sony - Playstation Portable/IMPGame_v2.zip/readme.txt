## IMPGame v2,
## by Gefa
## www.gefa.altervista.org

Copy python and PSP directory in the root of your memory stick.

Enjoy.

