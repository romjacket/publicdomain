## IMPGame,
## by Gefa
## www.gefa.altervista.org

import psp2d
import string
import random
import time

uno = psp2d.Image('1.png')
due = psp2d.Image('2.png')
tre = psp2d.Image('3.png')
quattro = psp2d.Image('4.png')
cinque = psp2d.Image('5.png')
font = psp2d.Font('font.png')
bg = psp2d.Image('bg.png')

screen = psp2d.Screen()

nlettera = -1
lettere = ['A','B','C','D','E','F','G','H','I','L','M','N','O','P','Q','R','S',\
           'T','U','V','Z','Y','W','X','K','J']

nparola = [] # Parola "mascherata"

cf = open("conf.ini","r")
linee = cf.readlines()
splittata = string.split(linee[0])
path = splittata[2]

def init(lingua):
    global parola
    parola = ''
    fl = open(path,"r")
    linee = fl.readlines()
    linea = linee[random.randint(0,len(linee)-1)]
    splittata = string.split(linea,",")
    #print splittata
    if lingua == 0: # Ita
        parola = splittata[1].upper()
    if lingua == 1: # Eng
        parola = splittata[0].upper()
    if lingua == 2: # Fra
        parola = splittata[2].upper()
    if lingua == 3: # Spa
        parola = splittata[4].upper()
    if lingua == 4: # Ted
        parola = splittata[3].upper()
        
    pos = 0
    for elemento in parola:
        if pos == 0:
            nparola.append(parola[0])
        elif pos == len(parola)-1:
            if lingua != 3: nparola.append(parola[len(parola)-1])
            else: nparola.append(parola[len(parola)-2])
        elif elemento == " ":
            nparola.append(" ")
        else:
            nparola.append('-')
        pos += 1
    #print parola

vite = 4

def insert(lettera):
    global vite
    pos = 0
    sostituito = 0
    for elemento in parola:
        if elemento == lettera:
            nparola[pos] = lettera
            sostituito = 1
        pos += 1
    if sostituito == 0:
        vite -= 1

def tostring(lista):
    ''' Converto lista in stringa. '''
    string = ''
    for elemento in lista:
        string += elemento
    return string

oldpad = psp2d.Controller()

gioco = 0 # 0 -> Menu 1 -> Nuovo Gioco
scelta = 1
terzascelta = ['Italiano', 'Inglese', 'Francese', 'Spagnolo', 'Tedesco']
nterzascelta = 0

while True:
    pad = psp2d.Controller()

    if gioco == 0:
        screen.blit(bg, 0, 0, bg.width, bg.height, 0, 0, True)
        if scelta == 1:
            font.drawText(screen, 20, 160, "< Nuovo Gioco >")
            font.drawText(screen, 20, 190, " Lingua: %s "% terzascelta[nterzascelta])
            font.drawText(screen, 20, 220, " Esci  ")
            if pad.cross and not oldpad.cross:
                vite = 4
                init(nterzascelta)
                time.sleep(1)
                gioco = 1
        if scelta == 2:
            font.drawText(screen, 20, 160, " Nuovo Gioco  ")
            font.drawText(screen, 20, 190, "< Lingua: %s >"% terzascelta[nterzascelta])
            font.drawText(screen, 20, 220, " Esci  ")
            if pad.cross and not oldpad.cross and nterzascelta != 5:
                nterzascelta += 1
            if pad.cross and not oldpad.cross and nterzascelta == 5:
                nterzascelta = 0
        if scelta == 3:
            font.drawText(screen, 20, 160, " Nuovo Gioco  ")
            font.drawText(screen, 20, 190, " Lingua: %s "% terzascelta[nterzascelta])
            font.drawText(screen, 20, 220, "< Esci > ")
            if pad.cross:
                break
            
        if pad.down and not oldpad.down and scelta != 3:
            scelta += 1
        if pad.up and not oldpad.up and scelta != 1:
            scelta -= 1
        
    if gioco == 1:
        if pad.select and not oldpad.select:
            nparola = []
            nlettera = -1
            gioco = 0
        if vite == 4:
            screen.blit(uno, 0, 0, uno.width, uno.height, 0, 0, True)
        if vite == 3:
            screen.blit(due, 0, 0, due.width, due.height, 0, 0, True)
        if vite == 2:
            screen.blit(tre, 0, 0, tre.width, tre.height, 0, 0, True)
        if vite == 1:
            screen.blit(quattro, 0, 0, quattro.width, quattro.height, 0, 0, True)
        if vite == 0:
            screen.blit(cinque, 0, 0, cinque.width, cinque.height, 0, 0, True)

        if vite != 0:
            font.drawText(screen, 125, 170, lettere[nlettera])
            if "-" in nparola:
                font.drawText(screen, 50, 70, tostring(nparola))
            
                if pad.left and not oldpad.left and nlettera != 0:
                    nlettera -= 1 
                if pad.right and not oldpad.right and nlettera != 25:
                    nlettera += 1

                if pad.cross and not oldpad.cross:
                    if not nlettera == -1:
                        insert(lettere[nlettera])
                    else:
                        nlettera = 0
            elif not "-" in nparola:
                font.drawText(screen, 50, 70, tostring(nparola))
                font.drawText(screen, 70, 120, "HAI VINTO!")
                if pad.start and not oldpad.start:
                    nparola = []
                    init(nterzascelta)
                    vite = 4
        if vite == 0:
            font.drawText(screen, 50, 70, "HAI PERSO!")
            font.drawText(screen, 13, 120, "LA PAROLA ERA:")
            font.drawText(screen, 13, 160, parola)
            if pad.start and not oldpad.start:
                nparola = []
                init(nterzascelta)
                vite = 4
        
    oldpad = pad
    screen.swap()
