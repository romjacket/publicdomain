
Laser Invaders V5 - Art 2008!


Hi Guys,
This is a laser control game based on the PSP laser control idea by califrag.
Laser Invaders is coded from scratch, using the ps2dev.org Go!Cam demo as a template.

Put the PSP on a stand and face the camera at the wall in a darkened room,
and then control the crosshair by moving the laser around the wall in view of the camera.

Here's a YouTube video:
http://au.youtube.com/watch?v=AA9kmoSB73c

The idea is to shoot all invaders in as short time as possible.
Shooting special invaders will win you a 5 second time bonus which is deducted
from the time before the skill level report is calculated.
Shooting special invaders when three appear on screen earns an 8 second bonus.
The time is displayed at the end of the game, and then the time bonus is
subtracted before determining the player skill level. Skill levels are as follows:

   PITIFUL
 DISGRACEFUL
  PATHETIC!
  HOPELESS!
   NOT BAD
  EXCELLENT
  LEGENDARY
   TOP GUN

Laser Invaders requires a PSP-300 Go!Cam if that wasn't obvious.

Cheers, Art.

bmar8190@bigpond.net.au

Laser Invaders V5 (10/11/08):
- Implemented Intrafont text.

Laser Invaders V4 (07/11/08):
- Added another type of invader.
- reduced stars to minimise distraction.

Laser Invaders V3 (06/11/08):
- Added moving starfield.

Laser Invaders V2 (05/11/08):
- Fixed a screen glitch.
- Added a new special invader,
  and up to three invaders on the screen.

Laser Invaders V1 (04/11/08):
- First working laser shooting game.
