--[[Etch A Sketch Portable
Created By zeroXorXdieXskater]]

--//What is it?\\--
Etch A Sketch Portable is just what the title implies.
Not only do you have the ability to make cool retro drawings
you can change the color of your Etch A Sketch as well.
I whipped this up in an afternoon so the graphics are not
too good. I may update them.

--//What are the controls?\\--
--Use the D-Pad or analog stick to control the cursor, as you move you draw.
--Press start to change the color of your Etch A Sketch
--Press music note to take a screenshot
--Press Select to reset your Etch A Sketch

--//Misc.\\--
Using Luaplayer .20
Coded in LuaDevKit

--//Credits\\--
me, zeroXorXdieXskater - coding and (bad) graphics.
n00bionaire - posting my game on qj

--//Changelog\\--
v0.1
(initial release)