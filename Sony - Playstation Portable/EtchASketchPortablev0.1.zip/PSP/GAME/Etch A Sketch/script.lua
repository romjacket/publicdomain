--[[Etch A Sketch Portable
Created by zeroXorXdieXskater]]

red = Color.new(255,0,0)
black = Color.new(0,0,0)
white = Color.new(255,255,255)
---loading images
back = nil
backgrounds = Image.load("images/background.png")
rightarrow = Image.load("images/right.png")
right2 = Image.load("images/right2.png")
leftarrow = Image.load("images/left.png")
left2 = Image.load("images/left2.png")
uparrow = Image.load("images/up.png")
up2 = Image.load("images/up2.png")
downarrow = Image.load("images/down.png")
down2 = Image.load("images/down2.png")
fake = {x = 0, y = 0, img = Image.createEmpty(480, 272) }
redback = { x = 0, y = 0, img = Image.load("images/red.png")}
blueback = Image.load("images/blue.png")
pinkback = Image.load("images/pink.png")
sketch = { x = 0, y = 0, img = Image.load("images/sketch.png")}
mark = { x = 240, y = 146, speed = 2, img = Image.load("images/mark.png")}
Resolution = { width = 448, height = 234 }
gamestate = nil

function drawimages()
	screen:blit(redback.x,redback.y,back)
	screen:blit(sketch.x,sketch.y,sketch.img)
	screen:blit(fake.x,fake.y,fake.img)
	screen:blit(mark.x,mark.y,mark.img)
	screen:blit(60,240,rightarrow)
	screen:blit(40,240,leftarrow)
	screen:blit(430,240,uparrow)
	screen:blit(410,240,downarrow)
end

function control()
	if pad:select() then
		fake.img:clear()

	end
	if pad:start() then
		gamestate = "pause"
	end
	if pad:note() then
		screen:save("screenshot.png")
	end
end

function move()
anaX=pad:analogX()
anaY=pad:analogY()
if pad:up() and mark.y > 15 then
	mark.y = mark.y - mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
	uparrow = up2
else
uparrow = Image.load("images/up.png")
end

if pad:down() and mark.y < ( Resolution.height) then
	mark.y = mark.y + mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
	downarrow = down2
else
downarrow = Image.load("images/down.png")
end

if pad:left() and mark.x > 30 then
	mark.x = mark.x - mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
	leftarrow = left2
else
leftarrow = Image.load("images/left.png")
end

if pad:right() and mark.x < ( Resolution.width ) then
	mark.x = mark.x + mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
	rightarrow = right2
else
rightarrow = Image.load("images/right.png")
end

if anaY<-127 and mark.y > 0 then
	mark.y = mark.y - mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
end

if anaY>126 and mark.y < ( Resolution.height ) then
	mark.y = mark.y + mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
end

if anaX<-127 and mark.x > 0 then
	mark.x = mark.x - mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
end

if anaX>126 and mark.x < ( 480 ) then
	mark.x = mark.x + mark.speed
	fake.img:blit(mark.x,mark.y,mark.img)
end

end

back = redback.img
menustatus = 1
gamestate = "play"
while true do
screen:clear()
pad = Controls.read()
if gamestate == "play" then
	drawimages()
	move()
	control()
end

if gamestate == "pause" then
screen:clear()
screen:blit(0,0,backgrounds)
pad = Controls.read()
if pad:up() then
menustatus = menustatus - 1
screen.waitVblankStart(4)
end
if pad:down() then
menustatus = menustatus + 1
screen.waitVblankStart(4)
end
color={white, white, white}
color[menustatus]=red
screen:print(50, 50, "Red", color[1])
screen:print(50,60, "Blue", color[2])
screen:print(50,70, "green", color[3])
if menustatus == 1 then
    if pad:cross() then
    	back = redback.img
	fake.img:clear()
	gamestate = "play"
    end
end
if menustatus == 2 then
    if pad:cross() then
    	back = blueback
	fake.img:clear()
	gamestate = "play"
    end
end
if menustatus == 3 then
    if pad:cross() then
    	back = pinkback
	fake.img:clear()
	gamestate = "play"
    end
end
if menustatus <= 0 then
menustatus = 3
end
if menustatus >= 4 then
menustatus = 1
end
end 

screen.waitVblankStart()
screen.flip()
end