--Param�tre bille :
boule.x=20
boule.y=130
--images :
obstacles=Image.load("./niveaux/"..niveau.."/fond1.png")
obstacles2=Image.load("./niveaux/"..niveau.."/fond2.png")
obstacles3=Image.load("./niveaux/"..niveau.."/fond3.png")
obstacles4=Image.load("./niveaux/"..niveau.."/fond4.png")