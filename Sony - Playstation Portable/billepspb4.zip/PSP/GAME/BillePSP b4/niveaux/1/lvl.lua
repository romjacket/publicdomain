sxv=480
-- Background
screen:blit(sx/4,0,background)
screen:blit(sx/4+sxv,0,background)

-- Reconnaissance des bords
trame:blit(sx,0,obstacles)
trame:blit(sx+sxv,0,obstacles2)
trame:blit(sx+2*sxv,0,obstacles3)

-- Affichage du d�cors
screen:blit(sx,0,obstacles)
screen:blit(sx+sxv,0,obstacles2)
screen:blit(sx+2*sxv,0,obstacles3)

-- Points
pts_tot=2 -- Points dans ce niveau