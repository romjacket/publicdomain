while true do
	screen:clear()
	pad = Controls.read()
	screen:print(50,70,"Niveau termine !",white)
	screen:print(50,85,"Avec : "..boule.vie.."vie(s) & "..boule.pt.."point(s).",white)
	screen:print(50,125,"Appuyez sur X pour passer au niveau "..(niveau+1)..".",white)
	screen:print(320,255,"SELECT pour quitter",grey)
	if pad:cross() then
		boule.x=20
		boule.y=120
		boule.vie=2
		boule.pt=0
		sx=0
		niveau=niveau+1
		dofile("./niveaux/"..niveau.."/config.lua")
		break
	end
	if pad:select() then System.Quit() end
	screen.flip()
	screen.waitVblankStart()
end
