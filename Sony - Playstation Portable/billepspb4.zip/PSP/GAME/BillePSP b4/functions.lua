function collision_top()
	if couleur_top==sol then
		saut=false
	end
end
function collision_bottom()
	if couleur_bottom~=sol and pad:cross()==false then
		boule.v_saut=boule.gavity
		saut=false
	end
	if couleur_bottom==sol then
		if pad:cross()==true  then
			boule.v_saut=boule.gavity
			saut=true
		else
			saut=0
		end
	end
	if saut==true then -- Saute
		boule.y=boule.y-boule.v_saut
		boule.v_saut=boule.v_saut-0.4
	end
	if saut==false then -- Tombe
		boule.y=boule.y+boule.v_saut
		boule.v_saut=boule.v_saut+0.4
	end
end
function collision_left()
	if couleur_left==sol then
		right=1
		left=0
	else
		left=1
	end
end
function collision_right()
	if couleur_right==sol then
		right=0
		left=1
	else
		right=1
	end
end

function commandes() -- Fonction pour les touches et ecran
	pad=Controls.read()
	if pad:left() and left==1 then
		if boule.x>60 then
			boule.x=boule.x-boule.v
		else
			sx=sx+boule.v
		end
	end
	if pad:right() and right==1 then
		if boule.x<270 then
			boule.x=boule.x+boule.v
		else
			sx=sx-boule.v
		end
	end
	if pad:select() then System.Quit() end
	if pad:start() then
		screen:print(5,5,"** Bille PSP build 4 ** (select pour quitter)", grey)
	end
end
