boule={}
niveau=1

--couleurs
sol=Color.new(0,0,255)
interdit=Color.new(255,0,255)
fin=Color.new(0,255,0)
pointcolor=Color.new(255,255,0)
green=Color.new(0,255,0)
white=Color.new(255,255,255)
grey=Color.new(130,130,130)
black=Color.new(5,5,5)
-- param�tres divers
background=Image.load("background.png")

boule.gavity=10
boule.y_ini=boule.y
boule.v=7 --Vitesse
boule.vie=2 --nombre de vie(s)
boule.pt=0 --nombre de point(s)
sx=0

boule.img=Image.load("bille.png")
trame=Image.createEmpty(480,272)
dofile("./niveaux/"..niveau.."/config.lua")
dofile("functions.lua")

while true do
screen:clear()
trame:clear()
dofile("./niveaux/"..niveau.."/lvl.lua")
screen:blit(boule.x,boule.y,boule.img)

commandes()

couleur_top=trame:pixel(boule.x+12,boule.y+0)
collision_top()

couleur_bottom=trame:pixel(boule.x+12,boule.y+23)
collision_bottom()

couleur_left=trame:pixel(boule.x,boule.y+6)
collision_left()

couleur_right=trame:pixel(boule.x+23,boule.y+6)
collision_right()

if couleur_bottom==interdit or couleur_top==interdit then
	boule.vie=boule.vie-1
	sx=0
	boule.x=20
	boule.y=120
	if boule.vie==0 then	
		dofile("gameover.lua")
	end
end

if couleur_top==fin or couleur_bottom==fin or couleur_left==fin or couleur_righ==fin then	
	dofile("end_lvl.lua")
end

screen:fillRect(0,262,480,10,black) 
screen:print(5,263,"Vie(s):"..boule.vie.." � ".."lvl:"..niveau, grey)
--screen:print(100,262,"Point(s):"..boule.pt.."/"..pts_tot.."l:"..left.."r:"..right, grey) --Debug pour le moment
batt=System.powerGetBatteryLifePercent() --TEST
screen:print(395,263,"Batterie:"..batt.."%", grey)


screen.flip()
screen.waitVblankStart()
end
-- ** Par BafS 2009 - http://fabiens.ch/blog - Merci ;) **