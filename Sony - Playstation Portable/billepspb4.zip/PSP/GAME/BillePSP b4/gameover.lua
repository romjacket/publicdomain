while true do
	screen:clear()
	pad = Controls.read()
	screen:print(50,70,"- GAME OVER -",white)
	screen:print(50,100,"X pour recommencer / Select pour quitter",white)
	if pad:cross() then
		boule.vie=2
		break
	end
	if pad:select() then System.Quit() end
	screen.flip()
	screen.waitVblankStart()
end
