System.currentDirectory("Applications")
appsDir = System.currentDirectory()

System.currentDirectory("Lowser")
dofile("calcul.lua")