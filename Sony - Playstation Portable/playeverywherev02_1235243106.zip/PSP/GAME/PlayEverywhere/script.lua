background = Image.load("start.png")
black = Color.new(0,0,0)
battery1 = Image.load("battery1.png")
battery2 = Image.load("battery2.png")
battery3 = Image.load("battery3.png")
battery4 = Image.load("battery4.png")
battery5 = Image.load("battery5.png")
battery6 = Image.load("battery6.png")
battery7 = Image.load("battery7.png")
battery8 = Image.load("battery8.png")
hour=System.getTime(1)
hour2=System.getTime(2)
font = Font.createProportional()
font:setPixelSizes(0,16)

image = Image.load("startprems.png")
fader = Image.createEmpty(480,272)
alphaValue = 255
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)

function printCenteredfont(y,text,color) 
local length = string.len(text) 
local x = 370 - ((length*8)/2) 
screen:fontPrint(font,x,y,text,color) 
end 
function printCenteredfont2(y,text,color) 
local length = string.len(text) 
local x = 395 - ((length*8)/2) 
screen:fontPrint(font,x,y,text,color) 
end 

while true do
screen:clear()
screen:blit(0,0,image)
screen:blit(0,0,fader)
if alphaValue > 0 then
alphaValue = alphaValue - 5
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
screen.waitVblankStart(50) 
while true do
screen:clear()
screen:blit(0,0,image)
screen:blit(0,0,fader)
if alphaValue < 255 then
alphaValue = alphaValue + 5
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end

while true do
screen:clear()
pad = Controls.read()
screen:blit(0,0,background)
printCenteredfont(17, " "..hour, Color.new(255,255,255))
printCenteredfont2(17, "H"..hour2, Color.new(255,255,255))
if pad:start() then
dofile("./scripts/menu.lua")
end
if pad:select() then
dofile("./scripts/batterie.lua")
end
if pad:cross() then
dofile("./scripts/avancer.lua")
end
  if System.powerGetBatteryLifePercent() >= 0 then batteryL = battery1 end
  if System.powerGetBatteryLifePercent() > 15 then batteryL = battery2 end
  if System.powerGetBatteryLifePercent() > 30 then batteryL = battery3 end
  if System.powerGetBatteryLifePercent() > 45 then batteryL = battery4 end
  if System.powerGetBatteryLifePercent() > 60 then batteryL = battery5 end
  if System.powerGetBatteryLifePercent() > 75 then batteryL = battery6 end
  if System.powerGetBatteryLifePercent() > 90 then batteryL = battery7 end
  if System.powerGetBatteryLifePercent() >= 100 then batteryL = battery8 end
 
screen:blit(420,3,batteryL)
screen.flip()
screen.waitVblankStart()
end


