System.currentDirectory("ms0:/")
white = Color.new(255,255,255)
red = Color.new(0,0,0)
custom = Color.new(0,255,255)

back = Image.load("ms0:/PSP/GAME/Play Everywhere/img/mp3.png")

fbrowser = {s = 1, fl = System.listDirectory("ms0:/MUSIC/"),ls = 1, sp = 10}

fbrowser.nf = table.getn(fbrowser.fl)
oldpad = Controls.read()

function runfbrowser()
for i = ((fbrowser.ls-1)*fbrowser.sp)+1, fbrowser.ls*fbrowser.sp do
if fbrowser.nf >= i then
screen:print(10,((i-((fbrowser.ls-1)*fbrowser.sp))*10)-10,
fbrowser.fl[i].name,white)
elseif fbrowser.nf < i then break end
end

screen:print(10,((fbrowser.s-((fbrowser.ls-1)*fbrowser.sp))*10)-10,
fbrowser.fl[fbrowser.s].name,red)

if pad:down() and not oldpad:down() then fbrowser.s = fbrowser.s + 1 end
if pad:up() and not oldpad:up() then fbrowser.s = fbrowser.s - 1 end

if fbrowser.s > fbrowser.nf then fbrowser.s = fbrowser.nf elseif fbrowser.s < 1 then fbrowser.s = 1 end
if fbrowser.s > fbrowser.sp*fbrowser.ls then fbrowser.ls = fbrowser.ls + 1
elseif fbrowser.s < ((fbrowser.ls-1) * fbrowser.sp)+1 then fbrowser.ls = fbrowser.ls - 1 fbrowser.s = (fbrowser.ls)*fbrowser.sp end

if pad:cross() and not oldpad:cross() then
System.currentDirectory("ms0:/MUSIC/")
if string.lower(string.sub(fbrowser.fl[fbrowser.s].name, -4)) == (".mp3") then
screen:clear()
playing = 1
screen:blit(0,0,back)
screen:print(100,20,"Musique en cour :",red)
screen:print(100,30,fbrowser.fl[fbrowser.s].name,white)
screen:print(100,60,"Press [] pour quitter",white)
Mp3me.load(fbrowser.fl[fbrowser.s].name)
Mp3me.play()
screen.flip()
while playing == 1 do
pad = Controls.read()
if pad:square() then
Mp3me.stop()
screen:clear()
System.currentDirectory("ms0:/PSP/GAME/Play everywhere/")
dofile("./mp3.lua")
end

end

end
if fbrowser.fl[fbrowser.s].directory then
System.currentDirectory(fbrowser.fl[fbrowser.s].name)
fbrowser.s = 1
fbrowser.fl=System.listDirectory()
fbrowser.nf=table.getn(fbrowser.fl)
fbrowser.ls = 1
end

elseif pad:triangle() and not oldpad:triangle() then
if System.currentDirectory ~= "ms0:/" then
System.currentDirectory("./..")
fbrowser.s = 1
fbrowser.fl=System.listDirectory()
fbrowser.nf=table.getn(fbrowser.fl)
fbrowser.ls = 1
end
end
end


while true do
pad = Controls.read()
screen:clear()
screen:blit(0,0,back)
runfbrowser()

screen:print(5,262,"Triangle:Menu",red)



screen.waitVblankStart()
screen.flip()
oldpad = pad
	if pad:triangle() then 
	System.currentDirectory("ms0:/PSP/GAME/Play everywhere/")
    dofile("./scripts/avancer.lua")	
	end
end
