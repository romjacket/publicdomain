selecteur = 1

X = 239 Y = 137

while true do

pad = Controls.read()

if pad:l() then selecteur = selecteur - 1
System.sleep(200) --PAUSE
end 

if pad:r() then selecteur = selecteur + 1
System.sleep(200) --PAUSE
end

if selecteur < 1 then
selecteur = 4
end

if selecteur > 4 then
selecteur = 1
end

if selecteur == 1 then
screen:blit(0,0,redScreen)
creatSquare(X, Y, 5, 5, bleu)
end

if selecteur == 2 then
screen:blit(0,0,blueScreen)
creatSquare(X, Y, 5, 5, rouge)
end

if selecteur == 3 then
screen:blit(0,0,greenScreen)
creatSquare(X, Y, 5, 5, bleu)
end

if selecteur == 4 then
screen:blit(0,0,blackScreen)
creatSquare(X, Y, 5, 5, blanc)
end


if pad:analogX() > 30 or pad:analogY() < -30 then
X = X + pad:analogX()/16
end

if pad:analogY() > 30 or pad:analogY() < -30 then
Y = Y + pad:analogY()/16
end

if pad:left() then
X = X-1
end
if pad:right() then
X = X+1
end
if pad:up() then 
Y = Y-1 
end
if pad:down() then 
Y = Y+1 
end


if pad:start() then
checkpixel = 1
abX = X
abY = Y
System.sleep(200) --PAUSE
dofile("scripts/smallMode.lua")
end


if pad:select() then
firstStart = 1
dofile("repair.lua")
end

screen.waitVblankStart()
screen.flip()
end