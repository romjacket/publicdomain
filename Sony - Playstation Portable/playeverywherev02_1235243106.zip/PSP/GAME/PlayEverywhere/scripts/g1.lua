--image
image = Image.load("img/image.png")
select = Image.load("img/select.png")
note = Image.load("img/note.png")
--
System.oaenable()
--
--charger notes


do1 = Sound.load("son/g1/g1do.wav", false)
re = Sound.load("son/g1/g1re.wav", false)
mi = Sound.load("son/g1/g1mi.wav", false)
fa = Sound.load("son/g1/g1fa.wav", false)
sol = Sound.load("son/g1/g1sol.wav", false)
la = Sound.load("son/g1/g1la.wav", false)
si = Sound.load("son/g1/g1si.wav", false)
dofinal = Sound.load("son/g1/g1dofinal.wav", false)


--netoyage notes
function nettoyage1()
do1 = nil
re = nil
mi = nil
fa = nil
sol = nil
la = nil
si = nil
sofinal = nil
end

Music.volume(128)
while true do
pad=Controls.read()

screen:clear()
screen:blit(0,0,image)
screen:print(7,260,"gamme1",Color.new(0,0,0))

if pad:r() and oldpad:r() ~= pad:r() then
nettoyage1()
dofile("./scripts/g2.lua")
end
if pad:l() and oldpad:l() ~= pad:l() then
nettoyage1()
dofile("./scripts/g3.lua")
end

--do
 if pad:left() and oldpad:left() ~= pad:left() then
 screen:blit(185,209,select)
screen:blit(132,66,note)
do1:play()
end
--r�
if pad:up() and oldpad:up() ~= pad:up()  then
screen:blit(200,209,select)
screen:blit(168,63,note)
re:play()
end
--mi
if pad:right() and oldpad:right() ~= pad:right() then
screen:blit(213,209,select)
screen:blit(204,59,note)
mi:play()
end
--fa
if pad:down() and oldpad:down() ~= pad:down() then
screen:blit(228,209,select)
screen:blit(240,55,note)
fa:play()
end
--sol
if pad:square() and oldpad:square() ~= pad:square() then
screen:blit(242,209,select)
screen:blit(227,52,note)
sol:play()
end
--la
if pad:triangle() and oldpad:triangle() ~= pad:triangle() then
screen:blit(256,209,select)
screen:blit(313,49,note)
la:play()
end
--si
if pad:circle() and oldpad:circle() ~= pad:circle() then
 screen:blit(270,209,select)
screen:blit(349,45,note)
si:play()
end
--do grave
if pad:cross() and oldpad:cross() ~= pad:cross() then
screen:blit(286,209,select)
screen:blit(385,42,note)
dofinal:play()
end

if pad:start() then
System.message("Merci d'avoir jouer",0)
dofile("./scripts/menu.lua")
end

screen.flip()
screen.waitVblankStart()
oldpad = pad
end

