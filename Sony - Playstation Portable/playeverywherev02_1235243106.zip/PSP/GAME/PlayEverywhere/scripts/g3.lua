--image
image = Image.load("img/image.png")
select = Image.load("img/select.png")
note = Image.load("img/note.png")

do13 = Sound.load("son/g3/g3do.wav", false)
re3 = Sound.load("son/g3/g3re.wav", false)
mi3 = Sound.load("son/g3/g3mi.wav", false)
fa3 = Sound.load("son/g3/g3fa.wav", false)
sol3 = Sound.load("son/g3/g3sol.wav", false)
la3 = Sound.load("son/g3/g3la.wav", false)
si3 = Sound.load("son/g3/g3si.wav", false)
dofinal3 = Sound.load("son/g3/g3dofinal.wav", false)
Music.volume(128)
--netoyage notes
function nettoyage3()
do13 = nil
re3 = nil
mi3 = nil
fa3 = nil
sol3 = nil
la3 = nil
si3 = nil
sofinal3 = nil
end

while true do
pad=Controls.read()
screen:clear()
screen:blit(0,0,image)
screen:print(7,260,"gamme3",Color.new(0,0,0))

if pad:r() and oldpad:r() ~= pad:r() then
nettoyage3()
dofile("./scripts/g1.lua")
end
if pad:l() and oldpad:l() ~= pad:l() then
nettoyage3()
dofile("./scripts/g2.lua")
end

--do
 if pad:left() and oldpad:left() ~= pad:left() then
 screen:blit(185,209,select)
screen:blit(132,66,note)
do13:play()
end
--r�
if pad:up() and oldpad:up() ~= pad:up() then
screen:blit(200,209,select)
screen:blit(168,63,note)
re3:play()
end
--mi
if pad:right() and oldpad:right() ~= pad:right() then
screen:blit(213,209,select)
screen:blit(204,59,note)
mi3:play()
end
--fa
if pad:down() and oldpad:down() ~= pad:down() then
screen:blit(228,209,select)
screen:blit(240,55,note)
fa3:play()
end
--sol
if pad:square() and oldpad:square() ~= pad:square() then
screen:blit(242,209,select)
screen:blit(227,52,note)
sol3:play()
end
--la
if pad:triangle() and oldpad:triangle() ~= pad:triangle() then
screen:blit(256,209,select)
screen:blit(313,49,note)
la3:play()
end
--si
if pad:circle() and oldpad:circle() ~= pad:circle() then
 screen:blit(270,209,select)
screen:blit(349,45,note)
si3:play()
end
--do grave
if pad:cross() and oldpad:cross() ~= pad:cross() then
screen:blit(286,209,select)
screen:blit(385,42,note)
dofinal3:play()
end 

if pad:start() then
System.message("Merci d'avoir jouer",0)
dofile("./scripts/menu.lua")
end

screen.flip()
screen.waitVblankStart()
oldpad = pad
end

