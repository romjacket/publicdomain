fond1 = Image.load("images/fondo.png") --on charge les images
fond2 = Image.load("images/fondoo.png")
curseur = Image.load("images/curseur.png")
curseur2 = Image.load("images/curseur2.png")
curs = Image.load("images/curs.png")
outil = Image.load("images/outil.png")
lignedim = Image.load("images/ligne.png")
rectangledim = Image.load("images/rectangle.png")
feuille1 = Image.createEmpty(310,255) --on créé les 3 feuilles du fond
feuille2 = Image.createEmpty(310,255)
feuille3 = Image.createEmpty(310,255)
coul = Image.createEmpty(24,24)
font = Font.load("images/police.ttf")
down = Image.load("images/downbar.png")
up = Image.load("images/upbar.png")
batt = Image.load("images/batt.png")
paramimg = Image.load("images/param.png")
select = Image.load("images/select.png")
select2 = Image.load("images/select2.png")


feuille=feuille1 --on definie la feuille principale
souris = curseur2 --on defini le curseur

saveimg = Image.load("images/save.png")
openimg = Image.load("images/open.png")
img1 = Image.load("images/1.png")
img2 = Image.load("images/2.png")
img3 = Image.load("images/3.png")


dossierimg=img1 --on defini ou les images son chargées/enregistrées
doss=1
dossier="ms0:"

x=419 --on definie ou est positionné le curseur au depart
y=60

fond=fond1 --on definie le fond
couleur=Color.new(0,0,0)

--on definie certaines bouleaines
rect=1 
rec=0
crayon=1

dess=0
t=9
save=0

cd=0

point=0

ft = 20 --on definie la taille de la police

--quelques variables pour le systeme de sauvegarde
txtmsg = ""
names = ""
nameo = ""

blanc = Color.new(255,255,255)

--vittesse du curseur
vitt = 5
xcurs = vitt * 6 + 108

while true do
System.usbDiskModeActivate()

screen:clear()
screen:blit(0,0,fond)

--pad
pad = Controls.read()

--on defini les controles du curseur
if pad:up() then y=y-1 end
if pad:down() then y=y+1 end
if pad:left() then x=x-1 end
if pad:right() then x=x+1 end

if pad:analogY() < -64 then
y = y-vitt
end
if pad:analogY() > 64 then
y = y+vitt
end
if pad:analogX() < -64 then
x = x-vitt
end
if pad:analogX() > 64 then
x = x+vitt
end



--couleur
if save~=1 and open~=1 and param~=1  then
if x>=360 and y<=120 and x<480 and y>0 and pad:cross() then
couleur = fond:pixel(x,y) end
if x>=360 and y>120 and x<480 and y<159 and pad:cross() then
couleur = fond:pixel(x,y) end


--épaisseur
if crayon==1 then
if x>=360 and y>=160 and y<=180 and pad:cross() then t=1 end
if x>=360 and y>=180 and y<=198 and pad:cross() then t=3 end
if x>=360 and y>=198 and y<=217 and pad:cross() then t=5 end
if x>=360 and y>=217 and y<=235 and pad:cross() then t=9 end
if x>=360 and y>=235 and y<=254 and pad:cross() then t=13 end
if x>=360 and y>=254 and y<=272 and pad:cross() then t=19 end
end


--outil
screen:blit(0,0,outil)
coul:clear(couleur)
screen:blit(13,242,coul)
 
--on definie si un outil est selectionné
if x>=11 and x<=38 and y>=2 and y<=24 and pad:cross() then crayon=1 lt=0 ligne=0 rectangle=0 pxcopie=0 cercle=0
elseif x>=11 and x<=38 and y>=40 and y<=62 and pad:cross() then ligne=1 lt=0 crayon=0 rectangle=0 pxcopie=0 cercle=0
elseif x>=11 and x<=38 and y>=80 and y<=102 and pad:cross() then rectangle=1 lt=0 ligne=0 crayon=0 pxcopie=0 cercle=0
elseif x>=11 and x<=38 and y>=120 and y<=142 and pad:cross() then cercle=1 lt=0 ligne=0 rectangle=0 crayon=0 pxcopie=0
elseif x>=11 and x<=38 and y>=160 and y<=182 and pad:cross() then pxcopie=1 lt=0 ligne=0 rectangle=0 cercle=0 crayon=0
elseif x>=11 and x<=38 and y>=200 and y<=222 and pad:cross() then lt=1 crayon=0 ligne=0 rectangle=0 pxcopie=0 cercle=0 end

--on affiche un carré autour de l'outil utilisé 
if crayon==1 then ysel=0 end
if ligne==1 then ysel=38 end
if rectangle==1 then ysel=78 end
if cercle==1 then ysel=117 end
if pxcopie==1 then ysel=158 end
if lt==1 then ysel=199 end

screen:blit(10,ysel,select)

end

--calque
--on affiche les feuilles
screen:blit(50,255,down)
if x>=55 and x<=100 and y>=257 and pad:cross() then 
feuille=feuille1
 end
if x>=101 and x<=146 and y>=257 and pad:cross() then 
feuille=feuille2 
end
if x>=147 and x<=192 and y>=257 and pad:cross() then 
feuille=feuille3 end

if feuille==feuille1 then xsel=55 end
if feuille==feuille2  then xsel=101 end
if feuille==feuille3 then xsel=147 end


screen:blit(xsel,257,select2)

--param
--on definie les parametres n1

--on definie l'aspect de la feuille
if param==1 then
if x>= 243 and x<= 306 and y>= 196 and y<= 259 and pad:cross()then
if feuille == feuille1 then
feuille1=Image.load("images/cadrie.png")
feuille=feuille1
end
if feuille == feuille2 then
feuille2=Image.load("images/cadrie.png")
feuille=feuille2
end
if feuille == feuille3 then
feuille3=Image.load("images/cadrie.png")
feuille=feuille3
end
end


if x>= 162 and x<= 225 and y>= 196 and y<= 259 and pad:cross()then
if feuille == feuille1 then
feuille1=Image.createEmpty(310,255)
feuille1:clear(blanc)
feuille=feuille1
end
if feuille == feuille2 then
feuille2=Image.createEmpty(310,255)
feuille2:clear(blanc)
feuille=feuille2
end
if feuille == feuille3 then
feuille3=Image.createEmpty(310,255)
feuille3:clear(blanc)
feuille=feuille3
end
end

if x>= 80 and x<= 145 and y>= 196 and y<= 259 and pad:cross()then
if feuille == feuille1 then
feuille1=Image.createEmpty(310,255)
feuille1:clear()
feuille=feuille1
end
if feuille == feuille2 then
feuille2=Image.createEmpty(310,255)
feuille2:clear()
feuille=feuille2
end
if feuille == feuille3 then
feuille3=Image.createEmpty(310,255)
feuille3:clear()
feuille=feuille3
end
end
end

--ligne
--fonction pour tracer une ligne
if ligne == 1 then

screen:blit(360,160,lignedim)

fond=fond1

if point==0 and x>50 and x<360 and y<255 and pad:cross() and not oldpad:cross() then 
px1=x-50
py1=y
point=1
end
if point==1 and x>50 and x<360 and y<255 and pad:circle() and not oldpad:circle() then 
px2=x-50
py2=y
feuille:drawLine(px1, py1, px2, py2, couleur)
point=0
end
end



--rectangle
--fonction pour tracer un rectangle
if rectangle == 1  then
fond=fond1
screen:blit(360,160,lignedim)


if x>=390 and x<=410 and y>=190 and y<=200 and pad:cross() then rect=1 end
if x>=430 and x<=449 and y>=190 and y<=200 and pad:cross() then rect=2 end

function drawRectangle(x,y,longueur,largeur)
for j=x,x+largeur do
feuille:pixel(j, y, couleur)
end

for p=x,x+largeur do
feuille:pixel(p, y+longueur, couleur)
end

for n=y,y+longueur do
feuille:pixel(x,n, couleur)
end

for q=y,y+longueur do
feuille:pixel(x+largeur,q, couleur)
end end

if rect==1 then
if rec==0 then
if x>50 and x<360 and y>=15 and y<255 and pad:cross() then rec=1 end
end
if rec==1 then
pr1=x
pr2=y
rec=2
end
if rec==2 then
if x>50 and x<360 and y>=15 and y<255 and pad:circle() then
largeur=x-pr1
longueur=y-pr2
if largeur>0 and longueur>0 then 
feuille:fillRect(pr1-50,pr2,largeur,longueur,couleur)end
if largeur>0 and longueur<0 then
feuille:fillRect(pr1-50,pr2+longueur,largeur,longueur*-1,couleur)end
if largeur<0 and longueur>0 then 
feuille:fillRect(pr1-50+largeur,pr2,largeur*-1,longueur,couleur)end
if largeur<0 and longueur<0 then 
feuille:fillRect(pr1-50+largeur,pr2+longueur,largeur*-1,longueur*-1,couleur)end
rec=0
end
end
end

end


--cercle
--fonction pour tracer un cercle
function drawCircle(x, y, rayon, color)
pi = math.pi
step = 2/(rayon*rayon*0.5)
for i=0,2, step do
a = x+rayon*math.cos(pi*i)
c = y+rayon*math.sin(pi*i)
if a>=0 and a<360 and c>=0 and c<272 then
feuille:pixel(a, c, couleur)
end
end
end

if cercle==1 then
fond=fond1
screen:blit(360,160,lignedim)
if cd==0 and pad:cross() then cd=1 end
if cd==1 then
if x>=50 and x<360 and y<255 and y>14 and pad:cross() and not oldpad:cross() then
p1=x-50
p2=y
cd=2
end
end


if cd==2
then
if x>=50 and x<360 and pad:circle() and not oldpad:circle() then

rayon=((x-50-p1)*(x-50-p1)+(y-p2)*(y-p2))^(1/2)

if p1+rayon<360 and p1-rayon>0 and p2+rayon<255 and p2-rayon>15 then
drawCircle(p1, p2, rayon, couleur)
cd=0
else cd=0

end
end
end
end

--pxcopie
--fonction pour la pipette
if pxcopie==1 then
 if x>50 and x<360 and y>20 and y<252 and pad:cross() then
couleur = feuille:pixel(x-50,y) end
if x>360 and x<480 and y>1 and y<272 and pad:cross() then
couleur = fond:pixel(x,y) end
fond=fond2
end


--lettre
--fonction pour ecrire du texte
if lt==1 then

fond=fond2

if x>360 and x<480 and y>1 and pad:cross() then
couleur = fond:pixel(x,y) end

font:setPixelSizes(ft,ft)

if x<=360 and x>=50 and y<=255 and y>=20 and pad:cross() and not oldpad:cross() then
txtmsg = System.startOSK("","")
feuille:fontPrint(font,x-50,y,txtmsg,couleur) 
end
end

--dessin (crayon)
--fonction pour dessiner au crayon
dessin=Image.createEmpty(t,t)
dessin:clear(couleur)

screen:blit(50,0,feuille)
if crayon==1 then
fond=fond1
if x<=360 and x>=50 and y<255 and pad:cross() then
feuille:blit(x-50+1-t/2,y+1-t/2,dessin)
end
end

--upbar
--affiche la barre du haut
if System.powerGetBatteryLifePercent()==0 then g=1 end
if System.powerGetBatteryLifePercent()>0 then g=5 end
if System.powerGetBatteryLifePercent()>=10 then g=10 end
if System.powerGetBatteryLifePercent()>=20 then g=15 end
if System.powerGetBatteryLifePercent()>=30 then g=20 end
if System.powerGetBatteryLifePercent()>=40 then g=25 end
if System.powerGetBatteryLifePercent()>=50 then g=30 end
if System.powerGetBatteryLifePercent()>=60 then g=35 end
if System.powerGetBatteryLifePercent()>=70 then g=40 end
if System.powerGetBatteryLifePercent()>=80 then g=45 end
if System.powerGetBatteryLifePercent()>=90 then g=50 end

powerbar = Image.createEmpty(g,8)
powerbar:clear(couleur)

screen:blit(50,0,up)
screen:blit(190,3,powerbar)
screen:blit(189,2,batt)
screen:print(150,5,System.powerGetBatteryLifePercent().."%")
math.floor(x)
math.floor(y)
screen:print(60,5,"x"..x)
screen:print(100,5,"y"..y)

if save~=1 and open~=1 and param~=1  then
if x>=320 and x<=350 and y<13 and pad:cross() then 
System.message("Merci d'avoir jouer",0)
dofile("./scripts/menu.lua")() end
end



--new
--créé une nouvelle image
if x>=210 and x<=250 and y>=257 and pad:cross() then feuille:clear() end

--parametre
--on definie les parametres n2
if x>=250 and x<=309 and y<=12 and pad:cross() then param = 1 end

if param==1 then
crayon=0 lt=0 ligne=0 rectangle=0 pxcopie=0 cercle=0 upbar=0
screen:blit(0,0,paramimg)

--aspect du curseur
if x >=324 and x<=383 and y>=16 and y<=75 and pad:cross() then souris = curseur end
if x >=405 and x<=464 and y>=16 and y<=75 and pad:cross() then souris = curseur2 end

--vitesse du curseur
if x>=108 and x<=192 and y>=40 and y<=50 and pad:cross() then 
vitt = math.floor((x- 108) / 6)  
xcurs = vitt * 6 + 108
end
screen:blit(xcurs-5,40,curs)

if x>=361 and x<=440 and y>=218 and y<=238 and pad:cross() then
param=0
end

end



--save
--fonction de sauvegarde
if x>=310 and x<=350 and y>=257 and pad:cross() then 
save=1
end

if save==1 then
crayon=0 lt=0 ligne=0 rectangle=0 pxcopie=0 cercle=0 upbar=0
screen:blit(0,0,saveimg)
screen:blit(135,98,dossierimg)
if x>=135 and x<=369 and y>=50+48 and y<=50+69 and pad:cross() and not oldpad:cross() then doss=doss+1 end
if doss>4 then doss=1 end

if doss==1 then 
dossierimg=img1
dossier="ms0:/"
elseif doss==2 then 
dossierimg=img2
dossier="ms0:/PSP/"
elseif doss==3 then 
dossierimg=img3 
dossier="ms0:/PICTURE/"
elseif doss==4 then 
doss=1
end

if x>=135 and x<=377 and y>=66 and y<=84 and pad:cross() and not oldpad:cross() then names = System.startOSK("","") end

screen:print(140,74,names)

if x>=400 and x<=460 and y>=184 and y<=202 and pad:cross() then
feuille:save(dossier..names..".png") 
save=0
end
if x>=330 and x<=390 and y>=184 and y<=202 and pad:cross() then
save=0
end

end

--open
--fonction de chargement (d'image)
if x>=260 and x<=300 and y>=257 and pad:cross() then 
open=1
end

if open==1 then
crayon=0 lt=0 ligne=0 rectangle=0 pxcopie=0 cercle=0 upbar=0
screen:blit(0,0,openimg)
screen:blit(135,98,dossierimg)
if x>=135 and x<=369 and y>=50+48 and y<=50+69 and pad:cross() and not oldpad:cross() then doss=doss+1 end
if doss>4 then doss=1 end

if doss==1 then 
dossierimg=img1
dossier="ms0:/"
elseif doss==2 then 
dossierimg=img2
dossier="ms0:/PSP/"
elseif doss==3 then 
dossierimg=img3 
dossier="ms0:/PICTURE/"
elseif doss==4 then 
doss=1
end

if x>=135 and x<=377 and y>=66 and y<=84 and pad:cross() and not oldpad:cross() then nameo = System.startOSK("","") end

screen:print(140,74,nameo)

if x>=400 and x<=460 and y>=184 and y<=202 and pad:cross() then
feuille=Image.load(dossier..nameo..".png") 
open=0
end
if x>=330 and x<=390 and y>=184 and y<=202 and pad:cross() then
open=0
end

end


--reste
--colision du curseur sur les bords
if x>=480 then x=480 end
if x<=0 then x=0 end
if y>=272 then y=272 end
if y<=0 then y=0 end

screen:blit(x-7,y-7,souris)

screen.waitVblankStart() 
screen.flip() 
oldpad = pad
end

