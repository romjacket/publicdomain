background = Image.load("credit.png")
battery1 = Image.load("battery1.png")
battery2 = Image.load("battery2.png")
battery3 = Image.load("battery3.png")
battery4 = Image.load("battery4.png")
hour=System.getTime(1)
hour2=System.getTime(2)
font = Font.createProportional()
font:setPixelSizes(0,16)

function printCenteredfont(y,text,color) 
local length = string.len(text) 
local x = 30 - ((length*8)/2) 
screen:fontPrint(font,x,y,text,color) 
end 

function printCenteredfont2(y,text,color) 
local length = string.len(text) 
local x = 85 - ((length*8)/2) 
screen:fontPrint(font,x,y,text,color) 
end 

while true do
screen:clear()
screen:blit(0,0,background)
pad = Controls.read()
printCenteredfont(20, "Heure:"..hour, Color.new(255,255,255))
printCenteredfont2(20, "H"..hour2, Color.new(255,255,255))
if pad:cross() then
System.message("Merci d'avoir prit le temps de lire cette partie",0)
dofile("./scripts/menu.lua")
end
  if System.powerGetBatteryLifePercent() >= 0 then batteryL = battery1 end
  if System.powerGetBatteryLifePercent() > 25 then batteryL = battery2 end
  if System.powerGetBatteryLifePercent() > 50 then batteryL = battery3 end
  if System.powerGetBatteryLifePercent() > 75 then batteryL = battery4 end
 
screen:blit(420,3,batteryL)
screen.waitVblankStart()
screen.flip()
end