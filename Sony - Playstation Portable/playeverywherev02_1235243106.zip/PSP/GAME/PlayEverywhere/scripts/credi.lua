background =Image.load("credits.png")

while true do
screen:clear()
screen:blit(0,0,background)
pad = Controls.read()
if pad:select() then
dofile("./scripts/menu.lua")
end
screen.flip()
end
