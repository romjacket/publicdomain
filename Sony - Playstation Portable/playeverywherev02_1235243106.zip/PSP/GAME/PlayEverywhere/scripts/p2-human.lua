function player2()
	if pad:cross() then
		yp2=yp2+5
		if t==1 and side=="left" then
			alea=math.random(2)
			acc=acc+2+alea/10
		end
	end
	if pad:triangle() or pad:r() then
		yp2=yp2-5
		if t==1 and side=="left" then
			alea=math.random(2)
			acc=acc-2-alea/10
		end
	end
end
