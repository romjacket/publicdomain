background = Image.load("jeux.png")
battery1 = Image.load("battery1.png")
battery2 = Image.load("battery2.png")
battery3 = Image.load("battery3.png")
battery4 = Image.load("battery4.png")
battery5 = Image.load("battery5.png")
battery6 = Image.load("battery6.png")
battery7 = Image.load("battery7.png")
battery8 = Image.load("battery8.png")
hour=System.getTime(1)
hour2=System.getTime(2)
font = Font.createProportional()
font:setPixelSizes(0,16)

function printCenteredfont(y,text,color) 
local length = string.len(text) 
local x = 370 - ((length*8)/2) 
screen:fontPrint(font,x,y,text,color) 
end 
function printCenteredfont2(y,text,color) 
local length = string.len(text) 
local x = 395 - ((length*8)/2) 
screen:fontPrint(font,x,y,text,color) 
end 

while true do
screen:clear()
screen:blit(0,0,background)
pad = Controls.read()
printCenteredfont(17, " "..hour, Color.new(255,255,255))
printCenteredfont2(17, "H"..hour2, Color.new(255,255,255))
if pad:select() then
dofile("./scripts/menu.lua")
end
if pad:start() then
dofile("./scripts/PSpaint.lua")
end
if pad:square() then
dofile("./scripts/g1.lua")
end
if pad:cross() then
dofile("./scripts/pong.lua")
end
if pad:triangle() then
dofile("./scripts/love.lua")
end
if pad:circle() then
dofile("./scripts/superman.lua")
end
if pad:down() then
dofile("./repair.lua")
end
if pad:right() then
System.runeboot("ms0:/PSP/GAME/Play Everywhere/Powernoid/EBOOT.PBP")
end
if pad:up() then
System.runeboot("ms0:/PSP/GAME/Play Everywhere/pspgba/EBOOT.PBP")
	end
  if System.powerGetBatteryLifePercent() >= 0 then batteryL = battery1 end
  if System.powerGetBatteryLifePercent() > 15 then batteryL = battery2 end
  if System.powerGetBatteryLifePercent() > 30 then batteryL = battery3 end
  if System.powerGetBatteryLifePercent() > 45 then batteryL = battery4 end
  if System.powerGetBatteryLifePercent() > 60 then batteryL = battery5 end
  if System.powerGetBatteryLifePercent() > 75 then batteryL = battery6 end
  if System.powerGetBatteryLifePercent() > 90 then batteryL = battery7 end
  if System.powerGetBatteryLifePercent() >= 100 then batteryL = battery8 end
 
screen:blit(420,3,batteryL)
screen.waitVblankStart()
screen.flip()
end