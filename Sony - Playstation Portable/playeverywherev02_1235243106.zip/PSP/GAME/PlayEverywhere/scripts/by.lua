ByLoad()

for i = 1, size do
   createStar(i)
   starfield[i].z = math.random(zMax)
end


while true do
   screen:clear()
   
   screen:blit(0,0,first)
   
   for i = 1, size do
      starfield[i].z = starfield[i].z - speed
      if starfield[i].z < speed then createStar(i) end
      x = width / 2 + starfield[i].x / starfield[i].z
      y = height / 2 + starfield[i].y / starfield[i].z
      if x < 0 or y < 0 or x >= width or y >= height then
         createStar(i)
      else
         screen:pixel(x, y, blanc)
      end
   end
         t1 = t1-speedTxt
		 t2 = t2-speedTxt
		 t3 = t3-speedTxt
		 t4 = t4-speedTxt
		 t5 = t5-speedTxt
		 t6 = t6-speedTxt
		 t7 = t7-speedTxt
		 t8 = t8-speedTxt
		 t9 = t9-speedTxt
		 t10 = t10-speedTxt
		 t11 = t11-speedTxt		 


Textecentre(t1,TextBy[1],blanc)
Textecentre(t2,TextBy[2],blanc)
Textecentre(t3,TextBy[3],blanc)
Textecentre(t4,TextBy[4],blanc)
Textecentre(t5,TextBy[5],blanc)
Textecentre(t6,TextBy[6],blanc)
Textecentre(t7,TextBy[7],blanc)
Textecentre(t8,TextBy[8],blanc)
Textecentre(t9,TextBy[9],blanc)
Textecentre(t10,TextBy[10],blanc)
Textecentre(t11,TextBy[11],blanc)
   
   screen:print(10,262,"O : Menu Principal",blanc)
   screen.waitVblankStart()
   screen.flip()
   
   if t11 <= -5 then
   firstStart = 1
   dofile("repair.lua")
   end

   if Controls.read():circle() then
   firstStart = 1
   dofile("repair.lua")
end
end
