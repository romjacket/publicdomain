background =Image.load("avancer.png")
black = Color.new(0,0,0)


while true do
screen:clear()
pad = Controls.read()
screen:blit(0,0,background)
screen.flip()
if pad:select() then
System.suspend()
end
if pad:start() then                                
System.suspend()
end
if pad:circle() then
dofile("./script.lua")
end
if pad:square() then
dofile("./scripts/msbrowser.lua")
end
if pad:triangle() then
dofile("mp3.lua")
file:close()
end
end
