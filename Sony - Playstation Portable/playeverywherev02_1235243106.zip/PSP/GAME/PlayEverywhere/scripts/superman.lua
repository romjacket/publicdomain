--pause
white=Color.new(255,255,255)
num_menu=1
menu_=Image.load("images/menu-"..num_menu..".png")
function pause()
oldpad = Controls.read()
while true do
	screen:blit(0,0,menu_)
    
   
  pad = Controls.read()
if pad:down() and not oldpad:down() and num_menu <3 then 
   num_menu=num_menu+1
   menu_=Image.load("images/menu-"..num_menu..".png")  
   end
if pad:up() and not oldpad:up() and num_menu >1 then 
   num_menu=num_menu-1
   menu_=Image.load("images/menu-"..num_menu..".png")  
   end

if num_menu==3 and  pad:cross() then
System.message("Merci d'avoir jouer",0)
   dofile("./scripts/menu.lua")
   end
if num_menu==2 and pad:cross() then
System.message("Merci d'avoir jouer",0)
   dofile("./scripts/jeux.lua")
   end
if num_menu==1 and pad:cross() then
screen:print(100,100,"pas encore disponible")
end
if  pad:circle() then
frommenu=false
break
end
screen.waitVblankStart()
screen:flip()
oldpad = pad
end
end
--couleurs
 vert = Color.new(0,255,0)
  rouge = Color.new(255,0,0)
  bleu = Color.new(0,0,255)
--statut
statut=right
--texte
  
 start = "Code et images par leo" 
fini = "bien jou�!"
 text1= "??? Un mur invisible!"
--fonds
num_fond=1
num_decord=1
num_barre=3
num_other=1
-- images
    fond = Image.load("images/fond"..num_fond..".png")
  perso = Image.load("images/superman-right.png")
 decord = Image.load("images/decord"..num_decord..".png")
  barre = Image.load("images/barre"..num_barre..".png")
   other = Image.load("images/other"..num_other..".png")
    mort = Image.load("images/mort.png")
	fleche= Image.load("images/fleche.png")
--autres variables
vie=3
 x = 4
 y = 170
--animation 
 flecheX=100
 flecheY=100
 compteurfleche=1
 anime_phase = true
--boucle principale
while true do
 screen:clear()
  screen:blit(0,0,fond)
  screen:blit(0,0,decord)
screen:blit(x,y,perso)
 screen:blit(3,233,barre)
screen:blit(0,0,other)

 pad = Controls.read()
 --collisions
 couleurpied = fond:pixel(x+17,y+50)
 if couleurpied ~= vert and pad:cross() == false and y<220 then y = y + 2 end
 couleurdroite1 = fond:pixel(x+25,y+16)
 couleurdroite2 = fond:pixel(x+25,y+21)
 couleurgauche1 = fond:pixel(x,y+16)
 couleurgauche1 = fond:pixel(x,y+21)
 couleurhaut = fond:pixel(x+17,y+13) 
 couleurcentre = fond:pixel(x+13,y+25)
--deplacements
 if pad:left() and x > 0 and couleurgauche1~=vert and couleurgauche2~=vert then 
   statut = "left"
 x = x - 2 end

if pad:right() and x < 455 and couleurdroite1 ~=vert and couleurdroite2 ~=vert then 
statut = "right"
x =  x + 2 end
if pad:cross() and y > 0 and couleurhaut ~= vert then 
statut = "up"
y = y - 2 end
if pad:select() then
screen:print(10,80,start,rouge)
end
if pad:start()then
pause()
end

--niveaux horizontaux
if x>=452 and num_decord<2 and num_fond<2 then--a modifier lors de ajout de niveaux
 x = 4
   num_fond=num_fond+1
   num_decord=num_decord+1
   num_other=num_other+1
  fond = Image.load("images/fond"..num_fond..".png")
decord = Image.load("images/decord"..num_decord..".png")
other = Image.load("images/other"..num_other..".png")
end
--niveau verticaux
if num_decord == 2 and y==0 then
y=205
num_fond=num_fond+1
num_decord=num_decord+1
num_other=num_other+1
fond=Image.load("images/fond"..num_fond..".png")
decord=Image.load("images/decord"..num_decord..".png")
other = Image.load("images/other"..num_other..".png")
end

--vie
if couleurcentre == bleu and vie >= 0 and num_barre >0 then
vie=vie - 1
num_barre=num_barre - 1
barre = Image.load("images/barre"..num_barre..".png")
end
if vie == 0 then
screen:blit(0,0,mort)
end
if couleurcentre == bleu and num_fond<=2 then
x=4
y=190
end
if couleurcentre == bleu and num_fond==3 then
x=420
y=219
end

 
--fonction particulieres
if num_fond == 2 and x>= 430 then
screen:print (260,250,text1,rouge)
end
--fin
if num_fond==3 then
screen:blit(0,0,fleche)
end
if num_fond==3 and couleurcentre == rouge then
screen:print(150,100,fini,rouge)
end



screen.flip()
screen.waitVblankStart()
end
