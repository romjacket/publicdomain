--Text-->>

TextBy = {}
TextBy[1] = "GeekRepair Pixel"
TextBy[2] = "By Team Geek Inside"
TextBy[3] = "********************"
TextBy[4] = "Remerciements:"
TextBy[5] = "Geekeur"
TextBy[6] = "Devsgen "
TextBy[7] = "Pspgen "
TextBy[8] = "Mais aussi Xtreamlua"
TextBy[9] = "Pour leur tutoriaux parfaits"
TextBy[10] = "Team Geek Inside vous remercie"
TextBy[11] = "De votre soutient "



--function center text-->>
function Textecentre(y,string,color)
screen:print( 240 - (string.len(string)*8) / 2 ,y,string,color);
end


--Function fader (--/++)-->>
function fadeScreen(mode, picture, speed)

if mode == "Diminution" then
fader = Image.createEmpty(480,272)
alphaValue = 0
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)

while true do
screen:clear()
screen:blit(0,0,picture)
screen:blit(0,0,fader)
if alphaValue < 255 then
alphaValue = alphaValue + speed
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
end

if mode == "Augmentation" then
fader = Image.createEmpty(480,272)
alphaValue = 255
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)

while true do
screen:clear()
screen:blit(0,0,picture)
screen:blit(0,0,fader)
if alphaValue > 0 then
alphaValue = alphaValue - speed
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
end
end


function loadPic()
menu1 = Image.load ("images/menu1.png")
menu2 = Image.load ("images/menu2.png")
menu3 = Image.load ("images/menu3.png")
menu4 = Image.load ("images/menu4.png")
menu5 = Image.load ("images/menu5.png")

pixelRed = Image.load("images/red.png")
pixelBlue = Image.load("images/blue.png")
pixelGreen = Image.load("images/green.png")
pixelWhite = Image.load ("images/white.png")

redScreen = Image.load ("images/redScreen.png")
blueScreen = Image.load ("images/blueScreen.png")
greenScreen = Image.load ("images/greenScreen.png")
blackScreen = Image.load ("images/blackScreen.png")
end


function loadColor()
rouge = Color.new(255,0,0)
vert = Color.new(0,255,33)
bleu = Color.new(0,38,255)
blanc = Color.new(255,255,255)
end



function PAUSE()
EXIT = 0

System.sleep(200) --PAUSE

while EXIT ~= 1 do
if Controls.read():start() then
EXIT = 1
end
end
System.sleep(200) --PAUSE
end


function ByLoad()
size = 200
zMax = 5
speed = 0.1
speedTxt = 0.9

width = 480
height = 272

starfield = {}
math.randomseed(os.time())

function createStar(i)
   starfield[i] = {}
   starfield[i].x = math.random(2*width) - width
   starfield[i].y = math.random(2*height) - height
   starfield[i].z = zMax
end

t1 = 270
t2 = 300
t3 = 340
t4 = 380
t5 = 400
t6 = 420
t7 = 440
t8 = 460
t9 = 480
t10 = 500
t11 = 520
end

function creatSquare(startX, startY, length, width, color)
Image:drawLine(startX, startY, startX, startY+width, color) --verticale gauche (d�but)
Image:drawLine(startX+length, startY, startX+length, startY+width, color) --verticale droite (fin)
Image:drawLine(startX, startY, startX+length, startY, color) --horizotale haut
Image:drawLine(startX, startY+width, startX+length, startY+width, color) --horizotale bas
end
