timer = Timer.new()
timer:start()
  
while true do
screen:clear()
pad = Controls.read()

--Pause mode-->>
if Controls.read():start() then
PAUSE()
end
 
if timer:time() > 0 then
screen:clear(rouge)
end
 
if timer:time() > 30 then
screen:clear(bleu)
end

if timer:time() > 60 then
screen:clear(vert)
end
 
if timer:time() > 90 then
timer:stop()
timer:reset(0)
timer:start()
end

if pad:select() then
timer:stop()
firstStart = 1
dofile("repair.lua")
end

screen.waitVblankStart()
screen.flip()
end