title_game="..:: Team Geek Inside ::.."
blanc=Color.new(220,220,220)
gris=Color.new(130,130,130)
bleu=Color.new(25,25,160)

textes={}
textes={"1 Player","2 Players","Quitter"}
selection=1
function menu(n)
	pad=Controls.read()
	if n-1>0 then
		screen:print(100,85,textes[n-1],gris)
	end
	screen:print(100,100,textes[n],blanc)
	if pad:cross() then
		if n==1 then
			screen.waitVblankStart(0)
			title=nil
			bleu=nil
			dofile("./scripts/variables.lua")
			dofile("./scripts/p2-IA.lua")
			dofile("./scripts/game.lua")
		elseif n==2 then
			title=nil
			bleu=nil
			screen.waitVblankStart(0)
			dofile("./scripts/variables.lua")
			dofile("./scripts/p2-human.lua")
			dofile("./scripts/game.lua")			
		elseif n==3 then
			System.Quit()
		end
	end
	if n+1<4 then
		screen:print(100,115,textes[n+1],gris)
	end
end

while true do
	screen:clear()
	pad=Controls.read()
	screen:print(140,35,title_game,blanc)
	screen:print(141,35,title_game,blanc)
	screen:fillRect(0,93,480,18,bleu)
	screen:fillRect(20,60,440,1,gris)
	
	if pad:down() and selection<8 or pad:right() and selection<8 then
		selection=selection+5
	end
	if pad:up() and selection>1 or pad:left() and selection>1 then
		selection=selection-5
	end
	
	screen:print(357,260,"Play Everywhere",gris)
	menu(selection)
	screen.waitVblankStart(4)
	screen:flip()
end
