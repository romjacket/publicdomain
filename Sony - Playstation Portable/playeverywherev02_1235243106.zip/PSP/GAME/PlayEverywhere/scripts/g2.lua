--image
image = Image.load("img/image.png")
select = Image.load("img/select.png")
note = Image.load("img/note.png")

do12 = Sound.load("son/g2/g2do.wav", false)
re2 = Sound.load("son/g2/g2re.wav", false)
mi2 = Sound.load("son/g2/g2mi.wav", false)
fa2 = Sound.load("son/g2/g2fa.wav", false)
sol2 = Sound.load("son/g2/g2sol.wav", false)
la2 = Sound.load("son/g2/g2la.wav", false)
si2 = Sound.load("son/g2/g2si.wav", false)
dofinal2 = Sound.load("son/g2/g2dofinal.wav", false)


--netoyage notes
function nettoyage2()
do12 = nil
re2 = nil
mi2 = nil
fa2 = nil
sol2 = nil
la2 = nil
si2 = nil
sofinal2 = nil
end
Music.volume(128)
while true do
pad=Controls.read()
screen:clear()
screen:blit(0,0,image)
screen:print(7,260,"gamme2",Color.new(0,0,0))

if pad:r() and oldpad:r() ~= pad:r() then
nettoyage2()
dofile("./scripts/g3.lua")
end
if pad:l() and oldpad:l() ~= pad:l() then
nettoyage2()
dofile("./scripts/g1.lua")
end

--do
 if pad:left() and oldpad:left() ~= pad:left() then
 screen:blit(185,209,select)
screen:blit(132,66,note)
do12:play()
end
--r�
if pad:up() and oldpad:up() ~= pad:up() then
screen:blit(200,209,select)
screen:blit(168,63,note)
re2:play()
end
--mi
if pad:right() and oldpad:right() ~= pad:right() then
screen:blit(213,209,select)
screen:blit(204,59,note)
mi2:play()
end
--fa
if pad:down() and oldpad:down() ~= pad:down() then
screen:blit(228,209,select)
screen:blit(240,55,note)
fa2:play()
end
--sol
if pad:square() and oldpad:square() ~= pad:square() then
screen:blit(242,209,select)
screen:blit(227,52,note)
sol2:play()
end
--la
if pad:triangle() and oldpad:triangle() ~= pad:triangle() then
screen:blit(256,209,select)
screen:blit(313,49,note)
la2:play()
end
--si
if pad:circle() and oldpad:circle() ~= pad:circle() then
 screen:blit(270,209,select)
screen:blit(349,45,note)
si2:play()
end
--do grave
if pad:cross() and oldpad:cross() ~= pad:cross() then
screen:blit(286,209,select)
screen:blit(385,42,note)
dofinal2:play()
end 

if pad:start() then
System.message("Merci d'avoir jouer",0)
dofile("./scripts/menu.lua")
end

screen.flip()
screen.waitVblankStart()
oldpad = pad
end

