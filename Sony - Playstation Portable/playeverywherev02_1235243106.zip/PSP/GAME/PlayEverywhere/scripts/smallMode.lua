if checkpixel ~= 1 then
X = 239 Y = 137
end

timer = Timer.new()
timer:start()

while true do
screen:clear()
pad = Controls.read()

if pad:analogX() > 30 or pad:analogY() < -30 then
X = X + pad:analogX()/16
end

if pad:analogY() > 30 or pad:analogY() < -30 then
Y = Y + pad:analogY()/16
end

if pad:left() then
X = X-1
end
if pad:right() then
X = X+1
end
if pad:up() then 
Y = Y-1 
end
if pad:down() then 
Y = Y+1 
end

--Pause mode-->>
if Controls.read():start() then
PAUSE()
end


if timer:time() > 0 then
screen:blit (X, Y, pixelRed)
end
 
if timer:time() > 40 then
screen:blit(X, Y, pixelBlue)
end

if timer:time() > 80 then
screen:blit(X, Y, pixelGreen)
end

if timer:time() > 120 then
screen:blit(X, Y, pixelWhite)
end
 
if timer:time() > 160 then
timer:stop()
timer:reset(0)
timer:start()
end


if pad:select() then
timer:stop()
firstStart = 1
dofile("repair.lua")
end

screen.waitVblankStart()
screen.flip()
end
