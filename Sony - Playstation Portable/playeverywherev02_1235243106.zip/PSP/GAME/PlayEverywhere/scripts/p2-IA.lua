function player2()
		if yp2>(yb-35) and xb>120 then
			yp2=yp2-10
			if t==1 then
				acc=acc-5
			end
		end
		if yp2<(yb-35) and xb>120 then
			yp2=yp2+10
			if t==1 then
				acc=acc+5
			end
		end
end
