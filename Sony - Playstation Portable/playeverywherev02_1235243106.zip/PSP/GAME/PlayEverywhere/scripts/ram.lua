collectgarbage()
System.memclean()
