if firstStart ~= 1 then
first = Image.load ("images/1.png")

dofile("scripts/fonctions.lua")

fadeScreen("Augmentation", first, 12) 		--AlphaValue++ first screen

loadPic()

loadColor()

System.sleep(1000) --PAUSE
fadeScreen("Diminution", first, 12) 		--AlphaValue-- first screen
end

selecteur = 1
 
while true do
screen:clear()

pad = Controls.read()

if pad:up() then selecteur = selecteur - 1
System.sleep(200) --PAUSE
end 

if pad:down() then selecteur = selecteur + 1
System.sleep(200) --PAUSE
end

if selecteur < 1 then
selecteur = 5
end

if selecteur > 5 then
selecteur = 1
end

if selecteur == 1 then
screen:blit(0,0,menu1)

if pad:cross() then
dofile("scripts/fullMode.lua")
end
end


if selecteur == 2 then
screen:blit(0,0,menu2)

if pad:cross() then
dofile("scripts/smallMode.lua")
end
end


if selecteur == 3 then
screen:blit(0,0,menu3)

if pad:cross() then
dofile("scripts/checkPixels.lua")
end
end


if selecteur == 4 then
screen:blit(0,0,menu4)

if pad:cross() then
dofile("scripts/by.lua")
end
end


if selecteur == 5 then
screen:blit(0,0,menu5)

if pad:cross() then
dofile("./scripts/jeux.lua")
end
end

screen.waitVblankStart()
screen.flip()
end
