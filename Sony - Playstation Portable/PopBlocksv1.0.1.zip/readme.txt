## PopBlocks v1.0.1,
## by Gefa
## www.gefa.altervista.org
## to contact me: gefasio@gmail.com

What is it?
===========
This is a clone of the flash puzzle game Pushori

Installation
============
Copy 'python' directory in the root of your memory stick, and
the directory PopBlocks in the path ms0:/PSP/GAME. This homebrew works
on a PSP with Custom Firmware by D_A

Goal
====
See HowToPlay pdf file.