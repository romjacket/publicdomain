X-Moto-PSP
http://royale.zerezo.com/psp/

Install:
	* Copy the X-Moto-PSP folder to your GAME3xx/4xx/5xx folder.

Controls:
	* up/cross: throttle
	* down/square: brake
	* left/left trigger: left flip
	* right/right trigger: right flip
	* circle: change direction
	* triangle: zoom out
	* select: enable fps and ugly mode
	* start: restart level
