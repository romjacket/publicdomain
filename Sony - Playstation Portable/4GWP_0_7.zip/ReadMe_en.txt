  __    __   _______    _____   _______    _______    _____     __    __
 / /\  / /\ /__  __/\  / ___/\ /__  __/\  / ___  /\  / ___ \   / /\  / /\
/ / / / / / \_/ /\_\/ / /\__\/ \_/ /\_\/ / /\_/ / / / /\_/ /\ / /_/_/ / /
\ \/_/ / / __/ /_/   / /_/_     / / /   / /_// / / / /_  _/ / \__  __/ /
 \____/ / /______/\ /_____/\   /_/ /   /______/ / /_/\_\_\\/   \/_/\_\/
  \___\/  \______\/ \_____\/   \_\/    \______\/  \_\/  \_\     \_\/
______________________________________________________________________________
                                                                Victory Studio
                                                             ftpiano@gmail.com
Geometry Wars Portable v0.7 Evaluation Release

-----------
-= About =-
-----------

  This program is a duplication of the casual game 'Geometry Wars: Retro
  Evolved' on XBOX360/PC.

  Currently have no idea on firmware compatibilities :(, only tested on Custom
  Firmware 3.71 M33. Please let me know if it runs on your PSP with other
  firmwares.

-------------
-= Install =-
-------------

  Copy the 'GWP' folder to the '/PSP/GAME/' directory on your memory stick.

--------------
-= Controls =-
--------------

            Directions: Menu Navigation
                 Start: Menu Confirm/Pause Game
          Analog Stick: Movement
              Triangle: Shoot Up
                Circle: Shoot Right/Menu Confirm
                 Cross: Shoot Down/Menu Back
                Square: Shoot Left
    Left/Right Trigger: Release Bomb

  You can combine shoot directions in order to shoot towards one of the
  diagonal directions:

       Square+Triangle: Shoot Upper-Left
       Triangle+Circle: Shoot Upper-Right
          Circle+Cross: Shoot Bottom-Right
          Cross+Square: Shoot Bottom-Left
