SudokuZen 1.0
By EvilDooinz (evildooinz@comcast.net)

Sound effects from http://www.wyomingwebdesign.com

music from BASS - Dark Trance @ http://www.jamendo.com/
http://creativecommons.org/licenses/by-nc-sa/2.5/

Sudoku Solver/Generator Source-Code from Ohad's blog
http://ohadp.blogspot.com/2005/11/sudoku-solvergenerator-source-code.html

Jas Game Engine++ (c) James Hui (a.k.a. Dr.Watson)

Thanks to Dark_AleX, TyRaNiD and the rest of the pspdev team.

the above mentioned names do not endorse me or my work.

Key mapping on PSP:
-----------------------

Buttons                 Functions
==================      ==================
UP/DOWN/LEFT/RIGHT      Move cursor
ANALOG CONTROL          Not used
TRIANGLE                Take screenshot
SQUARE                  Show hint
CIRCLE                  Change view ( numbers, colors, shapes )
CROSS                   Mark cell
SELECT                  Undo
START                   New puzzle
HOME                    Exit
L                       Decrement value
R                       Increment value

Key mapping on WinblowS
==================      ==================
W/S/A/D			Move cursor
UP/DOWN/LEFT/RIGHT	Not used
I			Take screenshot
J			Show hint
L			Change view ( numbers, colors, shapes )
K			Mark cell
CTRL			Undo
ENTER			New puzzle
F1			Exit
Q			Decrement value
E			Increment value

Please read the license and instructions files included in the package.
