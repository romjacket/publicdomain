## PSPPipes build 19122008,
## by Gefa
## www.gefa.altervista.org
## to contact me: gefasio@gmail.com

What is it?
===========
This is a clone of the puzzle game Pipes

Installation
============
Copy 'python' directory in the root of your memory stick, and
the directory PSPPipes in the path ms0:/PSP/GAME. This homebrew works
on a PSP with Custom Firmware by D_A

Goal
====
Rearrange the tiles to create an unbroken pipe from the spout 
(that is yellow) to the end (green).

How to move the tiles
=====================
First of all, you have to place the cursor on the tile that you want
to move. Then, you can move it whit the buttons cross, triangle, square and
circle to an adjacent open spot.

YOU HAVE 10 SECONDS BEFORE WATER POURS OUT THE SPOUT. HAVE FUN! :)