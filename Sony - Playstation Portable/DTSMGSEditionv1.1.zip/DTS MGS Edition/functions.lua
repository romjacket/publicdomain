--Function Coin Highscore
function coinhighscorecheck()

coinhighscorefile = io.open("coinhighscore.txt","r")
coinhighscore = coinhighscorefile:read("*n")
coinhighscorefile:close()

if Player.score > coinhighscore then
highscore = Player.score
coinhighscorefile = io.open("coinhighscore.txt","w")
coinhighscorefile:write(highscore)
coinhighscorefile:close()
end
end

--Function Classic Highscore
function classichighscorecheck()

classichighscorefile = io.open("classichighscore.txt","r")
classichighscore = classichighscorefile:read("*n")
classichighscorefile:close()

if Player.score > classichighscore then
classichighscore = Player.score
classichighscorefile = io.open("classichighscore.txt","w")
classichighscorefile:write(classichighscore)
classichighscorefile:close()
end
end

--Function Playermove
function levelup()

currentTime = counter:time()

if currentTime <= 0 then
counter:start()
end

if currentTime >= 20000 and level < 8 then
level = level + 1
counter:reset(0)
end
end

--Function Collision Check Player
function checkCollisionPlayer(obj1,obj2)

if (obj1.x + obj1.img:width() > obj2.x) and (obj1.x < obj2.x + 31) and
(obj1.y + obj1.img:height() > obj2.y) and (obj1.y < obj2.y + 31) then

for i = 1,3 do
if obj1 == Enemy[i] and obj2 == Player then
gamestate = "gameover"
end
end

if obj1 == Coin then
Coin.visible = "false"
end
end
end

--Increase Player Score
function scoretime()

Scoretime = stimer:time()

Player.score = Scoretime

stimer:start()
end

--Increase Player Score
function scorecoin()

if Coin.visible == "false" then
Player.score = Player.score + 50*level
Coin.visible = "scored"
end

if Coin.visible == "scored" then
Coin.x = math.random(20,440)
Coin.y = math.random(20,250)
Coin.visible = "true"
end
end

--Function Chase Player 
function chaseplayer(obj1,obj2)

enemyspeed = (level + 1)/2

stallchase = math.random(2)

if stallchase == 1 then
if obj1.x > obj2.x then
obj1.x = obj1.x - enemyspeed
elseif stallchase == 1 then
if obj1.x < obj2.x then
obj1.x = obj1.x + enemyspeed
end
end
end

stallchase = math.random(2)

if stallchase == 1 then
if obj1.y > obj2.y then
obj1.y = obj1.y - enemyspeed
elseif stallchase == 1 then
if obj1.y < obj2.y then
obj1.y = obj1.y + enemyspeed
end
end
end
end


--Function Playermove
function playermove()

if anim >= 53 then
anim = 0
end

--Move Player and set direction
if pad:left() then
Player.x = Player.x - 3
Player.dir = left

elseif pad:right() then
Player.x = Player.x + 3
Player.dir = right

elseif pad:up() then
Player.y = Player.y - 3
Player.dir = up

elseif pad:down() then
Player.y = Player.y + 3
Player.dir = down
end

if Player.x > Screen.width then
Player.x = 0
elseif Player.x < 0 then
Player.x = Screen.width
end

if Player.y > Screen.height then
Player.y = 0 
elseif Player.y < 0 then
Player.y = Screen.height
end
end

--Function Animate
function animate()

--Check if moving
if pad:up() then
movingup = true
else
movingup = false
end

if pad:down() then
movingdown = true
else
movingdown = false
end

if pad:left() then
movingleft = true
else
movingleft = false
end

if pad:right() then
movingright = true
else
movingright = false
end

if movingup == false and movingdown == false and movingleft == false and movingright == false then
moving = false
else
moving = true  
end

--Blit when not moving
if moving == false and Player.dir == down then
screen:blit(Player.x,Player.y,Player.img,36,0,31,32)
anim = 0

elseif moving == false and Player.dir == up then
screen:blit(Player.x,Player.y,Player.img,36,32,31,32)
anim = 0

elseif moving == false and Player.dir == left then
screen:blit(Player.x,Player.y,Player.img,36,64,31,32)
anim = 0

elseif moving == false and Player.dir == right then
screen:blit(Player.x,Player.y,Player.img,36,96,31,32)
anim = 0
end

--Animate Down
if movingdown == true and anim >= 0 and anim <= 13 then
screen:blit(Player.x,Player.y,Player.img,36,0,31,32)

elseif movingdown == true and anim >= 14 and anim <= 26 then
screen:blit(Player.x,Player.y,Player.img,4,0,31,32)

elseif movingdown == true and anim >= 27 and anim <= 39 then
screen:blit(Player.x,Player.y,Player.img,36,0,31,32)

elseif movingdown == true and anim >= 40 and anim <= 52 then
screen:blit(Player.x,Player.y,Player.img,68,0,31,32)
end

--Animate Up
if movingup == true and anim >= 0 and anim <= 13 then
screen:blit(Player.x,Player.y,Player.img,36,96,31,32)

elseif movingup == true and anim >= 14 and anim <= 26 then
screen:blit(Player.x,Player.y,Player.img,4,96,31,32)

elseif movingup == true and anim >= 27 and anim <= 39 then
screen:blit(Player.x,Player.y,Player.img,36,96,31,32)

elseif movingup == true and anim >= 40 and anim <= 52 then
screen:blit(Player.x,Player.y,Player.img,68,96,31,32)
end

--Animate Left
if movingleft == true and anim >= 0 and anim <= 13 then
screen:blit(Player.x,Player.y,Player.img,36,32,31,32)

elseif movingleft == true and anim >= 14 and anim <= 26 then
screen:blit(Player.x,Player.y,Player.img,4,32,31,32)

elseif movingleft == true and anim >= 27 and anim <= 39 then
screen:blit(Player.x,Player.y,Player.img,36,32,31,32)

elseif movingleft == true and anim >= 40 and anim <= 52 then
screen:blit(Player.x,Player.y,Player.img,68,32,31,32)
end

--Animate Right
if movingright == true and anim >= 0 and anim <= 13 then
screen:blit(Player.x,Player.y,Player.img,36,64,31,32)

elseif movingright == true and anim >= 14 and anim <= 26 then
screen:blit(Player.x,Player.y,Player.img,4,64,31,32)

elseif movingright == true and anim >= 27 and anim <= 39 then
screen:blit(Player.x,Player.y,Player.img,36,64,31,32)

elseif movingright == true and anim >= 40 and anim <= 52 then
screen:blit(Player.x,Player.y,Player.img,68,64,31,32)
end


if moving == true then
anim = anim + 1
end
end

--Function to Load Start Menu
function startmenuload()

maxSelect = 4

if char == 1 then
character = "Snake"
end

if char == 2 then
character = "Raiden"
end

stimer:stop()
stimer:reset(0)

Player.x = 50
Player.y = 200
Player.score = 0

Enemy[1].x = 50
Enemy[1].y = 50
Enemy[2].x = 400
Enemy[2].y = 50
Enemy[3].x = 400
Enemy[3].y = 200

screen:print(130,30,"Dodge the Squares",blue)
screen:print(130,40,"Metal Gear Solid",blue)
screen:print(150,50,"Edition",blue)

if pad:up() and oldpad:up() ~= pad:up() then
Select = Select - 1
end

if pad:down() and oldpad:down() ~= pad:down() then
Select = Select + 1
end

if Select > maxSelect then
Select = 1
elseif
Select <= 0 then
Select = maxSelect
end

--Highscores
screen:print(10,260,"Classic Highscore: "..classichighscore,blue)
screen:print(300,260,"Coin Highscore: "..coinhighscore,blue)

--Menu
if Select == 1 then
screen:blit(140,90,selector)
screen:print(150,90,"Classic Mode",blue)
screen:print(150,110,"Coin Mode",blue)
screen:print(150,130,"Difficulty: "..level,blue)
screen:print(150,150,"Character: "..character,blue)
end

if Select == 2 then
screen:blit(140,110,selector)
screen:print(150,90,"Classic Mode",blue)
screen:print(150,110,"Coin Mode",blue)
screen:print(150,130,"Difficulty: "..level,blue)
screen:print(150,150,"Character: "..character,blue)
end

if Select == 3 then
screen:blit(140,130,selector)
screen:print(150,90,"Classic Mode",blue)
screen:print(150,110,"Coin Mode",blue)
screen:print(150,130,"Difficulty: "..level,blue)
screen:print(150,150,"Character: "..character,blue)
end

if Select == 4 then
screen:blit(140,150,selector)
screen:print(150,90,"Classic Mode",blue)
screen:print(150,110,"Coin Mode",blue)
screen:print(150,130,"Difficulty: "..level,blue)
screen:print(150,150,"Character: "..character,blue)
end

if pad:cross() and Select == 1 then
gamemode = "classic"
gamestate = "game"
end

if pad:cross() and Select == 2 then
gamemode = "coin"
gamestate = "game"
end

if pad:right() and oldpad:right() ~= pad:right() and Select == 3 and level < 8 then
level = level + 1
elseif pad:left() and oldpad:left() ~= pad:left() and Select == 3 and level > 1 then
level = level - 1
end

if pad:right() and oldpad:right() ~= pad:right() and Select == 4 and char == 1 then
char = 2
Player.img = Raiden
elseif pad:left() and oldpad:left() ~= pad:left() and Select == 4 and char == 2 then
char = 1
Player.img = Snake
end
end

--Function Game Load
function coingameload()

screen:print(170,5,"Score: "..Player.score,black)

screen:print(320,5,"Highscore: "..coinhighscore,black)

screen:blit(Coin.x,Coin.y,Coin.img)

screen:print(5,5,"Level: "..level,black)

levelup()
playermove()
animate()
scorecoin()

chaseplayer(Enemy[1],Player)
chaseplayer(Enemy[2],Player)
chaseplayer(Enemy[3],Player)

screen:blit(Enemy[1].x,Enemy[1].y,Enemy[1].img,40,10,43,45)
screen:blit(Enemy[2].x,Enemy[2].y,Enemy[2].img,40,10,43,45)
screen:blit(Enemy[3].x,Enemy[3].y,Enemy[3].img,40,10,43,45)

checkCollisionPlayer(Coin,Player)
checkCollisionPlayer(Enemy[1],Player)
checkCollisionPlayer(Enemy[2],Player)
checkCollisionPlayer(Enemy[3],Player)
end

--Function Game Load
function classicgameload()

screen:print(170,5,"Score: "..Player.score,black)

screen:print(320,5,"Highscore: "..classichighscore,black)

screen:print(5,5,"Level: "..level,black)

levelup()
playermove()
animate()
scoretime()

chaseplayer(Enemy[1],Player)
chaseplayer(Enemy[2],Player)
chaseplayer(Enemy[3],Player)

screen:blit(Enemy[1].x,Enemy[1].y,Enemy[1].img)
screen:blit(Enemy[2].x,Enemy[2].y,Enemy[2].img)
screen:blit(Enemy[3].x,Enemy[3].y,Enemy[3].img)

checkCollisionPlayer(Enemy[1],Player)
checkCollisionPlayer(Enemy[2],Player)
checkCollisionPlayer(Enemy[3],Player)
end

--Function Game Load
function currentgameload()

if gamemode == "classic" then
classicgameload()
level = 5
end

if gamemode == "coin" then
coingameload()
end
end

--Function Game Over Load
function gameoverload()

if Player.score > coinhighscore and gamemode == "coin" then
gothighscore = "true"
elseif Player.score > classichighscore and gamemode == "classic" then
gothighscore = "true"
else
gothighscore = "false"
end

level = 1

if gothighscore == "false" and gamemode == "coin" then
screen:print(150,100,"Game Over",black)
screen:print(150,110,"Your Score: "..Player.score,black)
screen:print(150,120,"Highscore: "..coinhighscore,black)
screen:print(150,130,"Press O to Continue",black)
elseif gothighscore == "false" and gamemode == "classic" then
screen:print(150,100,"Game Over",black)
screen:print(150,110,"Your Score: "..Player.score,black)
screen:print(150,120,"Highscore: "..classichighscore,black)
screen:print(150,130,"Press O to Continue",black)
elseif gothighscore == "true" and gamemode == "coin" then
coinhighscorecheck()
screen:print(150,100,"Game Over",black)
screen:print(150,110,"Congratulations you got a"..Player.score,black)
screen:print(150,120,"Highscore!!"..Player.score,black)
screen:print(150,130,"Highscore: "..coinhighscore,black)
screen:print(150,140,"Press O to Continue",black)
elseif gothighscore == "true" and gamemode == "classic" then
classichighscorecheck()
screen:print(150,100,"Game Over",black)
screen:print(150,110,"Congratulations you got a"..Player.score,black)
screen:print(150,120,"Highscore!!"..Player.score,black)
screen:print(150,130,"Highscore: "..classichighscore,black)
screen:print(150,140,"Press O to Continue",black)
end

if pad:circle() then
gamestate = "startmenu"
end
end