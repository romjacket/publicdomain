--xXChromeXx

math.randomseed(os.time())

--Create Colors
green = Color.new(0,255,0)
white = Color.new(255,255,255)
blue = Color.new(0,0,255)
red = Color.new(255,0,0)
yellow = Color.new(255,255,0)
black = Color.new(0,0,0)


--Variables
oldpad = Controls.read()
gamestate = "startmenu"
Select = 1
level = 1
anim = 0
char = 1
character = "Snake"
counter = Timer.new()
stimer = Timer.new()

--Load Images

--Create Player
Snake = Image.load("Images/solidsnake.png")
Raiden = Image.load("Images/raiden.png")

--Create Coin
coin = Image.createEmpty(12,20)
coin:clear(yellow)

--Create Enemy
enemy1 = Image.createEmpty(40,40)
enemy1:clear(blue)

enemy2 = Image.createEmpty(40,40)
enemy2:clear(red)

enemy3 = Image.createEmpty(40,40)
enemy3:clear(green)

--Create Selector
selector = Image.createEmpty(8,8)
selector:clear(blue)

--Player Table
Player = {}
Player.x = 50
Player.y = 200
Player.img = Snake
Player.dir = down
Player.lives = 3
Player.score = 0

--Enemy Table
Enemy = {}
Enemy[1] = {x = 50,y = 50,img = enemy1}
Enemy[2] = {x = 400,y = 50,img = enemy2}
Enemy[3] = {x = 400,y = 200,img = enemy3}

Coin = {}
Coin.x = math.random(20,440)
Coin.y = math.random(20,250)
Coin.img = coin
Coin.visible = "true"

--Screen Size
Screen = {}
Screen.width = 470
Screen.height = 272

--Check Coin Highscore
coinhighscorefile = io.open("coinhighscore.txt","r")
coinhighscore = coinhighscorefile:read("*n")
coinhighscorefile:close()

--Check Classic Highscore
classichighscorefile = io.open("classichighscore.txt","r")
classichighscore = classichighscorefile:read("*n")
classichighscorefile:close()

--Load Functions
dofile("functions.lua")

--Main Loop-----------------------------------------------------
while true do 
pad = Controls.read()
screen:clear(white)

if gamestate == "startmenu" then
startmenuload()
end

if gamestate == "game" then
currentgameload()
end

if gamestate == "gameover" then
gameoverload()
end

--Quit
if pad:triangle() and oldpad:triangle() ~= pad:triangle() then
break
end

--Screenshot
if pad:select() then 
screen:save("screen1.png") 
end

screen.waitVblankStart()
screen.flip()
oldpad = pad
end