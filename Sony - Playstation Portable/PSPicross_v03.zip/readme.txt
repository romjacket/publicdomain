 _____   _____ _____  _                        
|  __ \ / ____|  __ \(_)                       
| |__) | (___ | |__) |_  ___ _ __ ___  ___ ___ 
|  ___/ \___ \|  ___/| |/ __| '__/ _ \/ __/ __|
| |     ____) | |    | | (__| | | (_) \__ \__ \
|_|    |_____/|_|    |_|\___|_|  \___/|___/___/ v0.3

/*-----Credits-----*/
PSPicross v0.3 by Maurice

Original code by Haggar (http://haggar.pocketheaven.com/)
Special thanks to earthHunter for converting some puzzles and Haggar for giving me permission to release this.

/*---Installation--*/
Unpack "PSPicross" folder into X:\PSP\GAME

/*-------Game------*/
'Picross' or 'Nonogram' is a puzzle game similiar to Sudoku and other Japanese Puzzle games.
The numbers on the side of each row and column indicate how many fields are to be filled in each row/column.
In a 5x5 puzzle, a "5" shows that the whole row/column has to be filled: 

      5| OOOOO

If there's more than one number at the side, it means that these 2 lines are not connected.
A "3 1" would therfor mean: 

    3 1| OOOXO

Using further thinking, more blocks can be filled.
For example, a "3" means that the line holds a line of 3 blocks. This leaves 3 possibilities:

      3| OOOXX
      3| XOOOX
      3| XXOOO

In all three cases, the one in the middle is filled, so it is safe to fill it.

Here's an example of a puzzle:

         11 11
         33033
         '''''
     22| OOXOO
      0| XXXXX
     22| OOXOO
     22| OOXOO
     22| OOXOO

***All included puzzles can be solved completely by logic! Other puzzles and selfmade puzzles might require trial and error testing!***
For a good description of techniques, visit http://en.wikipedia.org/wiki/Picross#Solution_techniques

/*-----Controls----*/
Main menu:
Start			= Start puzzle-browser
Triangle		= Start editor

Puzzle-browser:
Up and Down		= Scroll list
Left and Right	= Scroll list x10
Cross			= Open file/directory
Triangle		= Up one directory
L-Trigger		= Switch between time and name sorting
R-Trigger		= View filetypes
Select		= Back to main menu

In-game:
D-Pad			= Move Cursor
Cross			= Fill/Erase Block
Circle		= Mark/unmark block with X
Select		= Quit to puzzle-browser

Editor:
D-Pad			= Move Cursor
Cross			= Fill/Erase Block
Select		= Finish edit

/*-----Features----*/
- Sizes 5, 10 and 15 supported
- PicrossDS-like graphics
- Timer
- Music and sounds
- File browser
- Puzzle Editor/Maker
- 215 puzzles included
- Highscore tracking


Have fun!