back = Image.load("back.png")
chisel = Image.load("cursor.png")
tiles = Image.load("tiles.png")

backgroundLayer = Image.createEmpty(480, 272)
linesLayer = Image.createEmpty(480, 272)

math.randomseed(os.time())
dofile("./browser.lua")

function Controls.waitpadup()
	pad=Controls.read()
	while pad:select() or pad:start() or pad:up() or pad:right() or pad:down() or pad:left() or pad:l() or pad:r() or pad:triangle() or pad:circle() or pad:cross() or pad:square() do
		screen.waitVblankStart()
		pad=Controls.read()
	end
end

function firstDraw()
	backgroundLayer:clear()
	linesLayer:clear()

	backgroundLayer:blit(0, 0, back)

	if size>5 then
		linesLayer:drawLine(235, 72, 235, 71+(12*size), green)
		linesLayer:drawLine(176, 131, 175+(12*size), 131, green)
	end

	if size>10 then
		linesLayer:drawLine(295, 72, 295, 71+(12*size), green)
		linesLayer:drawLine(176, 191, 175+(12*size), 191, green)
	end
end

function drawRect(x,y)
	screen:blit(x-1,y-1,chisel)
end

function drawScreen()
	screen:clear()

	screen:blit(0,0,backgroundLayer)

	for i=1,size do
		for j=1,size do
			screen:blit(176+((i-1)*12), 72+((j-1)*12), tiles,12*(math.abs(board[j][i])-1), 0, 12, 12)
		end
	end

	screen:blit(0,0,linesLayer)

	drawRect(175+((dx-1)*12),71+((dy-1)*12))

	screen.waitVblankStart()
	screen.flip()
end

oldestcwd = System.currentDirectory()

repeat
	size=5
	name=""

	oldPad = Controls.read()
	fileopen=0

	System.currentDirectory(oldestcwd)
	newcwd = System.currentDirectory()
	checkDir = {}
	checkDir = System.listDirectory(newcwd)
	for i=1,table.getn(checkDir) do
		if checkDir[i].directory and string.lower(checkDir[i].name) == "puzzles" then
			System.currentDirectory("./puzzles/")
			newcwd = System.currentDirectory()
		end
	end

	Controls.waitpadup()

	repeat
		screen.waitVblankStart()
		pad = Controls.read()

		if pad~=oldPad then
			if pad:right() then
				size=size+5
				if size>15 then
					size=15
				end

			elseif pad:left() then
				size=size-5
				if size<5 then
					size=5
				end
			elseif pad:select() then
				fileopen=1
			end
		end

		screen:clear(Color.new(56, 144, 232))
		screen:print(0,0,"PSPICROSS PUZZLE EDITOR",Color.new(255,255,255))
		screen:print(0,20,"Either choose a puzzle size or open a workfile.",Color.new(255,255,255))
		screen:print(0,30,"Only *.mhw files can be opened, not *.mhp files.",Color.new(255,255,255))
		screen:print(0,40,"If you want to publish puzzle files, then only",Color.new(255,255,255))
		screen:print(0,50,"put out *.mhp files, and not any *.mhw files.",Color.new(255,255,255))
		screen:print(0,60,"MAKE SURE YOU KEEP THE *.MHW FILE YOURSELF.",Color.new(255,255,255))

		screen:print(0,124,"CHOOSE PUZZLE SIZE:",Color.new(255,255,255))
		screen:print(8,140,string.format ("%2d", size),Color.new(255,255,255))
		screen:print(0,240,"Left and right: Change",Color.new(255,255,255))
		screen:print(0,250,"X: Confirm",Color.new(255,255,255))
		screen:print(0,260,"Select: Open existing *.mhw workfile",Color.new(255,255,255))
		screen.waitVblankStart()
		screen.flip()

		oldPad=pad
	until pad:cross() or fileopen==1

	illegal=0

	if fileopen==1 then
		illegal=0
		filetypes = {}

		filetypes[1]=".mhw"

		filename, newcwd = browser(filetypes,newcwd,1,-1, 1,0)
		if filename==false then
			illegal=2
		else
			dofile(string.format("%s%s",newcwd,filename))
			System.currentDirectory(newcwd)
		end
	else
		board = {{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}}
	end

	if illegal~=2 then
		illegal=0

		for i=1,size do
			for j=1,size do
				if math.abs(board[i][j])~=1 then
					illegal=1
				end
				if board[i][j]==1 then
					board[i][j]=3
				elseif board[i][j]==-1 then
					board[i][j]=1
				end
			end
		end
	end

	if illegal==1 then
		repeat
			pad = Controls.read()
			screen:clear()
			screen:print(164,124,"WRONG FILEFORMAT!",Color.new(255,0,0))
			screen:print(164,140,"PRESS X TO GO BACK",Color.new(255,0,0))
			screen.waitVblankStart()
			screen.flip()
		until pad:cross()
	end
until illegal==0

Controls.waitpadup()

countmax=6
if size>5 then
	countmax=4
end

green = Color.new(248, 160, 0)

dx=1
dy=1

counter=0
memory=0

firstDraw()

oldPad = Controls.read()

repeat
	pad = Controls.read()

	if pad:cross() and pad:cross()~=oldPad:cross() then
		if math.abs(board[dy][dx])==1 then
			board[dy][dx]=board[dy][dx]*3
			memory=3
		elseif math.abs(board[dy][dx])==3 then
			board[dy][dx]=board[dy][dx]/3
			memory=1
		else
			memory=0
		end
	end

	if pad~=oldPad or counter==countmax-1 then
		if pad:left() then
			dx=dx-1
			if dx<1 then
				dx=1
			elseif pad:cross() then
				if math.abs(board[dy][dx])==1 and memory==3 then
					board[dy][dx]=board[dy][dx]*3
				elseif math.abs(board[dy][dx])==3 and memory==1 then
					board[dy][dx]=board[dy][dx]/3
				end
			end
		elseif pad:right() then
			dx=dx+1
			if dx>size then
				dx=size
			elseif pad:cross() then
				if math.abs(board[dy][dx])==1 and memory==3 then
					board[dy][dx]=board[dy][dx]*3
				elseif math.abs(board[dy][dx])==3 and memory==1 then
					board[dy][dx]=board[dy][dx]/3
				end
			end
		elseif pad:up() then
			dy=dy-1
			if dy<1 then
				dy=1
			elseif pad:cross() then
				if math.abs(board[dy][dx])==1 and memory==3 then
					board[dy][dx]=board[dy][dx]*3
				elseif math.abs(board[dy][dx])==3 and memory==1 then
					board[dy][dx]=board[dy][dx]/3
				end
			end
		elseif pad:down() then
			dy=dy+1
			if dy>size then
				dy=size
			elseif pad:cross() then
				if math.abs(board[dy][dx])==1 and memory==3 then
					board[dy][dx]=board[dy][dx]*3
				elseif math.abs(board[dy][dx])==3 and memory==1 then
					board[dy][dx]=board[dy][dx]/3
				end
			end
		end
	end

	drawScreen(0)

	if oldPad==pad then
		counter = math.mod(counter+1,countmax)
	else
		counter = 0
	end

	oldPad=pad
until pad:select()

Controls.waitpadup()

a=65
c=name
caseType=1

repeat
	screen:clear(Color.new(56, 144, 232))
	screen:print(0, 0, "This name is for both the file and the puzzle.", Color.new(255,255,255))
	screen:print(0, 10, "If you don't input any name, then it will be called temp", Color.new(255,255,255))
	screen:print(0, 20, "*.mhw workifle and *.mhp puzzle files will be written.", Color.new(255,255,255))
	screen:print(0, 30, "THIS WILL OVERWRITE FILES IF THERE'S ANY WITH THE SAME NAME.", Color.new(255,255,255))

	screen:print(0, 100, "Input name:", Color.new(255,255,255))
	if a<65 and caseType==1 then
		a=90
	elseif a>90 and caseType==1 then
		a=65
	elseif a<97 and caseType==2 then
		a=122
	elseif a>122 and caseType==2 then
		a=97
	end

	b=string.char(a)
	screen:print(8, 110, c.."<-"..b, Color.new(255,255,255))

	screen:print(0, 200, "Up and down: Change letter", Color.new(255,255,255))
	screen:print(0, 210, "Right: Space", Color.new(255,255,255))
	screen:print(0, 220, "Left: Backspace", Color.new(255,255,255))
	screen:print(0, 230, "L-Trigger: Lowercase", Color.new(255,255,255))
	screen:print(0, 240, "R-Trigger: Uppercase", Color.new(255,255,255))
	screen:print(0, 250, "X: Confirm letter", Color.new(255,255,255))
	screen:print(0, 260, "Select: Finished", Color.new(255,255,255))

	pad = Controls.read()
	if pad:up() and pad~=oldPad then
		a=a+1
	elseif pad:down() and pad~=oldPad then
		a=a-1
	elseif pad:right() and pad~=oldPad then
		c=c.." "
	elseif pad:left() and pad~=oldPad then
		c=string.sub(c, 1, (string.len(c)-1))
	elseif pad:cross() and pad~=oldPad then
		c=c..b
	elseif pad:l() then
		if caseType==1 then
			caseType=2
			a=a+32
		end
	elseif pad:r() then
		if caseType==2 then
			caseType=1
			a=a-32
		end
	end

	screen.waitVblankStart()
	screen.flip()
	oldPad=pad
until pad:select()

name=c

if name=="" then
	name="temp"
end

Controls.waitpadup()

file = io.open(name..".mhw", "w")
if file then
	file:write("size="..size.."\n")
	file:write("board={")

	for i=1,size do
		file:write("{")
		for j=1,size do
			if board[i][j]==3 then
				file:write("1")
			else
				file:write("-1")
			end
			if j~=size then
				file:write(",")
			end
		end
		file:write("}")
		if i~=size then
			file:write(",")
		end
	end
	file:write("}\n")
	file:write("name="..string.format("%c", 34)..name..string.format("%c", 34).."\n")
	file:close()
end

file = io.open(name..".mhp", "w")
if file then
	file:write("size="..size.."\n")
	file:write("board={")

	for i=1,size do
		file:write("{")
		for j=1,size do
			ranNum=math.random(1,254)
			if math.mod(ranNum,2)==0 then
				ran1=ranNum
				ran2=ranNum+1
			elseif math.mod(ranNum,2)==1 then
				ran1=ranNum+1
				ran2=ranNum
			end

			if board[i][j]==3 then
				file:write(ran1)
			else
				file:write(ran2)
			end
			if j~=size then
				file:write(",")
			end
		end
		file:write("}")
		if i~=size then
			file:write(",")
		end
	end
	file:write("}\n")
	file:write("name="..string.format("%c", 34)..name..string.format("%c", 34).."\n")
	file:close()
end

System.currentDirectory(oldestcwd)
