titleImage = Image.load("title.png")

function Controls.waitpadup()
	pad=Controls.read()
	while pad:select() or pad:start() or pad:up() or pad:right() or pad:down() or pad:left() or pad:l() or pad:r() or pad:triangle() or pad:circle() or pad:cross() or pad:square() do
		screen.waitVblankStart()
		pad=Controls.read()
	end
end

Controls.waitpadup()

Music.playFile("picross.it",true)

repeat
	screen.waitVblankStart()
	pad = Controls.read()

	if pad:start() then
		Controls.waitpadup()
		myCWD = System.currentDirectory()
		if Music.playing() then
			Music.stop()
		end
		dofile("./game.lua")
		Controls.waitpadup()
		System.currentDirectory(myCWD)
		Music.playFile("picross.it",true)

	elseif pad:triangle() then
		Controls.waitpadup()
		myCWD = System.currentDirectory()
		if Music.playing() then
			Music.stop()
		end
		dofile("./edit.lua")
		Controls.waitpadup()
		System.currentDirectory(myCWD)
		Music.playFile("picross.it",true)
	end

	screen:clear()
	screen:blit(0,0,titleImage)
	screen.waitVblankStart()
	screen.flip()

until false

Controls.waitpadup()

if Music.playing() then
	Music.stop()
end