#include "tables.h"
#include "m_fixed.h"


/*
#define WRITESTRING(p,b) {memcpy(p, b, strlen(p));p += strlen(p);}
void WRITESTRINGN(char *p,char *b,int n)
{
	int len = strlen(p);
	if(len > n) len = n;
	memcpy(b, p, len);
	p += len;
}*/
void writebyte(char *p, byte b)
{
	memcpy(p, &b, sizeof(byte));
}
void writechar(char *p, char b)
{
	memcpy(p, &b, sizeof(char));
}
void writeshort(char *p, short b)
{
	memcpy(p, &b, sizeof(short));
}
void writeushort(char *p, USHORT b)
{
	memcpy(p, &b, sizeof(USHORT));
}
void writelong(char *p, long b)
{
	memcpy(p, &b, sizeof(long));
}
void writeulong(char *p, ULONG b)
{
	memcpy(p, &b, sizeof(ULONG));
}
void writefixed(char *p, fixed_t b)
{
	memcpy(p, &b, sizeof(fixed_t));
}
void writeangle(char *p, angle_t b)
{
	memcpy(p, &b, sizeof(angle_t));
}

byte readbyte(char *p)
{
	byte ret;
	memcpy(&ret, p, sizeof(byte));
	return ret;
}
char readchar(char *p)
{
	char ret;
	memcpy(&ret, p, sizeof(char));
	return ret;
}
short readshort(char *p)
{
	short ret;
	memcpy(&ret, p, sizeof(short));
	return ret;
}
unsigned short readushort(char *p)
{
	unsigned short ret;
	memcpy(&ret, p, sizeof(short));
	return ret;
}
long readlong(char *p)
{
	long ret;
	memcpy(&ret, p, sizeof(long));
	return ret;
}
unsigned long readulong(char *p)
{
	unsigned long ret;
	memcpy(&ret, p, sizeof(long));
	return ret;
}
fixed_t readfixed(char *p)
{
	fixed_t ret;
	memcpy(&ret, p, sizeof(fixed_t));
	return ret;
}
angle_t readangle(char *p)
{
	angle_t ret;
	memcpy(&ret, p, sizeof(angle_t));
	return ret;

}/*
void READSTRING(char *p, char *s)
{
	memcpy(s, p, strlen(p));
	p += strlen(p);
}
void SKIPSTRING(char *p)
{
	p += strlen(p);
}*/

