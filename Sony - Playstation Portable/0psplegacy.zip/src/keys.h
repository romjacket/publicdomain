// Emacs style mode select   -*- C++ -*- 
//-----------------------------------------------------------------------------
//
// $Id: keys.h,v 1.2 2000/02/27 00:42:10 hurdler Exp $
//
// Copyright (C) 1998-2000 by DooM Legacy Team.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
//
// $Log: keys.h,v $
// Revision 1.2  2000/02/27 00:42:10  hurdler
// fix CR+LF problem
//
// Revision 1.1.1.1  2000/02/22 20:32:32  hurdler
// Initial import into CVS (v1.29 pr3)
//
//
// DESCRIPTION:
//
//
//-----------------------------------------------------------------------------


#ifndef __KEYS_H__
#define __KEYS_H__

//
// DOOM keyboard definition.
// This is the stuff configured by Setup.Exe.
//

#define KEY_NULL        0       // null key, triggers nothing

#define KEY_SELECT      27
#define KEY_CROSS       13
#define KEY_CIRCLE      14
#define KEY_START       15
#define KEY_TRIANGLE    (0x80+112)
#define KEY_SQUARE      (0x80+113)
#define KEY_UPARROW     (0x80+102)
#define KEY_LEFTARROW   (0x80+105)
#define KEY_RIGHTARROW  (0x80+107)
#define KEY_DOWNARROW   (0x80+110)
#define KEY_L           'L'
#define KEY_R           'R'

#define KEY_SCREEN      10 // screenshot

#endif
