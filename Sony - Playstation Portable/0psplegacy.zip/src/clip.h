typedef struct glvert_s
{
	float xyz[3];
	int col;
	float st[2];
} glvert_t;

#define max_clipped_vertices 64

