#include "doomdef.h"

void kgDebug(char *txt)
{
//	SceUID f = sceIoOpen("debug.txt", PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
	SceUID f = sceIoOpen("debug.txt", PSP_O_WRONLY | PSP_O_CREAT | PSP_O_APPEND, 0777);
	sceIoWrite(f, txt, strlen(txt));
	sceIoClose(f);
	sceKernelDelayThread(1000*1000);
}

