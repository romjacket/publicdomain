#include <pspkernel.h>
#include <pspwlan.h>
#include <pspsdk.h>
#include <pspnet.h>
#include <pspnet_adhoc.h>
#include <pspnet_adhocctl.h>
#include <psputility.h>

#define ADHOC_PORT 29

typedef struct
{
	int nic;
	u16 port;
	char mac[6];
} sockaddr;

typedef sockaddr mysockaddr_t;

int pspSdkLoadAdhocModules();
int pspSdkAdhocInit(char *product);
void pspSdkAdhocTerm();
int OpenSocket(int port);
int CloseSocket(int socket);
int recv(int socket, char *buf, int len, sockaddr *addr);
int send(int socket, char *buf, int len, sockaddr *addr);
char *AddrToString(sockaddr *addr);
int StringToAddr(char *string, sockaddr *addr);
int AddrCompare(sockaddr *addr1, sockaddr *addr2);
int Adhoc_Init();

