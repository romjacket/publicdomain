InsanerzShooter (http://insanerzshooter.googlepages.com)

About
====================

This is a classic shmup 2D, made with SDL.

Changes
===================
v0.5 (23/01/2009):

- Changed: the game difficult has changed.

v0.4 (22/01/2009):

- Changed: the player sound explosion.

- Fixed: PSP now has music!!!!!!!! The problem was the ogg format...
- Fixed: pause again. Loop doesn't create powerups in background.
- Fixed: the score and hiscore are centered in the screen.

v0.3 (19/01/2009):

- Added: particles to enemies.
- Added: a new enemy sprite file.

- Changed: powerup appear a little less and appear more bullet powerup.
- Changed: now the hiscore SAVES!!!!

- Fixed: ghost powerup. Before, when you die still catch all the powerups :)

v0.2 (16/01/2009):

- Added: icon0.png - the icon for XMB (psp).
- Added: new font Free Sans bold.
- Added: hiscore function.

- Changed: powerup appear a little more.

- Fixed: pause. Loop doesn't continue to add enemies in background.

v0.1 (someday in 2008):

- First release :)

====================
----INSTRUCTIONS----
====================

Requirements:
--------------------

I've tested on my PSP 2000 CFW 5.00.

Installation:
--------------------

PSP:
Place the insanerzshooter folder into PSP/GAME.

PC:
Run the .exe :D

Bugs
====================

- I don't know...

Credits:
====================

Marcio F. David
Marcelo Baccelli

------------------------------
Special Thanks

incacodecdecodec for our job!
ZX81 the guy who make the pspsdk to virtualbox.
ps2dev.org for the sdk.