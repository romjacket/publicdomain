### Mario Gold Rush By SafariAl ###

--Objective:

The objective of Mario Gold Rush is pretty simple. You want to try and collect as many coins and points 
as possible before you run out. There are two types of coins, a red coin and a yellow coin. Yellow coins 
are the normal coins worth 1 coin each and count as 350 points. The Red coins are worth 2 coins each
and count as 725 points. It's really your decision as to whether or not points are more valuable than the
number of coins you collect.

--Features: 

1. Yellow coins - worth 1 coin each, worth 350 points each
2. Red bonus coins -  worth 2 coins each, worth 725 points each
3. Ability to change time in the options menu
4. Ability to change number of red coins in the options menu
5. Ability to fly - similar to the Super Mario Brother's 3 raccoon flying engine

--Things to fix (read the Why section):

Please if you see any bugs not mentioned below, report them to me at www.homebrewheaven.net

1. Coin Sound bug - overlaps the sound on the same channel
2. Graphics - need to change the mario sprites and coin sprites

--Why?

Why did I even bother making this game? Mostly because I needed to know what I was capable of before I started
a large project. This was just a test of my abilities. The project itself may not ever be updated again unless there's
a very large response. Please do enjoy the game though.

--Installation
For 1.50:
1. Go into the "For 1.50" folder
2. Copy the "Mario Gold Rush" and "Mario Gold Rush%" folders into PSP/GAME
3. If you are on a custom firmware, make sure your kernel is set to 1.50

For 3XX/4XX
1. Go into the "For 3XX" folder
2. Copy the "Mario Gold Rush" folder into PSP/GAME3XX or GAME4XX (in 3XX, replace XX with your firmware)

--Source Code
If you would like this extremely sloppy source code, please message me on www.homebrewheaven.net, and I'll send it.

--Credits
Homer for all the timer help along with many other things
DimensionT for the music and sound conversion
Ninetndo (of course)
InsertWittyName for pgeFont
A_Nub for the random code
Brunni for oslib
everyone on my blog who mentioned ideas for the game
