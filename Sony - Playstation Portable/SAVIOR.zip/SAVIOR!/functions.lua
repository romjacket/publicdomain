--Function to Load Start Menu
function startmenuload()

--Variables
currentbullet = 1
currentbullet2 = currentbullet
ammo = 3
level = 1
round = 1
TotalRoundTime = 0
direction = "right"
maxbullet = 3
maxEnemy = 3
doublebullet = "No"
maxSelect = 3

Player.x = 30
Player.y = 60
Player.score = 0

--Bullet Table
Bullet = {}
Bullet[1] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[2] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[3] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[4] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[5] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[6] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[7] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[8] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[9] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[10] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[11] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[12] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[13] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[14] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[15] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}


--Enemy Table
Enemy = {}
Enemy[1] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[2] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[3] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[4] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[5] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[6] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[7] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[8] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[9] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[10] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[11] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[12] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[13] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[14] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[15] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}


--Clear Screen
screen:clear()

screen:blit(0,0,menubg)

if pad:up() and oldpad:up() ~= pad:up() then
Select = Select - 1
end

if pad:down() and oldpad:down() ~= pad:down() then
Select = Select + 1
end

if Select > maxSelect then
Select = 1
elseif
Select <= 0 then
Select = maxSelect
end

if Select == 1 then
screen:blit(50,110,selector1)
end

if Select == 2 then
screen:blit(143,150,selector2)
end

if Select == 3 then
screen:blit(285,197,selector3)
end

if pad:cross() and oldpad:cross() ~= pad:cross() and Select == 1 then
gamestate = "game"
end

if pad:cross() and oldpad:cross() ~= pad:cross() and Select == 2 then
gamestate = "options"
end

if pad:cross() and oldpad:cross() ~= pad:cross() and Select == 3 then
System.Quit()
end
end

--Function Game Load
function gameload()
screen:blit(0,0,background)
screen:blit(Player.x,Player.y,Player.img)
screen:blit(0,0,hud)

if pad:start() and oldpad:start() ~= pad:start() then
gamestate = "paused"
Music.pause()
end

if pad:cross() and oldpad:cross() ~= pad:cross() and ammo > 0 then
doublecheck()
ammo = ammo - 1
end

for j = 1,maxbullet do
if Bullet[j].active == false then
if ammo < 1 then
ammo = maxbullet
end
end
end

screen:print(10,3,"Score: "..Player.score,white)
screen:print(120,3,"Ammo: "..ammo,white)
screen:print(220,3,"Round: "..round,white)
screen:print(300,3,"Round Time: "..RoundSeconds,white)

bulletfire()
playermove()
generateEnemies()
levelup()
roundup()

for i = 1,maxEnemy do
for j = 1,maxbullet do
checkCollision(Bullet[j],Enemy[i])
checkCollision(Player,Enemy[i])
end
end

for i = 1,maxEnemy do
if Enemy[i].alive == true then
chaseplayer(Enemy[i],Player)
end
end
end

--Function Pause Load
function pauseload()
screen:blit(0,0,background)
screen:blit(Player.x,Player.y,Player.img)
screen:blit(0,0,hud)
screen:print(10,3,"Score: "..Player.score,white)
screen:print(120,3,"Ammo: "..ammo,white)
screen:print(220,3,"Round: "..round,white)
screen:print(300,3,"Round Time: "..RoundSeconds,white)

for i = 1,maxEnemy do
if Enemy[i].alive == true then
screen:blit(Enemy[i].x,Enemy[i].y,Enemy[i].img)
end
end

for i = 1,maxbullet do
if Bullet[i].active == true then
screen:blit(Bullet[i].x,Bullet[i].y,Bullet[i].img)
end
end

screen:blit(0,0,pause)

if pad:select() and oldpad:select() ~= pad:select() then
gamestate = "game"
Music.resume()
end

end

--Function bullet setup
function bulletsetup()
if currentbullet < maxbullet then
currentbullet = currentbullet + 1
else
currentbullet = 1
end


Bullet[currentbullet].x = Player.x + 30
Bullet[currentbullet].y = Player.y + 10

Bullet[currentbullet].active = true
end

--Function double bullet setup
function doublebulletsetup()
if currentbullet < maxbullet  and currentbullet2 < maxbullet then
currentbullet = currentbullet + 1
currentbullet2 = currentbullet + 1
else
currentbullet = 1
end


Bullet[currentbullet].x = Player.x + 30
Bullet[currentbullet].y = Player.y + 2
Bullet[currentbullet].active = true

Bullet[currentbullet2].x = Player.x + 30
Bullet[currentbullet2].y = Player.y + 30
Bullet[currentbullet2].active = true
end

--Function Double Check
function doublecheck()

if doublebullet == "Yes" then
doublebulletsetup()
else
bulletsetup()
end
end

--Function bullet fire
function bulletfire()
for i = 1,maxbullet do
if Bullet[i].active == true then
Bullet[i].x = Bullet[i].x + 6
screen:blit(Bullet[i].x,Bullet[i].y,Bullet[i].img)
end

if Bullet[i].x > 480 then
Bullet[i].active = false
end
end
end

--Function player move
function playermove()
if pad:up() then
Player.y = Player.y - 1
direction = "up"
elseif pad:down() then
Player.y = Player.y + 1
direction = "down"
elseif pad:left() then
Player.x = Player.x - 1
direction = "left"
elseif pad:right() then
Player.x = Player.x + 1
direction = "right"
end
end

--Function Chase Player 
function chaseplayer(obj1,obj2)

enemyspeed = (level + 1)/2

stallchase = math.random(2)

if stallchase == 1 then
if obj1.x > obj2.x then
obj1.x = obj1.x - enemyspeed
elseif stallchase == 1 then
if obj1.x < obj2.x then
obj1.x = obj1.x + enemyspeed
end
end

stallchase = math.random(2)

if stallchase == 1 then
if obj1.y > obj2.y then
obj1.y = obj1.y - enemyspeed
elseif stallchase == 1 then
if obj1.y < obj2.y then
obj1.y = obj1.y + enemyspeed
end
end
end
end
end

--Function Generate Enemies
function generateEnemies()
for i = 1,maxEnemy do
if Enemy[i].alive == true then
screen:blit(Enemy[i].x,Enemy[i].y,Enemy[i].img)
elseif Enemy[i].alive == false then
Enemy[i].alive = true
Enemy[i].x = math.random(390,500)
Enemy[i].y = math.random(0,276)
end
end
end

--Function Collision Check
function checkCollision(obj1,obj2)

if (obj1.x + obj1.img:width() > obj2.x) and (obj1.x < obj2.x + obj2.img:width()) and
(obj1.y + obj1.img:height() > obj2.y) and (obj1.y < obj2.y + obj2.img:height()) then

for i = 1,maxEnemy do
for j = 1,maxbullet do
if obj1 == Bullet[j] and obj2 == Enemy[i] and Bullet[j].active == true then
Enemy[i].alive = false
Bullet[j].active = false
Player.score = Player.score + (level * 100)/2
end
end
end

for i = 1,maxEnemy do
if obj1 == Player and obj2 == Enemy[i] then
gamestate = "gameover"
end
end
end
end

--Function Level Up
function levelup()

if round >= 5 and level < 3 then
level = 2
maxEnemy = 4
elseif round >= 10 and level < 4 then
level = 3
maxEnemy = 5
elseif round >= 15 and level < 5 then
level = 4
maxEnemy = 6
elseif round >= 20 and level < 6 then
level = 5
maxEnemy = 7
elseif round >= 25 and level < 7 then
level = 6
maxEnemy = 8
elseif round >= 30 and level < 8 then
level = 7
maxEnemy = 9
elseif round >= 40 and level < 9 then
level = 8
maxEnemy = 10
elseif round >= 50 and level < 10 then
level = 9
maxEnemy = 11
elseif round >= 60 and level < 11 then
level = 10
maxEnemy = 12
elseif round >= 70 and level < 12 then
level = 11
maxEnemy = 13
elseif round >= 80 and level < 13 then
level = 12
maxEnemy = 14
elseif round >= 90 and level < 14 then
level = 13
maxEnemy = 15
elseif round >= 100 and level < 15 then
level = 14
maxEnemy = 16
end
end

--Function Round Up
function roundup()

currentRoundTime = roundcounter:time()

TotalRoundTime = round * 10000

RoundSeconds = (currentRoundTime/1000)

if currentRoundTime <= 0 then
roundcounter:start()
end

if currentRoundTime >= TotalRoundTime then
round = round + 1
roundcounter:reset(0)
gamestate = "upgrade"
end
end

--Function Upgrade Load
function upgradeload()

--Variables
maxSelect = 3

--Clear Screen
screen:clear()

screen:blit(0,0,upgrades)
screen:print(430,65,maxbullet,white)
screen:print(425,100,doublebullet,white)
screen:print(200,120,"Score: "..Player.score,white)



if pad:up() and oldpad:up() ~= pad:up() then
Select = Select - 1
end

if pad:down() and oldpad:down() ~= pad:down() then
Select = Select + 1
end

if Select > maxSelect then
Select = 1
elseif
Select <= 0 then
Select = maxSelect
end

if Select == 1 then
screen:blit(10,60,selector4)
end

if Select == 2 then
screen:blit(10,95,selector4)
end

if Select == 3 then
screen:blit(10,210,selector4)
end

if pad:cross() and oldpad:cross() ~= pad:cross() and Player.score >= 1000 and Select == 1 then
maxbullet = maxbullet + 1
Player.score = Player.score - 1000
end

if pad:cross() and oldpad:cross() ~= pad:cross() and Player.score >= 5000 and Select == 2 then
doublebullet = "Yes"
Player.score = Player.score - 5000
end

if pad:cross() and oldpad:cross() ~= pad:cross() and Select == 3 then
gamestate = "game"
end
end

--Function Classic Highscore
function highscorecheck()

highscorefile = io.open("highscore.txt","r")
highscore = highscorefile:read("*n")
highscorefile:close()

if round > highscore then
highscore = round
highscorefile = io.open("highscore.txt","w")
highscorefile:write(highscore)
highscorefile:close()
end
end