--Colors
white = Color.new(255,255,255)
red = Color.new(255,0,0)
green = Color.new(0,255,0)
blue = Color.new(0,0,255)
black = Color.new(0,0,0)

--Load Images
menubg = Image.load("images/menubg.png")

selector1 = Image.load("images/selector1.png")
selector2 = Image.load("images/selector2.png")
selector3 = Image.load("images/selector3.png")
selector4 = Image.load("images/selector4.png")

pause = Image.load("images/paused.png")

upgrades = Image.load("images/upgrades.png")

options = Image.load("images/options.png")

gameover = Image.load("images/gameover.png")

ship = Image.load("images/ship2.png")

bullet = Image.load("images/bullet.png")

enemy = Image.load("images/enemy.png")
enemy2 = Image.load("images/enemy2.png")
enemy3 = Image.load("images/enemy3.png")

hud = Image.load("images/hud.png")

background = Image.load("images/background.png")

--Variables
math.randomseed(os.time())
currentbullet = 1
currentbullet2 = currentbullet
oldpad = Controls.read()
ammo = 3
level = 1
round = 1
TotalRoundTime = 0
roundcounter = Timer.new()
direction = "right"
gamestate = "menu"
Select = 1
maxbullet = 3
maxEnemy = 3
doublebullet = "No"

--Player Table
Player = {}
Player.x = 30
Player.y = 60
Player.img = ship
Player.score = 0

--Bullet Table
Bullet = {}
Bullet[1] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[2] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[3] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[4] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[5] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[6] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[7] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[8] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[9] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[10] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[11] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[12] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[13] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[14] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}
Bullet[15] = {x = Player.x + 50,y = Player.y,img = bullet,active = false}


--Enemy Table
Enemy = {}
Enemy[1] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[2] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[3] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[4] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[5] = {x = 500,y = math.random(0,276),img = enemy,alive = true}
Enemy[6] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[7] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[8] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[9] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[10] = {x = 500,y = math.random(0,276),img = enemy2,alive = true}
Enemy[11] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[12] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[13] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[14] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}
Enemy[15] = {x = 500,y = math.random(0,276),img = enemy3,alive = true}

--Load Functions
dofile("functions.lua")

RoundSeconds = (TotalRoundTime/1000)

--Check Highscore
highscorefile = io.open("highscore.txt","r")
highscore = highscorefile:read("*n")
highscorefile:close()

--Main Loop
while true do
pad = Controls.read()
screen:clear()

if gamestate == "menu" then
startmenuload()
end

if gamestate == "options" then
screen:blit(0,0,options)
screen:blit(95,160,selector4)

screen:print(160,120,"Press Circle",white)

if pad:circle() and oldpad:circle() ~= pad:circle() then
gamestate = "menu"
end
end

if gamestate == "paused" then
pauseload()
end


if gamestate == "gameover" then
highscorecheck()

screen:blit(0,0,gameover)
screen:print(220,180,"Press O",white)
screen:print(220,200,"Round: "..round,white)
screen:print(220,220,"Highscore: "..highscore,white)

if pad:circle() and oldpad:circle() ~= pad:circle() then
gamestate = "menu"
end
end

if gamestate == "game" then
gameload()
end

if gamestate == "upgrade" then
upgradeload()
end

--Screenshot
if pad:select() then 
screen:save("screen1.png") 
end

if pad:triangle() then
break
end

screen.waitVblankStart()
screen.flip()
oldpad = pad
end