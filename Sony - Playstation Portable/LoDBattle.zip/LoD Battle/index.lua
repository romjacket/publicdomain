--Battle Monsters by Luke Ryan (titch.ryan)

gamestate=0
math.randomseed(os.time())

--load menu
function loadmenu()
menubg=Image.load("images/menu.png")
menubox=Image.load("images/menubox.png")
menuboxx=165
menuboxy=480
menuanimon=true
menuselected=1
tbox=Image.load("images/textbox.png")
tboxy=230
tboxx=30
tboxanimon=true
white=Color.new(255,255,255)
red=Color.new(255,0,0)
gamestate=1
end
-------------------------------------------------------
--menu
function drawmenu()

if Music.playing()==false then
Music.playFile("sfx/menu.s3m")
end

screen:blit(0,0,menubg)
screen:blit(menuboxx,menuboxy,menubox,true)

if menuanimon==true and menuboxy>100 then
screen:blit(menuboxx,menuboxy,menubox,true)
menuboxy=menuboxy-5
end

if menuboxy==100 then
screen:print(195,115,"Start Game!", white)
screen:print(196,135,"How to Play", white)
screen:print(212,155,"Credits", white)
screen:print(218,175,"Exit", white)
end

if menuselected==1 and menuboxy==100 then
screen:print(195,115,"Start Game!", red)
end

if menuselected==2 and menuboxy==100 then
screen:print(196,135,"How to Play", red)
end

if menuselected==3 and menuboxy==100 then
screen:print(212,155,"Credits", red)
end

if menuselected==4 and menuboxy==100 then
screen:print(218,175,"Exit", red)
end

if menuselected==5 then
menuselected=1
end

if menuselected==0 then
menuselected=3
end

if pad:down() and oldpad:down()~=pad:down() then
menuselected=menuselected+1
end

if pad:up() and oldpad:up()~=pad:up() then
menuselected=menuselected-1
end

if pad:cross() and oldpad:cross()~=pad:cross() and menuselected==1 then
Music.stop()
gamestate=2
end

if pad:cross() and oldpad:cross()~=pad:cross() and menuselected==2 then
tboxanimon=true
tboxy=230
gamestate=4
end

if pad:cross() and oldpad:cross()~=pad:cross() and menuselected==3 then
tboxanimon=true
tboxy=230
gamestate=5
end

if pad:cross() and oldpad:cross()~=pad:cross() and menuselected==4 then
System.Quit()
end

end

------------------------------------------------------------------------
--load game
function loadgame()

--unload menu
menubg=nil
menu=nil
collectgarbage()
----------------------

bg=Image.load("images/background.png")
GUI=Image.load("images/GUI.png")
white=Color.new(255,255,255)
arrow=Image.load("images/arrow.png")

Cwin=Image.load("images/Cwin.png")
Pwin=Image.load("images/Pwin.png")
drawimage=Image.load("images/draw.png")

atkanim={}
atkanim[0]=Image.load("images/atk0.png")
atkanim[1]=Image.load("images/atk1.png")
atkanim[2]=Image.load("images/atk2.png")
atkanim[3]=Image.load("images/atk3.png")
atkanim[4]=Image.load("images/atk4.png")

block=Image.load("images/block.png")

beep=Sound.load("sfx/beep.wav")
atksound=Sound.load("sfx/attack.wav")
defsound=Sound.load("sfx/defend.wav")
blocksound=Sound.load("sfx/block.wav")
hitsound=Sound.load("sfx/hit.wav")
victorysound=Sound.load("sfx/victory.wav")

player={number=20}

computer={number=20}

for n=1,20 do
player[n]={}
player[n].card=math.random(1,79)
computer[n]={}
computer[n].card=math.random(1,79)

player[n].image=Image.load("cards/" .. player[n].card .. ".png")

computer[n].image=Image.load("cards/" .. computer[n].card .. ".png")
end

hand={selected=1}
        for z=1,5 do
        hand[z]={}
	end
hand[1].image=player[1].image
hand[2].image=player[2].image
hand[3].image=player[3].image
hand[4].image=player[4].image
hand[5].image=player[5].image
hand[1].card=player[1].card
hand[2].card=player[2].card
hand[3].card=player[3].card
hand[4].card=player[4].card
hand[5].card=player[5].card

computerhand={selected=1}
	for k=1,5 do
	computerhand[k]={}
	end
computerhand[1].image=computer[1].image
computerhand[2].image=computer[2].image
computerhand[3].image=computer[3].image
computerhand[4].image=computer[4].image
computerhand[5].image=computer[5].image
computerhand[1].card=computer[1].card
computerhand[2].card=computer[2].card
computerhand[3].card=computer[3].card
computerhand[4].card=computer[4].card
computerhand[5].card=computer[5].card

for i=1,5 do
file=io.open("cards/"..computerhand[i].card..".txt", "r")
computerhand[i].attack=file:read("*n")
computerhand[i].defense=file:read("*n")
file:close()
end

for m=1,5 do
file=io.open("cards/"..hand[m].card..".txt", "r")
hand[m].attack=file:read("*n")
hand[m].defense=file:read("*n")
file:close()
end

playernext=5
computernext=5

choosecard=false
choosestance=false
firstcard=true
computerwon=false
playerwon=false
draw=false
comchange=true
nocard=true
cardanimon=true

endofgame=false
cardy=272
cardx=0
arrowx=28
arrowy=111
stancex=87
cwinx=-357
pwinx=-300
drawx=-168
speed=2

playOnce=true

gamestate=3
end
------------------------------------

--draw game
function drawgame()

if Music.playing()==false and endofgame==false then
Music.playFile("sfx/music.mod")
end

screen:blit(0,0,bg)
screen:blit(0,0,GUI,true)
screen:print(18,12,"You",white)
screen:print(18,22,"Cards:"..player.number,white)
screen:print(391,12,"Comp",white)
screen:print(391,22,"Cards:"..computer.number,white)

if choosestance==true then

if firstcard==false and nocard==false then
screen:blit(298,66,computerhand[computerhand.selected].image)
end

screen:blit(67,66,hand[hand.selected].image)
screen:blit(stancex,170,arrow,true)

if pad:left() and oldpad:left()~=pad:left() then
local sound=atksound
voice=sound:play()
def=false
stancex=87
attk=true
end

if pad:right() and oldpad:right()~=pad:right() then
local sound=defsound
voice=sound:play()
attk=false
stancex=127
def=true
end

if pad:cross() and oldpad:cross()~=pad:cross() then

if stancex==87 then
def=false
attk=true
end

if stancex==127 then
attk=false
def=true
end

choosestance=false
computerturn=true
end

end


if cardanimon==true then

if firstcard==false and nocard==false then
screen:blit(298,66,computerhand[computerhand.selected].image)
end

if hand[1]~=nil then
screen:blit(0,cardy,hand[1].image)
end

if hand[2]~=nil then
screen:blit(96,cardy,hand[2].image)
end

if hand[3]~=nil then
screen:blit(192,cardy,hand[3].image)
end	

if hand[4]~=nil then
screen:blit(288,cardy,hand[4].image)
end

if hand[5]~=nil then
screen:blit(384,cardy,hand[5].image)
end

if cardy>131 then
cardy=cardy-3
end

if cardy==131 then
cardanimon=false
choosecard=true
end

end

if cardanimoff==true then

if firstcard==false and nocard==false then
screen:blit(298,66,computerhand[computerhand.selected].image)
end

screen:blit(67,66,hand[hand.selected].image)

if hand[1]~=nil and hand.selected~=1 then
screen:blit(0,cardy,hand[1].image)
end

if hand[2]~=nil and hand.selected~=2 then
screen:blit(96,cardy,hand[2].image)
end

if hand[3]~=nil and hand.selected~=3 then
screen:blit(192,cardy,hand[3].image)
end	

if hand[4]~=nil and hand.selected~=4 then
screen:blit(288,cardy,hand[4].image)
end

if hand[5]~=nil and hand.selected~=5 then
screen:blit(384,cardy,hand[5].image)
end

if cardy<272 then
cardy=cardy+3
end

if cardy==272 then
cardanimoff=false
choosestance=true
end

end

if choosecard==true then

if firstcard==false and nocard==false then
screen:blit(298,66,computerhand[computerhand.selected].image)
end

if hand[1]~=nil then
screen:blit(0,131,hand[1].image)
end

if hand[2]~=nil then
screen:blit(96,131,hand[2].image)
end

if hand[3]~=nil then
screen:blit(192,131,hand[3].image)
end	

if hand[4]~=nil then
screen:blit(288,131,hand[4].image)
end

if hand[5]~=nil then
screen:blit(384,131,hand[5].image)
end

screen:blit(arrowx,arrowy,arrow,true)

if pad:left() and oldpad:left()~=pad:left() and hand.selected>=0 then
local sound=beep
voice=sound:play()
arrowx=arrowx-96
hand.selected=hand.selected-1
end

if pad:right() and oldpad:right()~=pad:right() and hand.selected<=6 then
local sound=beep
voice=sound:play()
arrowx=arrowx+96
hand.selected=hand.selected+1
end

if hand.selected==0 then
hand.selected=5
arrowx=412
end

if hand.selected==6 then
hand.selected=1
arrowx=28
end

if pad:cross() and oldpad:cross()~=pad:cross() and hand[hand.selected]~=nil then
choosecard=false
cardanimoff=true
end

if pad:triangle() then
screen:blit(0,0,bg)
screen:blit(0,0,GUI,true)
screen:print(18,12,"You",white)
screen:print(18,22,"Cards:"..player.number,white)
screen:print(391,12,"Comp",white)
screen:print(391,22,"Cards:"..computer.number,white)
	if firstcard==false and nocard==false then
	screen:blit(298,66,computerhand[computerhand.selected].image)
	end
end

end

if computerturn==true and comchange==true then
screen:blit(67,66,hand[hand.selected].image)

if firstcard==true then
	for j=1,5 do
		if computerhand[j].attack > computerhand[computerhand.selected].attack then
		computeratk=true
		computerhand.selected=j
		end
	end
end

if computer.number>4 then
computerhand.selected=0
	for j=1,5 do
		if attk==true then
			if computerhand[j].attack > hand[hand.selected].attack then
			computeratk=true
			computerhand.selected=j
			else
			if computerhand[j].defense > hand[hand.selected].attack then
			computerdef=true
			computerhand.selected=j
			else
			if computerhand.selected==0 then
			computeratk=true
			computerhand.selected=math.random(1,5)
			end
			end
			end
		end

		if def==true then
			if computerhand[j].attack > hand[hand.selected].defense then
			computeratk=true
			computerhand.selected=j
			else
			if computerhand[j].defense > hand[hand.selected].defense then
			computerdef=true
			computerhand.selected=j
			else
			if computerhand.selected==0 then
			computeratk=true
			computerhand.selected=math.random(1,5)
			end
			end
			end
		end
	end
end

if computer.number<=4 then
computerhand.selected=0
	if computerhand[1]~=nil then
		if attk==true then
			if computerhand[1].attack > hand[hand.selected].attack then
			computeratk=true
			computerhand.selected=1
			else
			if computerhand[1].defense > hand[hand.selected].attack then
			computerdef=true
			computerhand.selected=1
			end
			end
		end

		if def==true then
			if computerhand[1].attack > hand[hand.selected].defense then
			computeratk=true
			computerhand.selected=1
			else
			if computerhand[1].defense > hand[hand.selected].defense then
			computerdef=true
			computerhand.selected=1
			end
			end
		end
	end
	if computerhand[2]~=nil then
		if attk==true then
			if computerhand[2].attack > hand[hand.selected].attack then
			computeratk=true
			computerhand.selected=2
			else
			if computerhand[2].defense > hand[hand.selected].attack then
			computerdef=true
			computerhand.selected=2
			end
			end
		end

		if def==true then
			if computerhand[2].attack > hand[hand.selected].defense then
			computeratk=true
			computerhand.selected=2
			else
			if computerhand[2].defense > hand[hand.selected].defense then
			computerdef=true
			computerhand.selected=2
			end
			end
		end
	end
	if computerhand[3]~=nil then
		if attk==true then
			if computerhand[3].attack > hand[hand.selected].attack then
			computeratk=true
			computerhand.selected=3
			else
			if computerhand[3].defense > hand[hand.selected].attack then
			computerdef=true
			computerhand.selected=3
			end
			end
		end

		if def==true then
			if computerhand[3].attack > hand[hand.selected].defense then
			computeratk=true
			computerhand.selected=3
			else
			if computerhand[3].defense > hand[hand.selected].defense then
			computerdef=true
			computerhand.selected=3
			end
			end
		end
	end
	if computerhand[4]~=nil then
		if attk==true then
			if computerhand[4].attack > hand[hand.selected].attack then
			computeratk=true
			computerhand.selected=4
			else
			if computerhand[4].defense > hand[hand.selected].attack then
			computerdef=true
			computerhand.selected=4
			end
			end
		end

		if def==true then
			if computerhand[4].attack > hand[hand.selected].defense then
			computeratk=true
			computerhand.selected=4
			else
			if computerhand[4].defense > hand[hand.selected].defense then
			computerdef=true
			computerhand.selected=4
			end
			end
		end
	end
	if computerhand[5]~=nil then
		if attk==true then
			if computerhand[5].attack > hand[hand.selected].attack then
			computeratk=true
			computerhand.selected=5
			else
			if computerhand[5].defense > hand[hand.selected].attack then
			computerdef=true
			computerhand.selected=5
			end
			end
		end

		if def==true then
			if computerhand[5].attack > hand[hand.selected].defense then
			computeratk=true
			computerhand.selected=5
			else
			if computerhand[5].defense > hand[hand.selected].defense then
			computerdef=true
			computerhand.selected=5
			end
			end
		end
	end
	if computerhand.selected==0 then
		while true do
		ranNumber=math.random(1,5)
			if computerhand[ranNumber]~=nil then
			computerhand.selected=ranNumber
			computeratk=true
			break
			end
		end
	end
end

firstcard=false
computerturn=false
battle=true
end


if computerturn==true and comchange==false then
computerturn=false
battle=true
end


if battle==true then

	if attk==true and computeratk==true then
		if hand[hand.selected].attack > computerhand[computerhand.selected].attack then
			for g=0,4 do
			local sound=hitsound
			voice=sound:play()
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(298,66,atkanim[g],true)
			screen:flip()
			screen.waitVblankStart(10)
			end
			playerwon=true
			battle=false
		else
		if hand[hand.selected].attack < computerhand[computerhand.selected].attack then
			for g=0,4 do
			local sound=hitsound
			voice=sound:play()
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(67,66,atkanim[g],true)
			screen:flip()
			screen.waitVblankStart(10)
			end
			computerwon=true
			battle=false
		else
		if hand[hand.selected].attack == computerhand[computerhand.selected].attack then
			for g=0,4 do
			local sound=hitsound
			voice=sound:play()
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(298,66,atkanim[g],true)
			screen:blit(67,66,atkanim[g],true)
			screen:flip()
			screen.waitVblankStart(10)
			end
			draw=true
			battle=false
		end
		end
		end
	else

	if def==true and computeratk==true then
		if hand[hand.selected].defense > computerhand[computerhand.selected].attack then
			for g=0,4 do
				if g==0 then
				local sound=blocksound
				voice=sound:play()
				end
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(298,66,block,true)
			screen:flip()
			screen.waitVblankStart(10)
			end
			playerwon=true
			battle=false
		else
		if hand[hand.selected].defense < computerhand[computerhand.selected].attack then
			for g=0,4 do
			local sound=hitsound
			voice=sound:play()
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(67,66,atkanim[g],true)
			screen:flip()
			screen.waitVblankStart(10)
			end
			computerwon=true
			battle=false
		else
		if hand[hand.selected].defense == computerhand[computerhand.selected].attack then
			for g=0,4 do
			local sound=hitsound
			voice=sound:play()
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(298,66,block,true)
			screen:blit(67,66,atkanim[g],true)
			local sound=blocksound
			voice=sound:play()
			screen:flip()
			screen.waitVblankStart(10)
			end
			draw=true
			battle=false
		end
		end
		end
	else
	if def==true and computerdef==true then
			if g==0 then
			local sound=blocksound
			voice=sound:play()
			end
		screen:blit(67,66,hand[hand.selected].image)
		screen:blit(298,66,computerhand[computerhand.selected].image)
		screen:blit(298,66,block,true)
		screen:blit(67,66,block,true)
		screen:flip()
		screen.waitVblankStart(10)
		def=false
		draw=true
	else
	if attk==true and computerdef==true then
		if hand[hand.selected].attack > computerhand[computerhand.selected].defence then
			for g=0,4 do
			local sound=hitsound
			voice=sound:play()
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(298,66,atkanim[g],true)
			screen:flip()
			screen.waitVblankStart(10)
			end
			playerwon=true
			battle=false
		else
		if hand[hand.selected].attack < computerhand[computerhand.selected].defence then
				if g==0 then
				local sound=blocksound
				voice=sound:play()
				end
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(67,66,block,true)
			screen:flip()
			screen.waitVblankStart(10)
			computerwon=true
			battle=false
		else
		if hand[hand.selected].attack == computerhand[computerhand.selected].defense then
			for g=0,4 do
			local sound=hitsound
			voice=sound:play()
			screen:blit(67,66,hand[hand.selected].image)
			screen:blit(298,66,computerhand[computerhand.selected].image)
			screen:blit(298,66,atkanim[g],true)
			screen:blit(67,66,block,true)
				if g==0 then
				local sound=blocksound
				voice=sound:play()
				end
			screen:flip()
			screen.waitVblankStart(10)
			end
			draw=true
			battle=false
		end
		end
		end
	end
	end
	end
	end
end

if playerwon==true then
computer.number=computer.number-1
computernext=computernext+1

	if computerdef==true then
	computerdef=false
	end

	if computeratk==true then
	computeratk=false
	end

	if computer.number>4 then
	computerhand[computerhand.selected].image=computer[computernext].image
	computerhand[computerhand.selected].card=computer[computernext].card
	
	file=io.open("cards/"..computerhand[computerhand.selected].card..".txt", "r")
	computerhand[computerhand.selected].attack=file:read("*n")
	computerhand[computerhand.selected].defense=file:read("*n")
	file:close()

	end

	if computer.number<=4 and computer.number>0 then
	computerhand[computerhand.selected]=nil

		if computerhand[1]~=nil then
		file=io.open("cards/"..computerhand[1].card..".txt", "r")
		computerhand[1].attack=file:read("*n")
		computerhand[1].defense=file:read("*n")
 		file:close()
		end
		
		if computerhand[2]~=nil then
		file=io.open("cards/"..computerhand[2].card..".txt", "r")
		computerhand[2].attack=file:read("*n")
		computerhand[2].defense=file:read("*n")
 		file:close()
		end

		if computerhand[3]~=nil then
		file=io.open("cards/"..computerhand[3].card..".txt", "r")
		computerhand[3].attack=file:read("*n")
		computerhand[3].defense=file:read("*n")
 		file:close()	
		end

		if computerhand[4]~=nil then
		file=io.open("cards/"..computerhand[4].card..".txt", "r")
		computerhand[4].attack=file:read("*n")
		computerhand[4].defense=file:read("*n")
 		file:close()
		end

		if computerhand[5]~=nil then
		file=io.open("cards/"..computerhand[5].card..".txt", "r")
		computerhand[5].attack=file:read("*n")
		computerhand[5].defense=file:read("*n")
 		file:close()
		end
	end

	if computer.number>0 then
	nocard=true
	comchange=true
	choosestance=true
	end

	if computer.number==0 then
	endofgame=true
	end

playerwon=false
end

if computerwon==true then
player.number=player.number-1
playernext=playernext+1

	if attk==true then
	attk=false
	end

	if def==true then
	def=false
	end

	if player.number>4 then
	hand[hand.selected].image=player[playernext].image
	hand[hand.selected].card=player[playernext].card

	file=io.open("cards/"..hand[hand.selected].card..".txt", "r")
	hand[hand.selected].attack=file:read("*n")
	hand[hand.selected].defense=file:read("*n")
	file:close()
	end

	if player.number<=4 and player.number>0 then
	hand[hand.selected]=nil
	end

	if player.number>0 then
	nocard=false
	comchange=false
	cardanimon=true
	end

	if player.number==0 then
	endofgame=true
	end

computerwon=false
end

if draw==true then
player.number=player.number-1
playernext=playernext+1
computer.number=computer.number-1
computernext=computernext+1

	if attk==true then
	attk=false
	end

	if def==true then
	def=false
	end

	if computerdef==true then
	computerdef=false
	end

	if computeratk==true then
	computeratk=false
	end

	if player.number>4 and computer.number>4 then
	hand[hand.selected].image=player[playernext].image
	hand[hand.selected].card=player[playernext].card
	computerhand[computerhand.selected].image=computer[computernext].image
	computerhand[computerhand.selected].card=computer[computernext].card

	
	file=io.open("cards/"..hand[hand.selected].card..".txt", "r")
	hand[hand.selected].attack=file:read("*n")
	hand[hand.selected].defense=file:read("*n")
	file:close()

	file=io.open("cards/"..computerhand[computerhand.selected].card..".txt", "r")
	computerhand[computerhand.selected].attack=file:read("*n")
	computerhand[computerhand.selected].defense=file:read("*n")
	file:close()

	end

	if computer.number<=4 and computer.number>0 then
	computerhand[computerhand.selected]=nil
			
		if computerhand[1]~=nil then
		file=io.open("cards/"..computerhand[1].card..".txt", "r")
		computerhand[1].attack=file:read("*n")
		computerhand[1].defense=file:read("*n")
 		file:close()
		end

		
		if computerhand[2]~=nil then
		file=io.open("cards/"..computerhand[2].card..".txt", "r")
		computerhand[2].attack=file:read("*n")
		computerhand[2].defense=file:read("*n")
 		file:close()
		end

		if computerhand[3]~=nil then
		file=io.open("cards/"..computerhand[3].card..".txt", "r")
		computerhand[3].attack=file:read("*n")
		computerhand[3].defense=file:read("*n")
 		file:close()	
		end
		
		if computerhand[4]~=nil then
		file=io.open("cards/"..computerhand[4].card..".txt", "r")
		computerhand[4].attack=file:read("*n")
		computerhand[4].defense=file:read("*n")
 		file:close()
		end

		if computerhand[5]~=nil then
		file=io.open("cards/"..computerhand[5].card..".txt", "r")
		computerhand[5].attack=file:read("*n")
		computerhand[5].defense=file:read("*n")
 		file:close()
		end
	end

	if player.number<=4 and player.number>0 then
	hand[hand.selected]=nil
	end

	if player.number>0 and computer.number>0 then
	nocard=true
	comchange=true
	cardanimon=true
	end
	
	if player.number==0 or computer.number==0 then
	endofgame=true
	end


draw=false
end

if endofgame==true and player.number<=0 and computer.number~=0 and cwinx<40 then
Music.stop()
screen:blit(cwinx,101,Cwin,true)
cwinx=cwinx+speed
speed=speed+5
end


if endofgame==true and player.number~=0 and computer.number<=0 and pwinx<90 then
Music.stop()
screen:blit(pwinx,101,Pwin,true)
pwinx=pwinx+speed
speed=speed+5
end

if endofgame==true and player.number<=0 and computer.number<=0 and drawx<168 then
Music.stop()
screen:blit(drawx,101,drawimage,true)
drawx=drawx+speed
speed=speed+5
end

if endofgame==true and player.number<=0 and computer.number~=0 and cwinx>=40 then
            if playOnce==true then
            Music.playFile("sfx/gameover.mod")
	    playOnce=false
            end
screen:blit(cwinx,101,Cwin,true)
screen:print(180,180,"Press START for menu",white)
                          if pad:start() and oldpad:start()~=pad:start() then
                          Music.stop()
                          bg=nil
                          GUI=nil
                          white=nil
                          arrow=nil
                          Cwin=nil
                          Pwin=nil
                          drawimage=nil
                          atkanim=nil
                          block=nil
                          beep=nil
                          atksound=nil
                          defsound=nil
                          blocksound=nil
                          hitsound=nil
                          collectgarbage()
                          gamestate=0
                          end
end


if endofgame==true and player.number~=0 and computer.number<=0 and pwinx>=90 then
            if playOnce==true then
            local sound=victorysound
            voice=sound:play()
	    playOnce=false
            end
screen:blit(pwinx,101,Pwin,true)
screen:print(180,180,"Press START for menu",white)
                          if pad:start() and oldpad:start()~=pad:start() then
                          voice:stop()
                          bg=nil
                          GUI=nil
                          white=nil
                          arrow=nil
                          Cwin=nil
                          Pwin=nil
                          drawimage=nil
                          atkanim=nil
                          block=nil
                          beep=nil
                          atksound=nil
                          defsound=nil
                          blocksound=nil
                          hitsound=nil
                          collectgarbage()
                          gamestate=0
                          end
end


if endofgame==true and player.number<=0 and computer.number<=0 and drawx>=168 then
            if playOnce==true then
            Music.playFile("sfx/gameover.mod")
	    playOnce=false
            end
screen:blit(drawx,101,drawimage,true)
screen:print(180,180,"Press START for menu",white)
                          if pad:start() and oldpad:start()~=pad:start() then
                          Music.stop()
                          bg=nil
                          GUI=nil
                          white=nil
                          arrow=nil
                          Cwin=nil
                          Pwin=nil
                          drawimage=nil
                          atkanim=nil
                          block=nil
                          beep=nil
                          atksound=nil
                          defsound=nil
                          blocksound=nil
                          hitsound=nil
                          collectgarbage()
                          gamestate=0
                          end
end

end
-------------------------------------------------------------------------

-- how to play
function htp()

screen:blit(0,0,menubg)
screen:blit(tboxx,tboxy,tbox,true)

if tboxanimon==true and tboxy>21 then
screen:blit(tboxx,tboxy,tbox,true)
tboxy=tboxy-5
end

if tboxy<=21 then
tboxanimon=false

screen:print(50,35,"Controls:",white)
screen:print(50,45,"d-pad= move arrow",white)
screen:print(50,55,"X= select",white)

screen:print(50,75,"On Your Turn:",white)
screen:print(50,85,"Choose card from hand to play",white)
screen:print(50,95,"Choose Stance",white)

screen:print(50,115,"Card with highest points wins!",white)
screen:print(50,125,"(depending on stance selcted)",white)

screen:print(50,145,"Winning:",white)
screen:print(50,155,"Defeat all the computers cards until he/she",white)
screen:print(50,165,"has no cards left.",white)

screen:print(50,235,"press TRIANGLE for menu",white)

if pad:triangle() and oldpad:triangle()~=pad:triangle() then
gamestate=1
end

end

end

---------------------------------------------------------
-------------------------------------------------------------------------
-- credits
function credits()

screen:blit(0,0,menubg)
screen:blit(tboxx,tboxy,tbox,true)

if tboxanimon==true and tboxy>21 then
screen:blit(tboxx,tboxy,tbox,true)
tboxy=tboxy-5
end

if tboxy<=21 then
tboxanimon=false


screen:print(50,35,"Thanks to:",white)

screen:print(50,55,"DCEMU for hosting",white)
screen:print(50,65,"QJ for hosting",white)
screen:print(50,75,"Evilmana for tutorials, coding community",white)
screen:print(50,85,"Cools for lua mod4",white)
screen:print(50,95,"CoolText for logo generator",white)
screen:print(50,105,"GIMP creators",white)
screen:print(50,115,"FlashKit for sfx",white)
screen:print(50,125,"The Mod Archive for music",white)
screen:print(50,135,"Konami for Yu-Gi-Oh cards",white)

screen:print(50,155,"My Girlfriend <3",white)

screen:print(50,235,"press TRIANGLE for menu",white)

if pad:triangle() and oldpad:triangle()~=pad:triangle() then
gamestate=1
end

end

end
---------------------------------------------------------

--program loop
while true do
pad=Controls.read()
screen:clear()

if gamestate==0 then
loadmenu()
end

if gamestate==1 then
drawmenu()
end

if gamestate==2 then
loadgame()
end

if gamestate==3 then
drawgame()
end

if gamestate==4 then
htp()
end

if gamestate==5 then
credits()
end

screen.waitVblankStart()
screen:flip()
oldpad=pad
n=1
g=1
i=1
m=1
z=1
end