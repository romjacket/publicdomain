red=Color.new(255,0,0)
white=Color.new(255,255,255)
a = math.random(50,430)
b=math.random(50,430)

f=math.random(-5,5)
g=math.random(-5,5)
gametimer=Timer.new()
time=20
gametimer:start()
nes=Font.load("Pretendo.ttf")
nes:setPixelSizes(25,17)
background=Image.load("Images/background2.PNG")
gun=Image.load("Images/gun2.PNG")
Gun={x=305,y=198}
BirdShot=Image.load("Images/Birdshot.png")
Background2=Image.load("Images/duckHuntArea.png")
BirdShot2=Image.load("Images/Birdshot2.png")
birdKill= Image.load("Images/kill.png")
crosshairs=Image.load("Images/crossHairs.png")
startMenu=Image.load("Images/startmenu.png")
DogDuck=Image.load("Images/DogDuck.png")
Dogjump1=Image.load("Images/DogJump1.png")
Dogjump2=Image.load("Images/DogJump2.png")
pointer=Image.load("Images/pointer.png")
bullet1=Image.load("Images/Bullet1.png")
bullet2=Image.load("Images/Bullet2.png")
bullet3=Image.load("Images/Bullet3.png")
bullet4=Image.load("Images/Bullet4.png")
bullet5=Image.load("Images/Bullet5.png")
bullet6=Image.load("Images/Bullet6.png")
bullet7=Image.load("Images/Bullet7.png")
bullet8=Image.load("Images/Bullet8.png")
Pointer={x=119,y=199}
Crosshairs={x=240,y=130}
Theimg={x=a,y=205,width=35,height=26,xspeed=0,yspeed=0}
Theimg2={x=b,y=205,width=35,height=26,xspeed=f,yspeed=g}
Dogimg={x=0,y=230,xspeed=2,yspeed=0}
Bullet1={x=10,y=10,xspeed=math.random(-7,7),yspeed=math.random(-7,7),width = 15,height = 15}
Bullet2={x=10,y=260,xspeed=math.random(-7,7),yspeed=math.random(-7,7),width = 15,height = 15}
Bullet3={x=470,y=10,xspeed=math.random(-7,7),yspeed=math.random(-7,7),width = 15,height = 15}
Bullet4={x=470,y=260,xspeed=math.random(-7,7),yspeed=math.random(-7,7),width = 15,height = 15}
shotBlocker=Image.load("Images/shotBlock.png")
gamestate= "gamestart"
animtimer=0
shots=0
kills=0
kills2=0
kills3=0
kills4=0
kills5=0
score=0
Bird=0
Bird2=0
shotTimer=0
shotTimer2=0
round = 1
dogpos=.75
object2 = bullet1
BirdKilled= false
BirdKilled2= false
BirdBlit = true
BirdBlit2 = true
dobBlit3 = true
dogBlit = true
dogBlit2 = true
dogBlit3 = true
dogBlit4 = true
noShot = true
BulletTimer = 0
oldpad=Controls.read()
BirdMovement = {
Image.load("Images/Bird1a.png"),
Image.load("Images/Bird2a.png"),
Image.load("Images/Bird3a.png"),
Image.load("Images/Bird4a.png"),
}
BirdMovement2 = {
Image.load("Images/Bird5a.png"),
Image.load("Images/Bird6a.png"),
Image.load("Images/Bird7a.png"),
Image.load("Images/Bird8a.png"),
}
BirdMovement3 = {
Image.load("Images/Bird1b.png"),
Image.load("Images/Bird2b.png"),
Image.load("Images/Bird3b.png"),
Image.load("Images/Bird4b.png"),
}
BirdMovement4 = {
Image.load("Images/Bird5b.png"),
Image.load("Images/Bird6b.png"),
Image.load("Images/Bird7b.png"),
Image.load("Images/Bird8b.png"),
}
BirdMovement5 = {
Image.load("Images/Bird9.png"),
Image.load("images/Bird10.png"),
Image.load("Images/Bird9b.png"),
Image.load("images/Bird10b.png"),
}
dogMove = {
Image.load("Images/Dog2.png"),
Image.load("Images/Dog3.png"),
Image.load("Images/Dog4.png"),
Image.load("Images/Dog5.png"),
Image.load("Images/Dog6.png"),
Image.load("Images/Dog7.png"),
Image.load("Images/Dog8.png"),
}
dogSniff = {
Image.load("Images/Dogsniff1.png"),
Image.load("Images/Dog2.png"),
Image.load("Images/Dogsniff1.png"),
Image.load("Images/Dog2.png"),
}

function bulletMovement(object)
screen:blit(object.x,object.y,object2)
object.x= object.x+ object.xspeed
object.y=object.y+object.yspeed
	if object.xspeed > 0 and object.yspeed == 0 then
	object2 = bullet2
	end
	if object.xspeed < 0 and object.yspeed == 0 then
	object2 = bullet4
	end
	if object.xspeed ==0 and object.yspeed > 0 then
	object2 = bullet3
	end
	if object.xspeed == 0 and object.yspeed < 0 then
	object2 = bullet1
	end
	if object.xspeed > 0 and object.yspeed > 0 then
	object2 = bullet6
	end
	if object.xspeed < 0 and object.yspeed > 0 then
	object2 = bullet7
	end
	if object.xspeed >0 and object.yspeed < 0 then
	object2 = bullet5
	end
	if object.xspeed < 0 and object.yspeed < 0 then
	object2 = bullet8
	end
	end
function BulletBird(object,object2)
	if (object2.x + object2.width > object.x) and (object2.x < object.x + object.width) and (object2.y + object2.height > object.y) and (object2.y < object.y + object.height) then
	gamestate = "gamestart"
	end
end
function bulletCollision(object)
	if object.x > 480 then
	object.x = object.x -480
	end
	if object.x < 0 then
	object.x = object.x + 480
	end
	if object.y > 272 then
	object.y = object.y - 272
	end
	if object.y < 0 then
	object.y = object.y + 272
	end
	if object.x >479 or object.x < 1 then
	object.yspeed = math.random(-7,7)
	end
	if object.y >271 or object.y < 1 then
	object.xspeed = math.random(-7,7)
	end
end
function dogMovement()
Dogimg.x = Dogimg.x +Dogimg.xspeed
Dogimg.y = Dogimg.y + Dogimg.yspeed
	dogpos=dogpos+.025
	if dogpos >= 1 and dogpos <= 2 then
		Dogimg.xspeed=0
		dogimg=animate7(dogSniff,4)
	end
	if dogpos >2 and dogpos < 3 then
		Dogimg.xspeed = 2
		dogimg=animate6(dogMove,1)
	end
	if dogpos >=3 and dogpos <3.5 and dogBlit2 == true then
		Dogimg.xspeed = 0
		dogBlit = false
		screen:blit(Dogimg.x,Dogimg.y-8,DogDuck)
	end
	if dogpos >= 3.5 and dogpos < 4.5 and dogBlit3 == true then
		Dogimg.xspeed = 1
		Dogimg.yspeed = -1
		dogBlit2 = false
		screen:blit(Dogimg.x+8,Dogimg.y - 10,Dogjump1)
	end
	if dogpos >=4.5 and dogpos <=5 and dogBlit4 == true then
		Dogimg.xspeed = 1
		Dogimg.yspeed = 1
		dogBlit3 = false
		screen:blit(Dogimg.x+4,Dogimg.y, Dogjump2)
	end
	if dogpos > 5 then
		dogBlit4 = false
	end
end
function gameStart()
pad = Controls.read()
	screen:clear()
	screen:blit(0,0,startMenu)
	screen:blit(Pointer.x,Pointer.y,pointer)
	if pad:down() and not oldpad:down() then
	Pointer.y = 224
	end
	if pad:up() and not oldpad:up() then
	Pointer.y = 199
	end
	if pad:cross() and Pointer.y == 199 then
	round = 1
	time = 20
	shots=0
	dogBlit3 = true
	BirdKilled = false
	BirdKilled2 = false
	BirdBlit = true
	BirdBlit2 = true
	noShot = true
	Bird = 0
	Bird2 = 0
	kills = 0
	kills2 = 0
	kills3 = 0
	kills4 = 0
	kills5=0
	score = 0
	shotTimer=0
	shotTimer2=0
	Dogimg.x = 0
	Dogimg.y = 230
	Dogimg.xspeed=0
	Dogimg.yspeed=0
	dogpos = .75
	dogBlit = true
	dogBlit2 = true
	dogBlit3 = true
	dogBlit4 = true
	Theimg.x = math.random(50,430)
	Theimg.y=205
	Theimg.xspeed = math.random(-5,5)
	Theimg.yspeed = math.random(-5,5)
	Theimg2.x = math.random(50,430)
	Theimg2.y = 205
	Theimg2.xspeed = math.random(-5,5)
	Theimg2.yspeed = math.random(-5,5)
	gamestate = "playing"
	end
	if pad:cross() and Pointer.y == 224 then
	gamestate = "gamestart2"
	Bullet1.x = 10
	Bullet1.y = 10
	Bullet2.x = 10
	Bullet2.y = 260
	Bullet3.x = 470
	Bullet3.y = 10
	Bullet4.x = 470
	Bullet4.y = 260
	BulletTimer=0
	end
end
function birdControl()
Theimg.x = Theimg.x + Theimg.xspeed
Theimg.y = Theimg.y + Theimg.yspeed
	pad=Controls.read()
	if pad:right() then
	Theimg.xspeed = 3
	Theimg.yspeed = 0
	theimg=animate(BirdMovement,2)
	end
	if pad:left() then
	Theimg.xspeed = -3
	Theimg.yspeed = 0
	theimg=animate3(BirdMovement3,2)
	end
	if pad:up() then
	Theimg.yspeed=-3
	Theimg.xspeed=0
	theimg=animate5(BirdMovement5,2)
	end
	if pad:up() and pad:right() then
	Theimg.xspeed=3
	Theimg.yspeed=-3
	theimg=animate2(BirdMovement2,2)
	end
	if pad:up() and pad:left() then
	Theimg.xspeed=-3
	Theimg.yspeed=-3
	theimg=animate4(BirdMovement4,2)
	end
	if pad:down() then
	Theimg.yspeed = 3
	Theimg.xspeed = 0
	end
	if pad:down() and pad:right() then
	Theimg.yspeed = 3
	Theimg.xspeed = 3
	end
	if pad:down() and pad:left() then
	Theimg.yspeed = 3
	Theimg.xspeed = -3
	end
end
function roundOver()
pad = Controls.read()
	if time == 0 or shooting == false or round >= 6 then
	Theimg.yspeed = -6
	Theimg.xspeed = 0
	Theimg2.yspeed = -6
	Theimg2.xspeed = 0
	end
	if round >= 6 then
	screen:clear()
	screen:fontPrint(nes,240,130,"GAME OVER",red)
	screen:fontPrint(nes,240,150,"Press X to Restart",red)
	screen:fontPrint(nes,10,20,"Score:" .. score,red)
		if score == 5000 and round == 6 then
		screen:fontPrint(nes,10,33,"PERFECT",red)
		end
		if pad:cross() and not oldpad:cross() then
	round = 1
	time = 20
	noShot = true
	shots=0
	shotTimer=0
	shotTimer2=0
	kills= 0
	kills2=0
	kills3=0
	kills4=0
	kills5=0
	score = 0
	BirdBlit = true
	BirdBlit2 = true
	dogBlit3 = true
	BirdKilled = false
	BirdKilled2 = false
	BirdBlit = true
	BirdBlit2 = true
	Dogimg.x = 0
	Dogimg.y = 230
	dogpos = .75
	dogBlit = true
	dogBlit2 = true
	dogBlit3 = true
	dogBlit4 = true
	Dogimg.xspeed=0
	Dogimg.yspeed=0
	Bird = 0
	Bird2 = 0
	Theimg.x = math.random(50,430)
	Theimg.y=205
	Theimg.xspeed = math.random(-5,5)
	Theimg.yspeed = math.random(-5,5)
	Theimg2.x = math.random(50,430)
	Theimg2.y = 205
	Theimg2.xspeed = math.random(-5,5)
	Theimg2.yspeed = math.random(-5,5)
		end
	end
end
function roundOverWin()
	if BirdBlit == false and BirdBlit2 == false then
	time = 20
	round = round + 1
	shots=0
	shotTimer=0
	shotTimer2=0
	BirdKilled = false
	BirdKilled2 = false
	dogBlit3 = true
	BirdBlit = true
	BirdBlit2= true
	Bird = 0
	Bird2 = 0
	noShot = true
	Theimg.x = math.random(50,430)
	Theimg.y=205
	Theimg.xspeed = math.random(-5,5)
	Theimg.yspeed = math.random(-5,5)
	Theimg2.x = math.random(50,430)
	Theimg2.y = 205
	Theimg2.xspeed = math.random(-5,5)
	Theimg2.yspeed = math.random(-5,5)
	end
end
function shoot()
pad=Controls.read()
shooting = true
   if pad:r() and not oldpad:r() and shooting == true then
   shots=shots+1
   end
   if shots >= 3 and shotTimer >= 2 then
   shooting = false
   shots=3
   end
   if shots >= 3 then
   shotTimer2 = shotTimer2 + .25
   end
   if shotTimer2 == 1 then
   noShot = false
   end
   if shots >= 1 then
   screen:blit(23,221,shotBlocker)
   end
   if shots >= 2 then
   screen:blit(35,221,shotBlocker)
   end
   if shots >= 3 then
   screen:blit(49,221,shotBlocker)
   shotTimer=shotTimer+.045
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg.x) and (Crosshairs.x +11 < Theimg.x + Theimg.width) and (Crosshairs.y +11 > Theimg.y) and (Crosshairs.y +11 < Theimg.y + Theimg.height) and round == 1 and noShot == true then
   kills=kills+1
   score = score + 500
   Bird=Bird+1
   BirdKilled = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg2.x) and (Crosshairs.x +11 < Theimg2.x + Theimg2.width) and (Crosshairs.y +11 > Theimg2.y) and (Crosshairs.y +11 < Theimg2.y + Theimg2.height) and round == 1 and noShot == true then
   kills=kills+1
   score = score + 500
   Bird2=Bird2+1
   BirdKilled2 = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg.x) and (Crosshairs.x +11 < Theimg.x + Theimg.width) and (Crosshairs.y +11 > Theimg.y) and (Crosshairs.y +11 < Theimg.y + Theimg.height) and round == 2 and noShot == true then
   kills2=kills2+1
   score = score + 500
   Bird=Bird+1
   BirdKilled = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg2.x) and (Crosshairs.x +11 < Theimg2.x + Theimg2.width) and (Crosshairs.y +11 > Theimg2.y) and (Crosshairs.y +11 < Theimg2.y + Theimg2.height) and round == 2 and noShot == true then
   kills2=kills2+1
   score = score + 500
   Bird2=Bird2+1
   BirdKilled2 = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg.x) and (Crosshairs.x +11 < Theimg.x + Theimg.width) and (Crosshairs.y +11 > Theimg.y) and (Crosshairs.y +11 < Theimg.y + Theimg.height) and round == 3 and noShot == true then
   kills3=kills3+1
   score = score + 500
   Bird=Bird+1
   BirdKilled = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg2.x) and (Crosshairs.x +11 < Theimg2.x + Theimg2.width) and (Crosshairs.y +11 > Theimg2.y) and (Crosshairs.y +11 < Theimg2.y + Theimg2.height) and round == 3 and noShot == true then
   kills3=kills3+1
   score = score + 500
   Bird2=Bird2+1
   BirdKilled2 = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg.x) and (Crosshairs.x +11 < Theimg.x + Theimg.width) and (Crosshairs.y +11 > Theimg.y) and (Crosshairs.y +11 < Theimg.y + Theimg.height) and round == 4 and noShot== true then
   kills4=kills4+1
   score = score + 500
   Bird=Bird+1
   BirdKilled = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg2.x) and (Crosshairs.x +11 < Theimg2.x + Theimg2.width) and (Crosshairs.y +11 > Theimg2.y) and (Crosshairs.y +11 < Theimg2.y + Theimg2.height) and ruond == 4 and noShot == true then
   kills4=kills4+1
   score = score + 500
   Bird2=Bird2+1
   BirdKilled2 = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg.x) and (Crosshairs.x +11 < Theimg.x + Theimg.width) and (Crosshairs.y +11 > Theimg.y) and (Crosshairs.y +11 < Theimg.y + Theimg.height) and round == 5 and noShot == true then
   kills5=kills5+1
   score = score + 500
   Bird=Bird+1
   BirdKilled = true
   end
   if pad:r() and not oldpad:r() and (shooting == true) and (Crosshairs.x +11 > Theimg2.x) and (Crosshairs.x +11 < Theimg2.x + Theimg2.width) and (Crosshairs.y +11 > Theimg2.y) and (Crosshairs.y +11 < Theimg2.y + Theimg2.height) and round == 5 and noShot == true then
   kills5=kills5+1
   score = score + 500
   Bird2=Bird2+1
   BirdKilled2 = true
   end
   if kills >= 1 then
   screen:blit(195,224,birdKill)
   end
   if kills >= 2 then
   screen:blit(209,224,birdKill)
   end
   if kills2 >= 1 then
   screen:blit(224,224,birdKill)
   end
   if kills2 >= 2 then
   screen:blit(239,224,birdKill)
   end
   if kills3 >=1 then
   screen:blit(253,224,birdKill)
   end
   if kills3 >=2 then
   screen:blit(266,224,birdKill)
   end
   if kills4 >=1 then
   screen:blit(280,224,birdKill)
   end
   if kills4 >=2 then
   screen:blit(295,224,birdKill)
   end
   if kills5 >=1 then
   screen:blit(309,224,birdKill)
   end
   if kills5 >=2 then
   screen:blit(324,224,birdKill)
   end
   if pad:start() then
   gamestate = "paused"
   end
end
function paused()
   pad = Controls.read()
   screen:print(160,145,"Press X to Start",white)
   screen:print(157,160,"Press [] to go to Menu",white)
   if pad:cross() then
   gamestate = "playing"
   end
     if pad:square() then
   gamestate = "gamestart"
   end
end
function paused2()
   pad = Controls.read()
   screen:print(160,145,"Press X to Start",white)
   screen:print(157,160,"Press [] to go to Menu",white)
   if pad:cross() then
   gamestate = "gamestart2"
   end
     if pad:square() then
   gamestate = "gamestart"
   end
end
function animate(BirdMovement,interval)
   local numFrames = table.getn(BirdMovement)
   if animtimer >= numFrames*interval then 
      animtimer = 0 
   end
   animtimer = animtimer + 1
   for i = 1, numFrames do
   if animtimer > interval*(i-1) and animtimer <= interval*i then
   img = BirdMovement[i]
   break
   end
   end
   return img
end
function animate2(BirdMovement2,interval)
   local numFrames = table.getn(BirdMovement)
   if animtimer >= numFrames*interval then 
      animtimer = 0 
   end
   animtimer = animtimer + 1
   for i = 1, numFrames do
   if animtimer > interval*(i-1) and animtimer <= interval*i then
   img = BirdMovement2[i]
   break
   end
   end
   return img
end
function animate3(BirdMovement3,interval)
   local numFrames = table.getn(BirdMovement)
   if animtimer >= numFrames*interval then 
      animtimer = 0 
   end
   animtimer = animtimer + 1
   for i = 1, numFrames do
   if animtimer > interval*(i-1) and animtimer <= interval*i then
   img = BirdMovement3[i]
   break
   end
   end
   return img
end
function animate4(BirdMovement4,interval)
   local numFrames = table.getn(BirdMovement)
   if animtimer >= numFrames*interval then 
      animtimer = 0 
   end
   animtimer = animtimer + 1
   for i = 1, numFrames do
   if animtimer > interval*(i-1) and animtimer <= interval*i then
   img = BirdMovement4[i]
   break
   end
   end
   return img
end
function animate5(BirdMovement5,interval)
   local numFrames = table.getn(BirdMovement)
   if animtimer >= numFrames*interval then 
      animtimer = 0 
   end
   animtimer = animtimer + 1
   for i = 1, numFrames do
   if animtimer > interval*(i-1) and animtimer <= interval*i then
   img = BirdMovement5[i]
   break
   end
   end
   return img
end
function animate6(dogMove,interval)
   local numFrames = table.getn(dogMove)
   if animtimer >= numFrames*interval then 
      animtimer = 0 
   end
   animtimer = animtimer + 1
   for i = 1, numFrames do
   if animtimer > interval*(i-1) and animtimer <= interval*i then
   img = dogMove[i]
   break
   end
   end
   return img
end
function animate7(dogSniff,interval)
   local numFrames = table.getn(dogSniff)
   if animtimer >= numFrames*interval then 
      animtimer = 0 
   end
   animtimer = animtimer + 1
   for i = 1, numFrames do
   if animtimer > interval*(i-1) and animtimer <= interval*i then
   img = dogSniff[i]
   break
   end
   end
   return img
end
function images()
   screen:blit(0,0,background)
   screen:blit(Gun.x,Gun.y,gun)
   screen:blit(Crosshairs.x,Crosshairs.y,crosshairs)
   screen:fontPrint(nes,387,235,score,red)
   screen:fontPrint(nes,95,173,"R = " .. round,red)
   end
function Line()
pad = Controls.read()
   if pad:right() then
   Crosshairs.x=Crosshairs.x+5
   end
   if pad:up() then
   Crosshairs.y=Crosshairs.y-5
   end
   if pad:down() then
   Crosshairs.y=Crosshairs.y+5
   end
   if pad:left() then
   Crosshairs.x=Crosshairs.x-5
   end
   if (pad:analogX() > 33 or pad:analogX() < - 33) then
   Crosshairs.x = Crosshairs.x + (pad:analogX() / 10)
end
if (pad:analogY() > 33 or pad:analogY() < - 33) then
   Crosshairs.y = Crosshairs.y + (pad:analogY() / 10)
end
end
function birdshot()
   if Bird>=1 and Bird <2 then
   screen:blit(Theimg.x,Theimg.y,BirdShot)
   Bird= Bird + .25
   Theimg.yspeed=0
   Theimg.xspeed=0
   end
   if Bird == 1 then
   screen:clear(white)
   end
   if Bird == 2 then
   Bird = 2
   end
   if Bird==2 and BirdBlit == true then
   screen:blit(Theimg.x,Theimg.y,BirdShot2)
   Theimg.yspeed=6
   Theimg.xspeed=0
   end
   if Theimg.y >= 212 or Theimg.y <=-2 then
   BirdBlit = false
   end
end
function birdshot2()
   if Bird2>=1 and Bird2 < 2 then
   screen:blit(Theimg2.x,Theimg2.y,BirdShot)
   Bird2=Bird2+ .25
   Theimg2.yspeed=0
   Theimg2.xspeed=0
   end
   if Bird2 == 1 then
   screen:clear(white)
   end
   if Bird2 == 2 then
   Bird2 = 2
   end
   if Bird2==2 and BirdBlit2 == true then
   screen:blit(Theimg2.x,Theimg2.y,BirdShot2)
   Theimg2.yspeed=6
   Theimg2.xspeed=0
   end
   if Theimg2.y >= 212 or Theimg2.y <= -2 then
   BirdBlit2 = false
   end
end
function birdMove()
   if BirdBlit == true then
   Theimg.x=Theimg.x+Theimg.xspeed
   Theimg.y=Theimg.y+Theimg.yspeed
   if Theimg.xspeed > 0 and Theimg.yspeed > 0 then
   theimg=animate(BirdMovement,2)
   end
   if Theimg.xspeed > 0 and Theimg.yspeed < 0 then
   theimg=animate2(BirdMovement2,2)
   end
   if Theimg.xspeed < 0 and Theimg.yspeed > 0 then
   theimg=animate3(BirdMovement3,2)
   end
   if Theimg.xspeed < 0 and Theimg.yspeed < 0 then
   theimg=animate4(BirdMovement4,2)
   end
   if Theimg.xspeed > 0 and Theimg.yspeed == 0 then
   theimg=animate(BirdMovement,2)
   end
   if Theimg.xspeed < 0 and Theimg.yspeed == 0 then
   theimg=animate3(BirdMovement3,2)
   end
   if Theimg.xspeed == 0 and Theimg.yspeed < 0 then
   theimg=animate5(BirdMovement5,2)
   end
   end
end
function birdCollision()
   if Theimg.x >= 480 - Theimg.width then
   Theimg.xspeed = math.random(-5,-2)
   end
   if Theimg.x<= 0 then
   Theimg.xspeed=math.random(2,5)
   end
   if Theimg.y<=2 then
   Theimg.yspeed =math.random(2,5)
   end
   if Theimg.y + Theimg.height >=212 and Theimg.yspeed ~= 6 then
   Theimg.yspeed =math.random(-5,-2)
   end
end
function birdMove2()
   if BirdBlit2 == true then
   Theimg2.x=Theimg2.x+Theimg2.xspeed
   Theimg2.y=Theimg2.y+Theimg2.yspeed
   if Theimg2.xspeed >=0 and Theimg2.yspeed >=0 then
   theimg2=animate(BirdMovement,2)
   end
   if Theimg2.xspeed >=0 and Theimg2.yspeed <=0 then
   theimg2=animate2(BirdMovement2,2)
   end
   if Theimg2.xspeed <=0 and Theimg2.yspeed >=0 then
   theimg2=animate3(BirdMovement3,2)
   end
   if Theimg2.xspeed <=0 and Theimg2.yspeed <=0 then
   theimg2=animate4(BirdMovement4,2)
   end
   if Theimg2.xspeed > 0 and Theimg2.yspeed == 0 then
   theimg2=animate(BirdMovement,2)
   end
   if Theimg2.xspeed < 0 and Theimg2.yspeed == 0 then
   theimg2=animate3(BirdMovement3,2)
   end
   if Theimg2.xspeed == 0 and Theimg2.yspeed < 0 then
   theimg2=animate5(BirdMovement5,2)
   end
   end
end
function birdCollision2()
   if Theimg2.x >= 480 - Theimg2.width then
   Theimg2.xspeed = math.random(-5,-2)
   end
   if Theimg2.x<= 0 then
   Theimg2.xspeed=math.random(2,5)
   end
   if Theimg2.y<=2 then
   Theimg2.yspeed =math.random(2,5)
   end
   if Theimg2.y + Theimg2.height >=212 and Theimg2.yspeed ~= 6 then
   Theimg2.yspeed =math.random(-5,-2)
   end
end
function walls1()
	if Theimg.x < 0 then
	Theimg.x = oldX
	end
	if Theimg.x + 23 > 480 then
	Theimg.x = oldX
	end
	if Theimg.y < 0 then
	Theimg.y = oldY
	end
	if Theimg.y + 23 > 272 then
	Theimg.y = oldY
	end
end
function walls2()
	if Crosshairs.x < 0 then
	Crosshairs.x = oldX2
	end
	if Crosshairs.x + 23 > 480 then
	Crosshairs.x = oldX2
	end
	if Crosshairs.y < 0 then
	Crosshairs.y = oldY2
	end
	if Crosshairs.y + 23 > 272 then
	Crosshairs.y = oldY2
	end
end
theimg=animate(BirdMovement,2)
theimg2=animate(BirdMovement,2)
dogimg=animate6(dogMove,1)
while true do
oldX2 = Crosshairs.x
oldY2 = Crosshairs.y
oldX = Theimg.x
oldY = Theimg.y
screen:clear()
pad=Controls.read()
  if gamestate== "paused" then
   paused()
   end
    if gamestate== "paused2" then
   paused2()
   end
	if time <= 0 then
	time= 0
	end
   if gamestate == "gamestart" then
   gameStart()
	end
	if gamestate == "gamestart2" then
	BulletTimer = BulletTimer + .25
	birdControl()
	screen:blit(0,0,Background2)
	screen:blit(Theimg.x,Theimg.y,theimg)
	BulletBird(Bullet1,Theimg)
	BulletBird(Bullet2,Theimg)
	BulletBird(Bullet3,Theimg)
	BulletBird(Bullet4,Theimg)
	bulletMovement(Bullet1)
	bulletMovement(Bullet2)
	bulletMovement(Bullet3)
	bulletMovement(Bullet4)
	bulletCollision(Bullet1)
	bulletCollision(Bullet2)
	bulletCollision(Bullet3)
	bulletCollision(Bullet4)
	screen:fontPrint(nes,10,10,BulletTimer,red)
	walls1()
	if pad:start() and pad:start() ~= oldpad:start() then
	gamestate = "paused2"
	end
	end
	
   if gamestate == "playing" then
   gamestime=gametimer:time()
   if gamestime>1000 and time >= 0 then 
   time=time - 1 
   gametimer:reset(0) 
   gametimer:start()
end
   if pad:start() then
   paused()
   end
   screen:print(10,10,time,red)
   roundOverWin()
   images()
   walls2()
   shoot()
   Line()
   birdshot()
   birdshot2()
   birdMove()
   birdCollision()
   birdMove2()
   birdCollision2()
   roundOver()
   dogMovement()
   screen:print(10,10,time,red)
   if dogBlit == true then
   screen:blit(Dogimg.x,Dogimg.y,dogimg)
   end
   if BirdBlit2 == true and BirdKilled2 == false then
   screen:blit(Theimg2.x,Theimg2.y,theimg2)
   end
   if BirdBlit == true and BirdKilled == false then
   screen:blit(Theimg.x,Theimg.y,theimg)
   end
   if pad:circle() and pad:square() then
   break
   end
   end
screen.waitVblankStart()
screen.flip()
oldpad = pad
end
