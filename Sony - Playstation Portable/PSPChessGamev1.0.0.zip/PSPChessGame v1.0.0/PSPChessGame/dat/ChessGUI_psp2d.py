## 
## PSPChess
## Copyright (C) 2009,2010 Germano Fabio
## gefasio@gmail.com
## 
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
##

import psp2d
from animation import Animation
from ChessRules import ChessRules
import ChessBoard

class ChessGUI(object):
    def __init__(self, screen):
        self.Rules = ChessRules()
        self.cursPos = [0, 7]
        self.cursor = (psp2d.Image('img/cursor/punt.png'), psp2d.Image('img/cursor/punt1.png'))
        self.cursAnimation = Animation(screen, self.cursor, 30, 25+self.cursPos[0]*30, 15+self.cursPos[1]*30)
        self.bg = psp2d.Image('img/bg.png')
        self.img = (psp2d.Image('img/brown_square.png'),\
                        psp2d.Image('img/white_square.png'),\
                        psp2d.Image('img/cyan_square.png'))
        self.tiles = {'bR' : psp2d.Image('img/torre_nero.png'),
                        'bT' : psp2d.Image('img/cavallo_nero.png'),
                        'bB' : psp2d.Image('img/alfiere_nero.png'),
                        'bQ' : psp2d.Image('img/donna_nero.png'),
                        'bK' : psp2d.Image('img/re_nero.png'),
                        'bP' : psp2d.Image('img/pedone_nero.png'),
                        'wR' : psp2d.Image('img/torre_bianco.png'),
                        'wT' : psp2d.Image('img/cavallo_bianco.png'),
                        'wB' : psp2d.Image('img/alfiere_bianco.png'),
                        'wQ' : psp2d.Image('img/donna_bianco.png'),
                        'wK' : psp2d.Image('img/re_bianco.png'),
                        'wP' : psp2d.Image('img/pedone_bianco.png')
                }
        self.menu = [psp2d.Image('img/newgame.png'), psp2d.Image('img/about.png'), psp2d.Image('img/exit.png'),]
        self.oldMove = psp2d.Image('img/old.png')
        self.mateImg = (psp2d.Image('img/mateWhite.png'), psp2d.Image('img/mateBlack.png'))
        self.aboutImg = psp2d.Image('img/aboutSplash.png')
        self.CPUThinking = psp2d.Image('img/thinking.png')
        self.movementPiece = 0
        self.fromList = [0,0]
        self.toList = [0,0]
        self.showAboutDialogVar = False
    def drawChessBoard(self, screen):
        screen.blit(self.bg, 0, 0, 480, 272, 0, 0, True)
        y, x = 15, 25
        for i in range(1, 9):
            for j in range(1, 9):
                if i % 2 != 0:
                    if j % 2 == 0:
                        screen.blit(self.img[0], 0, 0, 30, 30, x, y, True)
                else:
                    if j % 2 != 0:
                        screen.blit(self.img[0], 0, 0, 30, 30, x, y, True)
                x += 30
            y += 30
            x = 25
    def drawMenu(self, screen, menu):
        screen.blit(self.menu[menu], 0, 0, 114, 124, 312, 33, True)
    def drawCurs(self, screen):
        self.cursAnimation.show()
        self.cursAnimation.pos[0] = 25+self.cursPos[0]*30
        self.cursAnimation.pos[1] = 15+self.cursPos[1]*30
    def cursControl(self, pad, oldpad, board, color):
        if pad.right and not oldpad.right and self.cursPos[0] != 7:
            self.cursPos[0] += 1
        elif pad.left and not oldpad.left and self.cursPos[0] != 0:
            self.cursPos[0] -= 1
        elif pad.up and not oldpad.up and self.cursPos[1] != 0:
            self.cursPos[1] -= 1
        elif pad.down and not oldpad.down and self.cursPos[1] != 7:
            self.cursPos[1] += 1
        if pad.cross and not oldpad.cross and self.movementPiece == 1:
            self.GetPlayerInput_SquareTo(board,color)
        if pad.cross and not oldpad.cross and self.movementPiece == 0:
            if color == 'black':
                if board[self.cursPos[1]][self.cursPos[0]][0] == 'b':
                    self.movementPiece = 1
                    self.GetPlayerInput_SquareFrom(board,color)
            else: #white
                if board[self.cursPos[1]][self.cursPos[0]][0] == 'w':
                    self.movementPiece = 1
                    self.GetPlayerInput_SquareFrom(board,color)
    def GetPlayerInput_SquareFrom(self,board,color):
        self.fromList = [self.cursPos[1], self.cursPos[0]]
    def GetPlayerInput_SquareTo(self,board,color):
        validMoveList = self.Rules.GetListOfValidMoves(board,color,self.fromList)
        if (self.cursPos[1], self.cursPos[0]) in validMoveList:
            self.toList = [self.cursPos[1], self.cursPos[0]]
            self.movementPiece = 2
        else:
            ## Mossa invalida.
            self.movementPiece = 0
    def drawValidMoves(self, board,color,screen):
        validMoveList = self.Rules.GetListOfValidMoves(board,color,self.fromList)
        for move in validMoveList:
            screen.blit(self.img[2], 0, 0, 30, 30, 25+move[1]*30, 15+move[0]*30, True)
    def drawTiles(self, board, screen):
        y, x = 20, 30
        for r in range(8):
            for c in range(8):
                if board[r][c] != 'e':
                    screen.blit(self.tiles[str(board[r][c])], 0, 0, 20, 20, x, y, True)
                x += 30
            y += 30
            x = 30
    def drawOldAIMoves(self, screen, oldAIMove):
        screen.blit(self.oldMove, 0, 0, 30, 30, 25+oldAIMove[0][1]*30, 15+oldAIMove[0][0]*30, True)
        screen.blit(self.oldMove, 0, 0, 30, 30, 25+oldAIMove[1][1]*30, 15+oldAIMove[1][0]*30, True)
    def drawMate(self, screen, color):
        if color == 'white':
            screen.blit(self.mateImg[0], 0, 0, 200, 117, 42, (272/2)-(117/2), True)
        else:
            screen.blit(self.mateImg[1], 0, 0, 200, 117, 42, (272/2)-(117/2), True)
    def showAboutDialog(self, screen):
        screen.blit(self.aboutImg, 0, 0, 200, 117, 130, (272/2)-(117/2), True)
    def drawCPUThinking(self, screen):
        screen.blit(self.CPUThinking, 0, 0, 200, 117, (400/2)-(self.CPUThinking.width/2)+25, (272/2)-(self.CPUThinking.height/2), True)
    def printMove(self, boardList, board):
        if 'P' in boardList[self.toList[0]][self.toList[1]]:
            return board.ConvertToAlgebraicNotation((self.fromList[0], self.fromList[1])) + \
                  '-' + board.ConvertToAlgebraicNotation((self.toList[0], self.toList[1]))
        elif 'R' in boardList[self.toList[0]][self.toList[1]]: # torre
            return 'T'+board.ConvertToAlgebraicNotation((self.fromList[0], self.fromList[1])) + \
                  '-' + board.ConvertToAlgebraicNotation((self.toList[0], self.toList[1]))
        elif 'T' in boardList[self.toList[0]][self.toList[1]]: # cavallo
            return 'C'+board.ConvertToAlgebraicNotation((self.fromList[0], self.fromList[1])) + \
                  '-' + board.ConvertToAlgebraicNotation((self.toList[0], self.toList[1]))
        elif 'B' in boardList[self.toList[0]][self.toList[1]]: # alfiere
            return 'A'+board.ConvertToAlgebraicNotation((self.fromList[0], self.fromList[1])) + \
                  '-' + board.ConvertToAlgebraicNotation((self.toList[0], self.toList[1]))
        elif 'Q' in boardList[self.toList[0]][self.toList[1]]: # donna
            return 'D'+board.ConvertToAlgebraicNotation((self.fromList[0], self.fromList[1])) + \
                  '-' + board.ConvertToAlgebraicNotation((self.toList[0], self.toList[1]))
        elif 'K' in boardList[self.toList[0]][self.toList[1]]: # re
            return 'R'+board.ConvertToAlgebraicNotation((self.fromList[0], self.fromList[1])) + \
                  '-' + board.ConvertToAlgebraicNotation((self.toList[0], self.toList[1]))
