## 
## PSPChess
## Copyright (C) 2009,2010 Germano Fabio
## gefasio@gmail.com
## 
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
##

import psp2d
from ChessBoard import ChessBoard
from ChessAI import ChessAI_random, ChessAI_offense 
from ChessPlayer import ChessPlayer
from ChessGUI_psp2d import ChessGUI
from ChessRules import ChessRules
import random, string, time
from animation import Animation

class Main(object):
    def __init__(self):
        self.screen = psp2d.Screen()
        self.menu = 0 # 0-> New Game, 2 -> About, 3 -> Exit.
        self.gui = ChessGUI(self.screen)
        self.Board = ChessBoard(0)
        self.Rules = ChessRules()
        self.isInCheckMate = '' # ''-> No checkmate; 'color' -> color in ceckmate.
        self.player1Color = 'white'    
        self.player2Color = 'black'      
        self.player = [0,0]
        self.player[0] = ChessPlayer('',self.player1Color)
        self.player[1] = ChessAI_offense('',self.player2Color)
        if self.player1Color == 'black':
            self.currentPlayerIndex = 1
            self.gui.cursPos = [0,0]
        else:
            self.currentPlayerIndex = 0
        self.countAI = [False, 0]
        self.oldAIMove = [[],[]]
        self.turn = 0
        self.oldpad = psp2d.Controller()
    def Run(self):
        while True:
            self.pad = psp2d.Controller()
            
            self.board = self.Board.GetState()
            self.currentColor = self.player[self.currentPlayerIndex].GetColor()

            self.gui.drawChessBoard(self.screen)
            self.gui.drawMenu(self.screen, self.menu)          
            self.gui.drawTiles(self.board, self.screen)
            if len(self.oldAIMove[0]) != 0:
                self.gui.drawOldAIMoves(self.screen, self.oldAIMove)

            if self.isInCheckMate == '':
                if self.player[self.currentPlayerIndex].GetType() == 'AI' and self.countAI[1] > 1:
                    moveTuple = self.player[self.currentPlayerIndex].GetMove(self.Board.GetState(), self.currentColor)
                    self.oldAIMove[0] = moveTuple[0]
                    self.oldAIMove[1] = moveTuple[1]
                    self.Board.MovePiece(moveTuple)
                    self.currentPlayerIndex = (self.currentPlayerIndex+1)%2
                    self.countAI[1] = 0; self.countAI[0] = False
                    if self.Rules.IsCheckmate(self.Board.GetState(),self.player[self.currentPlayerIndex].color):
                        if self.player[self.currentPlayerIndex].color == 'white':
                            self.isInCheckMate = 'black'
                        else:
                            self.isInCheckMate = 'white'
                if self.player[self.currentPlayerIndex].GetType() == 'human':
                    self.gui.drawCurs(self.screen)
                    if not self.gui.showAboutDialogVar:
                        self.gui.cursControl(self.pad, self.oldpad, self.board, self.currentColor)
                    if self.gui.movementPiece == 1:
                        self.gui.drawValidMoves(self.board, self.currentColor, self.screen)
                    elif self.gui.movementPiece == 2:
                        self.Board.MovePiece(((self.gui.fromList[0], self.gui.fromList[1]), (self.gui.toList[0], self.gui.toList[1])))
                        self.gui.movementPiece = 0
                        self.currentPlayerIndex = (self.currentPlayerIndex+1)%2
                        self.countAI[0] = True
                        if self.Rules.IsCheckmate(self.Board.GetState(),self.player[self.currentPlayerIndex].color):
                            if self.player[self.currentPlayerIndex].color == 'white':
                                self.isInCheckMate = 'black'
                            else:
                                self.isInCheckMate = 'white'
            else:
                if self.isInCheckMate == 'black':
                    self.gui.drawMate(self.screen, 'black')
                else:
                    self.gui.drawMate(self.screen, 'white')

            if self.gui.showAboutDialogVar:
                self.gui.showAboutDialog(self.screen)

            ## Gestione del menu.
            if self.pad.r and not self.oldpad.r and self.menu != 2:
                self.menu += 1
            elif self.pad.l and not self.oldpad.l and self.menu != 0:
                self.menu -= 1
            if self.pad.start and not self.oldpad.start and self.menu == 0: # New Game
                self.Board = ChessBoard(0)
                self.isInCheckMate = ''
                if self.player1Color == 'black':
                    self.currentPlayerIndex = 1
                    self.gui.cursPos = [0,0]
                else:
                    self.currentPlayerIndex = 0
                    self.gui.cursPos = [0,7]
                self.oldAIMove = [[],[]]
                self.turn = 0
                time.sleep(2)
            elif self.pad.start and not self.oldpad.start and self.menu == 1 and self.gui.showAboutDialogVar: # About
                self.gui.showAboutDialogVar = False
            elif self.pad.start and not self.oldpad.start and self.menu == 1 and not self.gui.showAboutDialogVar: # About
                self.gui.showAboutDialogVar = True
            elif self.pad.start and not self.oldpad.start and self.menu == 2: # exit =)
                break

            if self.countAI[0]:
                self.gui.drawCPUThinking(self.screen)
                self.countAI[1] += 1
            
            self.screen.swap()
            self.oldpad = self.pad
