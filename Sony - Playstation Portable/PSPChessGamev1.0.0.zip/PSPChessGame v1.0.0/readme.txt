## PSPChessGame v1.0.0,
## by Gefa (chess engine by Steve Osborne, srosborne (at) gmail.com)
## www.gefa.altervista.org

What is it?
===========
This is a simple chess game, written in python, for Sony PSP. 
This program use the chess engine by Steve Osborne (srosborne@gmail.com). I thank him for this =)

Controls
========
The controls are very simple:
Use the d-pad to move the cursor on the board, then X button to select a piece and to move it.
Press L and R buttons to change option in the menu, and press Start to confirm it.

Installation
============
Copy 'python' directory in the root of your memory stick, and 'PSPChessGame' in the 'ms0:/PSP/GAME' path.

Enjoy.

