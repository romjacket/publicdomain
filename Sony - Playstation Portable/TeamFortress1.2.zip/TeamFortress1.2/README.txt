Team Fortress 1.3 (first clean release)

Please direct all questions toward halo9449@gmail.com or CyberDemon5150 at http://psp.wijou.com/forum/ (must register first, but registration is free.)

VERSION CHANGES:

VERSION 0.1: Quake has class-based teamplay, but nothing more. No flags whatsoever.

VERSION 0.2: Quake has flags now, but isn't really playable due to the lack of buttons on the PSP.

VERSION 1.0: First official release, through use of CONFIG cycling, nearly all commands are assigned to buttons from the start. Minor control bugs, but not much more.

VERSION 1.1: Now has the shape buttons as movement, and a-nub look is highly recommended. Some control patch-ups. Now uses Omicron bots instead of TFBots (The Omicrons have actually succeeded in taking flags and fight boldly and... well, they are very, VERY humanlike in how they play, whereas the TFBots had to be led around everywhere) Gameplay is much improved once the bots can map out the level. Be prepared for much blood and gore. Also of note, as of yet Engineer, Medic, and Spy bots are not implemented, not by fault of the bots, but because Team Fortress 2.8 just doesn't trust them. I have, however, seen Engineer bots in Team Fortress Classic work very well, and Medics as well. Of course, the Spies have never worked out, even in TFC, so those will be the hardest to get going (though if I can implement a 1 out of 15 probability thing for detection of undercover spies, as well as give the spies the know-how to disguise or feign death, those, too, might be possible.)

VERSION 1.2: Now has a-nub look and crosshair on by default. Minor control changes, including a .cfg added to the cycle that allows you to choose classes for class changing once you are playing. Classes go as follows: up arrow= scout; down arrow= sniper; triangle= soldier; circle= demoman; cross= medic; square= heavy weapons guy; left trigger= pyro; right trigger= spy; select= engineer. Also, if you figure you don't need Identification of bots (you might need it until I figure out why both teams are the same color...) you can bind the down arrow in CONFIG.cfg to impulse 22 for grappling hook, though some maps do not support use of it.

VERSION 1.3: Now has original .pak files removed, since heavy developmental period is over and users must supply their own .pak files (no use in including the shareware .pak either; the game doesn't function at all without it.)

TIPS
In-game, if you are playing in AdHoc mode, to cut down on player confusion, I recommend each player go into the console, open the On Screen Keyboard with Square, type in 'Name [custom name here]' with the directional buttons and Cross/X, and then press Square and Cross. That way, everyone will have a different name than 'Quake Guy,' and confusion won't run as rampant. Of course, confusion is always abundant on the battlefield.

DESCRIPTION AND CONTROLS
Well, this is it. At least, that's what I would like to say. This project has only begun, really. So far there is a bountiful selection of maps included with it, and new versions are coming out like there is no tomorrow.
Here is a run-down of the BASIC CONTROLS FOR THE PRIMARY CONTROL CONFIGURATION IN TFPSP V1.2. The other control configuration, which you may download separately below, is similar in its individual .cfg layouts to the primary set, though it has minor variations. If you don't feel like coming here to read the controls, you can always go search through the .cfg files included in the MS0:/PSP/GAME/Team Fortress/Fortress/ folder to get a better idea of how the controls are mapped out.

CONFIG.cfg-
L Trigger- jump
R Trigger- Attack
Triangle- Walk Forward
Circle- Strafe Right
Cross/X- Backpedal
Square- Strafe Left
Select- Identify structures and players as hostile or friendly, and also identify their classes (and armor levels if you are an engineers, and health levels if you are a medic)
Up Arrow- selects the grappling hook (on maps that allow it)
Down Arrow- activate the quickmenu (see Quickmenu.cfg below)

Quickmenu.cfg- (note: After pressing any one of these buttons in this .cfg, it will revert back to CONFIG.cfg, to make it a little bit simpler and faster to use. Example: activate the quick menu, prime a grenade, activate the menu once more, then throw the grenade and RUN.)
L Trigger, Circle, Square, Cross/X, Triangle- Drop ammo of various types
R Trigger- Change Weapon
Left Arrow- Prime Grenade Type 1
Up Arrow- Prime Grenade Type 2
Right Arrow- Throw Primed Grenade
Down Arrow- Reload Current Weapon

Weaponcontrol.cfg-
Up Arrow- Prime Grenade Type 1
Down Arrow- Prime Grenade Type 2
Triangle- Set a DetPack for 50 seconds
Circle-Set a DetPack for 20 seconds
Cross/X- Set a DetPack for 5 seconds
Square- Throw Primed Grenade
L Trigger- Open the console without opening the Options Menu
R Trigger- Detonate all tossed pipebombs
Select- Show Scores

Construction.cfg-
Up Arrow- Build or destroy an ammo and armor dispenser (Engineer only)
Down Arrow- Build or destroy a sentry gun (Engineer only)
Triangle- Drop the key if you are carrying it (doesn't work on all maps)
Circle- Scan, using 50 cells (Scout only)
Cross/X- Scan for friendlies (Scout only)
Square- Scan for enemies (Scout only)
L Trigger- Call for a Medic
R Trigger- Open the build menu (just for fun, really)
Select- Brief construction instructions

Class.cfg- Select the class you will respawn as when you die.
Up Arrow- Scout
Down Arrow- Sniper
Triangle- Soldier
Circle- DemoMan
Cross/X- Medic
Square- Heavy Weapons Guy
L Trigger- Pyro
R Trigger- Spy
Select- Engineer

Bot.cfg- Hit the order buttons repeatedly to affect all bots, or just tap them once near a single bot to command it.
Up Arrow- Change the team the next spawned bot will be on
Down Arrow- Tells how to spawn bots
Triangle- Tells bots on your team to camp at your location
Circle- Tells bots on your team to go ahead
Cross/X- Orders bots on your team to attack
Square- Tells bots on your team to defend the flag
L Trigger- Tells the bots on your team to roam freely
R Trigger- Requests bots on your team to follow you
Select- Tells what you have in your inventory

Numberkeys.cfg-
Up Arrow- 1 key
Down Arrow- 2 key
Triangle- 3 key
Circle- 4 key
Cross/X- 5 key
Square- 6 key
L Trigger- 7 key
R Trigger- 8 key
Select- Spawn bot

MiscCommands.cfg-
Up Arrow- Commit Suicide
Down Arrow- Show Team Fortress Variables on selected map
Triangle- Drop items; drops key or flag on certain maps
Circle- Special command; caries with classes
Cross/X- Feign Death (Spy only)
Square- Disguise (Spy only)
L Trigger- Show the classes of your teammates
R Trigger- Opens Messaging.cfg
Select- Executes CONFIG2.cfg (main .cfg of second control set)

Messaging.cfg-
Up Arrow- Say 'Hi'
Left Arrow- Say 'Nice Shot'
Right Arrow- Say 'Blue'
Down Arrow- Say 'Which team should I join?'
Triangle- Say 'Red'
Circle- Say 'Green'
Cross/X- Say 'Yellow'
Square- Say 'Bye'
L Trigger- Say 'OWNED!'
R Trigger- Say 'I've got to go.'
Select- return to CONFIG.cfg