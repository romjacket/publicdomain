================================================================
 Sorcerer.MD2                        		  v1.00
 by E. Villiers                                   18th July 1999
 
................................................................

================================================================
Title                   : Quake2 Male Player Model
Author                  : E. Villiers 
Homepage                : websites.ntl.com/~ewan.villiers
Email Address           : ewan.villiers@net.ntl.com
			  
Sound			: Anyone want to do a sound system
			   


Build Time              : 3 Weekss on and off over last 6 Months
================================================================


DESCRIPTION

   I wanted to make a model with totaly different weapons from the
   standard and somthing other than skin tight clothing. 

   The model has 695 polygons and the skin is 67% efficient 
   (I had it higher but this was easier to skin).

   

INSTALLATION

   Unzip the file into the same directory as the Quake2 folder,
   the sub-directories will be created by the zip file

TO USE

   Run quake2 go to Multiplay / PlayerSetup / Model and select
   Sorcerer. You can then choose a skin.

   If that doesn't work, or you get the "No Valid Players Found"
   bug, just add the following to your cfg file at the bottom.
	
	skin Sorcerer/Sorcerer


Tools used (in order of importance):

   Quake2
   3d Studio MAX
   Photoshop
   Paint Shop Pro
   Quake 2 Modeller 0.90b by Phillip Martin (martinp1@topaz.cqu.edu.au)
   MD2 viewer by Trey Harrison (trey@crack.com)
   SkinView Mod (http://telefragged.com/skinview/)
  

WHAT'S NEW?

   First time out so no improvements


TO DO:

   Please tell me if there is anything that can be improved.
