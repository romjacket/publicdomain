9-24-99
================================================================
Model Name              : squirtle

installation directory  : quake2/baseq2/players/squirtle

Author                  : Bryan "{TLK}KING" Cook

Skin Author             : Travis "SocialNemesis" Keene,                                          Brandon "Ravnos" Keene,
                          Bryan "{TLK}KING" Cook
          
Email Address           : bryan_c@mailexcite.com

Model description       : Squirtle tiny turtle Height:1'08"                                      Weight:20.0 pounds.. After birth its back                              swells and hardens into a shell.  Powerfully                           sprays foam from his mouth..(uses magnums                              now)


Other info              : I know pokemon dont use magnums but i thought                           they made him look more quakeish...this is my                           first attempt at making a model

Additional Credits to   : id software, The person who made q2modeler,                            And the people who made the great program                              Skinview, and also Jasc Software for making                            psp5.

Thanks to               : SocialNemesis, and Ravnos for pointing out                           some of the problems with the model and for                           showing me how to use q2modeler.
================================================================
* Play Information *

New Sounds              : 
CTF Skins               : YES
VWEP Support            : NO, Maybe a little later


* Construction *
Poly Count              : 606 Model,  128 Weapon
Vert Count              : 88
Skin Count              : 6, plus the skin mesh i exported out so you                            can use that instead of the skins i made
                          cause i know there sort of sloppy.

Base                    : This was a completely new model

Editor used             : Q2modeler for building and Animating the                               model, PaintShop Pro 5 for skins, Skinview                             for viewing the skins.

Known Bugs              : hmmm none that i know of but...Email me if                             you find any.

Build/Animation time    : Build Time about a week/Animation About 2                              weeks.
 

* How to use this model *
Just Spank this sucker into a c:\Quake2\baseq2\squirtle  directory

* Copyright / Permissions *

QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.

If you modify or use any part of this model please email me and let me know .

