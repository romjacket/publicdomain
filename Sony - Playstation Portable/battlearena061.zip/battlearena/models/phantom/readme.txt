October 21st, 1998
================================================================
Model Name              : Phantom
installation directory  : quake2/baseq2/players/phantom

Model, Skin, CTF skins  : Bjarne Kristensen
Email Address           : bk@mailme.dk
 
================================================================
* Play Information *

New Sounds              : yes
CTF Skins               : yes
VWEP Support            : no


* Construction *
Poly Count              : 636 (model + biggest weapon)
Vert Count              : 210
Skin Count              : 3 (Blue, Red, Brown)
Base                    : Original model
Editor used             : PaintShopPro 5.01, Quake 2 Modeller 0.83
Known Bugs              : Brace yourself...

Build/Animation time    : 8 hourhs


* How to use this model *

Extract this archive into your Quake2 directory.  It has it's own
internal directory structure in an attempt to make sure everyone has it
in the same location, and so the weapon skin shows up properly (it's
tied into the directory name somehow).  Whatever happens, the intention
is that the model will be installed into the following path:

    <quake2 dir>\baseq2\players\phantom
eg:
    c:\quake2\baseq2\players\phantom


