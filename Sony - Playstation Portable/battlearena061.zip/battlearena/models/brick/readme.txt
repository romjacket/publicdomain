hi again. here is my 4th attempt at quake2 modelling. i have perfected the process quite a bit 
from the previous models... i wrote a script in 3ds max2 that will export a sequence of .3ds files
and i have made batch files that take care of the compiling and copying.  The biggest help that 
i had was figuring out that i can boolean objects that dont touch each other to make a  single mesh 
that is unconnected.  Then i used sub-object editing and made selection sets of all different
combinations of the arms, legs, etc.. This was very useful in animating the model.  The most
glaring problem in this model is the NULL SKIN FOUND errors that will show up  in the game if you use it.
i have tried and tired but i cannot seem to get rid of them.  The error seems to be caused by the
weapon.md2 because i dont get the error when i use a weapon.md2 from the male or female model.
i have tried making very small objects as weapons and even large ones but they all give the same error.
if you want the error to go away so you can use this model, just copy the weapon.md2 and weapon.pcx
files from the male or female directory into the lego directory. It doesnt look good, but it wont give away
your position.  If anyone has any ideas about how to fix this i would greatly appreciate it.  Also
if anyone has a weapon.md2 that is invisible in the game and doesnt cause errors i would like to use it.
i plan on releasing this model again if i ever get the errors fixed...
enjoy.
-Paul Burslem