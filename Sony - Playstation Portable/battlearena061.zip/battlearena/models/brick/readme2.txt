to Paul Burslem

Dear Paul,
here is a null weapon.md2 model and a complete skins
pack whit a lot of skins and _i included for your
splendid lego md2.

				Ignazio Di Napoli
			       dinapoli@isynet.it