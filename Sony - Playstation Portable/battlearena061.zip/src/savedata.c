#include<pspgu.h>
#include<pspgum.h>
#include<psputiltiy.h>
#include"main.h"

void drawSaveData()
{
	
}

int showSaveDialog()
{
	
}

int showLoadDialog()
{
	
}
