
    Welcome to PSP Flight

Written by Ludovic.Jacomme also known as Zx-81 (zx81.zx81@gmail.com)

1. INTRODUCTION
   ------------

  PSP Flight is a simple flight simulator, nothing compared to Flight Simulator X
  but good enough to take off using Air-France plane, have a trip and land in several
  french airports.


2. INSTALLATION
   ------------

  Unzip the zip file, and copy the content of the directory fw5x in
  psp/game5XX directory.

  It has been developped on linux for Firmware 5.x-M33

  For any comments or questions on this version, please visit 
  http://zx81.zx81.free.fr, http://www.dcemu.co.uk, or 
  http://pspupdates.qj.net


  Enjoy,
  
         Zx
