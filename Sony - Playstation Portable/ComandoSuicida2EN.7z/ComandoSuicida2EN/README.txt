Comando Suicida 2 programmed by Eskema 2008  --------eskematicoARROBAhotmailPUNTOcom
Graphics modified by LW-Torrecilla	-----------l_torrecillaARROBAyahooPUNTOes




GAME-------------------------------------------

You are an expert soldier, and your mission its to defend your base from
the invasors
Each few time you receive an artillery attack (if you survive enough XD)
check the screen, if artillery is available, an icon appears in the title frame
Your max score is saved after you complete the level.




CONTROLS----------------------------------------


Cursors      	---     movements
X		--- 	shoot /accept
O		---	Artillery attack (if available)
START		---	Exit






MUSIC ----------------------

You can put any song in music folder, and rename it as existent



