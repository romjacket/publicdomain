LEDA - Legacy Software Loader, beta 0.2
 
Description:
LEDA is a program that integrates into M33 custom firmwares to let some old 1.00/1.50 homebrew to run.
To avoid waste of memory, leda is only loaded when necessary.
Current compatibility is unknown as is still in beta.
Although it may work on previous m33 versions, it has only be tested on 5.00 M33.

Changes:
- Increased compatibility