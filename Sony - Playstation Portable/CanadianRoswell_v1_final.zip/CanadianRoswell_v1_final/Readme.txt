Canadian Roswell
- by Mr305

My first learning experience coding for the PSP in C.


Controls:
-----

Start - Pause
Circle - Fast Bullets (Beware of engine overheating)
Cross - Single Bullets



Pretty much abandoned project (for over 2 years).