/*
 * Battlegrounds 3 - http://xfacter.wordpress.com
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE for details.
 *
 * Copyright (c) 2009 Alex Wickes
 */

#ifndef __MENU_H__
#define __MENU_H__

#include "xlib/xconfig.h"
#include "base.h"

void bg3_menu_loop(bg3_base* base);

#endif