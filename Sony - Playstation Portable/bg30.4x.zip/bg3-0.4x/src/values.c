/*
 * Battlegrounds 3 - http://xfacter.wordpress.com
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE for details.
 *
 * Copyright (c) 2009 Alex Wickes
 */

#include "values.h"

const int bg3_game_scores[] = {
	10,
	25,
	50
};

const int bg3_game_times[] = {
	5*60,
	10*60,
	15*60
};

const int bg3_game_spawns[] = {
	1,
	2,
	5,
	10
};
