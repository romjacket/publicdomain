MemorizeME
--------------
Here's a small game originally by Darkchild I've ported to the PSP from the DS. As you can probably guess from the title, it's a memory game. 

The object of the game is to recreate the patterns shown to you. An extra life is awarded every now and then depending on the difficulty you choose.

If anyone has any problems or suggestions you can email me at the address below and I'll take a look.

Hope you enjoy and thanks for downloading,
roe-ur-boat

Installation
-------------
Just copy the MemorizeME folder included to the PSP/GAME folder on your memory stick.

Instructions for use
---------------------
Use the D-pad or the analog stick to move the pointer around the screen and press X to click on something.

Credits
--------
Darkchild - For the original game and the PSP graphics.
Brunni - OSLib
Sakya - OSLib Mod
Benhur - Intrafont

Contact
-------
You can contact me at roe-ur-boat@hotmail.com
If you would like to make any suggestions to Darkchild about the DS version of the game you can contact him at madcat1990@gmail.com
