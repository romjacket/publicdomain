first=Image.load("first.png")

minuteur=Timer.new(0)

while true do
screen:blit(0,0,first)
minuteur:start() 
currentTime = minuteur:time() 
if currentTime>=3000 then dofile("casino.lua") end

screen.waitVblankStart() 
screen.flip() 
end