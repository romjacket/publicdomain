casino1 = Image.load("casino.png") 
casino2 = Image.load("casino2.png") 
nb0 = Image.load("0.png") 
nb1 = Image.load("1.png") 
nb2 = Image.load("2.png") 
nb3 = Image.load("3.png") 
nb4 = Image.load("4.png") 
nb5 = Image.load("5.png") 
nb6 = Image.load("6.png") 
nb7 = Image.load("7.png") 
mus1=Sound.load("1.wav")
mus2=Sound.load("2.wav")

rouge=Color.new(255,0,0)
minuteur=Timer.new(0) 
minuteur2=Timer.new(0) 
minuteur3=Timer.new(0) 
t=0 
nba=nb0 
nbb=nb0 
nbc=nb0 
gain=0
money=20



while true do 

System.usbDiskModeActivate() 

screen:clear() 

pad=Controls.read() 

if t==0 and money>0 and jeu==4 and pad:cross() and not oldpad:cross() then 
minuteur:start() 
minuteur2:start() 
minuteur3:start() 
t=1 
jeu=0
money=money-1
mus1:play()

end 

currentTime = minuteur:time() 
currentTime2 = minuteur2:time() 
currentTime3 = minuteur3:time() 

if pad:cross() then casino=casino2
else casino=casino1 
end

screen:blit(0,0,casino) 

--1 
if currentTime >= 1000 then a=math.random(1,7) end 
if currentTime >= 2000 then a=math.random(1,7) end 
if currentTime >= 3000 then a=math.random(1,7) end 
if currentTime >= 4000 then a=a
minuteur:reset() 
jeu=1
 end    
if a==1 then nba=nb1 end 
if a==2 then nba=nb2 end 
if a==3 then nba=nb3 end 
if a==4 then nba=nb4 end 
if a==5 then nba=nb5 end 
if a==6 then nba=nb6 end 
if a==7 then nba=nb7 end 
screen:blit(168,138,nba)  

--2 
if currentTime2 >= 4000 then b=math.random(1,7) end 
if currentTime2 >= 5000 then b=math.random(1,7) end 
if currentTime2 >= 6000 then b=math.random(1,7) end 
if currentTime2 >= 7000 then 
b=b 
minuteur2:reset() 
jeu=2
end    
if b==1 then nbb=nb1 end 
if b==2 then nbb=nb2 end 
if b==3 then nbb=nb3 end 
if b==4 then nbb=nb4 end 
if b==5 then nbb=nb5 end 
if b==6 then nbb=nb6 end 
if b==7 then nbb=nb7 end 
screen:blit(215,138,nbb) 

--3  
if currentTime3 >= 7000 then c=math.random(1,7) end 
if currentTime3 >= 8000 then c=math.random(1,7) end 
if currentTime3 >= 9000 then c=math.random(1,7) end 
if currentTime3 >= 10000 then 
c=c 
minuteur3:reset() 
jeu=3
t=0
end    
if c==1 then nbc=nb1 end 
if c==2 then nbc=nb2 end 
if c==3 then nbc=nb3 end 
if c==4 then nbc=nb4 end 
if c==5 then nbc=nb5 end 
if c==6 then nbc=nb6 end 
if c==7 then nbc=nb7 end 
screen:blit(261,138,nbc) 


 

if jeu==3 and a==1 and b==1 and c==1 then 
gain=gain+30
jeu=4 
mus2:play()
elseif jeu==3 and a==b and b==c and a==c then 
gain=gain+20 
jeu=4 
mus2:play()
elseif jeu==3 and a==1 and b==1 then 
gain=gain+15
jeu=4 
mus2:play()
elseif jeu==3 and a==1 and c==1 then 
gain=gain+15
jeu=4 
mus2:play()
elseif jeu==3 and c==1 and b==1 then 
gain=gain+15
jeu=4 
mus2:play()
elseif jeu==3 and a==1 then 
gain=gain+5
jeu=4 
mus2:play()
elseif jeu==3 and b==1 then 
gain=gain+5
jeu=4 
mus2:play()
elseif jeu==3 and c==1 then 
gain=gain+5
jeu=4 
mus2:play()
elseif jeu==3 and a==b then 
gain=gain+5 
jeu=4
mus2:play()
elseif jeu==3 and b==c then 
gain=gain+5 
jeu=4 
mus2:play()
elseif jeu==3 and a==c then 
gain=gain+5 
jeu=4 
mus2:play()
else jeu=4
end


screen:print(10,10,"jeton:"..gain,rouge)
screen:print(10,20,"money:"..money,rouge)

if gain>=50 and pad:circle() and not oldpad:circle() then 
money=money+5
gain=gain-50
screen:print(400,100,"change",rouge)
end


if money==0 then 
screen:clear()
screen:blit(0,0,casino1)
screen:print(10,100,"score:"..gain,rouge)
end

if pad:start() then System.Quit() end

screen.waitVblankStart() 
screen.flip() 
oldpad=pad 
end