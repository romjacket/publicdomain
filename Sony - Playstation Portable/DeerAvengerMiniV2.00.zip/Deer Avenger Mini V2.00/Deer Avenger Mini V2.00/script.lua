--Deer Avenger Mini V2.00 by Code Red

System.setHigh()

pointer=Image.load("images/8.PNG")

gamestate=0
option_selected=1
kills=0
shots=0
igbgs=1

dofile("./data/bambo.sav")
dofile("./data/lstht.sav")
dofile("./data/lstsht.sav")
dofile("./data/tltsht.sav")

red=Color.new(255, 0, 0)
green=Color.new(0,255,0)
blue=Color.new(0, 0, 255)
ltblue=Color.new(0, 255, 255)
white=Color.new(255,255,255)
black=Color.new(0,0,0)
yellow=Color.new(255,255,0)

gamestate=0

-------------------------------------------------------------------------------------------------------------------
function opensplash()

splash=Image.load("images/2.PNG")

Mp3me.load("sounds/splashsnd.mp3")
Mp3me.play()

fader = Image.createEmpty(480,272)
alphaValue = 255
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
while true do
screen:clear()
screen:blit(0,0,splash)
screen:blit(0,0,fader)
if alphaValue > 0 then
alphaValue = alphaValue - 5
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
screen.waitVblankStart(200) 
while true do
screen:clear()
screen:blit(0,0,splash)
screen:blit(0,0,fader)
if alphaValue < 255 then
alphaValue = alphaValue + 5
else
gamestate=1
Mp3me.stop()
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
end

-------------------------------------------------------------------------------------------------------------------
function luasplash()
splash=Image.load("images/0.PNG")

fader = Image.createEmpty(480,272)
alphaValue = 255
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
while true do
screen:clear()
screen:blit(0,0,splash)
screen:blit(0,0,fader)
if alphaValue > 0 then
alphaValue = alphaValue - 5
else
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
screen.waitVblankStart(200) 
while true do
screen:clear()
screen:blit(0,0,splash)
screen:blit(0,0,fader)
if alphaValue < 255 then
alphaValue = alphaValue + 5
else
gamestate=2
break
end
faderColor = Color.new(0,0,0,alphaValue)
fader:clear(faderColor)
screen.waitVblankStart()
screen.flip()
end
end

-------------------------------------------------------------------------------------------------------------------
function mainmenu()

mbg=Image.load("images/1.PNG")

Mp3me.stop()
Mp3me.load("sounds/menubgsnd.mp3")
Mp3me.play()

while true do

screen:blit(0,0,mbg)

pad=Controls.read()

	if option_selected==1 then
	screen:blit(101,22,pointer)
	end

	if option_selected==2 then
	screen:blit(101,68,pointer)
	end

	if option_selected==3 then
	screen:blit(101,117,pointer)
	end

	if option_selected==4 then
	screen:blit(101,163,pointer)
	end

	if option_selected==5 then
	screen:blit(101,208,pointer)
	end

	if pad:up() then
	Mp3me.stop()
	Mp3me.load("sounds/menuslt1.mp3")
	Mp3me.play()
	end

	if pad:down() then
	Mp3me.stop()
	Mp3me.load("sounds/menuslt1.mp3")
	Mp3me.play()
	end

	if pad:up() and oldpad:up() ~= pad:up() and option_selected>1 then
	option_selected=option_selected-1
	end

	if pad:down() and oldpad:down() ~= pad:down() and option_selected<5 then
	option_selected=option_selected+1
	end

	if pad:cross() then
	oldpad=pad
		if option_selected==1 then
		gamestate=3
		break
		end

		if option_selected==2 then
		gamestate=4
		break
		end

		if option_selected==3 then
		gamestate=5
		break
		end

		if option_selected==4 then
		gamestate=6
		break
		end

		if option_selected==5 then
		gamestate=7
		break
		end

	end

screen.waitVblankStart()
screen:flip()
oldpad=pad
end

end

--------------------------------------------------------------------------------------------------------------
function mapslct()

Mp3me.stop()

snslct=Image.load("images/23.PNG")

screen:clear (black)

tmvms=0

while true do

tmvms=tmvms+1

screen:blit(0,0,snslct)
screen:print(160, 226, "Press X Button to select", white)

pad=Controls.read()

	if igbgs==1 then
	screen:blit(130,202,pointer)
	end

	if igbgs==2 then
	screen:blit(370,202,pointer)
	end

	if pad:right() and oldpad:right() ~= pad:right() and igbgs<2 then
	igbgs=igbgs+1
	end

	if pad:left() and oldpad:left() ~= pad:left() and igbgs>1 then
	igbgs=igbgs-1
	end

	if pad:cross() and tmvms>6 then
        gamestate=8
        break
	end

screen.waitVblankStart()
screen:flip()
oldpad=pad
end

end



---------------------------------------------------------------------------------------------------------------
function maingame()

screen:clear()

callsndtm=0
callsnd=1
lurehun=0
sndslct=20
sndtm=0
bgsndtm=0
rec = 1
recx = 229
recy = 202
escsnd = 0

cambg1=Image.load("images/18.PNG")
cambg2=Image.load("images/19.PNG")
mgbg1=Image.load("images/3.PNG")
mgbg2=Image.load("images/15.PNG")
mgbg3=Image.load("images/21.PNG")
mgbg4=Image.load("images/22.PNG")
dgun=Image.load("images/10.PNG")
dcam=Image.load("images/16.PNG")
dcam2=Image.load("images/24.PNG")
darmu=Image.load("images/4.PNG")
darmr=Image.load("images/5.PNG")
darmd=Image.load("images/6.PNG")
darml=Image.load("images/7.PNG")
hunimg1=Image.load("images/9.PNG")
hunimg2=Image.load("images/12.PNG")
hunimg3=Image.load("images/13.PNG")
hunimg4=Image.load("images/14.PNG")
hunimgz1 = 0 - 220
hunimgz2 = 700
hunimgz3 = 0 - 220
hunimgz4 = 700
hunimg1d = 0
hunimg2d = 0
hunimg3d = 0
hunimg4d = 0
lasthunnum = 1
hunscreamtm = 0
hunscream = 0
hunscreamtm2 = 0
hunscream2 = 0
hunscreamtm3 = 0
hunscream3 = 0
hunscreamtm4 = 0
hunscream4 = 0
fartslsnd = 1
lurhuntm = 0
lurhunnum = 0
camslc = 1

while true do

callsndtm = callsndtm+1

if callsndtm>400 then
callsndtm=0
end

if sndslct==20 then
Mp3me.stop()
Mp3me.load("sounds/wvpn.mp3")
Mp3me.play()
sndslct=0
end

if sndslct==0 then
bgsndtm = bgsndtm+1
end

if sndslct==1 then
escsnd=0
Mp3me.stop()
Mp3me.load("sounds/gmbg.mp3")
Mp3me.play()
sndslct=0
end

if sndslct==2 then
sndtm = sndtm+1
end

if sndslct==3 then
sndtm = sndtm+0.14
end

if sndslct==4 then
sndtm = sndtm+0.05
end

if sndslct==5 then
sndtm = sndtm+0.1
end

if sndslct==6 then
sndtm = sndtm+0.07
end

if sndslct==7 then
sndtm = sndtm+0.2
end

if sndslct==8 then
sndtm = sndtm+0.26
end

if bgsndtm>440 then
sndslct=1
sndtm=0
bgsndtm=0
end

if sndtm>30 then
sndslct=1
sndtm=0
bgsndtm=0
end

if igbgs==1 then
screen:blit(0,0,mgbg1)
end
if igbgs==2 then
screen:blit(0,0,mgbg3)
end
screen:print(5, 256, "KILLS:"..kills, green)
screen:print(78, 256, "FART", white)
screen:print(148, 256, "CALL", white)
screen:print(228, 246, "AIM", white)
screen:print(288, 256, "LOOK", white)
screen:print(353, 256, "COMPASS", green)
screen:print(440, 256, "QUIT", white)
screen:blit(hunimgz1,107,hunimg1)
screen:blit(hunimgz2,107,hunimg2)
screen:blit(hunimgz3,79,hunimg3)
screen:blit(hunimgz4,79,hunimg4)
if igbgs==1 then
screen:blit(0,0,mgbg2)
end
if igbgs==2 then
screen:blit(0,0,mgbg4)
end

if lurhunnum==1 then
lurhuntm = lurhuntm + 1
end

if (lurehun>6 or lurhuntm==2000) and lasthunnum==1 then
lurhuntm = 0
lurhunnum = 0
hunimg4d=1
hunsndtm=1
lasthunnum=2
lurehun = 0
end

if (lurehun>6 or lurhuntm==2000) and lasthunnum==2 then
lurhuntm = 0
lurhunnum = 0
hunimg3d=1
hunsndtm=1
lasthunnum=3
lurehun = 0
end

if (lurehun>6 or lurhuntm==2000) and lasthunnum==3 then
lurhuntm = 0
lurhunnum = 0
hunimg2d=1
hunsndtm=1
lasthunnum=4
lurehun = 0
end

if (lurehun>6 or lurhuntm==2000) and lasthunnum==4 then
lurhuntm = 0
lurhunnum = 0
hunimg1d=1
hunsndtm=1
lasthunnum=1
lurehun = 0
end

if hunimg1d==1 and hunsndtm==1 then
lurhuntm = 0
lurhunnum = 0
sndslct=3
Mp3me.stop()
Mp3me.load("sounds/hun1.mp3")
Mp3me.play()
hunsndtm=0
end
if hunimg2d==1 and hunsndtm==1 then
lurhuntm = 0
lurhunnum = 0
sndslct=7
Mp3me.stop()
Mp3me.load("sounds/hun2.mp3")
Mp3me.play()
hunsndtm=0
end
if hunimg3d==1 and hunsndtm==1 then
lurhuntm = 0
lurhunnum = 0
sndslct=3
Mp3me.stop()
Mp3me.load("sounds/hun3.mp3")
Mp3me.play()
hunsndtm=0
end
if hunimg4d==1 and hunsndtm==1 then
lurhuntm = 0
lurhunnum = 0
sndslct=3
Mp3me.stop()
Mp3me.load("sounds/hun4.mp3")
Mp3me.play()
hunsndtm=0
end

if hunimg1d==1 then
ranhunnum=math.random(1,2)
hunimgz1 = hunimgz1 + ranhunnum
end
if hunimg2d==1 then
ranhunnum=math.random(1,2)
hunimgz2 = hunimgz2 - ranhunnum
end
if hunimg3d==1 then
ranhunnum=math.random(1,2)
hunimgz3 = hunimgz3 + ranhunnum
end
if hunimg4d==1 then
ranhunnum=math.random(1,2)
hunimgz4 = hunimgz4 - ranhunnum
end

if hunimgz1>520 then
escsnd=1
sndslct=3
Mp3me.stop()
Mp3me.load("sounds/hunesc1.mp3")
Mp3me.play()
hunimg1d=0
hunimgz1 = 0 - 220
lurehun = 0
end
if hunimgz2<0 then
escsnd=1
sndslct=4
Mp3me.stop()
Mp3me.load("sounds/hunesc2.mp3")
Mp3me.play()
hunimg2d=0
hunimgz2 = 700
lurehun = 0
end
if hunimgz3>520 then
escsnd=1
sndslct=3
Mp3me.stop()
Mp3me.load("sounds/hunesc3.mp3")
Mp3me.play()
hunimg3d=0
hunimgz3 = 0 - 220
lurehun = 0
end
if hunimgz4<0 then
escsnd=1
sndslct=5
Mp3me.stop()
Mp3me.load("sounds/hunesc4.mp3")
Mp3me.play()
hunimg4d=0
hunimgz4 = 700
lurehun = 0
end

if recx<160 then
screen:blit(344,236,darml)
end

if recx>320 then
screen:blit(372,237,darmr)
end

if recx>159 and recx<321 and recy<137 then
screen:blit(371,212,darmu)
end

if recx>159 and recx<321 and recy>136 then
screen:blit(371,237,darmd)
end

pad=Controls.read()

if pad:up() and recy>0 then
recy = recy - 5
end

if pad:down() and recy<272 then
recy = recy + 5
end

if pad:left() and recx>0 then
recx = recx - 5
end

if pad:right() and recx<480 then
recx = recx + 5
end

if rec==1 then
screen:blit(recx,recy,pointer)
end

if rec==2 then
screen:blit(recx,recy,dgun)
end

if rec==3 and igbgs==1 then
screen:blit(0,0,dcam)
end

if rec==3 and igbgs==2 then
screen:blit(0,0,dcam2)
end

if hunscream==1 then
hunscreamtm = hunscreamtm + 1
end

if hunscreamtm>20 then
		sndslct=4
		Mp3me.stop()
		Mp3me.load("sounds/hunsht.mp3")
		Mp3me.play()
		hunscream = 0
		hunscreamtm = 0
		lurehun = 0
end

if hunscream2==1 then
hunscreamtm2 = hunscreamtm2 + 1
end

if hunscreamtm2>20 then
		sndslct=6
		Mp3me.stop()
		Mp3me.load("sounds/hunsht2.mp3")
		Mp3me.play()
		hunscream2 = 0
		hunscreamtm2 = 0
		lurehun = 0
end

if hunscream3==1 then
hunscreamtm3 = hunscreamtm3 + 1
end

if hunscreamtm3>20 then
		sndslct=6
		Mp3me.stop()
		Mp3me.load("sounds/hunsht3.mp3")
		Mp3me.play()
		hunscream3 = 0
		hunscreamtm3 = 0
		lurehun = 0
end

if hunscream4==1 then
hunscreamtm4 = hunscreamtm4 + 1
end

if hunscreamtm4>20 then
		sndslct=3
		Mp3me.stop()
		Mp3me.load("sounds/hunsht4.mp3")
		Mp3me.play()
		hunscream4 = 0
		hunscreamtm4 = 0
		lurehun = 0
end

		if pad:cross() and oldpad:cross() ~= pad:cross() and rec==2 and recx>hunimgz1-44 and recx<hunimgz1 and recy+41>107 and recy<107 then
		hunimg1d=0
		hunimgz1 = 0 - 220
		hunscream2 = 1
		lurehun = 0
		kills = kills+1
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and rec==2 and recx>hunimgz2-44 and recx<hunimgz2 and recy+41>107 and recy<107 then
		hunimg2d=0
		hunimgz2 = 700
		hunscream = 1
		lurehun = 0
		kills = kills+1
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and rec==2 and recx>hunimgz3-44 and recx<hunimgz3 and recy+41>79 and recy<79 then
		hunimg3d=0
		hunimgz3 = 0 - 220
		lurehun = 0
		hunscream3 = 1
		kills = kills+1
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and rec==2 and recx>hunimgz4-44 and recx<hunimgz4 and recy+41>79 and recy<79 then
		hunimg4d=0
		hunimgz4 = 700
		hunscream4 = 1
		lurehun = 0
		kills = kills+1
 		end

		if recx>62 and recx<114 and recy>222 and recy<262 and rec==1 then
		screen:print(78, 256, "FART", yellow)
		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>62 and recx<114 and recy>222 and recy<262 and fartslsnd==1 then
		lurhunnum=1
		sndslct=2
		Mp3me.stop()
		Mp3me.load("sounds/fartslt.mp3")
		Mp3me.play()
		fartslsnd = 2
		lurehun = lurehun+1
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>62 and recx<114 and recy>222 and recy<262 and fartslsnd==2 then
		lurhunnum=1
		sndslct=2
		Mp3me.stop()
		Mp3me.load("sounds/fartslt2.mp3")
		Mp3me.play()
		fartslsnd = 3
		lurehun = lurehun+1
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>62 and recx<114 and recy>222 and recy<262 and fartslsnd==3 then
		lurhunnum=0
		lurhuntm=0
		sndslct=5
		Mp3me.stop()
		Mp3me.load("sounds/fartslt3.mp3")
		Mp3me.play()
		fartslsnd = 1
		lurehun = 0
 		end

		if recx>62 and recx<114 and recy>222 and recy<262 and rec==1 then
		screen:print(78, 256, "FART", yellow)
		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and rec==1 and (sndslct==0 or sndslct==1) and recx>146 and recx<174 and recy>222 and recy<262 and callsnd==1 and callsndtm>10 then
		lurhunnum=1
		sndslct=3
		Mp3me.stop()
		Mp3me.load("sounds/call1.mp3")
		Mp3me.play()
		callsndtm=0
		lurehun = lurehun+1
		callsnd=2
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>146 and recx<174 and recy>222 and recy<262 and callsnd==2 and callsndtm>10 then
		lurhunnum=1
		sndslct=3
		Mp3me.stop()
		Mp3me.load("sounds/call2.mp3")
		Mp3me.play()
		callsndtm=0
		lurehun = lurehun+1
		callsnd=3
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>146 and recx<174 and recy>222 and recy<262 and callsnd==3 and callsndtm>10 then
		lurhunnum=1
		sndslct=3
		Mp3me.stop()
		Mp3me.load("sounds/call3.mp3")
		Mp3me.play()
		callsndtm=0
		lurehun = lurehun+1
		callsnd=4
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>146 and recx<174 and recy>222 and recy<262 and callsnd==4 and callsndtm>10 then
		lurhunnum=1
		sndslct=3
		Mp3me.stop()
		Mp3me.load("sounds/call4.mp3")
		Mp3me.play()
		callsndtm=0
		lurehun = lurehun+1
		callsnd=5
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>146 and recx<174 and recy>222 and recy<262 and callsnd==5 and callsndtm>10 then
		lurhunnum=1
		sndslct=3
		Mp3me.stop()
		Mp3me.load("sounds/call5.mp3")
		Mp3me.play()
		callsndtm=0
		lurehun = lurehun+1
		callsnd=6
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and (sndslct==0 or sndslct==1) and rec==1 and recx>146 and recx<174 and recy>222 and recy<262 and callsnd==6 and callsndtm>10 then
		lurhunnum=0
		lurhuntm=0
		sndslct=5
		Mp3me.stop()
		Mp3me.load("sounds/call6.mp3")
		Mp3me.play()
		callsndtm=0
		lurehun = 0
		callsnd=1
 		end

		if recx>146 and recx<174 and recy>222 and recy<262 and rec==1 then
		screen:print(148, 256, "CALL", yellow)
		end

		if recx>214 and recx<264 and recy>230 and recy<268 and rec==1 then
		screen:print(228, 246, "AIM", yellow)
		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and rec==1 and (sndslct==0 or sndslct==1) and recx>214 and recx<264 and recy>230 and recy<268 then
		sndslct=2
		Mp3me.stop()
		Mp3me.load("sounds/gnslt.mp3")
		Mp3me.play()
		rec = 2
		recx = 197
                recy = 142
 		end

		if recx>436 and recx<476 and recy>222 and recy<262 and rec==1 then
		screen:print(440, 256, "QUIT", yellow)
		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and escsnd==0 and (sndslct==0 or sndslct==1) and rec==2 then
                shots=shots+1
		sndslct=2
		Mp3me.stop()
		Mp3me.load("sounds/gunsht.mp3")
		Mp3me.play()
 		end

		if rec==3 and camslc==1 then
		screen:blit(197,69,cambg1)
		end

		if rec==3 and camslc==3 then
		screen:blit(212,87,cambg2)
		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and camslc==1 and (sndslct==0 or sndslct==1) and rec==1 and recx>280 and recx<336 and recy>230 and recy<268 then
		sndslct=7
		Mp3me.stop()
		Mp3me.load("sounds/camslt.mp3")
		Mp3me.play()
		rec = 3
		camslc=2
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and camslc==2 and (sndslct==0 or sndslct==1) and rec==1 and recx>280 and recx<336 and recy>230 and recy<268 then
		sndslct=8
		Mp3me.stop()
		Mp3me.load("sounds/camslt2.mp3")
		Mp3me.play()
		rec = 3
		lurhunnum=1
		lurehun = lurehun+1
		camslc=3
 		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and camslc==3 and (sndslct==0 or sndslct==1) and rec==1 and recx>280 and recx<336 and recy>230 and recy<268 then
		sndslct=8
		Mp3me.stop()
		Mp3me.load("sounds/camslt3.mp3")
		Mp3me.play()
		rec = 3
		lurhunnum=1
		lurehun = lurehun+1
		camslc=1
 		end

		if recx>280 and recx<336 and recy>234 and recy<262 and rec==1 then
		screen:print(288, 256, "LOOK", yellow)
		end

		if pad:cross() and oldpad:cross() ~= pad:cross() and rec==1 and recx>436 and recx<476 and recy>222 and recy<262 then
		gamestate=2
		option_selected=1
                break
		end

		if rec==2 and pad:circle() and oldpad:circle() ~= pad:circle() and (sndslct==0 or sndslct==1) then
		sndslct=2
		Mp3me.stop()
		Mp3me.load("sounds/gnslt.mp3")
		Mp3me.play()
		rec = 1
		end


		if rec==3 and pad:circle() and oldpad:circle() ~= pad:circle() and (sndslct==0 or sndslct==1) then
		sndslct=2
		Mp3me.stop()
		Mp3me.load("sounds/gnslt.mp3")
		Mp3me.play()
		rec = 1
		end

	screen.waitVblankStart()
	screen:flip()
	oldpad=pad
	end
end

--------------------------------------------------------------------------------------------------------------------
function story()

screen:clear()

tmv = 1

credy = 272

sbg=Image.load("images/20.PNG")

Mp3me.stop()
Mp3me.load("sounds/menubgsnd.mp3")
Mp3me.play()

while true do
screen:blit(0,0,sbg)

tmv = tmv + 1

pad = Controls.read()

if credy > 70 then
credy = credy - 0.5
end

screen:print(10, credy + 10, "The story of Bambo is a sad tell of tail.", white)
screen:print(10, credy + 20, "Invading hillbillies have killed the doe of his dreams.", white)
screen:print(10, credy + 30, "Rage fills Bambo as his love lies dying in his arms.", white)
screen:print(10, credy + 40, "Now it is time for the hunted to become the hunter.", white)
screen:print(10, credy + 50, "Take up arms as you take revenge on the hillbillies.", white)
screen:print(10, credy + 60, "Why are you still reading this?", white)
screen:print(10, credy + 70, "Go shoot something already.", white)
screen:print(10, credy + 80, "You must be a hillbilly.", white)
screen:print(10, credy + 90, "I can wait as long as you.", white)
screen:print(10, credy + 100, "Now you're just pissing me off.", white)
screen:print(180, credy + 170, "Press O to return", white)


		if pad:circle() then
		gamestate=2
		option_selected=1
                break
		end

	screen.waitVblankStart()
	screen:flip()
	oldpad=pad
	end
end

--------------------------------------------------------------------------------------------------------------------
function trophies()

screen:clear()

cbg=Image.load("images/11.PNG")

Mp3me.stop()
Mp3me.load("sounds/tro.mp3")
Mp3me.play()

while true do
screen:blit(0,0,cbg)

pad=Controls.read()


screen:print(150, 93, "Hunters Bagged This Game:"..kills, green)
screen:print(150, 103, "Shots Fired This Game:"..shots, green)
screen:print(150, 113, "Hunters Bagged Last Game:"..lsthnt, green)
screen:print(150, 123, "Shots Fired Last Game:"..lstsht, green)
screen:print(150, 133, "Total Hunters Bagged:"..totkills+kills, green)
screen:print(150, 143, "Total Shots Fired:"..tltsht+shots, green)
screen:print(180, 240, "Press O to return", white)

		if pad:circle() then
		gamestate=2
		option_selected=1
                break
		end

	screen.waitVblankStart()
	screen:flip()
	oldpad=pad
	end
end

--------------------------------------------------------------------------------------------------------------------
function credits()

screen:clear()

tmv = 1

credy = 272

cbg=Image.load("images/11.PNG")

Mp3me.stop()
Mp3me.load("sounds/menubgsnd.mp3")
Mp3me.play()

while true do
screen:blit(0,0,cbg)

tmv = tmv + 1

pad = Controls.read()

if credy > 80 then
credy = credy - 0.5
end

screen:print(10, credy + 10, "Thank you for trying Deer Avenger Mini V2.00", white)
screen:print(10, credy + 20, "The game Deer Avenger was first made for PC & MAC", white)
screen:print(10, credy + 30, "Deer Avenger is a Simon & Schuster game", white)
screen:print(10, credy + 40, "Deer Avenger Mini is a knock off by Code Red", white)
screen:print(10, credy + 50, "You should try the real game", white)
screen:print(10, credy + 60, "Thanks to Dark~Alex for all his hard work on CFW's", white)
screen:print(10, credy + 70, "Thanks to Shine and Nevyn for Lua Player", white)
screen:print(10, credy + 80, "Thanks to Homemister and PickDat for Lua Player HM6", white)
screen:print(10, credy + 90, "Original release of Deer Avenger Mini @ www.psp-hacks.com", white)
screen:print(180, credy + 160, "Press O to return", white)


		if pad:circle() then
		gamestate=2
		option_selected=1
                break
		end

	screen.waitVblankStart()
	screen:flip()
	oldpad=pad
	end
end

--------------------------------------------------------------------------------------------------------------------
function savequit()

svpr=Image.load("images/17.PNG")
file = io.open("data/bambo.sav","w")
file:write("totkills = "..totkills+kills)
file:close()

file = io.open("data/lstht.sav","w")
file:write("lsthnt = "..kills)
file:close()

file = io.open("data/tltsht.sav","w")
file:write("tltsht = "..tltsht+shots)
file:close()

file = io.open("data/lstsht.sav","w")
file:write("lstsht = "..shots)
file:close()

tmv = 1

while true do

screen:clear(black)

tmv = tmv+1

if tmv>0 then
screen:blit(110,122,svpr)
end
if tmv>30 then
screen:blit(155,122,svpr)
end
if tmv>60 then
screen:blit(200,122,svpr)
end
if tmv>90 then
screen:blit(245,122,svpr)
end
if tmv>100 then
screen:blit(290,122,svpr)
end

screen:print(125, 133, "SAVING YOUR TROPHY COUNT", white)

if tmv>130 then
System.Quit()
end

	screen.waitVblankStart()
	screen:flip()
	oldpad=pad
	end
end
-------------------------------------------------------------------------------------------------------------------
--main loop

while true do
screen:clear()

	if gamestate==0 then
	opensplash()
	end

	if gamestate==1 then
	luasplash()
	end

	if gamestate==2 then
	mainmenu()
	end

	if gamestate==3 then
	mapslct()
	end

	if gamestate==4 then
	story()
	end

	if gamestate==5 then
	trophies()
	end

	if gamestate==6 then
	credits()
	end

	if gamestate==7 then
	savequit()
	end

	if gamestate==8 then
	maingame()
	end

screen.waitVblankStart()
screen:flip()
end

