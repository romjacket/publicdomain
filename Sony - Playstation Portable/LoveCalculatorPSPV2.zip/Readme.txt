######                                                                        
#     # #####  ######  ####  ###### #    # #####   ##   ##### #  ####  #    # 
#     # #    # #      #      #      ##   #   #    #  #    #   # #    # ##   # 
######  #    # #####   ####  #####  # #  #   #   #    #   #   # #    # # #  # 
#       #####  #           # #      #  # #   #   ######   #   # #    # #  # # 
#       #   #  #      #    # #      #   ##   #   #    #   #   # #    # #   ## 
#       #    # ######  ####  ###### #    #   #   #    #   #   #  ####  #    # 

Love Calculator PSP V2 est un homebrew qui permet de calculer vos chances de sortir
avec un gar�on ou une fille, simplement en entrant les 2 noms.

Cet homebrew est gratuit et a �t� d�velopp� par J3r3mie, membre de la Black Dev's
Team. Pour plus d'info visitez leur site web : www.blackdev.hotgoo.net

Pour t�l�chargez cet homebrew, rendez vous sur mon blog : J3r3mieDev.blogspot.com

#     #                                                               
##    #  ####  #    # #    # ######   ##   #    # ##### ######  ####  
# #   # #    # #    # #    # #       #  #  #    #   #   #      #      
#  #  # #    # #    # #    # #####  #    # #    #   #   #####   ####  
#   # # #    # #    # #    # #      ###### #    #   #   #           # 
#    ## #    # #    #  #  #  #      #    # #    #   #   #      #    # 
#     #  ####   ####    ##   ###### #    #  ####    #   ######  ####  

L'homebrew est disponible en Fran�ais et en Anglais. La langue est demand� au d�marrage
de l'homebrew.

L'homebrew est d�sormais divis� en 2 modes, un de ces modes est celui de la version pr�c�dente,
les pourcentages sont donc toujours al�atoires. Dans l'autre mode, les pourcentage sont les m�mes,
majuscules ou non.

Ajout d'un simple fond d'�cran.

Le module de screenshot est d�sormais am�lior�. Les captures sont au format PNG et sont
stock�s dans le dossier PSP/PHOTO/Love Calculator PSP/. Appuyez sur Select pour prendre
une capture d'�cran.

L'homebrew a d�sormais une fonction qui permet d'enregistrer/charger un calcul gr�ce au log
officiel de Sony.

###                                                                        
 #  #    # ######  ####  #####  #    #   ##   ##### #  ####  #    #  ####  
 #  ##   # #      #    # #    # ##  ##  #  #    #   # #    # ##   # #      
 #  # #  # #####  #    # #    # # ## # #    #   #   # #    # # #  #  ####  
 #  #  # # #      #    # #####  #    # ######   #   # #    # #  # #      # 
 #  #   ## #      #    # #   #  #    # #    #   #   # #    # #   ## #    # 
### #    # #       ####  #    # #    # #    #   #   #  ####  #    #  ####  

Pour un meilleur rendement, je vous conseil d'utiliser l'archive officiel disponible sur mon blog.

Je tient � remercier les membres de XtreamLua pour l'id�e du 2e mode.

Au plaisir,

J3r3mie.