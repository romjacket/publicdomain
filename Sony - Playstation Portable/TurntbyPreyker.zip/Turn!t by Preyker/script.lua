green = pge.gfx.createcolor(255, 150, 0)

verdana18 = pge.font.load("verdana.ttf", 18, PGE_RAM)

startpic = pge.texture.load("start.png")
backgpic = pge.texture.load("backg.png", PGE_VRAM)
gameoverpic = pge.texture.load("gameover.png")
links = pge.texture.load("links.png")
rechts = pge.texture.load("rechts.png")
oben = pge.texture.load("oben.png")
unten = pge.texture.load("unten.png")
viereck = pge.texture.load("viereck.png")
kreis = pge.texture.load("kreis.png")
dreieck = pge.texture.load("dreieck.png")
kreuz = pge.texture.load("kreuz.png")

mis_score = 0
bg_rotation = 0
keynumber = pge.math.randint(1, 8)
keynumber = pge.math.randint(1, 8)
timetopress = 0
x = 240 - 136

function start()
	while pge.running() do
	pge.controls.update()
	pge.gfx.startdrawing()
	pge.gfx.clearscreen()
	startpic:activate()
	startpic:draweasy(0, 0)
	
	if pge.controls.pressed(PGE_CTRL_START) then
	game()
	end
	
	pge.gfx.enddrawing()
	pge.gfx.swapbuffers()
	end
end

function gameover()
	while pge.running() do
	pge.controls.update()
	pge.gfx.startdrawing()
	pge.gfx.clearscreen()
	gameoverpic:activate()
	gameoverpic:draweasy(0, 0)
	
	if pge.controls.pressed(PGE_CTRL_START) then
	mis_score = 0
	bg_rotation = 0
	keynumber = pge.math.randint(1, 8)
	keynumber = pge.math.randint(1, 8)
	timetopress = 0
	start()
	end
	
	pge.gfx.enddrawing()
	pge.gfx.swapbuffers()
	end
end

function game()
	while pge.running() do
	pge.controls.update()
	pge.gfx.startdrawing()
	pge.gfx.clearscreen()
	backgpic:activate()
	backgpic:draweasy(x, 0, bg_rotation)
	
	bg_rotation = bg_rotation + 0.05
	
	if mis_score >= 5 then
	pge.delay(1000000)
	pge.delay(1000000)
	gameover()
	end
	
	if keynumber == 1 then
	timetopress = timetopress + 1
	links:activate()
	links:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_LEFT) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	if keynumber == 2 then
	timetopress = timetopress + 1
	rechts:activate()
	rechts:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_RIGHT) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	if keynumber == 3 then
	timetopress = timetopress + 1
	oben:activate()
	oben:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_UP) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	if keynumber == 4 then
	timetopress = timetopress + 1
	unten:activate()
	unten:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_DOWN) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	if keynumber == 5 then
	timetopress = timetopress + 1
	viereck:activate()
	viereck:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_SQUARE) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	if keynumber == 6 then
	timetopress = timetopress + 1
	kreis:activate()
	kreis:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_CIRCLE) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	if keynumber == 7 then
	timetopress = timetopress + 1
	dreieck:activate()
	dreieck:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_TRIANGLE) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	if keynumber == 8 then
	timetopress = timetopress + 1
	kreuz:activate()
	kreuz:draweasy(x, 0, bg_rotation)
	
		if timetopress <= 100 and pge.controls.pressed(PGE_CTRL_CROSS) then
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
		if timetopress > 100 then
		mis_score = mis_score + 1
		keynumber = pge.math.randint(1, 8)
		keynumber = pge.math.randint(1, 8)
		timetopress = 0
		end
		
	end
	
	verdana18:activate()
	verdana18:print(350, 5, green, "Fails: ")
	verdana18:print(400, 5, green, mis_score)
	verdana18:print(420, 5, green, "/5")
	
	pge.gfx.enddrawing()
	pge.gfx.swapbuffers()
	end
end

while pge.running() do
	start()
end