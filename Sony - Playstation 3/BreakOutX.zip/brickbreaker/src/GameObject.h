#ifndef GAMEOBJECT_H_
#define GAMEOBJECT_H_

#include "Vec2.h"

typedef struct {
  int health;
  float red;
  float green;
  float blue;
  bool enable;
  bool isHit;
  bool isDead;
  Vec2 position;
  Vec2 velocity;
  Vec2 lastPos;
}GameObject;

#endif