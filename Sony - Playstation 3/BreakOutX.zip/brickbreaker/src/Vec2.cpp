#include "Vec2.h"

//Create new vectors to pass in new variables
Vec2 Vec2_create(float x, float y){
	// Create a vector 
	Vec2 newVec;
	// Initialize the components with the arguments passed in
	newVec.x = x;
	newVec.y = y;
	return newVec;
}

Vec2 Vec2_add(Vec2 a, Vec2 b){
     Vec2 newVec;
     newVec.x = a.x + b.x;
     newVec.y = a.y + b.y;
     return newVec;
}