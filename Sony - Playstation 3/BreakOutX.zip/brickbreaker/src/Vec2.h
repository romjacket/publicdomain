#ifndef VEC2_H_
#define VEC2_H_

typedef struct {
  float x,y;
} Vec2;

Vec2 Vec2_create(float x, float y);
Vec2 Vec2_add(Vec2 a, Vec2 b);

#endif