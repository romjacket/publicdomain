/* 
 * PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001
 *                Copyright (C) 2007 Sony Computer Entertainment Inc.
 *                                               All Rights Reserved.
 *
 * Have a nice day
 * -Lachrymose
 */
 
#include <cell/fs/cell_fs_file_api.h>
#include <stdlib.h>
#include <stdio.h>

#include <sys/sys_time.h>
#include <sys/process.h>
#include <sys/spu_initialize.h>
#include <sys/paths.h>
#include <PSGL/psgl.h>
#include <PSGL/psglu.h>
#include <Cg/cg.h>
#include <cell/dbgfont.h>

#include "Common/gfxCommon.h"
#include "Common/gfxObject.h"
#include "Common/gfxPad.h"
#include "Common/mscommon.h"

#include "Vec2.h"
#include "GameObject.h"

#define CAM_SPEED 0.5f
#define CAM_RPY_SPEED 1.0f
#define DEFAULT_VIEW_DIST  -5.f		// setting up the view
#define NEAR_CLIP	0.1f
#define FAR_CLIP	8500.1f
#define FOV_Y		40.0f			//field of view in the y direction
#define degreesToRadians(__ANGLE__) (M_PI * (__ANGLE__) / 180.0)
#define radiansToDegrees(__ANGLE__) (180.0 * (__ANGLE__) / M_PI)

using namespace Vectormath;
using namespace Aos;

//Paddle Coordinates
float paddleCoord[] = { -0.1f, 0.02f, 0.0f,
						 0.1f, 0.02f, 0.0f, 
						-0.1f,-0.02f, 0.0f, 
						 0.1f,-0.02f, 0.0f };

float paddleColor[] = { 0.0, 0.0, 0.0,
						1.0, 0.0, 0.0,
						1.0, 0.0, 0.0,
						0.0, 0.0, 0.0 };
						
float blockCoord[] = { -0.1f, 0.025f, 0.0f,
						0.1f, 0.025f, 0.0f, 
					   -0.1f,-0.025f, 0.0f, 
					    0.1f,-0.025f, 0.0f };

// Border coordinates
float borderCoord[] = { -1.06, -0.5, 0.0, 
						-1.06,  0.5, 0.0,
					 	 1.06,  0.5, 0.0, 
						 1.06, -0.5, 0.0,
						-1.06, -0.5, 0.0 };
					 
float backgroundCoord[] = { -5.0, -2.0, -1.0,
							-5.0, -1.5, -10.0,
							 5.0, -2.0, -1.0,
							 5.0, -1.5, -10.0 };
	
float backgroundColor[] = { 0.0, 1.0, 0.0,
							0.5, 0.0, 0.9,
							0.0, 1.0, 0.0,
							0.5, 0.0, 0.9 };

// Menu stuff
float bgCoord[] = { -2.0, -1.5, 0.0, 
					-2.0,  0.0, 0.0,
				 	 2.0, -1.5, 0.0, 
					 2.0,  0.0, 0.0 };
						 
float bgColor[] = { 1.0, 1.0, 1.0,
					0.0, 0.0, 0.0,
					1.0, 1.0, 1.0,
					0.0, 0.0, 0.0 };		

float menuBrickCoord[] = { -0.02f, 0.02f, 0.0f,
						    0.02f, 0.02f, 0.0f, 
						   -0.02f,-0.02f, 0.0f, 
						    0.02f,-0.02f, 0.0f };
						
Vector3       		ViewPos; //What you're looking at   
Vector3       		ViewAng; // Angle which you're looking at
Matrix4       		View;	//current view ( camera ) matrix
void initVectors();

// Game objects
GameObject brick[7][7];
GameObject ball;
GameObject player;
GameObject enemy;
Vec2 	   border;

float coolUpDown, coolDownDown;

//The players speed
float Speed = .0035f;
float menuc;

bool 	isMenuOn   	= true;
bool	gamePaused 	= false;
bool	is_running 	= true;

int selectedMenuOption = 1;
int brickCount;
int level = 1;
int numLives = 5;

GLfloat ellipseVertices[720];
const GLfloat xradius = 0.02f; 
const GLfloat yradius = 0.02f;

void initView(){

	glClearColor(0.0f,0.0f,0.0f, 0.0f);
	glClearDepthf(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDisable (GL_CULL_FACE);

	//set the viewing parameters
	ViewPos = Vector3(0.0f,0.0f,DEFAULT_VIEW_DIST);
	ViewAng = Vector3(0.0f,0.0f,0.0f);

	//FPS reporting (disable vsync to get true time)
	glDisable(GL_VSYNC_SCE);

	// last the projection matrix 
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	gluPerspectivef(FOV_Y, gfxGetAspectRatio(), NEAR_CLIP,FAR_CLIP);
	glMatrixMode( GL_MODELVIEW );

}


void updateMatrices(){

	// update the view matrix
	View   			= Matrix4::identity ();
	Matrix4 trans   = Matrix4::translation (ViewPos);	 // set the translation
	Matrix4 rotX    = Matrix4::rotationX (ViewAng[0]);	 // set an x rotation  
	Matrix4 rotY    = Matrix4::rotationY (ViewAng[1]);	 // set a y roation 
	View 			= trans * rotX * rotY ;				 //multiply them all together

}

void controllerInput(){
	
	gfxPadRead(); 

	if(isMenuOn){
	
		if(gfxDpadUp(0)){
		
			if(coolUpDown < 1){
				coolUpDown = 100;
				selectedMenuOption -= 1;
				if(selectedMenuOption < 1) selectedMenuOption = 2;
			}
			
			else coolUpDown -= 2;
			
		}

		else coolUpDown = 0;
		
		
		if(gfxDpadDown(0)){
		
			if(coolDownDown < 1){
				coolDownDown = 100;
				selectedMenuOption += 1;
				if(selectedMenuOption > 2) selectedMenuOption = 1;
			}
			
			else coolDownDown -= 2;
			
		}		
		
		else coolDownDown = 0;
		
		
		if(gfxDpadCross(0) && selectedMenuOption == 1){
		   initVectors();
		   if(numLives < 5) numLives = 5;
		   isMenuOn = false;
		}
		
	    if(gfxDpadCross(0) && selectedMenuOption == 2){
		   psglExit();
    	   sys_process_exit(0);
		}
		
	}
	
	if(!isMenuOn){
	
		//If Up is pressed, increase the speed
		if(gfxDpadRight(0))		
			player.position.x += Speed;
			
		//If down is pressed, decrease the speed
		if(gfxDpadLeft(0))		
			player.position.x -= Speed; 	 	

		//If triangle is pressed
		if(gfxDpadTri(0)){
			initVectors(); //Reset vectors to original position.
			isMenuOn = true; //Exit back to the menu
		}
		
	}
}


void renderFunc(){

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if(isMenuOn){
	
		dbgFontPrintf(700,50,2.5f,"BreakOutX" );
		dbgFontDraw();
		
		dbgFontPrintf(800,230,2.0f," Play \n Quit");
		dbgFontDraw();

		if(numLives < 1){
			dbgFontPrintf(800,530,2.0f,"You Lose!");
		    dbgFontDraw();
		}
		
		if(selectedMenuOption == 1) menuc = 0.375;
		if(selectedMenuOption == 2) menuc = 0.275;
		
		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, menuBrickCoord);
		
		glPushMatrix(); 
		glColor4f(1.0, 0.0, 0.0, 0.2);
		glTranslatef( -0.25, menuc, -2.0 );
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
		glPopMatrix();

		glPushMatrix(); 
		glColor4f(1.0, 0.0, 0.0, 0.2);
		glTranslatef( 0.25, menuc, -2.0 );
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
		glPopMatrix();
		
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);

		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, bgCoord);

		glEnableClientState(GL_COLOR_ARRAY);
		glColorPointer(3, GL_FLOAT, 0, bgColor);
				
		glPushMatrix();
		glColor4f(1.0, 1.0, 0.0, 0.3);
		glTranslatef( 0.0, 0.0, -2.0 );
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
		glPopMatrix();

		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
				
	}
	
	if(!isMenuOn){

		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, paddleCoord);

		glEnableClientState(GL_COLOR_ARRAY);
		glColorPointer(3, GL_FLOAT, 0, paddleColor);
				
		glPushMatrix();
		glColor4f(1.0, 1.0, 0.0, 1.0);
		glTranslatef( player.position.x, player.position.y, -2.0 );
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
		glPopMatrix();

		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		
		for(int i = 1; i < 6; i++){  

			for(int j = 1; j < 6; j++){
				
				if(brick[i][j].enable){

					if(brick[i][j].health == 1){
						brick[i][j].red = 0.0;
						brick[i][j].green = 1.0;
						brick[i][j].blue = 0.0;
					}
					
					if(brick[i][j].health == 2){
						brick[i][j].red = 1.0;
						brick[i][j].green = 0.0;
						brick[i][j].blue = 0.0;
					}
					
					if(brick[i][j].health == 3){
						brick[i][j].red = 0.0;
						brick[i][j].green = 0.0;
						brick[i][j].blue = 1.0;
					}
					
					if(brick[i][j].health == 4){
						brick[i][j].red = 0.2;
						brick[i][j].green = 0.0;
						brick[i][j].blue = 1.0;
					}
					
					
					glEnableClientState(GL_VERTEX_ARRAY);
					
					glVertexPointer(3, GL_FLOAT, 0, blockCoord);										 
			    	glPushMatrix();
					glColor4f(brick[i][j].red, brick[i][j].green, brick[i][j].blue, 0.4);
					glTranslatef(brick[i][j].position.x, brick[i][j].position.y , -2.0);
					glDrawArrays(GL_TRIANGLE_STRIP, 0, 4); 
					glPopMatrix();

					glDisableClientState(GL_VERTEX_ARRAY);
				
				}
			}		   
		}

		dbgFontPrintf(100,100,1.5f,"level %i", level);
		dbgFontDraw();
		
		dbgFontPrintf(500,100,1.5f,"Bricks %i", brickCount);
		dbgFontDraw();

		dbgFontPrintf(900,100,1.5f,"Lives %i", numLives);
		dbgFontDraw();
		
		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, ellipseVertices);

		glPushMatrix();
		glColor4f(1.0, 1.0, 1.0, 1.0);
		glTranslatef( ball.position.x, ball.position.y, -2.0);
		glDrawArrays(GL_TRIANGLE_FAN, 0, 360);
		glPopMatrix();
		
		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, borderCoord);

		glPushMatrix();
		glColor4f(1.0, 1.0, 1.0, 1.0);
		glTranslatef( 0.0, 0.0, -2.0);
		glDrawArrays(GL_LINE_STRIP, 0, 5);
		glPopMatrix();
		
		glDisableClientState(GL_VERTEX_ARRAY);
		glEnable(GL_DEPTH_TEST);

		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_COLOR_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, backgroundCoord);
		glColorPointer(3, GL_FLOAT, 0, backgroundColor);
		
		glPushMatrix();
		glColor4f(0.0, 0.0, 0.0, 0.4);
		glTranslatef( 0.0, 0.0, -1.0);
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
		glPopMatrix();
				
		glDisableClientState(GL_COLOR_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glEnable(GL_DEPTH_TEST);

		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, borderCoord);
		
		glPushMatrix();
		glColor4f(1.0, 1.0, 1.0, 1.0);
		glTranslatef( 0.0, 0.0, -2.0);
		glDrawArrays(GL_LINE_STRIP, 0, 5);
		glPopMatrix();
		glDisableClientState(GL_VERTEX_ARRAY);
		
		}
	
}



void idleFunc(){ 
	
     for(int i = 1; i < 6; i++){

         for(int j = 1; j < 6; j++){
     
			if(brick[i][j].enable){
			
               if(ball.position.x > brick[i][j].position.x - 0.1 && ball.position.x < brick[i][j].position.x + 0.1 &&
			      ball.position.y > brick[i][j].position.y - 0.025 && ball.position.y < brick[i][j].position.y + 0.025){
				  
					brick[i][j].health -= 1;
					
					if(brick[i][j].health < 1){
						brick[i][j].enable = false;
						brickCount -= 1;
					}
					
					ball.velocity.y *= -1;
				  
			   }
            }
         }
     }
	
	// Bouncing off things, etc
	if(ball.position.y < -0.45){
	
	   if(ball.position.x > player.position.x - 0.1f && ball.position.x < player.position.x + 0.1f){
		  
		  float hitPercent = ((ball.position.x - player.position.x) / 0.25);

		  ball.velocity.y *= -1;
		  ball.velocity.x = hitPercent * 50;
		  
	    }
		
	}
	   
	if(ball.position.y < -0.5){
		ball.velocity.y *= -1;
	    numLives -= 1;
	}
	   
	   
	if(brickCount < 1){
		level++;
		initVectors();
	}
	
	if(numLives < 1) isMenuOn = true;
	
	if(ball.position.y > 0.5) ball.velocity.y *= -1;
	if(ball.position.x > 1.04) ball.velocity.x *= -1;
	if(ball.position.x <-1.04) ball.velocity.x *= -1;

	if(player.position.x < -0.95) player.position.x = -0.945;
	if(player.position.x >  0.95) player.position.x =  0.945;
		
	//Update the balls position with its velocity
	ball.position.x += ball.velocity.x / 5000;
	ball.position.y += ball.velocity.y / 5000;
	
}

SYS_PROCESS_PARAM(1001, 0x10000)

void initVectors(){
 
	brickCount = 0;
	
	for (int i = 0; i < 720; i+=2) {
		ellipseVertices[i] = (cos(degreesToRadians(i)) * xradius) + 0.0f;
		ellipseVertices[i+1] = (sin(degreesToRadians(i)) * yradius) + 0.0f;
	}
	
	//Initialze the vectors with the Vec2_create function found in Vec2.cpp
	player.position = Vec2_create( 0.0, -0.48);
	ball.position 	= Vec2_create( 0.0, 0.0);
	border			= Vec2_create( 0.0, 0.0);
	ball.velocity 	= Vec2_create( 5.0, -15.0);
	
	brick[1][1].position = Vec2_create(-1.0, 0.1);
	brick[2][1].position = Vec2_create(-0.5, 0.1);
	brick[3][1].position = Vec2_create( 0.0, 0.1);
	brick[4][1].position = Vec2_create( 0.5, 0.1);
	brick[5][1].position = Vec2_create( 1.0, 0.1);
	brick[1][2].position = Vec2_create(-1.0, 0.2);
	brick[2][2].position = Vec2_create(-0.5, 0.2);
	brick[3][2].position = Vec2_create( 0.0, 0.2);
	brick[4][2].position = Vec2_create( 0.5, 0.2);
	brick[5][2].position = Vec2_create( 1.0, 0.2);
	brick[1][3].position = Vec2_create(-1.0, 0.3);
	brick[2][3].position = Vec2_create(-0.5, 0.3);
	brick[3][3].position = Vec2_create( 0.0, 0.3);
	brick[4][3].position = Vec2_create( 0.5, 0.3);
	brick[5][3].position = Vec2_create( 1.0, 0.3);
	brick[1][4].position = Vec2_create(-1.0, 0.4);
	brick[2][4].position = Vec2_create(-0.5, 0.4);
	brick[3][4].position = Vec2_create( 0.0, 0.4);
	brick[4][4].position = Vec2_create( 0.5, 0.4);
	brick[5][4].position = Vec2_create( 1.0, 0.4);
	brick[1][5].position = Vec2_create(-1.0, 0.5);
	brick[2][5].position = Vec2_create(-0.5, 0.5);
	brick[3][5].position = Vec2_create( 0.0, 0.5);
	brick[4][5].position = Vec2_create( 0.5, 0.5);
	brick[5][5].position = Vec2_create( 1.0, 0.5);


	for(int i = 1; i < 6; i++){
		for(int j = 1; j < 6; j++){
	
			brick[i][j].enable  = true;
			brick[i][j].red 	= 0.0;
			brick[i][j].blue 	= 0.0;
			brick[i][j].green   = 1.0;
			brickCount += 1;
		
		}
	}
	
	if(level == 1){
		brick[3][2].health = 2;
	}

	if(level == 2){
		brick[3][2].health = 2;
		brick[2][2].health = 2;
		brick[4][2].health = 2;
		brick[3][3].health = 2;
		brick[2][3].health = 2;
		brick[4][3].health = 2;
	}	

	if(level == 3){
		brick[1][1].health = 2;
		brick[2][1].health = 2;
		brick[3][1].health = 2;
		brick[4][1].health = 2;
		brick[5][1].health = 2;
		brick[1][2].health = 2;
		brick[1][3].health = 2;
		brick[1][4].health = 2;
		brick[1][5].health = 2;
		brick[2][5].health = 2;
		brick[3][5].health = 2;
		brick[4][5].health = 2;
		brick[5][5].health = 2;
		brick[5][4].health = 2;
		brick[5][3].health = 2;
		brick[5][2].health = 2;
	}		

	if(level == 4){
		brick[1][1].health = 2;
		brick[2][1].health = 2;
		brick[3][1].health = 2;
		brick[4][1].health = 2;
		brick[5][1].health = 2;
		brick[1][2].health = 2;
		brick[1][3].health = 2;
		brick[1][4].health = 2;
		brick[1][5].health = 2;
		brick[2][5].health = 2;
		brick[3][5].health = 2;
		brick[4][5].health = 2;
		brick[5][5].health = 2;
		brick[5][4].health = 2;
		brick[5][3].health = 2;
		brick[5][2].health = 2;

		brick[3][2].health = 3;
		brick[2][2].health = 3;
		brick[4][2].health = 3;
		brick[3][3].health = 3;
		brick[2][3].health = 3;
		brick[4][3].health = 3;
	}

	if(level == 5){
		brick[1][1].health = 3;
		brick[2][1].health = 3;
		brick[3][1].health = 3;
		brick[4][1].health = 3;
		brick[5][1].health = 3;
		brick[1][2].health = 3;
		brick[1][3].health = 3;
		brick[1][4].health = 3;
		brick[1][5].health = 3;
		brick[2][5].health = 3;
		brick[3][5].health = 3;
		brick[4][5].health = 3;
		brick[5][5].health = 3;
		brick[5][4].health = 3;
		brick[5][3].health = 3;
		brick[5][2].health = 3;

		brick[3][3].health = 3;
		brick[2][3].health = 3;
		brick[4][3].health = 3;
		brick[3][4].health = 3;
		brick[2][4].health = 3;
		brick[4][4].health = 3;
	
	}			
	
	if(level > 5) level == 1;
	
}	

int main(){

	// Initialize 6 SPUs but reserve 1 SPU as a raw SPU for PSGL
	sys_spu_initialize(6, 1);	

	// init PSGL and get the current system width and height
	gfxInitGraphics();

	// initalize the PAD 	
	gfxInitPad(); 

	// initalize the dbgFonts 
	dbgFontInit();		
	
	// initialize sample data and projection matrix 
	initView();
	
	while(is_running){
			
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

		// update control input
		controllerInput();
		
		// update the matrices 
		updateMatrices();
		
		// render 
		renderFunc(); 
				
		//idle game logic
		if(!isMenuOn) 
			idleFunc();
		
		// swap PSGL buffers -
		psglSwap();
		
	}

	
	psglExit();
    sys_process_exit(0);

}
