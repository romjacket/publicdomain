BreakOutX 0.2 by Lachrymose

Features:

- A menu system that doesn't suck! :D
- 5 levels
- Brick difficulty
- Ball "physics"

Have fun! Love you all!
contact: twitter @lachrymose3