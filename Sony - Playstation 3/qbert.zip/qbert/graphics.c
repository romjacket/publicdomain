
#include <gsKit.h>
#include <dmaKit.h>

#include "system.h"

#include "qbert.h"

#include "gsKit.h"
extern 		GSGLOBAL 	*gsGlobal;

extern int Lv,Rd;
extern int P2[7][7];
extern int C[4];

typedef u32 DWORD;

DWORD 	pal32bpp[16];


GSTEXTURE	sprites[36][2];

int slx[36]=
{
	16,16,16,16,16,16,16,16,16,16,16,16,16,16,32,32,32,
	16,16,16,16,16,16,96,
	32,32,32,32,32,32,16,16,16,16,32,32
};

int sly[36]=
{
	21,21,21,21,24,24,24,24,24,24,10,10,10,10,32,32,32,
	16,16,16,16,34,34,46,
	23,23,26,22,22,24,34,34,31,31,20,20
};

unsigned int Levcl[50]=
{
	0x2f00,0x50f0,0x6ff0,0x8fff,0x4ccc,
	0x1a06,0x30a6,0x5aa6,0x8fff,0x4ccc,
	0x3f84,0x58f4,0x7ff4,0x8fff,0x4ccc,
	0x30ff,0x500f,0x8fff,0x6ccc,0x4888,
	0x1f80,0x38f0,0x5ff8,0x6ccc,0x4888,
	0x208f,0x68ff,0x488f,0x50ff,0x3088,
	0x6f88,0x4f08,0x8ff8,0x5f0f,0x3808,
	0x2800,0x4840,0x3620,0x8cc0,0x6880,
	0x3246,0x4624,0x5482,0x1222,0x0000,
	0x4ff8,0x6f8f,0x88ff,0x3444,0x1222
};




void draw_sprite(int n,int mirror,int dst_x,int dst_y)
{
	float	xscale=2.0f;
	float	yscale=2.0f;

	u64 	TexCol;

//Jbit's clue : UV(0.5, 0.5) XY(0,0) to UV(W-0.375, H-0.375) XY(W-0.9375, H-0.9375).
//http://www.jbit.net/ps2/gs-linear-sprite.html 

	//no transparentcy
	//TexCol = GS_SETREG_RGBAQ(0x80,0x80,0x80,0x00,0x00);

	//transparentcy
	TexCol = GS_SETREG_RGBAQ(0x80,0x80,0x80,0x80,0x00);

	gsKit_prim_sprite_texture(	gsGlobal, 
					&sprites[n][mirror],
					dst_x*xscale,			// X1
					dst_y*yscale,			// Y1
					0.5f,				// U1
					0.5f,				// V1
					(dst_x+slx[n])*xscale-0.9375f,	// X2
					(dst_y+sly[n])*yscale-0.9375f,	// Y2
					slx[n]-0.375f,			// U2
					sly[n]-0.375f,			// V2
					0,				// Z
					TexCol	);
}

void Spr(int x,int y,int mirror,int n)
{
	draw_sprite(n,mirror,x,y-sly[n]);
}

void draw_pyramid(void)
{	
	int x,y;
	for(y=0;y<7;y++)
		for(x=0;x<7;x++)
			if (x+y<7)
				Spr(160+x*16-y*16-16,24+x*24+y*24+24,0,14+C[P2[x][y]]);
}




//draws a sprite and upload it in VRAM (4194304 bytes max can be uploaded there)
//so we draw small sprites and we will draw them with double scale later
void loadsprite(int n,char *s[])
{
	int i,j,c,lx,ly,v;
	int mirror;

	GSTEXTURE *Texture;
	u32 FTexSize;
	u32 *p;
	u32 TextureSize;
	u32 VramTextureSize;



	lx=slx[n];
	ly=sly[n];
	
	//do we need the mirrored copy?
	if ((n<10)||(n>20)) mirror=1; else mirror=0;


	Texture=&sprites[n][0];

	Texture->Width = lx;
	Texture->Height = ly;
	Texture->Filter = GS_FILTER_NEAREST;
	Texture->PSM = GS_PSM_CT32;
	Texture->VramClut = 0;
	Texture->Clut = NULL;
	Texture->Delayed = 0;

	FTexSize = Texture->Width*Texture->Height*4;

	TextureSize = gsKit_texture_size_ee(Texture->Width, Texture->Height, Texture->PSM);
	VramTextureSize = gsKit_texture_size(Texture->Width, Texture->Height, Texture->PSM);

	Texture->Mem = memalign(128,TextureSize);

	p = (u32 *)((u32)Texture->Mem | 0x30000000);
	for (i=0;i<FTexSize/4;i++) *(p+i)=0x80000000; //transparent (alpha=128)


	//draws sprite
	for(i=0;i<ly;i++)
		for(j=0;j<lx;j++)
		{
			c=(int)s[i][j];
			if (c!=' ')
			{
				if (c<'A') c-='0';
				else
					if (c<'a') c-='A'-10;
					else
						c-='a'-10;
						
				p[i*Texture->Width+j]=pal32bpp[c];
			}
		}



	if(!Texture->Delayed)
	{
		Texture->Vram = gsKit_vram_alloc(gsGlobal, VramTextureSize, GSKIT_ALLOC_USERBUFFER);
		if(Texture->Vram == GSKIT_ALLOC_ERROR)
		{
			debugPrint("VRAM Allocation Failed. Will not upload texture.\n");
			return;
		}

		gsKit_texture_upload(gsGlobal, Texture);
		free(Texture->Mem);
	}
	else
	{
		gsKit_setup_tbw(Texture); //for later manual upload
	}


	if (mirror==0) return;



	Texture=&sprites[n][1];

	Texture->Width = lx;
	Texture->Height = ly;
	Texture->Filter = GS_FILTER_NEAREST;
	Texture->PSM = GS_PSM_CT32;
	Texture->VramClut = 0;
	Texture->Clut = NULL;
	Texture->Delayed = 0;

	FTexSize = Texture->Width*Texture->Height*4;

	TextureSize = gsKit_texture_size_ee(Texture->Width, Texture->Height, Texture->PSM);
	VramTextureSize = gsKit_texture_size(Texture->Width, Texture->Height, Texture->PSM);

	Texture->Mem = memalign(128,TextureSize);

	p = (u32 *)((u32)Texture->Mem | 0x30000000);
	for (i=0;i<FTexSize/4;i++) *(p+i)=0x80000000; //transparent (alpha=128)






	//draws mirrored image
	for(i=0;i<ly;i++)
		for(j=0;j<lx;j++)
		{
			v=lx-j-1; //mirrored coordinate
			c=(int)s[i][j];
			if (c!=' ')
			{
				if (c<'A') c-='0';
				else
					if (c<'a') c-='A'-10;
					else
						c-='a'-10;

				p[(i*Texture->Width+v)]=pal32bpp[c];
			}
		}


	if(!Texture->Delayed)
	{
		Texture->Vram = gsKit_vram_alloc(gsGlobal, VramTextureSize, GSKIT_ALLOC_USERBUFFER);
		if(Texture->Vram == GSKIT_ALLOC_ERROR)
		{
			debugPrint("VRAM Allocation Failed. Will not upload texture.\n");
			return;
		}

		gsKit_texture_upload(gsGlobal, Texture);
		free(Texture->Mem);
	}
	else
	{
		gsKit_setup_tbw(Texture); //for later manual upload
	}
	
	
}

//reuploads sprite in vram (palette changed)
//caution: texture reupload fails if texture has just been drawn right before this call
//(need to draw another texture before re-uploading this one because of some lock mechanism)
void reloadsprite(int n,char *s[])
{
	int i,j,c,lx,ly,v;
	int mirror;

	GSTEXTURE *Texture;
	u32 FTexSize;
	u32 *p;
	u32 TextureSize;
	u32 VramTextureSize;



	lx=slx[n];
	ly=sly[n];
	
	//do we need the mirrored copy?
	if ((n<10)||(n>20)) mirror=1; else mirror=0;


	Texture=&sprites[n][0];

	Texture->Width = lx;
	Texture->Height = ly;
	Texture->Filter = GS_FILTER_NEAREST;
	Texture->PSM = GS_PSM_CT32;
	Texture->VramClut = 0;
	Texture->Clut = NULL;
	Texture->Delayed = 0;

	FTexSize = Texture->Width*Texture->Height*4;

	TextureSize = gsKit_texture_size_ee(Texture->Width, Texture->Height, Texture->PSM);
	VramTextureSize = gsKit_texture_size(Texture->Width, Texture->Height, Texture->PSM);

	Texture->Mem = memalign(128,TextureSize);

	p = (u32 *)((u32)Texture->Mem | 0x30000000);
	for (i=0;i<FTexSize/4;i++) *(p+i)=0x80000000; //transparent (alpha=1)


	//draws sprite
	for(i=0;i<ly;i++)
		for(j=0;j<lx;j++)
		{
			c=(int)s[i][j];
			if (c!=' ')
			{
				if (c<'A') c-='0';
				else
					if (c<'a') c-='A'-10;
					else
						c-='a'-10;
						
				p[i*Texture->Width+j]=pal32bpp[c];
			}
		}



	if(!Texture->Delayed)
	{
		//caution: texture reupload fails if texture has just been drawn right before this call
		//(need to draw another texture before re-uploading this one because of some lock mechanism)
		gsKit_texture_upload(gsGlobal, Texture);
		free(Texture->Mem);
	}
	else
	{
		gsKit_setup_tbw(Texture); //for later manual upload
	}


	if (mirror==0) return;



	Texture=&sprites[n][1];

	Texture->Width = lx;
	Texture->Height = ly;
	Texture->Filter = GS_FILTER_NEAREST;
	Texture->PSM = GS_PSM_CT32;
	Texture->VramClut = 0;
	Texture->Clut = NULL;
	Texture->Delayed = 0;

	FTexSize = Texture->Width*Texture->Height*4;

	TextureSize = gsKit_texture_size_ee(Texture->Width, Texture->Height, Texture->PSM);
	VramTextureSize = gsKit_texture_size(Texture->Width, Texture->Height, Texture->PSM);

	Texture->Mem = memalign(128,TextureSize);

	p = (u32 *)((u32)Texture->Mem | 0x30000000);
	for (i=0;i<FTexSize/4;i++) *(p+i)=0x80000000; //transparent (alpha=255)






	//draws mirrored image
	for(i=0;i<ly;i++)
		for(j=0;j<lx;j++)
		{
			v=lx-j-1; //mirrored coordinate
			c=(int)s[i][j];
			if (c!=' ')
			{
				if (c<'A') c-='0';
				else
					if (c<'a') c-='A'-10;
					else
						c-='a'-10;

				p[(i*Texture->Width+v)]=pal32bpp[c];
			}
		}


	if(!Texture->Delayed)
	{
		//caution: texture reupload fails if texture has just been drawn right before this call
		//(need to draw another texture before re-uploading this one because of some lock mechanism)
		gsKit_texture_upload(gsGlobal, Texture);
		free(Texture->Mem);
	}
	else
	{
		gsKit_setup_tbw(Texture); //for later manual upload
	}
	
	
}



void prepare_sprites(void)
{
	int		i,n;

	//converts M4R4G4B4 palette into A8B8G8R8 palette
	for(i=0;i<16;i++)
		pal32bpp[i]=	(((pal[i]&0x0f00)*0x11)>>8)|
				(((pal[i]&0x00f0)*0x11)<<4)|
				(((pal[i]&0x000f)*0x11)<<16)|
				0x00000000; //opaque (alpha=0)
				


	n=0;
	
	loadsprite(n++,blocaa);
	loadsprite(n++,blocab);
	loadsprite(n++,blocac);
	loadsprite(n++,blocad);
	loadsprite(n++,blocba);
	loadsprite(n++,blocbb);
	loadsprite(n++,blocbc);
	loadsprite(n++,blocbd);
	loadsprite(n++,blocbe);
	loadsprite(n++,blocbf);
	loadsprite(n++,blocca);
	loadsprite(n++,bloccb);
	loadsprite(n++,bloccc);
	loadsprite(n++,bloccd);
	loadsprite(n++,blocda);
	loadsprite(n++,blocdb);
	loadsprite(n++,blocdc);
	loadsprite(n++,blocea);
	loadsprite(n++,bloceb);
	loadsprite(n++,blocec);
	loadsprite(n++,bloced);
	loadsprite(n++,blocfa);
	loadsprite(n++,blocfb);
	loadsprite(n++,blocga);
	loadsprite(n++,blokaa);
	loadsprite(n++,blokab);
	loadsprite(n++,blokba);
	loadsprite(n++,blokca);
	loadsprite(n++,blokcb);
	loadsprite(n++,blokda);
	loadsprite(n++,blokea);
	loadsprite(n++,blokeb);
	loadsprite(n++,blokfa);
	loadsprite(n++,blokfb);
	loadsprite(n++,blokga);
	loadsprite(n++,blokgb);
}


void updatecubecolor()
{
	int i;
	
	pal[1]=Levcl[(Lv-1)*5];
	pal[2]=Levcl[(Lv-1)*5+1];
	pal[3]=Levcl[(Lv-1)*5+2];
	pal[7]=Levcl[(Lv-1)*5+3];
	pal[8]=Levcl[(Lv-1)*5+4];
	if (Rd==4)
	{
		pal[3]=0;
		pal[7]=0;
		pal[8]=0;
	}

	//converts M4R4G4B4 palette into A8B8G8R8 palette
	for(i=0;i<16;i++)
		pal32bpp[i]=	(((pal[i]&0x0f00)*0x11)>>8)|
				(((pal[i]&0x00f0)*0x11)<<4)|
				(((pal[i]&0x000f)*0x11)<<16)|
				0x00000000; //opaque (alpha=0)

	reloadsprite(14,blocda);
	reloadsprite(15,blocdb);
	reloadsprite(16,blocdc);
}


void updateliftcolor(void)
{
	unsigned int t;
	int i;
	static int toggle;
	
	toggle^=1;
	
	if (toggle&1) return;

	t=pal[12];
	pal[12]=pal[11];
	pal[11]=pal[10];
	pal[10]=pal[9];
	pal[9]=t;

	//converts M4R4G4B4 palette into A8B8G8R8 palette
	for(i=9;i<13;i++)
		pal32bpp[i]=	(((pal[i]&0x0f00)*0x11)>>8)|
				(((pal[i]&0x00f0)*0x11)<<4)|
				(((pal[i]&0x000f)*0x11)<<16)|
				0x00000000; //opaque (alpha=0)

	reloadsprite(13,bloccd);
}


void update_sprites_filter(int antialiasing)
{
	int i;
	for(i=0;i<36;i++)
	{
		if (antialiasing)
		{
			sprites[i][0].Filter = GS_FILTER_LINEAR;
			sprites[i][1].Filter = GS_FILTER_LINEAR;
		}
		else
		{
			sprites[i][0].Filter = GS_FILTER_NEAREST;
			sprites[i][1].Filter = GS_FILTER_NEAREST;
		}
	}
}

