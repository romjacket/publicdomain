#include "string.h"
#include "stdio.h"
#include <stdlib.h>

#include "qbert.h"

#include "system.h"




int main(void)
{
	pb_init();

	prepare_sprites(); //draw needed sprites in extra buffer #1

	while(game());

	pb_kill(0);
	
	return 0;
}

