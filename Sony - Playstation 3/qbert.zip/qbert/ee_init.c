#include <kernel.h>
#include <string.h>

#include "ee_init.h"
#include "dma.h"
#include "irx_data.h"

#define SMS_DSP_SPR_CONST   (  (unsigned short*)0x70000400  )

void EE_Init ( void ) 
{
	volatile DMACRegs* lpDMAC = DMAC;

	lpDMAC -> m_CTRL = DMA_SET_CTRL( 	1, 
						D_CTRL_RELE_ON, 
						D_CTRL_MFD_OFF, 
						D_CTRL_STS_UNSPEC, 
						D_CTRL_STD_OFF, 
						D_CTRL_RCYC_8 );
	lpDMAC -> m_STAT = 0;
	lpDMAC -> m_PCR  = 0;
	lpDMAC -> m_SQWC = 0;
	lpDMAC -> m_RBSR = 0;
	lpDMAC -> m_RBOR = 0;

	ChangeThreadPriority (  GetThreadId (), 64  );

	memcpy(SMS_DSP_SPR_CONST, &g_DataBuffer[IDCT_CONST_OFFSET], IDCT_CONST_SIZE );
}

