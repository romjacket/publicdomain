This is the assembly of :

main.c		//remake of "Q*bert" (graphics handled by wonderful gsKit library)
qbert.c/.h
graphics.c
game.c
bitmaps.c
system.c/.h		//calls initialization routines & provides compatibility with pbKit
irx_data.c/.h	//common encapsulated irx's taken from SMS source (see sms.txt)
pad.c/.h		//taken from SMS source (see sms.txt)
iop_init.c/.h	//taken from SMS source (see sms.txt)
ee_init.c/.h	//taken from SMS source (see sms.txt)
exception.c/.s	//taken from PS2Link sources (see ps2link.txt)
license.txt		//AFL license

'Magic biases' from Jbit have been used for high quality texture mapping
(http://www.jbit.net/ps2/gs-linear-sprite.html )


This source also can act as a minimal starter kit for people interested in gsKit.





ps2devman
(just a ps2dev library happy user)



Hints about ps2dev installation :
http://forums.ps2dev.org/viewtopic.php?t=6890

Tutorial about quick cygwin reinstallation :
http://forums.ps2dev.org/viewtopic.php?t=6902

----------------------------------------------------------------------------------
[2014.04.02]
Adapted in order to use Left Joypad and compile with 32-Bit Linux latest PS2SDK by doctorxyz (due to an imnsonia night).
All credits and aplauses should go to ps2devman!
----------------------------------------------------------------------------------
"ps2devman
Wed Mar 26, 2008 5:36 pm
These are a few open sources experiments I've done on ps2. 

The last one is pure 3D fun... Lets you rotate a .3ds textured mesh. 
(based on modified saotome's vulib and standard neovangelist's gsKit) 

http://home.tele2.fr/~fr-51785/ps2_pktdrv.zip (GPL packet driver source for PS2) 
http://home.tele2.fr/~fr-51785/ps2_afl_pktdrv.zip (AFL packet driver source for PS2) 
http://home.tele2.fr/~fr-51785/ps2_pong.zip (Hardware accelerated Pong) 
http://home.tele2.fr/~fr-51785/ps2_qbert.zip (AntiAliased Q*Bert) 
http://home.tele2.fr/~fr-51785/ps2_initial_fantasy.zip (250000 v/f 3D rendering loop)"
http://lukasz.dk/mirror/forums.ps2dev.org/viewtopic8d87.html?t=10043&highlight=qbert
----------------------------------------------------------------------------------
