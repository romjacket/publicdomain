

#ifndef _EXCEPTION_H_
#define _EXCEPTION_H_

void installExceptionHandlers(void);

#endif
