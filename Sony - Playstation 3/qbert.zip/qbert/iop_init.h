#ifndef __IOP_INIT_H__
#define __IOP_INIT_H__

void IOP_Reset ( void ) ;
void IOP_Init ( void ) ;

#endif
