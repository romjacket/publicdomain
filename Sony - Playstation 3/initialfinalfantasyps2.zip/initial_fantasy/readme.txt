This is the assembly of :

main.c		
vu.c/.h		//saotome's vu upload/start optimized routines (new functions added)
system.c/.h		//calls initialization routines & provides compatibility with pbKit
irx_data.c/.h	//common encapsulated irx's taken from SMS source (see sms.txt)
pad.c/.h		//taken from SMS source (see sms.txt)
iop_init.c/.h	//taken from SMS source (see sms.txt)
ee_init.c/.h	//taken from SMS source (see sms.txt)
exception.c/.s	//taken from PS2Link sources (see ps2link.txt)
license.txt		//AFL license

Triangle : Quit
Square/Circle : Raise/Lower number of batches (default : all)

Max vertex/frame calculation isn't accurate below 30000 vertices.
Current performance : 250000 vertices/frame (19 cycles spent in vu1 in each rendering loop)

Thanks to saotome for his quick and kind help!

This source also can act as a minimal starter kit for people interested in gsKit.

"Fuselage" can be drawn instead of "SpaceFight" in main.c if BIPLANE is defined in meshes.h
(need to use convert.sh to create biplane headers in /meshes)

SpaceFight=1500 vertices
Fuselage=around 100000 vertices

You may need this if you don't know how to compile a .vcl file :
http://home.tele2.fr/~fr-51785/ps2_gasp_vcl.zip


ps2devman
(just a ps2dev library happy user)



Hints about ps2dev installation :
http://forums.ps2dev.org/viewtopic.php?t=6890

Tutorial about quick cygwin reinstallation :
http://forums.ps2dev.org/viewtopic.php?t=6902

Hints about Programmer's Notepad 2 :
http://forums.ps2dev.org/viewtopic.php?t=7438

Other useful older stuff: 
http://home.tele2.fr/~fr-51785/ps2_qbert.zip (2D sprites) 
http://home.tele2.fr/~fr-51785/ps2_pong.zip (wiimote) 
http://home.tele2.fr/~fr-51785/ps2_afl_pktdrv.zip (packet driver)
