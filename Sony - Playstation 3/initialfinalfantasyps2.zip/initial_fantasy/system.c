#include <stdio.h>
#include <gsKit.h>
#include <dmaKit.h>
#include <malloc.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <kernel.h>
#include <string.h>

#include "iop_init.h"
#include "ee_init.h"
#include "pad.h"
#include "exception.h"

		GSGLOBAL 	*gsGlobal;

static 	int 		nextRow=0;
static 	int		nextCol=0;

static 	u64 		White, Black, Red, Green, Blue, BlueTrans, RedTrans, GreenTrans, WhiteTrans;
static 	u64 		BlackFont, WhiteFont, RedFont, GreenFont, BlueFont;

static		unsigned int	pb_vbl_counter=0;

static		int		pb_swapscreen_todo=0;

#define ROWS	16
#define COLS	60

static		char		debugscreen[ROWS][COLS];

static 	unsigned char	systemFont[] =
{
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,56,56,56,56,56,0,56,56,
	108,108,0,0,0,0,0,0,0,108,254,254,108,254,254,108,
	48,126,224,124,14,254,252,48,98,230,204,24,48,102,206,140,
	120,220,252,120,250,222,252,118,28,28,56,0,0,0,0,0,
	14,28,28,28,28,28,28,14,112,56,56,56,56,56,56,112,
	0,0,0,230,124,56,124,206,0,0,28,28,127,127,28,28,
	0,0,0,0,0,28,28,56,0,0,0,0,124,124,0,0,
	0,0,0,0,0,0,56,56,28,28,56,56,112,112,224,224,
	124,254,238,238,238,254,254,124,56,120,248,56,56,254,254,254,
	252,254,14,60,112,254,254,254,252,254,14,60,14,254,254,252,
	238,238,238,254,254,14,14,14,254,254,224,252,14,254,254,252,
	124,252,224,252,238,254,254,124,252,254,14,14,28,28,56,56,
	124,254,238,124,238,254,254,124,124,254,238,126,14,254,254,252,
	0,0,28,28,0,28,28,28,0,0,28,28,0,28,28,56,
	6,14,28,56,56,28,14,6,0,0,124,124,0,124,124,124,
	112,56,28,14,14,28,56,112,124,254,206,28,56,0,56,56,
	124,198,190,182,190,182,200,126,124,254,238,254,238,238,238,238,
	252,254,206,252,206,254,254,252,124,254,238,224,238,254,254,124,
	252,254,238,238,238,254,254,252,254,254,224,248,224,254,254,254,
	126,254,224,248,224,224,224,224,126,254,224,238,238,254,254,124,
	238,238,238,254,238,238,238,238,254,254,56,56,56,254,254,254,
	254,254,14,14,238,254,254,124,238,238,252,248,252,238,238,238,
	224,224,224,224,224,254,254,126,130,198,238,254,254,238,238,238,
	206,238,254,254,254,254,238,230,124,254,238,238,238,254,254,124,
	252,254,238,238,252,224,224,224,124,254,238,238,254,254,252,118,
	252,254,238,238,252,238,238,238,126,254,224,124,14,254,254,252,
	254,254,56,56,56,56,56,56,238,238,238,238,238,254,254,124,
	238,238,238,238,238,238,124,56,238,238,238,254,254,238,198,130,
	238,238,124,56,124,238,238,238,238,238,124,124,56,56,112,112,
	254,254,28,56,112,254,254,254,124,124,112,112,112,124,124,124,
	112,112,56,56,28,28,14,14,124,124,28,28,28,124,124,124,
	56,124,238,198,0,0,0,0,0,0,0,0,0,254,254,254,
	56,56,28,0,0,0,0,0,0,124,254,238,254,238,238,238,
	0,252,254,206,252,206,254,252,0,124,254,238,224,238,254,124,
	0,252,254,238,238,238,254,252,0,254,254,224,248,224,254,254,
	0,126,254,224,248,224,224,224,0,126,254,224,238,238,254,124,
	0,238,238,238,254,238,238,238,0,254,254,56,56,56,254,254,
	0,254,254,14,14,238,254,124,0,238,238,252,248,252,238,238,
	0,224,224,224,224,224,254,126,0,130,198,238,254,254,238,238,
	0,206,238,254,254,254,238,230,0,124,254,238,238,238,254,124,
	0,252,254,238,238,252,224,224,0,124,254,238,238,254,252,118,
	0,252,254,238,238,252,238,238,0,126,254,224,124,14,254,252,
	0,254,254,56,56,56,56,56,0,238,238,238,238,238,254,124,
	0,238,238,238,238,238,124,56,0,238,238,238,254,238,198,130,
	0,238,238,124,56,124,238,238,0,238,238,124,124,56,56,112,
	0,254,254,28,56,112,254,254,60,124,112,112,112,124,124,60,
	56,56,56,0,56,56,56,56,120,124,28,28,28,124,124,120,
	236,254,118,0,0,0,0,0,0,16,56,124,254,254,254,254,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

static void scrollup(void)
{
	int i;
	for(i=0;i<ROWS-1;i++)
	memcpy(&debugscreen[i][0],&debugscreen[i+1][0],COLS);
	memset(&debugscreen[ROWS-1][0],0,COLS);
}

static void debugPrintChar(char c)
{
	if (c=='\n')
	{
		nextRow++;
		if (nextRow>=ROWS) { nextRow=ROWS-1; scrollup(); }
		nextCol=0;
	}
	else
	if (c=='\r')
	{
		nextCol=0;
	}
	else
	if (c==8)
	{
		nextCol--;
		if (nextCol<0) nextCol=0;
	}
	else
	if (c>=32)
	{
		debugscreen[nextRow][nextCol]=c;
		nextCol++;
		if (nextCol>=COLS)
		{
			nextRow++;
			if (nextRow>=ROWS) { nextRow=ROWS-1; scrollup(); }
			nextCol=0;
		}		
	}
}


static unsigned int getStatusReg() {
    register unsigned int rv;
    asm volatile (
        "mfc0 %0, $12\n"
        "nop\n" : "=r" 
	(rv) : );
    return rv;
}

static void setStatusReg(unsigned int v) {
    asm volatile (
        "mtc0 %0, $12\n"
        "nop\n"
	: : "r" (v) );
}

static void setKernelMode() {
    setStatusReg(getStatusReg() & (~0x18));
}

static void setUserMode() {
    setStatusReg((getStatusReg() & (~0x18)) | 0x10);
}


static void initscreen(void)
{
	gsGlobal = gsKit_init_global();
//	gsGlobal = gsKit_init_global(GS_MODE_NTSC);
//or	gsGlobal = gsKit_init_global(GS_MODE_DTV_480P); // HTDV 480P

	// You can use these to turn off Z/Double Buffering. They are on by default.
	//gsGlobal->DoubleBuffering = GS_SETTING_ON;
	//gsGlobal->ZBuffering = GS_SETTING_OFF;

	// This makes things look marginally better in half-buffer mode...
	// however on some CRT and all LCD, it makes a really horrible screen shake.
	// Uncomment this to disable it. (It is on by default)
	//gsGlobal->DoSubOffset = GS_SETTING_OFF;	

	gsGlobal->PrimAlphaEnable = GS_SETTING_ON;

	dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC,
		    D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);

	// Initialize the DMAC
	dmaKit_chan_init(DMA_CHANNEL_GIF);
	dmaKit_chan_init(DMA_CHANNEL_FROMSPR);
	dmaKit_chan_init(DMA_CHANNEL_TOSPR);

	White = GS_SETREG_RGBAQ(0xFF,0xFF,0xFF,0x00,0x00);
	Black = GS_SETREG_RGBAQ(0x00,0x00,0x00,0x00,0x00);
	Red = GS_SETREG_RGBAQ(0xFF,0x00,0x00,0x00,0x00);
	Green = GS_SETREG_RGBAQ(0x00,0xFF,0x00,0x00,0x00);
	Blue = GS_SETREG_RGBAQ(0x00,0x00,0xFF,0x00,0x00);

	WhiteFont = GS_SETREG_RGBAQ(0xFF,0xFF,0xFF,0x80,0x00);
	BlackFont = GS_SETREG_RGBAQ(0x00,0x00,0x00,0x80,0x00);
	RedFont = GS_SETREG_RGBAQ(0xFF,0x00,0x00,0x80,0x00);
	GreenFont = GS_SETREG_RGBAQ(0x00,0xFF,0x00,0x80,0x00);
	BlueFont = GS_SETREG_RGBAQ(0x00,0x00,0xFF,0x80,0x00);

	BlueTrans = GS_SETREG_RGBAQ(0x00,0x00,0xFF,0x40,0x00);
	RedTrans = GS_SETREG_RGBAQ(0xFF,0x00,0x00,0x60,0x00);
	GreenTrans = GS_SETREG_RGBAQ(0x00,0xFF,0x00,0x50,0x00);
	WhiteTrans = GS_SETREG_RGBAQ(0xFF,0xFF,0xFF,0x50,0x00);

	gsKit_init_screen(gsGlobal);

	//Since we will use vu1 for rendering, we don't want
	//unsynchronized mixes between vulib and gsKit. 
	//So, no automatic rendering at beginning of a new frame.
	//Thus, that means persistent queue will remain empty.
	
	//gsKit_mode_switch(gsGlobal, GS_PERSISTENT);

	//gsKit_clear(gsGlobal, Black);
	
	gsKit_mode_switch(gsGlobal, GS_ONESHOT);

	gsKit_set_test(gsGlobal, GS_ZTEST_OFF); //Will be turned on by 'per frame stuff' in vu1

	gsKit_set_clamp(gsGlobal, GS_CMODE_CLAMP);
	
	gsKit_set_primalpha(gsGlobal, GS_SETREG_ALPHA(1,2,0,0,0), 1);
	//Cv=(Cd-0)*As>>7+Cs (p100 GS user manual)
	//Alpha blending per pixel is on (p115 GS user manual)

	gsKit_set_test(gsGlobal, GS_ATEST_OFF);

}


static void swapscreen(void)
{
	if(!gsGlobal->FirstFrame)
	{
		if(gsGlobal->DoubleBuffering == GS_SETTING_ON)
		{
			GS_SET_DISPFB2( gsGlobal->ScreenBuffer[gsGlobal->ActiveBuffer & 1] / 8192,
				gsGlobal->Width / 64, gsGlobal->PSM, 0, 0 );
	 
			gsGlobal->ActiveBuffer ^= 1;
			gsGlobal->PrimContext ^= 1;
		}

	}

	gsKit_setactive(gsGlobal);
}



//public functions


void debugPrint(char *format, ...)
{
	char 	buffer[512];
	int 	i;
	
	va_list argList;
	va_start(argList, format);
	vsprintf(buffer, format, argList);
	va_end(argList);

	for(i=0;i<strlen(buffer);i++) debugPrintChar(buffer[i]);	
}



void pb_print(char *format, ...)
{
	char 	buffer[512];
	int 	i;
	
	va_list argList;
	va_start(argList, format);
	vsprintf(buffer, format, argList);
	va_end(argList);

	for(i=0;i<strlen(buffer);i++) debugPrintChar(buffer[i]);	
}



void pb_printat(int row, int col, char *format, ...)
{
	char 	buffer[512];
	int 	i;

	if ((row>=0)&&(row<ROWS)) nextRow=row;
	if ((col>=0)&&(col<COLS)) nextCol=col;
	
	va_list argList;
	va_start(argList, format);
	vsprintf(buffer, format, argList);
	va_end(argList);

	for(i=0;i<strlen(buffer);i++) debugPrintChar(buffer[i]);	
}




int pb_init(void)
{
	IOP_Reset();

	EE_Init();

	initscreen();

	PAD_Init ();

	IOP_Init();

//	SPU_Init();

	installExceptionHandlers();

	return 0;
}


void pb_kill(int power_off)
{
	PAD_Quit();

//	SPU_Shutdown();

	IOP_Reset();

	if (power_off)
	{
		// Turn off PS2
		setKernelMode();
		*((unsigned char *)0xBF402017) = 0;
		*((unsigned char *)0xBF402016) = 0xF;
		setUserMode();
	}

	Exit ( 0 );
}


void pb_reset()
{
	//does nothing on PS2 but keep it.
	//on other platforms, a call made at beginning of frame drawing is useful
}




unsigned int pb_get_vbl_counter(void)
{
	return pb_vbl_counter;
}

unsigned int pb_wait_for_vbl(void)
{

	while ((*GS_CSR&8)==0) {};

	*GS_CSR = *GS_CSR & 8;

	pb_vbl_counter++;

	if (pb_swapscreen_todo)
	{
		swapscreen();
		pb_swapscreen_todo=0;
	}

	return pb_vbl_counter;
}

int pb_finished(void)
{
	gsKit_queue_exec(gsGlobal); //send persistent and one shot queue (push buffer sequences) to GPU

	pb_swapscreen_todo=1; //we want swapscreen called at next VBlank synchronization

	return 0; //we never have to delay the caller (not a triple buffering technic)
}

void pb_fill(int x,int y,int w,int h,int color)
{
	u64 rgbaq;

	rgbaq=GS_SETREG_RGBAQ((color&0xFF0000)>>16,(color&0xFF00)>>8,color&0xFF,0x00,0x00);

	gsKit_prim_quad(gsGlobal,x,y,x,y+h,x+w,y,x+w,y+h,1,rgbaq);
}

void pb_erase_text_screen(void)
{
	nextRow=0;	
	nextCol=0;
	memset(debugscreen,0,sizeof(debugscreen));
}

void pb_draw_text_screen(void)
{
	int i,j,k,l,m,x1,x2,y;
	unsigned char c;

//TODO: use a font texture instead of quads
//Jbit clue : UV(0.5, 0.5) XY(0,0) to UV(W-0.375, H-0.375) XY(W-0.9375, H-0.9375).
//To remember the day I use texture mapping... (improves pixels sharpness)

	//convert debugscreen characters into GS primitives
	for(i=0;i<ROWS;i++)
	for(j=0;j<COLS;j++)
	{
		c=debugscreen[i][j];
		if (c)
		{
			for(l=0,x1=-1,x2=-1;l<8;l++,x1=-1,x2=-1)
			for(k=0,m=0x80;k<8;k++,m>>=1)					
			if (systemFont[c*8+l]&m)
			{
				if (x1>=0) 
					x2=20+j*10+k;
				else
					x1=20+j*10+k;
			}
			else
			{
				if (x2>=0)
				{
					y=25+i*25+l*2;
					gsKit_prim_quad(gsGlobal,x1,y,x1,y+1,x2+1,y,x2+1,y+2,1,White);
					x1=x2=-1;
				}
				else
				if (x1>=0)
				{
					y=25+i*25+l*2;
					gsKit_prim_line(gsGlobal,x1,y,x1,y+2,1,White);
					x1=-1;
				}
			}
		}
	}	
}

