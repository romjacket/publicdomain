
#//3D Tutorial: http://www.expertrating.com/courseware/3DCourse/3D-Tutorial.asp
#//.max=>.3ds : Select object, File->Export selected (in 3DSMax)
#//.3ds=>.h   : "/usr/local/ps2dev/ps2sdk/bin/bin2c object.3DS object.h objectname
#//add new calls to parse_mesh with new objectnames in mesh.c
#//or just gather all your objects in same .3ds file
/usr/local/ps2dev/ps2sdk/bin/bin2c polyship.3ds polyship.h polyship
/usr/local/ps2dev/ps2sdk/bin/bin2c polyship.bmp polysbmp.h polysbmp
/usr/local/ps2dev/ps2sdk/bin/bin2c biplane.3ds biplane.h biplane
/usr/local/ps2dev/ps2sdk/bin/bin2c biplane.bmp biplabmp.h biplabmp
