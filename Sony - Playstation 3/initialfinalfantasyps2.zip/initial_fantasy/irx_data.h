
#ifndef __IRX_DATA_H
# define __IRX_DATA_H

# define AUDSRV_SIZE      6765
# define IDCT_CONST_SIZE   368
# define IOMANX_SIZE      7417
# define PS2DEV9_SIZE     7781
# define USBD_SIZE       26105
# define SIO2MAN_SIZE     5817

# define AUDSRV_OFFSET     0
# define IDCT_CONST_OFFSET (  ( AUDSRV_OFFSET     + AUDSRV_SIZE     + 15 ) & 0xFFFFFFF0  )
# define IOMANX_OFFSET     (  ( IDCT_CONST_OFFSET + IDCT_CONST_SIZE + 15 ) & 0xFFFFFFF0  )
# define PS2DEV9_OFFSET    (  ( IOMANX_OFFSET     + IOMANX_SIZE     + 15 ) & 0xFFFFFFF0  )
# define USBD_OFFSET       (  ( PS2DEV9_OFFSET    + PS2DEV9_SIZE    + 15 ) & 0xFFFFFFF0  )
# define SIO2MAN_OFFSET    (  ( USBD_OFFSET       + USBD_SIZE       + 15 ) & 0xFFFFFFF0  )
# define DATA_BUFFER_SIZE  (  ( SIO2MAN_OFFSET    + SIO2MAN_SIZE    + 15 ) & 0xFFFFFFF0  )

extern unsigned char g_DataBuffer[ DATA_BUFFER_SIZE ];


#endif  /* __IRX_DATA_H */

