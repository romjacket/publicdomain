Hey, it's LB :)

To compile this project, you'll need gsKit installed, and you'll first have to (from the msys command line, of course) type, "/usr/local/ps2dev/dvp/bin/dvp-as vu1.vsm -o vu1.o" (without the quotes), press Enter, then type "Make", and press Enter.