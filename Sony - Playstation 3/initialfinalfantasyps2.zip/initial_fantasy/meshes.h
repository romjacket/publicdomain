#ifndef __meshes_h__
#define __meshes_h__

//3D Tutorial: http://www.expertrating.com/courseware/3DCourse/3D-Tutorial.asp
//.max=>.3ds : Select object, File->Export selected (in 3DSMax)
//.3ds=>.h   : "/usr/local/ps2dev/ps2sdk/bin/bin2c object.3DS object.h objectname
//add new calls to parse_mesh with new objectnames in mesh.c
//or just gather all your objects in same .3ds file

//#define BIPLANE

//objectname "SpaceFight"
#include "meshes/polyship.h" //3ds data
#include "meshes/polysbmp.h" //uncompressed rgb bmp file has data at offset 54, upside down

#ifdef BIPLANE
//objectname "Fuselage"
#include "meshes/biplane.h" //3ds data
#include "meshes/biplabmp.h" //uncompressed rgb bmp file has data at offset 54, upside down
#endif

#endif
