/*
	(C) 2005, Saotome/TheMirek

	thanks for bugfixing help to: ps2devman

	changelog:
	20050409 first release
	20070223 wait argument (wait for transfer to finish) was wrong way round, fixed! (1=wait, 0=don't)

*/
#ifndef __VU_H
#define __VU_H

#include <tamtypes.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** Upload MPG to VU0-micromem ***/
void vu0UploadCode(void *code, u32 size, u32 destoffset, u32 wait);

/*** Upload Data to VU0-memory ***/
void vu0UploadData(void *data, u32 size, u32 destoffset, u32 wait);

/*** Set whole VU0-memory to 0  so it looks nice and clean and shiny :) ***/
/* you don't really need this */
void vu0ClearData();

/*** Wait for VU0-MPG to finish ***/
void vu0Wait();

/*** Starts VU0-Microprogram - start address in micromem specified by the offset parameter ***/
void vu0Start(u32 offset);



/*** Upload MPG to VU1-micromem ***/
void vu1UploadCode(void *code, u32 size, u32 destoffset, u32 wait);

/*** Upload Data to VU1-memory ***/
void vu1UploadData(void *data, u32 size, u32 destoffset, u32 wait);

/*** Set whole VU1-memory to 0  so it looks nice and clean and shiny :) ***/
void vu1ClearData();

/*** Wait for VU1-MPG to finish ***/
void vu1Wait();

/*** Starts VU1-Microprogram - start address in micromem specified by the offset parameter ***/
void vu1Start(u32 offset);


//new variants added by ps2devman
//functions for uploading all batches at once (requires entire vu1 data memory)
void vu1UploadHugeDataCont(void *data, u32 size, u32 destoffset, u32 wait);
void vu1UploadHugeDataContFlush(void *data, u32 size, u32 destoffset, u32 wait);
//functions allowing progressive partial uploads
void vu1UploadDataCont(void *data, u32 size, u32 destoffset, u32 wait);
void vu1UploadDataContFlush(void *data, u32 size, u32 destoffset, u32 wait);
//function allowing to set BASE and OFFSET
void vu1Set(u32 cmd, u32 value);
//function which actually waits for the end of all vu1 rendering
void vu1WaitEndOfVu1();


#ifdef __cplusplus
}
#endif

#endif
