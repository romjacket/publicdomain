#ifndef __SYSTEM_H__
#define __SYSTEM_H__

//function names look like the ones in pbKit in order to simplify xb1<=>ps2 ports

void debugPrint(char *format, ...);

void pb_reset(void);			//call it at beginning of frame (does nothing on PS2)
					//(push buffer already empty since we use one shot queue)

int pb_finished(void);			//call it when frame drawing is finished

unsigned int pb_get_vbl_counter(void);
unsigned int pb_wait_for_vbl(void);	//wait for VBlank, returns VBL counter

void pb_fill(int x,int y,int w,int h,int color);	//rectangle fill

int pb_init(void);
void pb_kill(int power_off);

void pb_print(char *format, ...);	//populates a text array
void pb_printat(int row, int col, char *format, ...);
void pb_erase_text_screen(void);	//clears text array
void pb_draw_text_screen(void);		//converts text array into GS directives

#endif

