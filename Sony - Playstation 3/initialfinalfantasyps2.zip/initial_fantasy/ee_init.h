#ifndef __EE_INIT_H__
#define __EE_INIT_H__

void EE_Init ( void );

#endif

