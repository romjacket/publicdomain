/************************************
*|      Pong Unadvanced by Hoe      *|
*|_______________________________   *|
*|\                              \  *|
*| \ http://home.dal.net/HoeBot/  \ *|
*|  \______________________________\*|
*|                                  *|
*|  This rom uses an empty version  *|
*|  of twister.c As a plat form to  *|
*|  work Off of.                    *|
*|  Orignal Pong code  was  writen  *|
*|  By me and DK for Dos16.         *|
*|__________________________________*|
*************************************/



#include <math.h>
#include "xl_mode4.h"
#include <string.h>

u16 pal[256] = {
0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x420, 0x420, 0x1, 0x21, 0x21, 0x21, 0x840, 0x840, 0x2, 0x2, 
0x3, 0x1081, 0x14a1, 0x4, 0x5, 0x5, 0x6, 0x7, 0x84, 0x84, 0xe7, 0x24c0, 0x2522, 0x2942, 0x2942, 0x3183, 
0x35a3, 0x35a3, 0x3de3, 0x3de4, 0x8, 0x9, 0x9, 0xa, 0xb, 0xc, 0xc, 0xd, 0xd, 0xe, 0xe, 0xf, 
0xf, 0x16b, 0x18c, 0x18c, 0x1ce, 0x51c0, 0x51c1, 0x4204, 0x4204, 0x4624, 0x4624, 0x4a44, 0x4e64, 0x4e65, 0x5285, 0x56a5, 
0x5ac5, 0x6306, 0x6726, 0x6f67, 0x7387, 0x7387, 0x77a7, 0x77a7, 0x7bc7, 0x7bc7, 0x7fe8, 0x10, 0x10, 0x11, 0x11, 0x12, 
0x13, 0x13, 0x14, 0x15, 0x15, 0x16, 0x17, 0x18, 0x18, 0x19, 0x19, 0x1a, 0x1b, 0x1b, 0x1c, 0x1c, 
0x1d, 0x1d, 0x1e, 0x1e, 0x1f, 0x210, 0x294, 0x294, 0x2f7, 0x318, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 
};

int exon = 1;
int exlen = 3;
int pone = 5;
int ptwo = 5;
int tone = 0;
int ttwo = 0;
int siz = 6;
int siz2 = 4;
int paddleY = 50;
int aiturn = 0;
int G = 0;
int g = 0;
int bspeed = 2;
int onespeed = 3;
int twospeed = 3;
int dx = 50 + 32;
int dy = 99 + 32;
int gs = 0;

int yDirection=1;
int xDirection=1;

void checkwin(void);
void exdraw(int x, int y);
void drawpoints(void);
void PutPixel(int x, int y, int drawcolor);
void DrawBox(int drawcolor);
void MoveDot(int x, int y, int drawcolor, int paddleX, int paddleY, int dxDirection, int dyDirection);
void delay(int x);

void MovePaddle(int x, int drawcolor, int size);
void MovePaddle2(int x, int drawcolor, int size);
void CheckCollisions(int x, int y, int paddleX, int paddleY, int dxDirection, int dyDirection);
void dtext(int x, int y, char * lpString);
void clearscreen(void);
void Letter(int x, int y, int lett);
//void CheckCollisions(int x, int y, int paddleX, int paddleY, int xDirection, int dyDirection)









u8 *buffer;
typedef struct {
	s32 x,y;
} Coord;


#define NUMPTS (3)

Coord origpts[NUMPTS];

u8 *screen = (u8*)0x6000000L;
u8 color[NUMPTS];


void PSet(int x, int y, int color);
void rset(int x, int y, int x2, int y2, int color);

void clearscreen(void)
{
    int i, i2;
    for(i=0; i < 160; i++)
    {
        for(i2=0; i2 < 240; i2++)
        {
            PSet(i2,i, 0);
        }
    }
}
void delay(int x)
{
    int y;
    for (y=0;y<x*1000;y++)
    {
    }
}

void checkwin(void)
{
    if (tone >= 9)
    {
        gs=5;
        clearscreen();
        dtext(5, 5, "player one wins");
        dtext(5, 30, "player one");  Letter(100, 30, tone + 48);
        dtext(5, 40, "player two");  Letter(100, 40, ttwo + 48);
    }
    else if (ttwo >= 9)
    {
        gs=5;
        clearscreen();
        dtext(5, 5, "player two wins");
        dtext(5, 30, "player one");  Letter(100, 30, tone + 48);
        dtext(5, 40, "player two");  Letter(100, 40, ttwo + 48);
    }
    else
    {
        dtext(5, 20, "player one");  Letter(100, 20, '&'); Letter(100, 20, tone + 48);
        dtext(5, 30, "player two");  Letter(100, 30, '&'); Letter(100, 30, ttwo + 48);
    }
}

void PSet(int x, int y, int color)
{
    screen[y * 240 + x] = color;
    
}
void rset(int x, int y, int x2, int y2, int color)
{
    int i, j;
    for (i=x; i < x2; i++)
    {
        screen[y * 240 + x + i] = color;
        for (j=0; j < 1000; j++);
    }
    for (i=y; i < y2; i++)
    {
        screen[(y + i) * 240 + x] = color;
        for (j=0; j < 1000; j++);
    }
}
void exdraw(int x, int y)
{
	if (exon == 1) {
		for (g=0;g<exlen;g++)
		{
			PutPixel(x - g,y - g,g);
			PutPixel(x + g,y + g,g);
			PutPixel(x + g,y - g,g);
			PutPixel(x - g,y + g,g);
			delay(20);
		}
		for (g=0;g<exlen;g++)
		{
			PutPixel(x - g,y - g,0);
			PutPixel(x + g,y + g,0);
			PutPixel(x + g,y - g,0);
			PutPixel(x - g,y + g,0);
			delay(20);
		}
	}
}
void MovePaddle(int x, int drawcolor, int size)
{
    int g;
	for (g=0;g<size;g++)
		PutPixel(x + g, 130, 0x4222);
	for (g=0;g<size;g++)
		PutPixel(x + (g * -1), 130, 0x4222);
	PutPixel(x + size + 1, 130, 0);
	PutPixel(x - size - 1, 130, 0);
	PutPixel(x - size - 2, 130, 0);
	PutPixel(x + size + 2, 130, 0);
	PutPixel(x - size - 3, 130, 0);
	PutPixel(x + size + 3, 130, 0);

	for (g=0;g<size;g++)
		PutPixel(x + g, 131, 0x4222);
	for (g=0;g<size;g++)
		PutPixel(x + (g * -1), 131, 0x4222);
	PutPixel(x + size + 1, 131, 0);
	PutPixel(x - size - 1, 131, 0);
	PutPixel(x - size - 2, 131, 0);
	PutPixel(x + size + 2, 131, 0);
	PutPixel(x - size - 3, 131, 0);
	PutPixel(x + size + 3, 131, 0);

	for (g=0;g<size;g++)
	{
		PutPixel(x + g, 132, 0x4222);
	}
	for (g=0;g<size;g++)
	{
		PutPixel(x + (g * -1), 132, 0x4222);
	}
	PutPixel(x + size + 1, 132, 0);
	PutPixel(x - size - 1, 132, 0);
	PutPixel(x - size - 2, 132, 0);
	PutPixel(x + size + 2, 132, 0);
	PutPixel(x - size - 3, 132, 0);
	PutPixel(x + size + 3, 132, 0);
}
void MovePaddle2(int x, int drawcolor, int size)
{
	for (g=0;g<size;g++)
		PutPixel(x + g, 50, 0x4222);
	for (g=0;g<size;g++)
		PutPixel(x + (g * -1), 50, 0x4222);
	PutPixel(x + size + 1, 50, 0);
	PutPixel(x - size - 1, 50, 0);
	PutPixel(x - size - 2, 50, 0);
	PutPixel(x + size + 2, 50, 0);
	PutPixel(x - size - 3, 50, 0);
	PutPixel(x + size + 3, 50, 0);

	for (g=0;g<size;g++)
		PutPixel(x + g, 51, 0x4222);
	for (g=0;g<size;g++)
		PutPixel(x + (g * -1), 51, 0x4222);
	PutPixel(x + size + 1, 51, 0);
	PutPixel(x - size - 1, 51, 0);
	PutPixel(x - size - 2, 51, 0);
	PutPixel(x + size + 2, 51, 0);
	PutPixel(x - size - 3, 51, 0);
	PutPixel(x + size + 3, 51, 0);

	for (g=0;g<size;g++)
	{
		PutPixel(x + g, 52, 0x4222);
	}
	for (g=0;g<size;g++)
	{
		PutPixel(x + (g * -1), 52, 0x4222);
	}
	PutPixel(x + size + 1, 52, 0);
	PutPixel(x - size - 1, 52, 0);
	PutPixel(x - size - 2, 52, 0);
	PutPixel(x + size + 2, 52, 0);
	PutPixel(x - size - 3, 52, 0);
	PutPixel(x + size + 3, 52, 0);
}

void CheckCollisions(int x, int y, int paddleX, int paddleY, int dxDirection, int dyDirection)
{
	if (x <= 42)
	{
		xDirection = bspeed;
		//tone++;
		//drawpoints();
            DrawBox(30000);
	}
	if (x >= 198)
	{
		xDirection = bspeed * -1;
		//ttwo++;
		//drawpoints();
            DrawBox(30000);
	}
	if (y < 42)
	{
		yDirection = bspeed;
		tone++;
		drawpoints();
		exdraw(x,y);
            DrawBox(30000);
	}
	if (y > 136)
	{
		yDirection = bspeed * -1;
		ttwo++;
		drawpoints();
		exdraw(x,y);
            DrawBox(30000);
	}
	if ((y > 127) && (x > paddleX - siz) && (x < paddleX + siz))
      {
		yDirection = bspeed * -1;
            DrawBox(30000);
      }
	if ((y < 53)  && (x > paddleY - siz2) && (x < paddleY + siz2))
      {
		yDirection = bspeed;
            DrawBox(30000);
      }

}

void DrawBox(int drawcolor)
{
	int xPosition = 40;
	int yPosition = 40;
//240*160
	while (xPosition < 200)
	{
		PutPixel(xPosition, yPosition, 0x4222);
		xPosition++;
	}
	while (yPosition < 140)
	{
		PutPixel(xPosition, yPosition, 0x4222);
		yPosition++;
	}
	while (xPosition > 40)
	{
		PutPixel(xPosition, yPosition, 0x4222);
		xPosition--;
	}
	while (yPosition > 40)
	{
		PutPixel(xPosition, yPosition, 0x4222);
		yPosition--;
	}
}

void MoveDot(int x, int y, int drawcolor, int paddleX, int paddleY, int dxDirection, int dyDirection)
{
	CheckCollisions(x, y, paddleX, paddleY, xDirection, yDirection);

	PutPixel(x-xDirection, y-yDirection, 0);
	PutPixel(x-xDirection, y, 0);
	PutPixel(x-xDirection, y+yDirection, 0);
	PutPixel(x, y-yDirection, 0);
	PutPixel(x, y, 0x4222);
	PutPixel(x, y+yDirection, 0x4222);
	PutPixel(x+xDirection, y-yDirection, 0);
	PutPixel(x+xDirection, y, 0x4222);
	PutPixel(x+xDirection, y+yDirection, 0x4222);
	dx += xDirection;
	dy += yDirection;
}


void PutPixel(int x, int y, int drawcolor)
{
    PSet(x, y, drawcolor);
}
void drawpoints(void)
{

}


void Letter(int x, int y, int lett)
{
    switch(lett)
    {
        case '$':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222); PSet(x + 1, y + 1, 0x4222); PSet(x + 2, y + 1, 0x4222); PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 2, y + 1, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 3, y + 1, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222); PSet(x + 4, y + 1, 0x4222); PSet(x + 2, y + 4, 0x4222); PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 5, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case '@':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                             PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                             PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);
                                    PSet(x + 5, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case '/':
            PSet(x + 3, y, 0x4222);
            PSet(x + 2, y + 1, 0x4222); 
            PSet(x + 2, y + 1, 0x4222); 
            PSet(x, y + 3, 0x4222); 
        break;
        case '#':
            PSet(x, y, 0x4222);                                 PSet(x + 2, y, 0x4222);    
            PSet(x, y + 1, 0x4222);                             PSet(x + 2, y + 1, 0x4222); 
            PSet(x, y + 2, 0x4222); PSet(x + 2, y + 1, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                             PSet(x + 2, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222); PSet(x + 4, y + 1, 0x4222); PSet(x + 2, y + 4, 0x4222); PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222);                             PSet(x + 2, y + 5, 0x4222);
        break;
        case '^':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);
            PSet(x, y + 1, 0x4222); PSet(x + 1, y + 1, 0x4222); PSet(x + 2, y + 1, 0x4222); PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222); PSet(x + 1, y + 4, 0x4222); PSet(x + 2, y + 4, 0x4222); PSet(x + 3, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case '&':
            PSet(x, y, 0);     PSet(x + 1, y, 0);     PSet(x + 2, y, 0);     PSet(x + 3, y, 0);
            PSet(x, y + 1, 0); PSet(x + 1, y + 1, 0); PSet(x + 2, y + 1, 0); PSet(x + 3, y + 1, 0);
            PSet(x, y + 2, 0); PSet(x + 1, y + 2, 0); PSet(x + 2, y + 2, 0); PSet(x + 3, y + 2, 0);
            PSet(x, y + 3, 0); PSet(x + 1, y + 3, 0); PSet(x + 2, y + 3, 0); PSet(x + 3, y + 3, 0);
            PSet(x, y + 4, 0); PSet(x + 1, y + 4, 0); PSet(x + 2, y + 4, 0); PSet(x + 3, y + 4, 0);
            PSet(x, y + 5, 0); PSet(x + 1, y + 5, 0); PSet(x + 2, y + 5, 0); PSet(x + 3, y + 5, 0);
        break;
        case '-':
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
        break;
        case '!':
            PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);  
            PSet(x + 1, y + 1, 0x4222); PSet(x + 2, y + 1, 0x4222);
            PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); 
            PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); 
          
            PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); 
        break;
        case '.':
            PSet(x + 1, y + 4, 0x4222); PSet(x + 2, y + 4, 0x4222);
            PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case '1':
                                     PSet(x + 1, y, 0x4222);    PSet(x + 2, y, 0x4222); 
                                                                PSet(x + 2, y + 1, 0x4222);
                                                                PSet(x + 2, y + 2, 0x4222);
                                                                PSet(x + 2, y + 3, 0x4222);
                                                                PSet(x + 2, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case '2':
                                    PSet(x + 1, y, 0x4222);
            PSet(x, y + 1, 0x4222);                             PSet(x + 2, y + 1, 0x4222); 
                                                                PSet(x + 2, y + 2, 0x4222);
                                    PSet(x + 1, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case '3':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);   
                                                                                            PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222);
                                                                                            PSet(x + 3, y + 3, 0x4222);
                                                                                            PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); 
        break;
        case '4':
            PSet(x, y, 0x4222);                                 PSet(x + 2, y, 0x4222); 
            PSet(x, y + 1, 0x4222);                             PSet(x + 2, y + 1, 0x4222); 
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
                                                                PSet(x + 2, y + 3, 0x4222); 
                                                                PSet(x + 2, y + 4, 0x4222);
                                                                PSet(x + 2, y + 5, 0x4222);
        break;
        case '5':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222); 
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222);
                                                                                            PSet(x + 3, y + 3, 0x4222);
                                                                                            PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case '6':
                                    PSet(x + 1, y, 0x4222);
            PSet(x, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                                                         PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case '7':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
                                                                                            PSet(x + 3, y + 1, 0x4222);
                                                                PSet(x + 2, y + 2, 0x4222);
                                    PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222);
                                    PSet(x + 1, y + 4, 0x4222); 
                                    PSet(x + 1, y + 5, 0x4222); 
        break;
        case '8':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case '9':
                                                                PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
                                    PSet(x + 1, y + 1, 0x4222);                             PSet(x + 3, y + 1, 0x4222);
                                                                PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
                                                                                            PSet(x + 3, y + 3, 0x4222);
                                                                                            PSet(x + 3, y + 4, 0x4222);
                                                                                            PSet(x + 3, y + 5, 0x4222);
        break;
        
        case 'a':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222);                                                         PSet(x + 3, y + 5, 0x4222);
        break;
        case 'b':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                                                         PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'c':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222); 
            PSet(x, y + 2, 0x4222); 
            PSet(x, y + 3, 0x4222); 
            PSet(x, y + 4, 0x4222); 
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'd':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                                                         PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case 'e':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'f':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); 
            PSet(x, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); 
        break;
        case 'g':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222); 
            PSet(x, y + 2, 0x4222); 
            PSet(x, y + 3, 0x4222);                             PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'h':
            PSet(x, y, 0x4222);                                                             PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222);                                                         PSet(x + 3, y + 5, 0x4222);
        break;
        case 'i':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
                                    PSet(x + 1, y + 1, 0x4222);
                                    PSet(x + 1, y + 2, 0x4222);
                                    PSet(x + 1, y + 3, 0x4222);
                                    PSet(x + 1, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'j':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
                                                                PSet(x + 2, y + 1, 0x4222);
                                                                PSet(x + 2, y + 2, 0x4222);
                                                                PSet(x + 2, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                             PSet(x + 2, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case 'k':
            PSet(x, y, 0x4222);                                                             PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                             PSet(x + 2, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); 
            PSet(x, y + 4, 0x4222);                             PSet(x + 2, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222);                                                         PSet(x + 3, y + 5, 0x4222);
        break;
        case 'l':
            PSet(x, y, 0x4222);    
            PSet(x, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'm':
            PSet(x, y, 0x4222);                                                             PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 1, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 1, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222); PSet(x + 1, y + 1, 0x4222); PSet(x + 2, y + 4, 0x4222); PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'n':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);                                 PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222); PSet(x + 1, y + 1, 0x4222);                             PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                             PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                             PSet(x + 2, y + 4, 0x4222); PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222);                             PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'o':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                                                         PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case 'p':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);    
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); 
            PSet(x, y + 3, 0x4222); 
            PSet(x, y + 4, 0x4222); 
            PSet(x, y + 5, 0x4222);
        break;
        case 'q':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);  
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                                                         PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                             PSet(x + 2, y + 4, 0x4222); PSet(x + 3, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
        case 'r':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222); 
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                             PSet(x + 2, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222);                                                         PSet(x + 3, y + 5, 0x4222);
        break;
        case 's':
                                    PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);
                                    PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222);
                                                                                            PSet(x + 3, y + 3, 0x4222);
                                                                                            PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case 't':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);          PSet(x + 3, y, 0x4222);
                                    PSet(x + 1, y + 1, 0x4222);
                                    PSet(x + 1, y + 2, 0x4222);
                                    PSet(x + 1, y + 3, 0x4222);
                                    PSet(x + 1, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222);
        break;
        case 'u':
            PSet(x, y, 0x4222);                                                             PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222);                                                         PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);                                                         PSet(x + 3, y + 4, 0x4222);
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222);
        break;
        case 'v':
            PSet(x, y, 0x4222);                                                             PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222);                                                         PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
                                    PSet(x + 1, y + 4, 0x4222); PSet(x + 2, y + 4, 0x4222); 
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); 
        break;
        case 'y':
            PSet(x, y, 0x4222);                                                             PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                                                         PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
                                    PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); 
                                    PSet(x + 1, y + 4, 0x4222); PSet(x + 2, y + 4, 0x4222); 
                                    PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); 
        break;
        case 'x':
            PSet(x, y, 0x4222);                                                             PSet(x + 3, y, 0x4222);
            PSet(x, y + 1, 0x4222);                             PSet(x + 2, y + 1, 0x4222); PSet(x + 3, y + 1, 0x4222);
            PSet(x, y + 2, 0x4222); PSet(x + 1, y + 2, 0x4222); PSet(x + 2, y + 2, 0x4222); PSet(x + 3, y + 2, 0x4222);
            PSet(x, y + 3, 0x4222); PSet(x + 1, y + 3, 0x4222); PSet(x + 2, y + 3, 0x4222); PSet(x + 3, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222); PSet(x + 1, y + 4, 0x4222);                             PSet(x + 3, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222);                                                         PSet(x + 3, y + 5, 0x4222);
        break;
        case 'z':
            PSet(x, y, 0x4222);     PSet(x + 1, y, 0x4222);     PSet(x + 2, y, 0x4222);     PSet(x + 3, y, 0x4222);
                                                                                            PSet(x + 3, y + 1, 0x4222);
                                                                PSet(x + 2, y + 2, 0x4222);
                                    PSet(x + 1, y + 3, 0x4222);
            PSet(x, y + 4, 0x4222);
            PSet(x, y + 5, 0x4222); PSet(x + 1, y + 5, 0x4222); PSet(x + 2, y + 5, 0x4222); PSet(x + 3, y + 5, 0x4222);
        break;
    
    }
}

void dtext(int x, int y, char * lpString)
{
    int lengthxx = strlen(lpString);
    int i, ascv;
    for(i = 0; i < lengthxx; i++)
    {
        ascv=(int) lpString[i];
        Letter(x + (i * 5), y, ascv);
    }
}

void C_Entry() 
{
	
    int i;
    u16 btn;
    int paddleX = 150;
    int xDirection = 0;
    int yDirection = 0;
    int menu=0;
    //int menuv[10];


    BG2CNT = 0x0000;
    DISPCNT = 0x0404;
    for (i=0; i<256; i++)
    {
        //int x=i>>3;
        BG_PALETTE[i] = pal[i]; //	/*(x<<10) |*/ (x<<5) | x;
    }


	//srand((unsigned)time(0));

	while (xDirection == 0 || yDirection == 0)
	{
		xDirection = 2;
		yDirection = 2;
	}
      gs=0;
      clearscreen();
      dtext(50, 3, "pong unadvanced. by hoebot.");
      dtext(50, 20, "start");
      dtext(50, 28, "options");
      dtext(50, 36, "info");

    while (1)
    {
        btn=joypad();
        if (gs==0)
        {
            if (!(btn & J_UP))
            {
                dtext(43, menu * 8 + 20, "&");
                if (menu != 0)
                    menu--;
            }
            else if (!(btn & J_DOWN))
            {
                dtext(43, menu * 8 + 20, "&");
                if (menu != 2)
                    menu++;
            }

            dtext(43, menu * 8 + 20, "^");
            if (!(btn & J_A) || !(btn & J_B) || !(btn & J_START))
            {
                if (menu == 0)
                {
                    clearscreen();
                    dtext(50, 3, "pong unadvanced. by hoebot.");
                    DrawBox(30000);
                    MovePaddle(paddleX, 63000, siz);
                    drawpoints();
                    gs=3;
                }
                else if (menu == 1)
                {
                    clearscreen();
                    dtext(50, 3, "pong unadvanced. by hoebot.");
                    dtext(50, 20, "p1 size");     Letter(130, 20, siz+48);
                    dtext(50, 28, "p2 size");     Letter(130, 28, siz2+48);
                    dtext(50, 36, "p1 speed");    Letter(130, 36, onespeed+48);
                    dtext(50, 44, "p2 speed");    Letter(130, 44, twospeed+48);
                    dtext(50, 52, "ball speed");  Letter(130, 52, bspeed+48);
                    dtext(50, 60, "okay");
                    menu=0;
                    gs=1;
                }
                else if (menu == 2)
                {
                    clearscreen();
                    gs=2;
                    dtext(50, 3, "pong unadvanced. by hoebot.");
                    dtext(5, 20, "this game is a port with lots of extras added");
                    dtext(5, 28, "in of a dos16 version of pong  me  and  dk256");
                    dtext(5, 36, "wrote back in the day. i would like  to  just");
                    dtext(5, 44, "say hi to");
                    dtext(5, 52, "blitzwing  -  eizneckam  -  dk256  and to all");
                    dtext(5, 60, "of #psx-blitz on dalnet.");
                    dtext(5, 70, "03.26.01 hoebot hoebot@hotmail.com");
                    dtext(5, 78, "home.dal.net/hoebot/");
                    dtext(5, 90, "masive thanks to www.agbdev.net/gbadev/");
                }
            }
        }
        else if (gs==2)
        {
            if (!(btn & J_A) || !(btn & J_B) || !(btn & J_START))
            {
                menu=0;
                gs=0;
                clearscreen();
                dtext(50, 3, "pong unadvanced. by hoebot.");
                dtext(50, 20, "start");
                dtext(50, 28, "options");
                dtext(50, 36, "info");
            }
        }
        else if (gs==1)
        {
            if (!(btn & J_UP))
            {
                dtext(43, menu * 8 + 20, "&");
                if (menu != 0)
                    menu--;
		}
		else if (!(btn & J_DOWN))
		{
                dtext(43, menu * 8 + 20, "&");
                if (menu != 5)
                    menu++;
            }
            else if (!(btn & J_LEFT))
            {
                if ((menu == 0) && (siz != 1)) siz--;
                if ((menu == 1) && (siz2 != 1)) siz2--;
                if ((menu == 2) && (onespeed != 1)) onespeed--;
                if ((menu == 3) && (twospeed != 1)) twospeed--;
                if ((menu == 4) && (bspeed != 1)) bspeed--;
                Letter(130, 20, '&'); Letter(130, 20, siz+48);
                Letter(130, 28, '&'); Letter(130, 28, siz2+48);
                Letter(130, 36, '&'); Letter(130, 36, onespeed+48);
                Letter(130, 44, '&'); Letter(130, 44, twospeed+48);
                Letter(130, 52, '&'); Letter(130, 52, bspeed+48);
            }
            else if (!(btn & J_RIGHT))
            {
                if ((menu == 0) && (siz != 8)) siz++;
                if ((menu == 1) && (siz2 != 8)) siz2++;
                if ((menu == 2) && (onespeed != 8)) onespeed++;
                if ((menu == 3) && (twospeed != 8)) twospeed++;
                if ((menu == 4) && (bspeed != 8)) bspeed++;
                Letter(130, 20, '&'); Letter(130, 20, siz+48);
                Letter(130, 28, '&'); Letter(130, 28, siz2+48);
                Letter(130, 36, '&'); Letter(130, 36, onespeed+48);
                Letter(130, 44, '&'); Letter(130, 44, twospeed+48);
                Letter(130, 52, '&'); Letter(130, 52, bspeed+48);
            }
            dtext(43, menu * 8 + 20, "^");
            if (!(btn & J_A) || !(btn & J_B) || !(btn & J_START))
            {
                if (menu == 5)
                {
                    menu=0;
                    gs=0;
                    clearscreen();
                    dtext(50, 3, "pong unadvanced. by hoebot.");
                    dtext(50, 20, "start");
                    dtext(50, 28, "options");
                    dtext(50, 36, "info");
                }
            }
        }
        else if (gs==3)
        {
            if (!(btn & J_LEFT))
		{
			if (paddleX < 43)
				goto ToFar;
			paddleX -= onespeed;
			delay(10);
			MovePaddle(paddleX, 63000, siz);
			paddleX -= onespeed;
			delay(10);
			MovePaddle(paddleX, 63000, siz);
		}
		else if (!(btn & J_RIGHT))
		{
			if (paddleX > 195)
				goto ToFar;
			paddleX += onespeed;
			delay(10);
			MovePaddle(paddleX, 63000, siz);
			paddleX += onespeed;
			delay(10);
			MovePaddle(paddleX, 63000, siz);
            }
		ToFar:
		checkwin();
		MoveDot(dx,dy,63000,paddleX, paddleY,xDirection,yDirection);
		G = 5;
		if (G > 12) {
			if (dx > paddleY)
				paddleY += twospeed;
			if (dx < paddleY)
				paddleY -= twospeed;
			MovePaddle2(paddleY, 63000, siz2);
		}
		MoveDot(dx,dy,63000,paddleX,paddleY, xDirection,yDirection);
		delay(20);
		G = 55;
		if (G > 12) {
			if (dx > paddleY)
				paddleY += twospeed;
			if (dx < paddleY)
				paddleY -= twospeed;
			MovePaddle2(paddleY, 63000, siz2);
		}
            }
	}
}