WinPuzzle 0.04
Deligon Entertainment
http://www.deligon.com

Coder: Chris Tanner
Graphics: Alex Skinner

Graphic Conversion Utility: NeHe

This ROM is Public Domain.  It may be copied to a flash cart or played on an emulator at no cost.

Source Code for this ROM is also available at:

English: http://www.deligon.com/products/gba/winpuzzle/
Swedish: http://www.deligon.com/products/gba/winpuzzle/?language=swedish