// Palette rotation for the GBA
// /Mic, 2000 | stabmaster_@hotmail.com | come.to/progzone
//
//
// How to compile:
//  zarmasm -CPU ARM7TDMI -Littleend start.asm
//  zarmcc -c -Wall -Otime -ansic -fpu none -Littleend -cpu ARM7TDMI -apcs /narrow/noswst rotpal.c -o rotpal.o
//  zarmlink -bin -first start.o start.o rotpal.o -map -ro-base 0x08000000 -o rotpal.bin
//


#include <stdlib.h>
#include "gbal.h"


u16 colors[256];
u16 ymul240[160];



// Draw a filled circle with it's center at {x,y} and a radius of r.
// (this is slooooow)
void circle(int x,int y,int r,u8 col)
{
int i,x2,y2,p,tmp,tmp2,tmp3;
  x2 = 0;
  y2 = r;
  p = 1-r;
  while (x2<=y2)
  {
    tmp = y+y2;
    if ((tmp>=0) && (tmp<160))
    {
      tmp2 = x-x2;
      if (tmp2<0) { tmp2=0; }
      if (tmp2>=240) { tmp2=239; }
      tmp3 = x+x2;
      if (tmp3<0) { tmp3=0; }
      if (tmp3>=240) { tmp3=239; }
      tmp3 = (tmp3-tmp2)+1;
      if (tmp3>0)
      {
        for (i=0; i<tmp3; i++) { *(u8 *)(VRAM+ymul240[tmp]+tmp2+i) = col; }
      }
    }
    tmp = y-y2;
    if ((tmp>=0) && (tmp<160))
    {
      tmp2 = x-x2;
      if (tmp2<0) { tmp2=0; }
      if (tmp2>=240) { tmp2=239; }
      tmp3 = x+x2;
      if (tmp3<0) { tmp3=0; }
      if (tmp3>=240) { tmp3=239; }
      tmp3 = (tmp3-tmp2)+1;
      if (tmp3>0)
      {
        for (i=0; i<tmp3; i++) { *(u8 *)(VRAM+ymul240[tmp]+tmp2+i) = col; }
      }
    }

    tmp = y+x2;
    if ((tmp>=0) && (tmp<160))
    {
      tmp2 = x-y2;
      if (tmp2<0) { tmp2=0; }
      if (tmp2>=240) { tmp2=239; }
      tmp3 = x+y2;
      if (tmp3<0) { tmp3=0; }
      if (tmp3>=240) { tmp3=239; }
      tmp3 = (tmp3-tmp2)+1;
      if (tmp3>0)
      {
        for (i=0; i<tmp3; i++) { *(u8 *)(VRAM+ymul240[tmp]+tmp2+i) = col; }
      }
    }

    tmp = y-x2;
    if ((tmp>=0) && (tmp<160)) 
    {
      tmp2 = x-y2;
      if (tmp2<0) { tmp2=0; }
      if (tmp2>=240) { tmp2=239; }
      tmp3 = x+y2;
      if (tmp3<0) { tmp3=0; }
      if (tmp3>=240) { tmp3=239; }
      tmp3 = (tmp3-tmp2)+1;
      if (tmp3>0)
      {
        for (i=0; i<tmp3; i++) { *(u8 *)(VRAM+ymul240[tmp]+tmp2+i) = col; }
      }
    }

    if (p<0) 
    { 
      x2++;
      p = p+(x2<<1)+1;
    }else
    {
      x2++; 
      y2--;
      p = p+((x2-y2)<<1)+1;
    }
  }
}
 



void draw_box(int x1, int y1, int x2, int y2, u8 col)
{
  __asm
  {
    mov r2,VRAM

    mov r0,y1

    mov r1,#240
    mul r1,r0,r1
    mov r0,x1
    add r0,r0,r1
    add r0,r0,r2

    mov r2,x2
    mov r1,x1
    sub r2,r2,r1
    add r2,r2,#1

    mov r1,y2
    mov r3,y1
    sub r1,r1,r3
    add r1,r1,#1

    mov r3,#240
    sub r3,r3,r2

    mov r4,col
    mov r5,r4,lsl #8
    orr r4,r4,r5
    mov r5,r4,lsl #16
    orr r4,r4,r5

    boxYloop:
      mov r5,r2
      mov r6,r5,lsr #2
      and r5,r5,#3
      boxXloop:
        str r4,[r0],#4
        subs r6,r6,#1
      bne boxXloop
      orrs r5,r5,r5
      beq noTail
      boxTail:
        strb r4,[r0],#1
        subs r5,r5,#1
      bne boxTail
      noTail:
      add r0,r0,r3
      subs r1,r1,#1
    bne boxYloop
  }
}


 
int GBA_main()
{
int i;
u16 col0;

  gbalSetMode(_240x160x1x256_);

  for (i=0; i<160; i++)
  {
    ymul240[i] = i*240;
  }

  // Set up the palette.
  for (i=0; i<32; i++)
   {
    colors[i] = i;
    colors[i+32] = (i<<5)|31;
    colors[i+64] = 992|(31-i);
    colors[i+96] = (i<<10)|992;
    colors[i+128] = 31744|((31-i)<<5);
    colors[i+160] = 31744|i;
    colors[i+192] = 31775|(i<<5);
    colors[i+224] = ((31-i)<<10)|((31-i)<<5)|(31-i);
   }
  gbalSetPalette(BACKGROUND,&colors[0],256);



  for (i=145; i>0; i--)
  {
    circle(120, 80, i, i);
  }

  while (1)
  {
 
    __asm
    {
      mov r0, #0x4000006
      delay:
       ldrh r1, [r0]
       cmp r1, #80
      blt delay
    }

    col0 = colors[0];
    for (i=0; i<255; i++)
    {
      colors[i] = colors[i+1];
    }
    colors[255] = col0;

    gbalSetPalette(BACKGROUND,&colors[0],256);


  }


  return 0;
}

       





