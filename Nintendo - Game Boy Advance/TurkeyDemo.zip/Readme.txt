==========================================================
= Turkey Demo ============================================
==========================================================
=                                                        =
=  This was a simple demo put to gether using a core I   =
= have been working on for a month. I did this demo      =
= since nobody wanted to do a thanksgiving demo so sorry =
= its a day late. The demo uses Mode_3 and the Text is   =
= an oam block of 64x8. Do not email me for sorce code   =
= for it will not be given out.                          =
==========================================================
= Subice/Chakoo ==========================================
= Bevis590@gte.net =======================================
==========================================================
