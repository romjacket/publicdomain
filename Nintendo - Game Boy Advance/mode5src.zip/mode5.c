// Example program for GBALib
// Mic, 2000
//
//
// Note: the white background isn't my fault. There seems to be a bug in the emu that
//       causes the dma to transfer 0xffffffffh-words no matter what you store in the
//       source memory. You can uncomment the line that says 'gbalDisable(GBAL_DMA_CLEAR)'
//       to get the correct background color, but then you'll have to accept a lower
//       framerate.
//


#include <stdlib.h>
#include <math.h>
#include "gbal.h"


long camX,camY,camZ;


POINT quad[4];
float points[12],
      backup[12] = {-24.0f,-24.0f,0.0f, 24.0f,-24.0f,0.0f,
                    24.0f,24.0f,0.0f, -24.0f,24.0f,0.0f};

float sine[256], cosine[256];




void Rotate(float *src, float *dest, int rx, int ry, int rz, int num_points)
{
int i, offs;
float zsa,zca;
float xr,yr,f1;

 zsa = sine[rz&255];
 zca = cosine[rz&255];

 offs = 0;
 for (i=0; i<num_points; i++)
 {
    xr = src[offs];
    yr = src[offs+1];

    // only rotate about the z-axis.
    f1 = xr;
    xr = ((zca*xr)-(zsa*yr));
    yr = ((zsa*f1)+(zca*yr));
    dest[offs] = xr;
    dest[offs+1] = yr;
    offs += 3;
 }
}



void Project(float *src,long *dest,int num_points)
{
int i,si,di;
float sx,sy,sz;
  si = 0;
  di = 0;
  for (i=0; i<num_points; i++)
  {
    sx = src[si]; 
    sy = src[si+1];
    sz = src[si+2];
    si += 3;
    sz += (float)(camZ);
    if (sz!=0)
    {
      dest[di] = (long)((FOCAL*sx)/sz)+camX;
      dest[di+1] = (long)((FOCAL*sy)/sz)+camY;
    }else
    {
      dest[di] = camX;
      dest[di+1] = camY;
    }
    di += 5;
  }
}





 
int GBA_main()
{
u8 theta=0;
float f;

  for (f=0; f<256; f+=1)
  {
    sine[(int)f] = (float)sin(f*3.1415926f/128.0f);
    cosine[(int)f] = (float)cos(f*3.1415926f/128.0f);
  }

  // Set mode 5 (160x128 15-bit).
  gbalSetMode(_160x128x0x32k_);


  quad[0].c = gbalMakeColor(255, 0, 0);
  quad[1].c = gbalMakeColor(0, 255, 0);
  quad[2].c = gbalMakeColor(0, 0, 255);
  quad[3].c = gbalMakeColor(255, 255, 255);
  

  // Move the camera to the center of the screen.
  camX = 80;	camY = 64;	camZ = -300;

  gbalShadeModel(GBAL_SMOOTH);

  // Uncomment the next line to get the correct background color.
  //gbalDisable(GBAL_DMA_CLEAR);


  while (1)
  {
    // 31380 = (30<<10) | (20<<5) | 20 = light blue	
    gbalClearBuffer(31380);

    Rotate(&backup[0], &points[0], 0, 0, theta, 4);
    Project(&points[0], &quad[0].x, 4);

    gbalTriangle(&quad[0], &quad[1], &quad[2]);
    gbalTriangle(&quad[0], &quad[2], &quad[3]);

    theta += 2;
    gbalSwapBuffers();

  }


  return 0;
}

       





