//---------------------------------------------------//
//       AGB OAM Demo by Nokturn - Nok_03            //
//                Readme file                        //
//            nokturn_@hotmail.com                   //
//                                                   //
//    First Version: 1.  Dec. 2000                   //
//    Last  Version: 7.  Jan. 2001                   //
//---------------------------------------------------//




 -----------Introduction:-------------

 Well, originally I wanted to code an OAM demo. OAM is really great. But finally it became 
a real game. First I was making it alone but then my very good friend SimonB joined the fun
and made some intro gfx. See the "credits" section for more details.

 See the "Awards section" for an astonishing amount of awards the game won!




 ------How to play the game:---------

 First the intro comes. It takes about 5 seconds.
Then the playing field will appear. Now use the d-pad to move the bomber and the "a"
button to lay a bomb. You have 5 hearts. You can check how many you have in the upper
right corner.
 
 Kill all the enemies and you'll get into the next level. Win level 9 and you are done! ;)





 ----------- Programming matters: ------------

 I won't release the code because it is really messy and not an example of "neat" and "clean"
programming. However, if you want the code, please contact me ( I am often on #gbadev ) and
with any luck I'll give it to you.




 ------------ Credits:-----------------

 Now it's time to fame all the people who worked on the game:

 SimonB            -  Designed the first 3 images in the intro and the bomberman!
 Nokturn's brother -  Designed level 6 ;)
 Nokturn           -  Coded the game, designed the levels, drew all other images
                      ( or stole them ;) ) and did all the rest





 ------------ Awards our game already has ( before having been published! ): --------------

 - First ever released AGB game!
 - First ever released AGB game with handdrawn pics!
 - First ever released AGB game with no sound!
 - First ever released AGB prog that uses 3 different gfx modes! ( mode 3, 4 and 0 )
 - First ever released AGB game which name is "BombOAMan"!
 - First ever released AGB game with a mosaic effect!
 - First ever released AGB game which authors are Nokturn and SimonB!
 - First ever released AGB game with more than 0 levels!
 - First ever released AGB game with an AI implemented!
 - First ever released AGB game that does not work on the AGB! :)
 - Many more!





 Please write me eMail if you have any comments: nokturn_@hotmail.com