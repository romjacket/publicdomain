
 'Super Fighter' demo for Nintendo's GameBoy Advance
 ---------------------------------------------------

 Thank-you for downloading the latest SUPER FIGHTER
 demo, this one made for Nintendo's GameBoy Advance
 hand-held system. The demo can be viewed using a
 GameBoy Advance emulator. Such a program can be
 found on our emulator website of choice, Zophar's
 Domain [http://www.zophar.net/]. The GameBoy Advance
 emulator(s) should be available from this address -
 http://www.zophar.net/gba.html

 This new demo is the work of:

  * Mic [stabmaster_@hotmail.com] - (Coding, font)
  * Death Adder [death-adder@juno.com] - (Graphic, scrolltext, original idea)

 If you have any questions / comments about this,
 or any other 'Super Fighter' production, address
 them to Death Adder.

 This demo will ALWAYS be available from the
 'Unofficial Super Fighter Website', located
 at - http://www.superfighter.com/
