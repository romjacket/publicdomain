Aladdin for Game Boy Advance
Original Game: 1992 Sega/Virgin/Disney
Gameboy Advance Reprogram: 2003 Anoop Gantayat

For more details, see http://www.andriasang.com under the programming section