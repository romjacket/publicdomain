// Crossfade effect for the GBA
// /Mic, 2000 | stabmaster_@hotmail.com | come.to/progzone
//
//
// How to compile:
//  zarmasm -CPU ARM7TDMI -Littleend xf_start.asm
//  zarmasm -CPU ARM7TDMI -Littleend xf_data.asm
//  zarmcc -c -Wall -Otime -ansic -fpu none -Littleend -cpu ARM7TDMI -apcs /narrow/noswst xf_main.c -o xf_main.o
//  zarmlink -bin -first xf_start.o xf_start.o xf_main.o xf_data.o -map -ro-base 0x08000000 -o xfade.bin
//
//
// Again, thanks to all the other GBA coders whose nifty hacks, together with the
// ARM SDK docs have served as my source of information.
//


#include <stdlib.h>

#define DISPCNT	0x04000000
#define SCREEN	((unsigned short *)0x6000000)

// Define some types to save me some typing later on.
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;

// Import some "labels" from xf_data.o
extern uchar lbl_pic1;
extern uchar lbl_pic2;
extern uchar lbl_pic3;


uchar alpha_multable1[256];
uchar alpha_multable2[256];




// I ripped this one from Eloist's wire-cube demo...
//
void vsync()
{
  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}



// A very basic blitter for mode 3. Doesn't check whether the parameters are valid
// or not.
void blit15(uchar x, uchar y, uchar xdim, uchar ydim, ushort *src)
{
__asm
{
 // r0 = SCREEN + (y*240*2)+(x*2)
 mov r0,#480
 mov r1,y
 mul r1,r0,r1
 mov r0,x
 add r1,r1,r0
 add r1,r1,r0
 mov r0,#0x06000000
 add r0,r0,r1

 // r3 = (240*2) - (x*2)
 mov r2,src
 mov r3,#480
 mov r4,xdim
 sub r3,r3,r4
 sub r3,r3,r4

 mov r4,ydim
 Yloop:
  mov r5,xdim
  Xloop:
   // Move a half-word (16 bits) from [r2] to [r0]
   ldrh r1,[r2]
   strh r1,[r0]

   add r2,r2,#2
   add r0,r0,#2

   // The 's'-suffix is neccecary to update the flags, or you'd get an
   // eternal loop..
   subs r5,r5,#1
  bne Xloop
  add r0,r0,r3
  subs r4,r4,#1
 bne Yloop
}
}


// Takes two images (200x50, 15-bit colour), blends them using the 'alpha'-
// parameters, and writes the result to the GBA screen.
void blend15(uchar x, uchar y, ushort *src1, ushort *src2, short alpha)
{
int i,j;
ushort src_offs, *dest;
ushort pixel1,pixel2,red,green,blue;

 dest = (ushort *)(0x06000000 + (y*480) + x+x);
 src_offs = 0;
 for (i=0; i<50; i++)
 {
  for (j=0; j<200; j++)
  {
   pixel1 = *(src1+src_offs);
   pixel2 = *(src2+src_offs);
   red = (((pixel1 & 31) * alpha_multable1[alpha])&7936);
   red += (((pixel2 & 31) * alpha_multable2[alpha])&7936);
   pixel1 >>= 5;
   pixel2 >>= 5;
   green = (((pixel1 & 31) * alpha_multable1[alpha])&7936);
   green += (((pixel2 & 31) * alpha_multable2[alpha])&7936);
   pixel1 >>= 5;
   pixel2 >>= 5;
   blue = (((pixel1 & 31) * alpha_multable1[alpha])&7936);
   blue += (((pixel2 & 31) * alpha_multable2[alpha])&7936);
   red >>= 8;
   green >>= 3;
   blue <<= 2;
   src_offs++;
   __asm 
   {
    mov r0,dest
    mov r1,red
    mov r2,green
    mov r3,blue
    add r1,r1,r2
    add r1,r1,r3
    strh r1,[r0]
    add r0,r0,#2
    mov dest,r0
   }
  }
  dest += 40;
 }
}

  


//!!! main !!!

int GBA_main()
{
int i;
ushort *video, *pic1, *pic2, *pic3;
short alpha, d_alpha;

  // Set gfx-mode 3, the hiColor mode.
  *(ulong *)(0x04000000) = 3;

  // Set up the lookup-tables
  for (i=0; i<256; i++)
  {
    alpha_multable1[i] = ((i<<8)/255);
    alpha_multable2[i] = (((255-i)<<8)/255);
  } 

  // Link the data from xf_data.o
  pic1 = (ushort *)(&lbl_pic1);
  pic2 = (ushort *)(&lbl_pic2);
  pic3 = (ushort *)(&lbl_pic3);

  video = SCREEN;
  alpha = 255;
  d_alpha = -2;

  // Repeat forever
  while (1)
  {
    vsync();
    blit15(40, 139, 160, 16, pic3);
    blend15(20, 55, pic1, pic2, alpha);
    alpha += d_alpha;
    if ((alpha==1)||(alpha==255)) d_alpha = -d_alpha;
  }

  return 0;
}

       





