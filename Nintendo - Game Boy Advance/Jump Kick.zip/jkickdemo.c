#include "C:\devkitadv\include\gba.h"
#include "C:\devkitadv\include\screenmode.h"
#include "C:\devkitadv\include\sprite.h"
#include "C:\devkitadv\include\keypad.h"
#include "jkick2.h"
void GetInput(void);
void SetUpSprites(void);
void DoGrav(void);
u16* VRAM = (u16*)0x6000000;
int jumpin = 0;
int x = 10;
int y = 100;
s16 d,p=160;
u8 Normal = 0; 
u8 jkick = 1;
u8 State = 0;  //Hopefully will be the state of your character (normal,kicking,pucnchingetc...)
int main(void)
{
x = 10;
y = 95;
SetUpSprites();
while(1)
{
GetInput();
MoveSprite(&sprites[State],x,y);
DoGrav();
CopyOAM();
for(d=0; d<240; d++)
{VRAM[d+159*240] = RGB16(0,31,0);};
}
}

void GetInput(void)
{
	if(!(*KEYS & KEY_UP))
	{
 	if(jumpin==0)
	{
	jumpin=2;
	}
	}
	if(!(*KEYS & KEY_DOWN))
	{
	if(y+1<95)
 		{y++;}
	}
	if(!(*KEYS & KEY_LEFT))
	{
 		x--;
	}
	if(!(*KEYS & KEY_RIGHT))
	{
 		x++;
	}
	if(!(*KEYS & KEY_A))
	{
	if(jumpin!=0)
	{
	WaitForVsync();
	MoveSprite(&sprites[Normal],x,170);
	State = jkick;
	WaitForVsync();
	MoveSprite(&sprites[State],x,y);
CopyOAM();
}
}
}

void SetUpSprites(void)
{
SetMode(MODE_3|OBJ_ENABLE|OBJ_MAP_1D|BG2_ENABLE); //set mode 2 and enable sprites and 2d mapping 
u16 char_number = 0;
u16 charnum2 = 2;
InitializeSprites();
sprites[Normal].attribute0 = COLOR_256 | SQUARE | 100;
sprites[Normal].attribute1 = SIZE_64 | x;
sprites[Normal].attribute2 = char_number+512;
sprites[jkick].attribute0 = COLOR_256 | SQUARE | 160;
sprites[jkick].attribute1 = SIZE_64 | 10;
sprites[jkick].attribute2 = charnum2 +512+128;
int x_loop = 0, y_loop = 0, index = 0;
u16 loop;
u16* CharMem = (u16*)0x6010000;
for(index = 0; index < 512*8; index++)
{
OAMData[index+(512*16)] = SPRITE1Data[index];  //copy it starting 512 tiles into oamdata mem.  remember one tile = 32bytes and OAMdata is 16 bit pointer so offset is 512*16
};//end index loop
for(index = 0 ; index < 256*8 ; index++)
{
	OAMData[index+(256*8)+(512*16)] = jkickD[index];  
}//end index loop
for(loop = 0; loop < 256; loop++)
{
OBJPaletteMem[loop] = jkickP[loop]; 
}
CopyOAM();
}

void DoGrav(void)
{
if(jumpin==2)
{
y=y-1;
//return;
}
if(y<40) 
{
jumpin = 1;
};
if(jumpin==1)
{
y=y+1;
}
if(y==95)
{
jumpin=0;
WaitForVsync();
MoveSprite(&sprites[1],x,160);
MoveSprite(&sprites[0],x,y);
State = Normal;
CopyOAM();
}//MoveSprite(&sprites[Normal],x,y);
}

