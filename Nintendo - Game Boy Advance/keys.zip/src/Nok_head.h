//---------------------------------------------------//
//             AGB Header by Nokturn                 //
//                                                   //
//    First Version: 29. Nov. 2000                   //
//    Last  Version: 30. Nov. 2000                   //
//    Last  Used in: Key Demo 01 - Nok_Key           //
//---------------------------------------------------//

 // Defines first

#define AGBRULEZ 1          // Define some morale. What would a demo without morale be? ;) 

#define PI 3.141592654

 // Here go the BITXX Macros to spare me some typing later and make the code more readable

#define BIT00 1
#define BIT01 2
#define BIT02 4
#define BIT03 8
#define BIT04 16
#define BIT05 32
#define BIT06 64
#define BIT07 128
#define BIT08 256
#define BIT09 512
#define BIT10 1024
#define BIT11 2048
#define BIT12 4096
#define BIT13 8192
#define BIT14 16384
#define BIT15 32768

 // Some "new" types. A must-be.

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

 // Registers

#define DISPCNT    *( u32 * )0x04000000
#define VCOUNT     *( u16 * )0x04000006
#define DISPSTAT   *( u16 * )0x04000004
#define P1         *( u16 * )0x04000130

 // GFX Specific

#define PALBG      *( u16 * )0x05000000

 // GFX Mode 4

#define VBUFFER0   *( u8 *  )0x06000000
#define VBUFFER1   *( u8 *  )0x0600A000

#define BG2CNT     *( u8 *  )0x0400000C

// Now some globals.

u8 *BackBuffer     = &VBUFFER1;
u8 *VBuffer0       = &VBUFFER0;
u8 *VBuffer1       = &VBUFFER1;

u16 *PaletteBG     = &PALBG;

// Stolen from Mic ;)

u8 *font;
int font_width, font_height, char_size;

// Function that returns a RGB color in 15bit format 

u16 RRGBColor( u8 R, u8 G, u8 B )          // Uses u8 because it only needs 5 bits. Int is waste of speed.
 { 
  return ((R)|(G<<5)|(B<<10));
 }



// Function that BLITS a char onto the screen. Very inefficient, but OAM would complicate this demo. I took it from Mic's lag demo.

void RenderChar( u8 x, u8 y, u8 color, u8 letter )     // I changed the type of some args to increase speed.
{
u8 *src,*dest;
int xdim,ydim;

  src = (font+(char_size*letter))+260;
  xdim = *(u8 *)(font+letter+4);
  ydim = font_height;
  dest = (BackBuffer+(y*240)+x);
  __asm 
  {
    mov r0,src
    mov r1,dest
    mov r2,ydim
    mov r3,font_width
    mov r5,xdim
    sub r3,r3,r5
    mov r4,#240
    sub r4,r4,r5
    mov r7,color
    pcYloop:
      mov r5,xdim
      pcXloop:
        ldrb r6,[r0]
        orrs r6,r6,r6
        beq invisible
          strb r7,[r1]
        invisible:
        add r0,r0,#1
        add r1,r1,#1
        subs r5,r5,#1
      bne pcXloop
      add r0,r0,r3  
      add r1,r1,r4
      subs r2,r2,#1
    bne pcYloop
  }
}

// The next one makes the buffer black. Needed to wipe out the changing text.
// Very, very badly done. Really slow.

void ClearBuffer()
{
 int Counter;
 for( Counter = 0; Counter < 38400; Counter++ ) BackBuffer[Counter]=0;
}


 // Function to wait for Vertical Sync. I took Eloist's ASM Version

void WaitForVSync()
{
  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}

 // Function that Flips the BackBuffer pointer and writes the BackBuffer bits into the DISPCNT reg. ONLY call after WaitForVSync!

void Flip()  // Only for modes 4 and 5.
{
 if( DISPCNT & BIT04 )       // If the current buffer displayed is = 1
  {   
   BackBuffer += 0xA000;   // Update buffer pointer
   DISPCNT &= ~BIT04;        // Make the current buffer displayed = 0
  }
 else                        // The current buffer displayed is = 0
  {
   BackBuffer -= 0xA000;   // Update buffer pointer 
   DISPCNT |= BIT04;         // Make the current buffer displayed = 1 so that we can draw into VBUFFER0
  }
} 