//---------------------------------------------------//
//       AGB Key Demo by Nokturn - Nok_01            //
//                                                   //
//    First Version: 30. Nov. 2000                   //
//    Last  Version: 1.  Dec. 2000                   //
//    View readme for more info                      //
//---------------------------------------------------//

#include "Nok_head.h"
#include <math.h>

// ColorWave table used for color changes. I used the formula 16*sin( x )+16 where x is 0� to 360� and is increased with a step of 6
 u8 ColorWave[60]={15,17,18,20,22,23,24,26,27,28,29,30,30,31,31,31,31,31,30,30,29,28,27,26,24,23,22,20,18,17,15,13,12,10,8,7,6,4,3,2,1,1,0,0,0,0,0,1,1,2,3,4,5,7,8,9,10,11,13,14};
 
// Import the font. Credits go to Mic
 extern u8 lbl_font;

// The color phases.
 u8 ColorR = 10, ColorB = 20, ColorG = 30;

// Which greeting ( which message ) is being shown.
 u8 Greetings = 0;

// Renders a string in the x-center at the coordinates y. Type means: 0 = white string, 1 = colorful string ;)
 void RenderStringCenter( char *string, u8 y, u8 type )
 {
  u8 counter, color=2, x = ( 240 - strlen( string ) * 8 ) / 2 - 4;
  if( type == 0 ) for( counter = 0; counter < strlen( string ); counter++ ) RenderChar( x + ( counter<<3 ), y, 1, string[counter] );
  if( type == 1 ) for( counter = 0; counter < strlen( string ); counter++ )
  {
   RenderChar( x + ( counter<<3 ), y, color, string[counter] );
   color++; if( color > 7 ) color = 2;
  }
 }

// Called once. Inits gfx mode and stuff

 void Init()
 {

  // Make up colors!
 
  // Black and white...
  PaletteBG[0] = 0;
  PaletteBG[1] = RRGBColor( 31, 31, 31 );

  // Red, green, blue
  PaletteBG[2] = RRGBColor( ColorWave[ColorR], 0, 0 );
  PaletteBG[3] = RRGBColor( 0, ColorWave[ColorG], 0 );
  PaletteBG[4] = RRGBColor( 0, 0, ColorWave[ColorB] );

  // Combinations - but mix the ColorWaves, to get a nicer result!
  PaletteBG[5] = RRGBColor( ColorWave[ColorB], 0, ColorWave[ColorR] );
  PaletteBG[6] = RRGBColor( ColorWave[ColorR], ColorWave[ColorG], 0 );
  PaletteBG[7] = RRGBColor( 0, ColorWave[ColorG], ColorWave[ColorB] );

  // Sets video mode to 4. I wanted a palette and I wanted backbuffering.
  DISPCNT = 0x04;
 
  // Set BG2 display to true. All data written into VRAM is treated as BG2   
  DISPCNT |= BIT10;

  // Pointer to the font
  font = &lbl_font;

  // Some font setup. Stolen from Mic's lag demo ;)
  font_width = *(u8 *)(font+2);
  font_height = *(u8 *)(font+3);
  char_size = (font_width*font_height);
 }

 // This funxion reads the key register.
 void GetKeys()
 {
  if( !(P1 & BIT00) ) Greetings = 1;   // "A" button
  if( !(P1 & BIT01) ) Greetings = 2;   // "B" button
  if( !(P1 & BIT02) ) Greetings = 3;   // "Select" button
  if( !(P1 & BIT03) ) Greetings = 4;   // "Start" button 
  if( !(P1 & BIT04) ) Greetings = 8;   // Right-Direction
  if( !(P1 & BIT05) ) Greetings = 7;   // Left-Direction
  if( !(P1 & BIT06) ) Greetings = 5;   // Up-Direction
  if( !(P1 & BIT07) ) Greetings = 6;   // Down-Direction
  if( !(P1 & BIT08) ) Greetings = 10;  // "R" button
  if( !(P1 & BIT09) ) Greetings = 9;   // "L" button
 }

// Funxion for rendering the screen

 void RenderScreen()
 {
  ClearBuffer();  // Slowly clear the buffer... ;)
  RenderStringCenter( "Key Demo by Nokturn", 32, 0 ); 
  RenderStringCenter( "Press a button.", 64, 0 ); 
  if( Greetings == 1  ) RenderStringCenter( "A: Greets & thanx to Mic!", 96, 1 );
  if( Greetings == 2  ) RenderStringCenter( "B: Greets & thanx to Guano!", 96, 1 );
  if( Greetings == 3  ) RenderStringCenter( "SELECT: Greets to Q-Leder!", 96, 1 );
  if( Greetings == 4  ) RenderStringCenter( "START: Greets to #gbadev!", 96, 1 );
  if( Greetings == 5  ) RenderStringCenter( "UP: Greets to Subice!", 96, 1 );
  if( Greetings == 6  ) RenderStringCenter( "DOWN: Greets to Eloist!", 96, 1 );
  if( Greetings == 7  ) RenderStringCenter( "LEFT: Greets to SimonB!", 96, 1 );
  if( Greetings == 8  ) RenderStringCenter( "RIGHT: Greets to you!", 96, 1 );
  if( Greetings == 9  ) RenderStringCenter( "L: Thanx to Nintendo!", 96, 1 );
  if( Greetings == 10 ) RenderStringCenter( "R: The AGB rulez!", 96, 1 );
 }

 void UpdateColors()
 {

  // Go through the colors...
  ColorR++; if( ColorR > 59 ) ColorR = 0;
  ColorG++; if( ColorG > 59 ) ColorG = 0;
  ColorB++; if( ColorB > 59 ) ColorB = 0;

  PaletteBG[2] = RRGBColor( ColorWave[ColorR], 0, 0 );
  PaletteBG[3] = RRGBColor( 0, ColorWave[ColorG], 0 );
  PaletteBG[4] = RRGBColor( 0, 0, ColorWave[ColorB] );

  PaletteBG[5] = RRGBColor( ColorWave[ColorR], ColorWave[ColorG], ColorWave[ColorB] );
  PaletteBG[6] = RRGBColor( ColorWave[ColorB], ColorWave[ColorR], ColorWave[ColorG] );
  PaletteBG[7] = RRGBColor( ColorWave[ColorG], ColorWave[ColorB], ColorWave[ColorR] );
 }

 void AGBMain()
 {
  Init();
  while( AGBRULEZ )
   {
    GetKeys();
    RenderScreen();
    UpdateColors();
    WaitForVSync();
    Flip();
   }
 }