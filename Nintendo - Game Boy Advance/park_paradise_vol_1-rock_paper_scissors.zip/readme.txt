----====================================----
 PARK PARADISE VOL 1 : "Rock Paper Scissors"
     + Demonstration of FUTURE QUEST
----====================================----
(c) 2001 ZoneGN        HTTP://WWW.ZONEGN.COM

