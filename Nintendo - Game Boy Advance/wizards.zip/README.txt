Wizards GBA Beta
----------------

This is my game. Which is neat. Play it. Sorry it only has a couple levels. Making levels is boring. Want to make some for me? Contact me: drorex@hotmail.com

*Controls:
Left & Right - Move
           A - Jump
           B - Use Spell
      Select - Choose Spell
       START - Menu where you can set diffulculty, or save and load your game.  (also you can cheat, you big cheater!)


*Spells:
(red icon)   Fireball uses 1 Red Power
(yellow icon)Cloud spell uses 1 Yellow Power
(blue icon)  Rain spell uses 1 Blue Power

- Gems give you magic Power. You get different amounts depending on diffulculty.

- Normally, enemies take 5 fireballs to kill. May be less on easy modes.

- Fireballs destroy bricks and solid bushes

- Cloud spell lets you jump higher.

- Use Rain spell on bushes with RED BERRIES to make them grow into platforms.

Every 50 coins, you get a new song!!

(c) David Rorex 2000-2003


.

.

.










Secret Keys:
L - show cpu usage (broken?)
R - max speed

