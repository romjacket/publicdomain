**********************************************************
* Wiggles 2001! GBA Demo by Ujn Hunter          02.07.01 *
**********************************************************
*   well folks... here is my first GBA demo... hopefully *
* i'll be doing more in the near future. seeing this is  *
* my first demo, there isn't really anything special in  *
* it... hopefully next time i'll do something spiffy! ;) *
*                                          until then... *
*                                                 enjoy! *
**********************************************************
* Credits:                                               *
*   Art & Programming: Ujn Hunter                        *
*                                                        *
*   Thanks: #GBADEV, y0shi, TWK, #SNESEMU                *
*   Special Thanks: Joat, Mic, Eloist                    *
*   Greetings: Polycount, #Model_Design                  *
**********************************************************
* Ujn Hunter *********************************************
* timhunter@earthlink.net ********************************
* http://www.digital-lifeforms.com ***********************
**********************************************************