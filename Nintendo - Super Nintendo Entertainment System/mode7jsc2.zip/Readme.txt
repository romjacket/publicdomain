Hi.  This is my Mode 7 demo.
Controls are described in demo.

Ver 1}  12- 1-1999 	Initial release
Ver 2}   6-10-2000	Added code for X and A buttons
			Finally got DMA working! =)

--------------------------------

This demo lets you see the effects of messing with the mode7 registers.

There are 8 main registers:
$210D: SX - Scroll X | 13-bit
$210E: SY - Scroll Y | 13-bit
$211F: OX - Origin X | 16-bit
$2120: OY - Origin Y | 16-bit
$211B: A  - CosX     | 16-bit signed
$211C: B  - SinX     | 16-bit signed
$211D: C  - SinY     | 16-bit signed
$211E: D  - CosY     | 16-bit signed

The mode 7 virtual screen is 1024 x 1024 pixels or 128 x 128 tiles.

OX and OY define a point on the virtual screen to perform the screen transformations around.

--------------------------------

To rotate and size-
alpha: Size X
beta : Size Y
gamme: Rotation angle

A=  cos (gamma) * (1 / alpha)
B=  sin (gamma) * (1 / alpha)
C= -sin (gamma) * (1 / beta)
D=  cos (gamma) * (1 / beta)

--------------------------------

To position the center of tranformation (ox,oy) at a point on the physical screen (cx,cy) use the folowing equations:

sx = ox - cx
sy = oy - cy

--------------------------------

Send comments or suggestions.

Joshua Cain
cainjs@iac.net
irc: AppleGS / rAPPtar