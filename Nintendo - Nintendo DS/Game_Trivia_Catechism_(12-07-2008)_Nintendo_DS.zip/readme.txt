"Game Trivia Catechism"
Ver.20080712
A DS homebrew game by Multiple:Option 
http://multiple-option.blogspot.com

What is it?
Game Trivia Catechism is a multiple-choice trivia game, testing your knowledge of video gaming. It can be played as straight trivia, or as part of a story that follows Al and Sally as they compete in the King of Game Trivia Tournament.

Features
- 200 questions spanning the history of video games!
- Retro-styled chiptune soundtrack!
- 2 game modes!
- Rumble Pak support!

Rules
You have two minutes to answer the allotted number of questions. You are graded from "A+" (95% correct) to "F" (below 50% correct). If you run out of time, you will not receive any grade higher than a "C".

Saving
This game allows you to save your progress via DLDI. On first play, the game will create the save file "gtc_save.sav" on your flash cart. If you find that saving does not work, please try manually patching the game with the appropriate DLDI patch for your flash cart. If it still doesn't work, you're out of luck. Please choose the "continue without saving" option on the initial menu, which will let you play the game in any case.

Requirements
A Nintendo DS/Lite and a flash cart. Tested on R4 Revolution and Neo MK5 DX. Runs in DeSmuME emulator but does not support saving (see Issues). I make no guarantee that the game will work for you, your hardware or software.

Controls - Story Mode
A - Continue/Next

Controls - Trivia Mode
A, B, X, Y - Answer choice

Issues
* Saving does not work in DeSmuME (as of 2008/06). May work in other emus (No$GBA, IDeaS), but haven't tried.
* No sleep mode

Music Credits - CC-Licensed by-nc-sa
"All of Us" - Eric Skiff (glitchnyc.com)
"Race To The Stars" - 8-Bit Terror (myspace.com/8bitterrorcybergrind)
"[48h challenge] - A variety of Funks" - PDF format (myspace.com/pdfmusic)
"FINAL BOSS" - Breakfast Afternoon (myspace.com/breakfastafternoon)
"Good Moods" - Circles (myspace.com/circlesarerad)
"the end of the beginning" - ne7 (ne7.untergrund.net)
"dear_sir_or_madam" - 777minus111 (virb.com/777minus111)

Thanks
Devkitpro - DS Homebrew tools - www.devkitpro.org
PALib & PAlib Forums - DS Homebrew tools & dev help - www.palib.info
DeSmuME - DS emulator - desmume.sourceforge.net
8bit Collective - Chiptune source - 8bitcollective.com
All musical artists that appear in the game

Version History
20080712 - Initial Release

Multiple:Option Releases
01 - Fate/stay night Trial Edition (Abridged for DS) - DS - fate_ds.zip
02 - Snatcher Pilot DS - DS - snatcher_ds.zip
03 - Fate/hollow ataraxia Prologue - DS - fate2_ds.zip
04 - Game Melody Oratorio - DS - melody_ds.zip
05 - Game Melody Oratorio Volume Two - DS - melody2_ds.zip
06 - A Question of Promise: Digital Comic - DS - question_ds.zip
07 - Game Trivia Catechism - DS - trivia_ds.zip