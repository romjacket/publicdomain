  
  Binary Star, an SCC music ROM for the NEC Turbografx-16 / PC-Engine
  -------------------------------------------------------------------
  
  By Chris Covell (CMC)   http://www.chrismcovell.com/
  e-mail:  chris_covell -at - yahoo.ca
  
 Please don't take this music disk/ROM too seriously. It's just a small effort with
 a few effects made just for fun.  Let me know if you like it!