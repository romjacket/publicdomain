QuadTris by Orion_ [2011/2014]

Final Version

QuadTris is a puzzle game, playable on the GP32 console.
The game was created in less than 24 hours for the "speed coding" contest held at
the retro computing convention AC 2011, the 16th and 17th April 2011 at "Congis sur Th�rouanne" France.

The game won the first prize! \o/

Contest Rules: http://yaronet.com/posts.php?s=138950


Principle of the Game:
You have to match at least 4 blocks of the same color in a square or rectangle form.
For this you can rotate the blocks 4 by 4 using a cursor and the A button.
As the level increases, new colors appear as well as bonus and penalties.

Bonus:
-If you blow up a block with the "Bomb" symbol, all the blocks of the same color will explode.

Penalties:
-Some Leafs can appears on the board and interfere with your game.
-A block containing the "Lock" symbol will locks the rotation of the block.
-A block containing the "Arrow" symbol will reverse the rotation of the cursor.


This is the final version released in 2014:
-Now using the official GPSDK (provides only one FXE file for all GP32 consoles and emulators)
-Switched to 8bits graphic mode: The game is now seamlessly playable at 66mhz (the previous "party" version was running at 100mhz in 16bits and despite that, it had slowdowns)
-Added Title and Gameover screens + HiScore.
-The "leaves" particles now disappears smoothly.
-Removed the explosion particles that was ugly.
-Added music and sounds. (The file GPMM\QUADTRIS\decision.ima is optional ! if you want to save some space on your smc)


Credits:
Programming and Additional Graphics: Orion_

Blocks' Graphics: Osmic (http://opengameart.org/content/gem-jewel-diamond-glass)
Leaf's Graphics: Ails (http://opengameart.org/content/420-pixel-art-icons-medievalfantasy-rpg)
Background Graphics: Rawdanitsu (http://opengameart.org/content/space-backgrounds-3)
Background Graphics: StumpyStrust (http://opengameart.org/content/space-background-2)

Music "Decision" by Alexandr Zhelanov (http://opengameart.org/content/decision)

Website: http://onorisoft.free.fr/
E-Mail: onorisoft@free.fr
