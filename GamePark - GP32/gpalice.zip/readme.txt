GpAlice by Orion_ [2014]


GpAlice is a platform game, playable on the GP32 console.
This game was created for the "speed coding" contest held at the retro computing convention AC 2014,
on the 5th and 6th April 2014 at "Congis sur Th�rouanne", France.


Principle of the Game:
Alice is in wonderland and she must find the white rabbit hole.
She can collect fruits and gems, but she must avoid the peaks and be careful with the mushrooms !
If she jumps on a tiny mushroom she will become tiny, and won't be able to jump too high.
Jumping on a big mushroom will get its normal size back !


The Contest Rules required a 2 players mode, but because of the lack of 2 GPLink, I couldn't do a real 2 players mode.
That's why, Player 1 plays first, then Player 2, and in the end, the game tell who finished the level faster !
The fastest player win !


The game will be finalized with more levels and stuff on another platform,
Android phone & tablet, and maybe other retro platform (Jaguar ? PS1 ? Dreamcast ? you tell me :)


Credits:

Game & Map Design, Programming by Orion_

Email: onorisoft@free.fr
Site: http://onorisoft.free.fr/

Tiles Graphics by Carl Olsson (http://opengameart.org/content/generic-platformer-tiles)
Girl & Cat Sprite from charset by REFMAP (http://www.tekepon.net/fsm)
Mini Girl Sprite by Lanea Zimmerman (http://opengameart.org/content/tiny-16-basic)
Bunny Sprite by Stephen "Redshrike" Challener (http://opengameart.org/content/bunny-rabbit-lpc-style-for-pixelfarm)
Bonus Items Graphics by Markus (http://opengameart.org/content/platform-game-sprites)
Title Anime Girl by Niabot (http://commons.wikimedia.org/wiki/File:Anime_Girl.png)

Music by Matthew Pablo : www.matthewpablo.com
