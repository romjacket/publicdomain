,~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~,
|Bugiin v1.3 by brunetteredhead|
'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'

Released under GNU GPLv2 license, which can be found here: http://www.gnu.org/licenses/gpl-2.0.txt

Please credit me if you use any of my code.






# 1 ######## Installation Instructions

Merge the contents of the zip file to the root of your SD card. Please note that when extracting the contents of the file are as follows:

/apps/bugiin/[bugiin files]

If copying from version 1.2 or later, the bugiin.cfg is not necissary and will replace your high scores and settings should you replace your older file with it.

After copying the files, insert your SD card and boot your Wii to the Hombrew Channel and you should be good to go.

--------------------------------------------

# 2 ######## How to Play

## A # Controls

 A or B: Swats the swatter or selects menu item
 Home: Exits menu, or quits game from main menu
 Plus: Brings up options screen during gameplay
 One: Takes a screenshot, saved as bugiin.png in the bugiin folder
 Two: Shows the how to play screen

## B # Classic Mode [1-2 wiimotes]

Classic mode consists of 5 levels of increasing difficulty that you must survive. To play simply use the wiimote to swat each of the bugs. Press the A or B button to swat. 

To play with more than one wiimote, simply press the home button on an additional controller you wish to connect. Lives are shared between players, so when you initially join or when you die, a life is taken from the pool.  If the pool of lives has only 1 life left, you will not be able to join or continue.

If all of the enemies are swatted (before they self destruct) then an extra life will be given. Once all the levels are completed, the levels will loop over, but your life count will remain the same. The level counter will also continue to increase, so go for the high score!

## C # Swarm Mode [1 wiimote]

In this mode, one player will try to survive as long as possible against increasingly large swarms of bugs. An extra life is given every level, and after level 15 multiple lives are given. That doesn't mean that things get any easier, though.

--------------------------------------------

# 3 ######## Tips

+ Try using two wiimotes at once in Classic Mode to take out bugs twice as fast!

+ If the gnat spraying bugs are close to the bottom of the screen, they aren't an immediate threat, and can be left alone if other bugs need to be taken out.

+ Once you have missed one bug in the level, you will not be able to get the extra life bonus at the end. Don't hesitate to start dodging lesser threats, like the bomb bugs.

--------------------------------------------

# 4 ######## Contact

Having display issues?
Find any bugs that aren't supposed to be there? 
Suggestions on game modes?
Want to help translate this game?
Interested in making level backgrounds or additional bug skins?

Please contact me! I will take everything you say into consideration and it will be greatly appreciated. You can email me at brunetteredhead@vt.edu or you can visit this link: http://brunetteredhead.wordpress.com/bug-reports/ to let me know.

Thank you for reading!