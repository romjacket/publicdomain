Developed by Uffe Flarup - www.flarup.org

Powered by HBC, devkitPro, GRRLIB and associated libraries

Go to http://wiibrew.org/wiki/Sand_Traps for more information about how to create your own levels.
