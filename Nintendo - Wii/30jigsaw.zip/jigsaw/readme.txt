Welcome to Arcade Jigsaw!

The object of the game is to assemble the puzzle, of course. But this is not
just another computer jigsaw puzzle! You must put the pieces exactly where they
go or they head to the back of the queue. You only get to see a few at a time.

To grab a piece, move the cursor over it and press and hold (A). The piece will
attach to your cursor, which will shrink and become transparent to help you see
the piece. Move the piece to where you think it goes and let go of (A) to drop
it there.

If it's in the right spot, it will stay. Otherwise, it will disappear, the
remote will rumble, and you will have to wait for the piece to get to the front
of the queue to try placing it again.


Controls
========

To enter the menu, press HOME. Press HOME again to exit the menu. While in a
menu, use the D-pad to move up and down, (A) to choose an entry, or (B) to exit
a sub-menu.

To grab a piece from the piece queue, press and hold (A). To release it, let go
of (A). While holding it, hold (B) to magnify it.

To speed up the piece queue, press (+). Press (-) to slow it back down. Press
(B) to give it a quick boost.

Press (1) to show your own score briefly. Hold (1) to keep it on the screen.
Press (2) to show all scores, and hold (2) to keep them on the screen.


Scoring
=======

Every time you place a piece correctly, you get some points added to your score.
The piece itself has a value (1 for corner pieces, and more for edge and center
pieces), and a time bonus is added for placing a piece soon after a previous
piece. The total is multiplied by your current score multiplier and added to
your score.

The score multiplier starts at 1 and increases up to a maximum of 4 every time
you place a piece correctly. If you place a piece incorrectly, it resets to 1.

The time bonus starts at 60 and counts down quickly; press (1) or (2) to see the
time bonus along with your current score.

The exact value of each piece (aside from corner pieces) depends on the queue
depth setting (see the section on options). It is larger for the harder queue
depths. However, the time bonus and multiplier are far more influential than the
intrinsic piece values.


Power-ups
=========

There are two power-ups that you may get randomly upon placing a piece
correctly: the second chance (shown as two glowing puzzle pieces) and the metal
detector (shown as a glowing metal detector). The power-ups that you have are
shown in your player tray on the left side of the screen.

The second chance power-up allows you to try placing a piece a second time if
you fail to place it correctly. Instead of immediately going to the end of the
piece queue, it will stay under your cursor and fade out. If you press and hold
(A) before it fades, the second chance is used up, but you re-grab the piece. If
you do not re-grab it, then your second chance will not be used but your score
multiplier will be reset to 1.

While you have the metal detector power-up, the remote will rumble with
increasing frequency as you move a piece closer to where it goes. The metal
detector only lasts a short while though, so you must act fast!


Options
=======

There are several gameplay options that can be set in the options menu.

The piece size controls how large pieces are; the smaller the piece size, the
more pieces there will be and the harder the puzzle will be.

The queue depth option controls what pieces will be in the piece queue at any
time. Initially, only the corner and edge pieces will be in the queue. In easy
mode, in addition to the corner and edge pieces, the queue will contain only
pieces adjacent to pieces already placed. In medium mode, pieces diagonal or two
pieces away fromp laced pieces will also be in the queue. In hard mode, even
more pieces will be in the queue.

You can set the solved puzzle to show dimly in the playing field, to help
placing pieces. You can also set the solved puzzle and piece outlines to show,
for even more help.

Finally you can set whether or not to show the "grabbing hand" cursor while
holding a piece during play. For small pieces it may be desireable to turn it
off, to better see the piece.


Music
=====

Arcade Jigsaw comes with a selection of built-in music, all of which comes from
the internet. I'm pretty sure the original authors would be thrilled that it's
being used 10-15 years after they created it, but in case you happen to be one
of those authors and would like your music removed, let me know. Eventually I'll
make Arcade Jigsaw able to use player-provided music anyway...


Up to four players can work together to solve puzzles. The puzzles must be PNG
or JPEG images, up to 480x440 in size. A built-in puzzle is used if no SD card
is present when Arcade Jigsaw starts.

Have fun,
Mike Mammarella
