
                                   ----------------------------------------- 
                                                _       _ __      ___ _    
                                               | |_ ___| |\ \    / (_|_)___
                                               |  _/ -_)  _\ \/\/ /| | (_-<
                                                \__\___|\__|\_/\_/ |_|_/__/

                                                     Copyright (C)2009 Pembo
                                                      http://www.pembo.co.uk

                                    -----------------------------------------
            				       v0.1b - NOvember 18th 2009


 TetWiis - A Nintendo WII Tetris Clone, shamelessly based on the Nintendo DS
 version of Tetris.  

 TetWiis is freeware, can be distributed freely and should never be charged for.
 If you distribute this, I'd appreciate being informed via the contact me link
 on my website.

 This has taken a considerable amount of time to create.  If you would like to
 give something back, you'll find a donate link on my website
 http://www.pembo.co.uk


 Controls
 ===================================

 Use the wiimote pointer in the menus to select the options and start the game.
 Point at the menu items with the wiimote and press A to select the options.

 The options screen allows you to turn up/down the volume of the background
 music and the sound effects.


 Once the game starts you'll need to use your wiimote in the horizontal position, 
 e.g.


  +---------------------------------------+
 #|   ---                                 |
 #|  -|U|-   ---     [+]                  | 
 #| |L   R|  |A|     [H]       [1]  [2]   | 
 #|  -|D|-   ---     [-]                  |          
 #|   ---                                 |
  +---------------------------------------+

 The game will count down from 3 flashing an image of a horizontal wiimote 
 as a reminder and will start after the count.  This gives you time to rotate
 the wiimote before the blocks start dropping!

 Controls during the game are as follows
 
 left  - move block left one square
 right - move block right one square
 down  - move block down quickly
 up    - Immediately Drop the block into place
 A     - Hold a piece/swap the piece for the one already held
 Home  - Pause the game
 1     - Rotate the block
 2     - Rotate the block

 Every ten lines you clear increases the level, which increase the speed at 
 which the blocks drop.

 Scoring
 ===================================

 More score can be achieved for getting double/triple/quad lines and
 back to back quad lines.  The higher the level, the higher the rewarded
 score, but the faster the blocks start to drop!


 Change Log
 ===================================
 
 18th November 2009 v0.1b
  - Initial beta release to get feedback and testing results

 Known Issues / Missing Features
 ===================================

 - Currently only works from an SD card.
 - Power reset callback not implemented correctly
 - GameCube Pad, Classic Controller support not yet complete
 - Options aren't saved
 - Highscore table not implemented yet
 - Blocks not all coloured/patterend correctly
 - Only currently tested on PAL TV - may have issues with NTSC.


 Credits & Thanks
 ===================================

 - All coding & Graphics by Pembo
 - Music arranged by Peter M�rck (http://www.sunsetselection.com)
 - Music composed originally by Rob Hubbard, Ben Daglish and Fred Gray
 - Orignal Game Design by Alexey Pajitnov
 - Teknecal for his tutorials on http://www.codemii.com
 - Elisherer for getting me going with GRRLib
 - Arikado for his MP3 code
 - mdbrim for the pcm sound code

