*** YahtzWii v2.0 ***

Yahtzee on the Wii.

This can be distributed in any non-chargeable format, so long as the contents
of the zip file are not modified.  No warranty, etc, etc.

Bugs, feedback to chris@toxicbreakfast.com

*** RELEASE NOTES ***

v2.01 22/10/2009

	Corrected Painted Yahtzee to use the proper number/colour combinations on the dice instead of using random colours.
	Auto-detects rumble settings.

v2.0  19/10/2009

	Added Painted Yahtzee rules.
	Added music.
	More attractive background for Scandinavian rules.
	Slightly enhanced intro and outro.

v1.12 24/02/2009

	Fixed critical bug introduced in v1.1 where if you selected all your dice before marking your score and passed to the next player, the next player would be unable to throw, forcing a restart of the game.

v1.11 20/02/2009

	Now handles tied games correctly.
	Fixed bug with Two Pair scoring (thanks, Uffe)
	Fixed issue where if you quit to the main menu while rolling then started another
game, Player One would get four rolls on his first go.

v1.1  28/01/2009

	Added Scandinavian rules.
	Added French language support.
	If you accidentally press B to roll again before you are done selecting
your dice, you can now press MINUS to go back and select again.
	Highlighting a box on the scorecard will show you the score you could get by selecting that box.
	Using Bonus Yahtzees as jokers now works properly.
	Game will now not let you roll if all dice are selected.
	Fixed issue where game would crash on saving if no sd card inserted or folder renamed.
	
v1.0  08/12/2008

	Initial release.


www.toxicbreakfast.com
TOX 009
