r�alis� par Crazygoth 

Un grand merci �:
# Team Twiizers
# DevkitPro Authors 
# GRRLIB http://grrlib.santo.fr
# Wii Addict http://www.wii-addict.fr
# Nintendo Max et les sponsors pour ce super concours http://www.nintendomax.com

changlog v1.1 20/06/2009
- ajout 3 vie
- plusieurs couleurs pour les fant�mes et ils sont �galement un peu plus beaux
- image sur sd (pr�paration pour th�me)
- suppression du splashscreen du concours
- nouveau splashscreen 

changlog v1.0 pour le concours pour la Nintendomax Wii Dev Comp�tition 2k9
1er version

