OpenTyrianWii README

Current version: 1.0
Coder: Molokai

This is a preliminary readme that will help you to get this running.

This game is a port of OpenTyrian, based on the DOS sourcecode of the game Tyrian for MSDOS.
OpenTyrian is an open source project built around the SDL library.
This port uses Tantric's SDL port as its base.

TO INSTALL:
Copy the contents of archive to the root of your SD card.  You don't have to copy this readme.
Make sure that your apps folder contains OpenTyrianWii, and a tyrian folder resides on the root of your card.

TO PLAY:
Open up HBC and run OpenTyrianWii.

CONTROLS:
    Wiimote+nunchuk:
        A: Fire/confirm
	B: Cancel/Change rear weapon fire type + fire both sidekicks
	1&2: Fire sidekicks (not sure which is left and whic is right).  Awkward, I know.
	Joystick: navigate menus, move ship

Other controls untested.

SAVING:
Just use Tyrian's internal saving.  It works flawlessly.

NOTES:
Do not press A and B too many times too quickly, as this will likely cause an exception.  Buffer overflow, somewhere, is suspected.
Don't hold A or B too long in the Game Menu, or it will register 2 clicks for A, or a B click and an A click for B.
Wii-specific improvements (such as popup keyboard) will be forthcoming.

This program is released under the GNU Public License v. 2.  All credit is given where it is due, and I will try to get 
everyone up as soon as possible.  If I used any of your stuff and have not given you proper credit, please, let me know,
and I will add you as soon as I can.