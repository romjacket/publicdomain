------------------------------------------------------------------------
Yaroze Total Soccer /
-------------------/

  A soccer game on the playstation ... with gameplay !

  ECTS demo
  01/09/98
  A Yaroze conversion of an original PC Windows95 game
  by Charles Chapman (c) 1998
  http://www.netyaroze-europe.com/~charlie/
  charlie@livemedia.co.uk

------------------------------------------------------------------------
Important Notes ! /
-----------------/

  Even though it looks 2D, it is 3D (just from an overhead viewpoint).
  You can zoom in and out of the display.

  Replays from various other angles were not included.

  The control modes include 'autodribble' which makes the ball stick 
  to your players feet. More control of the ball can be had by not
  using autodribble, but control is much more difficult to pick up
  especially with a joypad. Should be cool with the Playstation
  arcade joystick though.

------------------------------------------------------------------------
Options screens /
---------------/

  Navigate the menu screens using Pad 1. CROSS to Select, TRIANGLE to
  go back, and so on.

  Single Game   - play a single game
  Training      - do some training exercises
  Controls      - swap the KICK and PASS buttons, and rotate your joypad !
  Options       - change game options
  Screen Adjust - adjust your screen.. hold down X and move the joypad
  Quit          - erm ... quit

------------------------------------------------------------------------
Options /
-------/

  Pitch type  - Normal, Muddy, Wet, Dry or Random. Each with their own
                bounce and roll characteristics.
  Wind        - None, Light or Strong
  Half Length - 01:00, 02:00, 04:00, 08:00
  Sound FX    - Turn the SFX on or off
  Crowd SFX   - Turn the crowd sound on or off
  Referee     - 16 different refs, or random
  CPU skill   - Low, Medium, High or Super
  Keeper skill- Low, Medium, High or Super

------------------------------------------------------------------------
Team Selection /
--------------/

  Change your team around by highlighting a player, pressing X, and then
  highlighting a player to swap with and pressing X again.

  Also select your tactics and play style here.

------------------------------------------------------------------------
Playing the game /
----------------/

  Erm - its soccer.

  'autodribble' makes the ball stick to your feet when dribbling.

  The player currently under control is highlighed by a square around
  his feet.
  Directions control the movement of your player(s), you will sometimes
  appear to be in control of more than one player.

  Control and dribbling may be a little tricky at first, but you'll soon
  pick it up.

  CROSS Kicks, hold down to get more height on the ball
  SQUARE Passes. (you can swap these around in the Controls menu)

  If you hold down the PASS button whilst running up to the ball you will
  hold the ball, where you can change your direction and pass.
  When KICKing the ball, the longer you hold down the fire button, the
  higher the ball will go.
  When the ball is in the air pressing KICK will make your player jump.
  If he makes contact with the ball whilst mid air he will head the ball.
  When the ball is on the ground, and not in your possession then
  pressing KICK will make your player do a sliding tackle.
  Aftertouch (using the direction controls) can be used to swerve the
  ball once kicked. eg to bend in a cross or curl a pass around an
  opposition player.

  Corners  : KICK will play a ball into the 18 yard box in the direction
             of your controller. Hold down KICK to get more height.
             PASS will pass the ball to the nearest player.

  FreeKicks: KICK/PASS will pass the ball to the nearest player.
             when within shooting area, pressing KICK will shoot at the
             goal in the direction pointed at, aftertouch will then apply.

  Penalties: Press KICK to kick the ball in the direction of the moving
             pointer. Use aftertouch to curl the ball.

  Goalkeepers are computer controlled, except when the ball is in their
  posession where you may use the KICK, PASS and direction buttons to
  release the ball.

------------------------------------------------------------------------
In game controls /
----------------/

  TRIANGLE - Request a substitution or tactics change.. your team name
             will be shown in blue at the top, and the next time play
             is stopped you will be able to change your team & tactics.
  CIRCLE   - Replay last few seconds of the game (press SELECT to exit)
  R1       - Zoom in
  R2       - Zoom out
  L1 or L2 - Default zoom level
  SELECT   - Pause / Quit
  START    - Show stats (press START again to continue)
  
------------------------------------------------------------------------
