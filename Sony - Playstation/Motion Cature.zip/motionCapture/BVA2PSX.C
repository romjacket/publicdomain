#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dir.h>
#include <ctype.h>

void convertSegment(int segNum);
void getStats();
FILE *fpin,*fpout,*fptest,*fpinclude;
int totalSegments=0;
int totalFrames=0;
char infile[255];

int getNextNum(char *s, char *n,int l)
{
int j=0;

while(!isdigit(s[l])&&s[l]!='.'&&s[l]!='-')l++;
while (isdigit(s[l])||s[l]=='.'||s[l]=='-'){
	n[j]=s[l];
	j++;l++;
	}
   n[j]=NULL;
	return(l);
}


void getStats()
{
static int first=1;
char seg[255]="Segment", astring[255],tmp[255],tmp1[255];
	if ((fpin = fopen(infile, "r"))==NULL)
	 {	printf("ERROR: can't open %s\n",infile); exit(0);}

	while(!feof(fpin)){
		fgets(tmp,255,fpin); //read first line
		sscanf(tmp,"%s",astring);
		if((strncmp(seg,tmp,5))==0){
			// found start of segement
			totalSegments++;
		  if(first){
			first=0;
			fgets(tmp,255,fpin); //read second line
			// get totalFrames form 2nd line
			getNextNum(tmp,tmp1,9);
			printf("tmp1 %s\n",tmp1);
			totalFrames=atoi(tmp1);
			printf("totalFrames %d\n",totalFrames);
         }
		}
	}
	fprintf(fpout,"#define TOTAL_SEGMENTS %d\n#define TOTAL_FRAMES %d\n\n",totalSegments,totalFrames);
	fclose(fpin);
}


void main(int argc,char *argv[])
{

int i;
 char string[10];

strcpy(infile,*++argv);


	if ((fpout = fopen("motion.h", "w+"))==NULL)
	  {	printf("ERROR: can't open %s\n","motion.h");exit(0);}
	if ((fptest = fopen("mydat.c", "w+"))==NULL)
	  {	printf("ERROR: can't open %s\n","mydat.c");exit(0);}
	if ((fpinclude = fopen("frame.h", "w+"))==NULL)
	  {	printf("ERROR: can't open %s\n","frame.h");exit(0);}
	getStats();
		if ((fpin = fopen(infile, "r"))==NULL)
	 {	printf("ERROR: can't open input .bva file %s\n",infile); exit(0);}

	for(i=0;i<totalSegments;i++) convertSegment(i);

	fclose (fpin);
	fclose (fpout);
	fclose (fptest);
	printf("segs %d frames %d",totalSegments,totalFrames);
	printf("Done\n");
	exit(0);

}

void convertSegment(int segNum)
{

char seg[255]="Segment", astring[255],tmp[255],tmp1[255];
int i,c,numframes,boneNumber=0;
float val;
int xtran,ytran,ztran,xrot,yrot,zrot;
float scaleTrans=60.0,scaleRot=4096.0/360.0,rotscale=360.0/4096.0;

			if(segNum==0)fprintf(fpout,"int motionData[%d][%d][6] = {{\n",totalSegments,totalFrames);
			else fprintf(fpout,"},\n{\n");


			//skip first five lines to start of data
			fgets(tmp,255,fpin);
			fgets(tmp,255,fpin);
			fgets(tmp,255,fpin);
			fgets(tmp,255,fpin);
			fgets(tmp,255,fpin);
			for (i=0;i<totalFrames;i++){
			 fgets(tmp,255,fpin);

			c=0;
			c=getNextNum(tmp,tmp1,c);
			val=atof(tmp1);
			xtran=(int)(val*scaleTrans);

			
			c=getNextNum(tmp,tmp1,c);
			val=atof(tmp1);
			ytran=(int)(val*scaleTrans);


			
			c=	getNextNum(tmp,tmp1,c);
			val=atof(tmp1);
			ztran=(int)(val*scaleTrans);

			
			c=	getNextNum(tmp,tmp1,c);
			val=atof(tmp1);
			xrot=(int)(val*scaleRot);


			
			c=	getNextNum(tmp,tmp1,c);
			val=atof(tmp1);
			yrot=(int)(val*scaleRot);

         
			c=getNextNum(tmp,tmp1,c);
			val=atof(tmp1);
			zrot=(int)(val*scaleRot);
          //xrot=yrot=zrot=0;
			 if(i==totalFrames-1&&segNum==totalSegments-1){
				fprintf(fpout,"{%d,	%d,	%d,	%d,	%d,	%d},\n",xtran,ytran,ztran,xrot,yrot,zrot);
				fprintf(fpout,"}};\n");
				fprintf(fptest,"{%f  %f  %f  %f  %f  %f},\n",xtran/scaleTrans,ytran/scaleTrans,ztran/scaleTrans,
				xrot*rotscale,yrot*rotscale,zrot*rotscale);
				}
			 else{
				fprintf(fpout,"{%d,	%d,	%d,	%d,	%d,	%d},\n",xtran,ytran,ztran,xrot,yrot,zrot);
				fprintf(fptest,"{%f  %f  %f  %f  %f  %f},\n",xtran/scaleTrans,ytran/scaleTrans,ztran/scaleTrans,
				xrot*rotscale,yrot*rotscale,zrot*rotscale);
			 
			}
		}



}

