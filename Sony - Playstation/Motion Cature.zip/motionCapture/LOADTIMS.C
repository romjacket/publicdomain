#include "addrs.h"

void	LoadTextures(){
}
