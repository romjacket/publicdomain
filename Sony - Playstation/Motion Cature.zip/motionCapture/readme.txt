During our second short course two cool guys, Roy Bailey and Lee Spring, found some motion 
catputre data on the web and started work on applying it to a model of theirs. 
They didn't manage to get it done in a day and so they moved on to working on 
dynamic TMD's. Look out for some hot demos from these guys in the coming months ...

I couldn't resist trying to get motion capture data into the PSX, so I did. The data comes from:

Jeff Lander 
jeffl@darwin3d.com
www.darwin3d.com/gamedev.htm	

where you will find an opengl previewer and other very useful stuff about 
quaternions and other topics.

motcap.zip contains a dos c program with source that converts Biovision (.bva) 
format motion catures files into a include file to be used on the PSX. Five 
motion capture .bva files are included, you can probably find more if you 
search the web, but I don't guarentee my utility will convert them ok 
(but I included the source). To run the different motion capture files type:

bva2psx thefile.bva

and then make clean, and then make. Then run siocons auto. The L1, L2, R1, 
and R2 buttons give different views of the object. I gave the actor a teapot 
head but just used a box for the other bones. I don't know whether the pivot 
points are correct but the animation looks similar to the original.

I included the source of the PSX program which is especially designed to 
upset CW users. Maybe somebody will convert it to CW for Mac and other 
CW users (Paul?).

motcap.zip can be found from: 
http://www.netyaroze-europe.com/~middx_uni/