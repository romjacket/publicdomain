/*******************
 step7.h
*******************/

#define ORDERING_TABLE_LENGTH (12)
#define MAX_NO_PACKETS  (248000)

#define TRUE (1)
#define FALSE  (0)

#define SCREEN_WIDTH  (320)
#define SCREEN_HEIGHT (240)

int CurrentBuffer;
#define RenderPrepare()\
		GsSetRefView2(&ViewPoint);\
		CurrentBuffer=GsGetActiveBuff(); \
		GsSetWorkBase((PACKET*)Packet_Memory[CurrentBuffer]);\
		GsClearOt(0, 0, &OTable_Header[CurrentBuffer]); 

#define 	RenderFinish()\
		DrawSync(0);\
		GsSwapDispBuff(); \
		GsSortClear(0, 0, 0,&OTable_Header[CurrentBuffer]); \
		GsDrawOt(&OTable_Header[CurrentBuffer]);

// We need two Ordering Table Headers, one for each buffer
GsOT OTable_Header[2];
// And we need Two Ordering Tables, one for each buffer
GsOT_TAG        OTable_Array[2][1<<ORDERING_TABLE_LENGTH];
//We also allocate memory used for depth sorting, a block for each buffer
PACKET          Packet_Memory[2][MAX_NO_PACKETS];

// This is an array of structures for the lights
GsF_LIGHT       LightSource[2];

// Define a structure to hold a 3D object that will be rendered on screen
typedef struct
{   SVECTOR         Rotation;
	 GsDOBJ2         Object_Handler;
	 GsCOORDINATE2   Object_Coord;
}PlayerStruct1;

typedef struct
{   VECTOR		  Direction;
	 GsDOBJ2         Object_Handler;
	 GsCOORDINATE2   Object_Coord;
}PlayerStruct;


/************* FUNCTION PROTOTYPES *******************/
void InitialisePlayerModel(PlayerStruct *thePlayer, int nX, int nY, int nZ,
	unsigned long *lModelAddress);
void InitialisePlayerModel1(PlayerStruct1 *thePlayer, int nX, int nY, int nZ,
	unsigned long *lModelAddress);
void DrawPlayer(PlayerStruct *thePlayer);
void DrawPlayer1(PlayerStruct1 *thePlayer);
void InitialiseALight(GsF_LIGHT *flLight, int nLight, int nX, int nY, int nZ,
		int nRed, int nGreen, int nBlue);
void InitialiseLights();
void InitialiseView(GsRVIEW2 *view, int nProjDist, int nRZ,
						  int nVPX, int nVPY, int nVPZ,
						  int nVRX, int nVRY, int nVRZ);
void Initialise3DGraphics();                                    
void RenderWorld();
long NormalScale(long x,long y,long z);
void AdjustCoordinate2(GsCOORDINATE2 *coord);

void InitialiseStaticView(GsRVIEW2 *view, int nProjDist, int nRZ,
						  int nVPX, int nVPY, int nVPZ,
						  int nVRX, int nVRY, int nVRZ);


void InitialiseTrackerView(GsRVIEW2 *view, int nProjDist, int nRZ,
						  int nVPX, int nVPY, int nVPZ,
						  int nVRX, int nVRY, int nVRZ,GsCOORDINATE2 *Object_Coord);

/*****************************************************/
