#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dir.h>
#include <ctype.h>

int whiteSpace(char * s)
{
int i=0,j;
char *c;
while(*c==' '){
 //	printf("c is %c\n", *c);
	c=s++;  i++;
	}
	return i;
}

void getNum(char *s, char *n,int l)
{
int i,j=0,k;

while (s[l]=='0'||s[l]=='1'||s[l]=='2'||s[l]=='3'||s[l]=='4'||s[l]=='5'||
s[l]=='6'||s[l]=='7'||s[l]=='8'||s[l]=='9'||s[l]=='.'||s[l]=='-'){
	n[j]=s[l];
  //	printf("getn %c %d\n  ",s[l],l);
	j++;l++;
	}
}
int getNextNum(char *s, char *n,int l)
{
int i,j=0,k;
while (s[l]!='0'&&s[l]!='1'&&s[l]!='2'&&s[l]!='3'&&s[l]!='4'&&s[l]!='5'&&
s[l]!='6'&&s[l]!='7'&&s[l]!='8'&&s[l]!='9'&&s[l]!='.'&&s[l]!='-')l++;
while (s[l]=='0'||s[l]=='1'||s[l]=='2'||s[l]=='3'||s[l]=='4'||s[l]=='5'||
s[l]=='6'||s[l]=='7'||s[l]=='8'||s[l]=='9'||s[l]=='.'||s[l]=='-'){
	n[j]=s[l];
	//printf("getn %c %d\n  ",s[l],l);
	j++;l++;
	//printf("l is now%d\n  ",l);
	}
	return(l);
}
int passWord(char * s)
{
int i=0,j;
char *c;
c=s++; i++;
while(*c!=' '){
  //	printf("c is %c\n", *c);
	c=s++;  i++;
	}
 while(*c==' '){
//	printf("c is %c\n", *c);
	c=s++;  i++;
	}

	return i;

}
void main()
{
FILE *fpin,*fpout,*fptest;
char seg[255]="Segment", astring[255],tmp[255],tmp1[255];
int done,i,ignore=0,c,numframes;
float val;
int xtran,ytran,ztran,xrot,yrot,zrot;
float scaleTrans=40.0,scaleRot=4096.0/360.0,rotscale=360.0/4096.0;

struct ffblk ffblk;
 char old_ff_name[13],body_ff_name[13],myfilename1[255];
	if ((fpin = fopen("test.bva", "r"))==NULL)
	 {	printf("ERROR: can't open %s\n","test.bva"); exit(0);}

	if ((fpout = fopen("arry.c", "w+"))==NULL)
	  {	printf("ERROR: can't open %s\n","arry.c");exit(0);}
		if ((fptest = fopen("mydat.c", "w+"))==NULL)
	  {	printf("ERROR: can't open %s\n","mydat.c");exit(0);}

		fgets(tmp,255,fpin); //read first line
		sscanf(tmp,"%s",astring);
		if((strncmp(seg,tmp,5))==0){
			// found start of segement
			printf("segment found\n");
			printf("seg %s tmp %s \n",seg,tmp);
			fgets(tmp,255,fpin); //read second line
			// get numframes form 2nd line
			printf("%d\n",passWord(tmp));
			c=passWord(tmp)-1;
			getNum(tmp,tmp1,c);
			printf("%s\n",tmp1);
			numframes=atoi(tmp1);
			printf("numframes %d\n",numframes);
				fprintf(fpout,"int leftFoot[%d][6] = {\n",numframes);
			//skip next three lines to start of data
			fgets(tmp,255,fpin);//printf("string %s \n",tmp);
			fgets(tmp,255,fpin);//printf("string %s \n",tmp);
			fgets(tmp,255,fpin);// printf("string %s \n",tmp);
			for (i=0;i<numframes;i++){
			 fgets(tmp,255,fpin);//printf("string %s \n",tmp);
           printf("string %s \n",tmp);
			 c=whiteSpace(tmp)-1;if(c<0)c=0;
			 tmp1[0]=NULL;
			getNum(tmp,tmp1,c);
		 //	printf("string %s %d\n",tmp1,c);
			val=atof(tmp1);
		  //		printf("val %f\n",val);
			xtran=(int)(val*scaleTrans);
		  //	printf("xtran %d\n",xtran);

			 tmp1[0]=NULL;
			 c=5;
			c=getNextNum(tmp,tmp1,c);
		 //	printf("string %s %d\n",tmp1,c);
			val=atof(tmp1);
			  //	printf("val %f\n",val);
			ytran=(int)(val*scaleTrans);
		  //	printf("ytran %d\n",ytran);

						 tmp1[0]=NULL;
			// c=12;
		  c=	getNextNum(tmp,tmp1,c);
		 //	printf("string %s %d\n",tmp1,c);
			val=atof(tmp1);
		  //		printf("val %f\n",val);
			ztran=(int)(val*scaleTrans);
		  //	printf("ztran %d\n",ztran);

			 //			 c=19;
		  c=	getNextNum(tmp,tmp1,c);
		//	printf("string %s %d\n",tmp1,c);
			val=atof(tmp1);
		 //		printf("val %f\n",val);
			xrot=(int)(val*scaleRot);
		 //	printf("xrot %d\n",xrot);

		  //	c=26;
		  c=	getNextNum(tmp,tmp1,c);
		 //	printf("string %s %d\n",tmp1,c);
			val=atof(tmp1);
		  //		printf("val %f\n",val);
			yrot=(int)(val*scaleRot);
		 //	printf("yrot %d\n",yrot);

		  //	c=32;
			c=getNextNum(tmp,tmp1,c);
		 //	printf("string %s %d\n",tmp1,c);
			val=atof(tmp1);
			  //	printf("val %f\n",val);
			zrot=(int)(val*scaleRot);
		 //	printf("zrot %d\n",zrot);
		 printf("i is %d %d ",i,(i==87) );
			 if(i==numframes-1){
				printf("inloop\n");
				fprintf(fpout,"{%d,	%d,	%d,	%d,	%d,	%d}\n",xtran,-ytran,ztran,xrot,yrot,zrot);
				fprintf(fpout,"};\n");
				fprintf(fptest,"{%f  %f  %f  %f  %f  %f},\n",xtran/scaleTrans,-ytran/scaleTrans,ztran/scaleTrans,
				xrot*rotscale,yrot*rotscale,zrot*rotscale);
				}
			 else{
				fprintf(fpout,"{%d,	%d,	%d,	%d,	%d,	%d},\n",xtran,-ytran,ztran,xrot,yrot,zrot);
				fprintf(fptest,"{%f  %f  %f  %f  %f  %f},\n",xtran/scaleTrans,-ytran/scaleTrans,ztran/scaleTrans,
				xrot*rotscale,yrot*rotscale,zrot*rotscale);
			 }
			}
		}
       printf("\n");

	// write initial load textures line


	fclose (fpin);
	fclose (fpout);	fclose (fptest);

	printf("Done\n");
}

