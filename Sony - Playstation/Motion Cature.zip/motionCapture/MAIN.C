/***************************************************************
	 main.c - run bva motion capture files
	 ======
***************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <libps.h>
#include "pad.h"
#include "addrs.h"
#include "step7.h"
#include "motion.h"

// Create an array of  PlayerStruct to hold segments
PlayerStruct TheSegments[TOTAL_SEGMENTS];
// We need a viewing system for 3D graphics
GsRVIEW2        ViewPoint;
u_long PADstatus=0;
u_long GameRunning=TRUE;
u_long VerticalSync;
int xval=-700;
int viewRot=4096*180;
/************* Function prototypes ***********/
void RenderWorld();

// This function deals with double buffering and drawing of 3D objects
void RenderWorld()
{  int i;
		RenderPrepare();
		for (i=0;i<TOTAL_SEGMENTS;i++)
			DrawPlayer(&TheSegments[i]);
		VerticalSync=VSync(2);
		FntFlush(-1);
		RenderFinish();
}



void ProcessUserInput()
{
	PADstatus=PadRead();
	if(PADstatus & PADselect)GameRunning=0;

	if (PADstatus & PADL1){
		FntPrint ( "PAD padL1:BACK_VIEW\n");
		InitialiseStaticView(&ViewPoint, 250, viewRot, 0, 4000,-5000, 0, 2000, 0 );
	}
  if (PADstatus & PADL2)
	{
		FntPrint ( "PAD padL2: ARIAL_VIEW\n");
		InitialiseStaticView(&ViewPoint, 250, viewRot, 0, 10000, -00, 0,2000,0);
  }
	if (PADstatus & PADR1){
		FntPrint ( "PAD padL1:SIDE_VIEW\n");
		InitialiseStaticView(&ViewPoint, 250, viewRot, 6000, -0, 0, 0, 2000, 0 );
	}
  if (PADstatus & PADR2)
	{
		FntPrint ( "PAD padL2: FRONT_VIEW\n");
		InitialiseStaticView(&ViewPoint, 250, viewRot, -0, 4000,9000, 0, 2000, 0 );
  }

}

void UpdateWorld()
{
	MATRIX matTmp;
	SVECTOR svRotate;

	static int frameNum=0;
	int segNum=0;
	frameNum++;
	if (frameNum==TOTAL_FRAMES-1) frameNum=0;
	for(segNum=0;segNum<TOTAL_SEGMENTS;segNum++){
		TheSegments[segNum].Object_Coord.coord=GsIDMATRIX;
		// This is the vector describing the rotation
		svRotate.vx =0;
		svRotate.vy =0;
		svRotate.vz = motionData[segNum][frameNum][5];
		RotMatrix(&svRotate, &matTmp);
		MulMatrix0(&TheSegments[segNum].Object_Coord.coord, &matTmp,&TheSegments[segNum].Object_Coord.coord);

		svRotate.vx =0;
		svRotate.vy = motionData[segNum][frameNum][4];
		svRotate.vz =0;
		RotMatrix(&svRotate, &matTmp);
		MulMatrix0(&TheSegments[segNum].Object_Coord.coord, &matTmp,&TheSegments[segNum].Object_Coord.coord);

		svRotate.vx = motionData[segNum][frameNum][3];
		svRotate.vy =0;
		svRotate.vz =0;
		RotMatrix(&svRotate, &matTmp);
		MulMatrix0(&TheSegments[segNum].Object_Coord.coord, &matTmp,&TheSegments[segNum].Object_Coord.coord);

		TheSegments[segNum].Object_Coord.coord.t[0]=motionData[segNum][frameNum][0];
		TheSegments[segNum].Object_Coord.coord.t[1]=motionData[segNum][frameNum][1];
		TheSegments[segNum].Object_Coord.coord.t[2]=motionData[segNum][frameNum][2];
		TheSegments[segNum].Object_Coord.flg=0;
	}
}

int main()
{ int i;
	// set up print-to-screen font, the parameters are where the font is
	// loaded into the frame buffer
	FntLoad(960, 256);
	//specify where to write on the PSX screen
	FntOpen(-96, -96, 192, 192, 0, 512);
	// initialise the joypad
	PadInit();
	// initialise graphics
	Initialise3DGraphics();
	// Setup view to view the car from the side
	InitialiseStaticView(&ViewPoint, 250, viewRot, -0, 4000,9000, 0, 2000, 0 );
	InitialiseLights();
	// The car's initial xyz is set to 0,-200,0
	for(i=0;i<TOTAL_SEGMENTS;i++){
		if (i==3)InitialisePlayerModel(&TheSegments[i],  0, -200,0, (u_long*)TEAPOT_TMD);
		else InitialisePlayerModel(&TheSegments[i],  0, -200,0, (u_long*)BOX_TMD);
		}
	while(GameRunning){
		ProcessUserInput();
		// render the car and hello world message
		UpdateWorld();
		RenderWorld();
		}
	// clean up
	ResetGraph(3);
	return 0;
}

