#include <libps.h>

int LoadTexture(long addr);

// load up from conventional memeory into video memory
int LoadTexture(long addr)
{
	RECT rect;
	GsIMAGE tim1;

	// get tim info/header, again a little bit of majic is needd the pointer
	// is incremented past the first 4 positions to get to this!
	GsGetTimInfo((u_long *)(addr+4),&tim1);

	// set the rect struct to contain the images x and y offset, width and height
	rect.x=tim1.px;
	rect.y=tim1.py;	
	rect.w=tim1.pw;	
	rect.h=tim1.ph;	

	//load image from main memory to video memory
	LoadImage(&rect,tim1.pixel);

	// if image has clut we need to load it too,
	//pmode =8 for 4 bit and 9 for 8 bit colour

	if((tim1.pmode>>3)&0x01) 
    {
	// set the rect struct to contain the clut's x and y offset, width and height
		rect.x=tim1.cx;
		rect.y=tim1.cy;	
		rect.w=tim1.cw;	
		rect.h=tim1.ch;	
	// load the clut into video memeory
		LoadImage(&rect,tim1.clut);
	}
	DrawSync(0);
	return(0);
}
