SUPER BUB CONTEST - Version 1.01.PAL.SIO
========================================



ABOUT THE GAME
--------------

The Super Bub Contest is 1 or 2 player.  Practice against the CPU, then
slaughter your friends!  Yes, it's a Baku Baku, Super Puzzle Fighter,
Bust-A-Move type of arrangement.


HOW TO LOAD
-----------

Hopefully you've extracted these files into a new folder.  Now just run
Auto.sio from SIOCONS or PSComUtil.


HOW TO PLAY
-----------

Group like coloured bubbles together.  Flames pop all connected bubbles of
matching colour.  Attack the other player by destroying 3 or more
bubbles/flames.  The more items you destroy, the more you'll "spill" into
the other player's area.  Create chain reactions to multiply the spill.
If either player ends up with bubbles/flames in the lower playing area
(below the line) then that player loses the round.  (Watch a demo by leaving
the game at the title page.)



