This is a Net Yaroze conversion done by PSXDEV.net.
http://www.psxdev.net/forum/viewtopic.php?f=56&t=636

The image is licensed as a European license, but the game itself
is running in a 320x240 resolution, which is NTSC.

If there are any issues, please feel free to email us directly at
contact@psxdev.net, or find us on EFnet #psxdev.