Opera of Destruction
--------------------

Note:
-----

PAL TV Players download game using (PALAUTO). NTSC players use AUTO.

Game Overview:
--------------

In both one and two player mode the objective of the game is to destroy
the enemy city while at the same time protecting your own city from
attack. At the start of the game your city will be at 100% strength.
When your city is leveled (0% in 1 player, 10% in 2 player mode), the
battle is lost. In one player mode, you have to destroy a certain
percentage of the enemy city depending on the level. There are 20 worlds
to conquer.

Your city is guarded by massive cannons capable of firing 10000
rounds/minute. You will need this kind of fire power to defend the city
against the alien craft that the enemy commands. You also have a single
fighter jet to protect the city and attack the enemy city. The jet can drop
bombs and unlilke your cannons has unlimited ammo. When you are using a
cannon your fighter enters statis and freezes in place but is still
vulnerable. If your fighter is destroyed the game ends. You can switch
between fighter and cannon at any time.

You have a limited amount of cannon ammo and bombs. These can be
replenished by collecting Enery Cubes scattered throughout the world.
When you are out of ammo or have no more bombs, pressing the fire
button for that weapon will automatically convert an energy cube to
either a bomb or ammo.

Game Controls:
--------------

   select:           pause game
   L1:               enter gun post 1
   L2:               enter gun post 2
   circle:           enter fighter jet
   x:                fire 

In Cannon:
   direction pad:    move gun turrent

   Hold down start button to use direction pad to move the gun post
   in the direction in which it is pointing. 
   With start button down, L1 and L2 move gun post up/down.

In Fighter:
   direction pad:    movement
   R1:               hold down for rear view
   R2:               hold down for top view
   Triangle:         increase speed
   Circle:           decreaase speed
   Square:           drop bomb


On Screen Messages:
-------------------
PWR   - the strength of your fighter
CITY  - your city's strength
ENEMY - enemy city's strength
CUBES - number of energy cubes

Tips:
-----

- flying into a builing damages your aircraft
- don't drop all your bombs at once. Space your bombs so that you
  only use one bomb per building.
- cannon fire can level a city quickly but some buildings are better
  destroyed by bombs.
- move your cannons to strategic locations before the enemy attacks
- the best way to lose a bogey on your tail is to do some tight flying
  through a canyon.
- there is a cheat that can be accessed from the main menu..


Contact
-------

Feel free to contact me to chat about anything.

James Pretorius
jpretori@home.com

