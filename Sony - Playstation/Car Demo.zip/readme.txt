Basic Instructions for the car demo.

auto is the script to run from SIOCONS

Keys:

Lleft:	turn left
Lright:	turn right
Ldown:	reverse

Rdown:	accelerate
Rleft:	brake
Rup:		record mode
Rright:	playback mode

R1:		change camera

Steve Collins
Telekinesys Research
www.telekinesys.com
