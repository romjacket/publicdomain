game: Blitter Boy in Operation: Monster Mall
by Chris Chadwick - chris.chadwick@dial.pipex.com
PAL only version for ECTS giveaway CD

To load and Run
---------------
In SIOCONS, press F3 and type AUTO, then press ENTER.
The game will now automatically load and run.

Controls
--------
All game controls are displayed onscreen before the game starts.

Levels
------
This version currently has 20 levels. Level 20 will
then simply repeat if cleared.

Exiting
-------
To exit the game and return to SIOCONS, press
START+SELECT when actually playing the game.
