
OOGA BOOGA!
Kaneda - release 10.1



INTRODUCTION

This is a VERY little game I (Kaneda) made for the y2kode competition.
It's a pure jump and run game.
I tried to use all the features of the Sega Genesis except Raster and 
Highlight since it's not quite good emulated, even FM Music!! See the
ending for this 2 channels song.
I also hide a cheat code :).
Kaneda@softhome.net


WORKING
I tested on all the emus i have and only found bugs on GenEm, Ages, Gens,
st0rm and VGen which are aborted projects or WIP.
I didn't try yet on a real Genesis.


CONTROLS

Left	Go to left
Right	Got to right
A	Jump
B	Run
C	Attack (if you have a attack item)
Start	Pause

ENEMIES
Mosquito	Damage: 10
Fish		Damage: 20


OTHERS ITEMS
Heart		Restore 20
Pic		Kill you if you jump on it


COMING SOON

OOGA BOOGA! is only a sample of what we can do.
Soon you'll have reflexion(Tetris-like), shoot(TForce-like), beat (SORage-
like), RPG (SForce-like). And some beautiful demos!!
See www.consoledev.fr.st for more infos


THANKS

Paul Lee for the SGCC compiler and the support
Charles Doty for all he does for the emu-dev scene
Kevin Banks for FMMUSIC sample demo
Ari Felman for his free sprites lib graphism
Deedo to let me work hard a complete week (the final one!)