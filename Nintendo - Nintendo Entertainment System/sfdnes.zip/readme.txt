
        Super Fighter Demo for Nintendo [NES]
 ----------------------------------------------------
  CODE: Chris Covell [ccovell@direct.ca]
  GRAPHICS: Death Adder [deathadder@superfighter.com]
  MUSIC: Memblers [5010.0951@tcon.net]
 ----------------------------------------------------
  Thank-you for downloading the NES Super Fighter
  demo! You can enjoy the demo on most any Nintendo
  emulator, but I recommend using LoopyNES, which
  can be downloaded from http://www.superfighter.com/
  (from this demo's download page).
 ----------------------------------------------------
  The Super Fighter cast picture was ripped from the
  game's end sequence. It was resized (to fit the
  Nintendo's screen size) and color-reduced. The
  fire-logo was ripped from the Super Fighter title
  screen, and similarly treated to fit into Nintendo
  specs. The music was composed using the original
  MIDI score as a guideline. It comes from the
  character Lan's background stage.
 ----------------------------------------------------
  LEGAL 'STUFF' ->
   The game "Super Fighter", its characters, music,
   and everything else related to it are (c)1993 by
   C&E INC. (Taiwan). This demo is in no way connected
   to the company, and was made only for enjoyment, and
   to spread the word about this great game.
 ----------------------------------------------------
  This demo will -ALWAYS- be available from the
  Unofficial Super Fighter Website, located at:

             http://www.superfighter.com/

                          or

           http://hardcoregamers.com/sfighter/
  ---------------------------------------------------
