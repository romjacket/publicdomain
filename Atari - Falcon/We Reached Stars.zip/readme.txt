
     ___ ___  __  __           __   _______         __    __               
    |   |   ||__||  |_ .---.-.|  | |   |   |.-----.|  |_ |__|.-----..-----.
    |   |   ||  ||   _||  _  ||  | |       ||  _  ||   _||  ||  _  ||     |
     \_____/ |__||____||___._||__| |__|_|__||_____||____||__||_____||__|__|
                                                                           
                                  Presents

                          an Atari Falcon 060 demo

                                   called

                          .-* We Reached Stars *-.


  Code: Orion_
  
  Musik: kioniro
  
  Graf : reveclosion & yogib33r


  Gr33ts to scoopex, m4nkind, pospy team, tristar, x-men, frequency,
  ctrl alt test, adinpsz, punkfloyd, purelamerz, WillBe/cocoon, no extra, Ra,
  sector one, dune, cerebral vortex, libre pc, jagware team, le boucher,
  voxel, relec, amigaouf, demoscene.fr, oxygene, rgc, mjjprod, tawny/kikiprods,
  h20 & Franck / rebels, adoru, red7, Gun, shen, Line, farbrausch, tbl, andromeda,
  asd, dekadence, traction, crisot/univers, furrtek, spaceballs, DHS, alchimie 
  & tripleA, rouquemoute, m!!, tpolm and all we forgot ! Falcon rulez !!! 

  Special gr33ts to all vm members !!!


Technicals stuff for running this demo:

-This demo is intended to be viewed on a Falcon CT60 at 96Mhz on a 60Hz VGA 
 display. (for best timing !)
-This demo should run with any CT60 speed (66Mhz), and on 60Hz VGA or 50Hz TV 
 display.
-This demo needs around 3,32MB of free ST-RAM, and 3,5MB of free FastRAM.
-If you don't have enough free ST-RAM (4MB Falcon), simply start your Falcon
 by holding the "control" key until the desktop appears, this will skip all
 the startup programs and accessories.
 (pro-tip: try reducing your harddrive's driver cache)
