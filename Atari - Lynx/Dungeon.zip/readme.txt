The Dungeon
Lynx-Version 0.12
March 21, 1998

History:
Version 0.12
   The starting position of Player 1 in version 0.11 was one of the
   test positions, sorry.
   A workaround for a little rendering failure (door part 3 is missing
   when you are just one bnlock away from it) has been implemented.

Version 0.11
   Removed the bug that denied the access to the second level.
   Added the screen-output of the own position:
     Row 3: 
     digits 1+2: level
     digit 3:    y-postion
     digit 4:    x-position

Version 0.10
   Mixed the SinglePlayer- and the MultiPlayer-versions.
   A sample is played at the start and whenever Option1 is pressed.

Version 0.08, 0.09
   Changed the program to be a ComLynx-Demo.

Version 0.07
   Some internal redesign has been done.
   The stairways are repaired, but i removed the second level. So i
   blocked the stairways with some non-player characters (NPCs).

Version 0.06
   Now there are switches on the floor and at the walls for opening and
   closing the doors.
   The wall-decorations are positioned better, but the stairways are
   still out of order.

Version 0.05
   Released March 23, 1997
   Added a third wall-decoration: torches
   Wall-decorations and doors are now visible in most of the positions.
   The stairways are out of order :(

Version 0.04
   Released March 16, 1997
   Added wall-decorations: handcuffs and gargoyles
   Doors can now be opened and closed using the Option1-button.
   For this purpose, movement is now only possible every 16th frame.
   Wall-decorations and doors are still only seen if they are in
   the middle block-section.

Version 0.03
   Released March 8, 1997
   Added a graphic, needed if you are in a door-block looking to the side.
   Changed the way how the screen is build:

      Depth 4:           background
      Depth 3: 2.Left Left Middle Right 2.Right
      Depth 2:        Left Middle Right
      Depth 1:        Left Middle Right
      Depth 0:        Left   x    Right

Version 0.02
   Released March 2, 1997
   Better use of sprites and pen-colours.
   Stairways and two different door-types are implemented.
   To save RAM, there are only 2 graphics used for the stairways,
   so they have to be "around the corner". The graphics are for use
   as Depth 1, middle.
   There are door-graphics for the Middle-Columns only.
   Maze: 14*14, 2 Levels

Version 0.01
   Released February 23, 1997
   Simple demonstration of a block-based graphic-engine.
   How the screen is build:

      Depth 4:    background
      Depth 3: Left Middle Right
      Depth 2: Left Middle Right
      Depth 1: Left Middle Right
      Depth 0: Left   x    Right

      Player looks from x towards background.
      
   Maze: 8*8, 1 level
   Control:
      A-button:      turn right
      B-button:      turn left
      Left-cursor:   move to the left
      Right-cursor:  move to the right
      Up-cursor:     move forward
      Down-cursor:   move backward
