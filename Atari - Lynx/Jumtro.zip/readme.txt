Lynx Demo 1
~~~~~~~~~~~

By Jum Hig '99

Complicated Instructions:
~~~~~~~~~~~~~~~~~~~~~~~~
1) Load "mydemo.o" into Lynx emulator (eg: Handy).
   Or if you are one of the chosen few with an upload
   card, you can upload it to your Lynx (may have to hack it
   first, I really don't know).

2) Watch lame graphics.


Source code (CC65) included. Read it for a good laugh. :*)


Technical:
~~~~~~~~~
3D transform routine works intermittently. My guess due to
flaky Suzy math flag clearing. I've got a contract job now
and SCO courses to study, and band practice etc etc, so I
don't have the time and energy to fix it.

Thanks to the Lynx "sceners" (they know who they are) for the
kool tools for programming aattaarrii's best effort at hardware
(har har har). And of course wotsaname for his Handy emulator
which is way (just way). Maybe someday I'll download the
debugging version (when the hyperlink is fixed, maybe...).


Forthcoming ventures:
~~~~~~~~~~~~~~~~~~~~
Maybe a Lynx game? I'll need better tools first.


Cheers

 - James Higgs 12/1/99
 