#include <lynx.h>
#include <lynxlib.h>
#include <stdlib.h>

#define SCREEN (MEMTOP-8160)
#define RENDER (MEMTOP-16320)

#define NUMSTARS	40

extern char blankSCB[];
extern char welcomeSCB[];
extern char ball1SCB[];
extern char ball2SCB[];
extern char ball3SCB[];
extern char ball4SCB[];
extern char ball5SCB[];
extern char ball6SCB[];
extern char ball7SCB[];
extern char ball8SCB[];
extern char synth103[];
extern char back1[];
extern char scrollSCB[];


// assembler definitions of Sprite Control Blocks
#asm
          xref _blankspr
          xref _welcome
          xref _ball_r
          xref _scrtxt1

_blankSCB dc.b $c1,$10,$20
          dc.w 0,_blankspr
          dc.w 0,0,$400,$400
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_welcomeSCB dc.b $c4,$10,$20
          dc.w 0,_welcome
          dc.w 8,40,$100,$100
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball1SCB dc.b $c4,$10,$20
          dc.w _ball2SCB,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball2SCB dc.b $c4,$10,$20
          dc.w _ball3SCB,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball3SCB dc.b $c4,$10,$20
          dc.w _ball4SCB,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball4SCB dc.b $c4,$10,$20
          dc.w _ball5SCB,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball5SCB dc.b $c4,$10,$20
          dc.w _ball6SCB,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball6SCB dc.b $c4,$10,$20
          dc.w _ball7SCB,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball7SCB dc.b $c4,$10,$20
          dc.w _ball8SCB,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_ball8SCB dc.b $c4,$10,$20
          dc.w 0,_ball_r
          dc.w 0,0,$040,$040
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef

_scrollSCB dc.b $c4,$10,$20
          dc.w 0,_scrtxt1
          dc.w 160,92,$100,$100
          dc.b $01, $23, $45, $67, $89,$Ab,$cd,$ef
#endasm

// load in palette and sin/cos table
#include "mydemo.pal"
#include "sincos.h"
// 3d vector blob verts
#include "cube.h"


char copyright[] = "James' 1st Lynx Intro, December 1998. This program code copyright James Higgs 1998. What you looking in binaries for anyway? ?)";

int tx[8], ty[8], tz[8];
int s_order[8];
int rx, ry, rz;
int s, c, sx;
unsigned int k;

// assembler vertical retrace syncronisation routine
void Vsync(void) {
#asm
vretrace:
	lda $fd0a
	bne vretrace
#endasm
}


// program execution starts here
main()
{
  int i, j;
  int wy;
  int x[NUMSTARS], y[NUMSTARS], z[NUMSTARS];
  char shade[4];
  shade[0] = 15; shade[1] = 7;
  shade[2] = 8; shade[3] = 0;
  wy = 320;
  sx = 180;

 InitIRQ();
//  InstallUploader(_62500Bd);
  CLI;
  // set screen and double buffers
  SetBuffers(SCREEN, RENDER, 0);
  SmpInit(0,1);

  // set palette
  _SetRGB(pal);
  for(i=0; NUMSTARS > i; i++) {
     x[i] = (random() >> 7) - 128;
     y[i] = (random() >> 7) - 128;
     z[i] = random() >> 9;
  }

  // title page
  DrawSprite(blankSCB);
  POKE(0xFDA2, 0);
  TextOut(12, 20, 15, 0, "*** JumTro #1 ***");
  TextOut(24, 36, 2, 0, "By Jum Hig '98");
  SwapBuffers();

  for(j=0; 127 > j; j++) Vsync();

  for(i=0; 16 > i; i++) {
     POKE(0xFDA2, i);
     for(j=0; 8 > j; j++) Vsync();
  }

  for(j=0; 255 > j; j++) Vsync();

  SmpStart(synth103, 2000);

  SCBNEXT(blankSCB) = scrollSCB;
  // counter below must be 350 > i for final version
  for(i=0; 350 > i; i++) {

      // NB: clear background with first sprite ("background sprite")
      // DrawSprite draws all sprites in SCB linked-list
      sx -= 2;
      SCBX(scrollSCB) = sx;
      if(325 > i) DrawSprite(blankSCB);
      for(j=0; NUMSTARS > j; j++) {
         SetPixel(80 + x[j] / z[j], 51 + y[j] / z[j], shade[z[j] >> 4]);
         z[j]--;
         if(z[j] == 0) {
           z[j] = 63;
           x[j] = (random() >> 7) - 128;
           y[j] = (random() >> 7) - 128;
         }
      }
      if(i > 300) DrawSprite(welcomeSCB);
      Vsync();
      SwapBuffers();
  }

  // curtain close
  for(i=0; 52 > i; i++) {
      j = 101 - i;
      DrawLine(0, i, 159, i, 0);
      DrawLine(0, j, 159, j, 0);
      Vsync();
      SwapBuffers();
  }
  Vsync();
  SwapBuffers();
  for(i=0; 52 > i; i++) {
      j = 101 - i;
      DrawLine(0, i, 159, i, 0);
      DrawLine(0, j, 159, j, 0);
      Vsync();
      SwapBuffers();
  }

  // draw palette on screen
  for(i=0; 16 > i; i++) {
     DrawFBox(i*10, 90, 10, 12, i);
  }
  // draw circle using sin & cos
  for(i=0; 256 > i; i++) {
     SetPixel(80 + cos[i], 51 - sin[i], 15);
  }

  // change background
  SCBDATA(blankSCB) = back1;
  blankSCB[12] = 1;
  blankSCB[14] = 1;
  // show vector ball objects
  for(j=0; 256 > j; j++) {
    SCBY(blankSCB) = 0 - (j % 32);
    // rotate object
    s = sin[j];
    c = cos[j];
    for(i=0; 8 > i; i++) {
       //tz[i] = vz[i] * 96;
       //tx[i] = (vx[i] * 8) / tz[i];
       //ty[i] = (vy[i] * 8) / tz[i];
       // rotate about x-axis
       ry = c * vy[i] - s * vz[i];
       rz = s * vy[i] + c * vz[i];
       ry = ry >> 6;
       rz = rz >> 6;
       // rotate about z-axis
       rx = c * vx[i] - s * ry;
       ty[i] = s * vx[i] + c * ry;
       rx = rx >> 6;
       ty[i] = ty[i] >> 6;
       // rotate about y-axis
       tx[i] = c * rx + s * rz;
       tz[i] = -s * rx + c * rz;
       tx[i] = tx[i] >> 6;
       tz[i] = tz[i] >> 6;
       // shift along z-axis
       tz[i] += 64;
    }

    // initialise sort order
    for(i=0; 8 > i; i++) {
       s_order[i] = i;
    }

    // sort balls
    for(i=0; 7 > i; i++) {
      for(k=0; 7 > k; k++) {
        if(tz[s_order[k]] < tz[s_order[k+1]]) {
          wy = s_order[k];
          s_order[k] = s_order[k+1];
          s_order[k+1] = wy;
        }
      }
    }
     

    DrawSprite(blankSCB);
    // draw cube verts
    for(i=0; 8 > i; i++) {
       k = s_order[i];
       SCBX(ball_rSCB) = 72 + tx[k] / tz[i]; 
       SCBY(ball_rSCB) = 51 - ty[k] / tz[i];
       ball_rSCB[11] = 255 - tz[k];
       ball_rSCB[13] = 255 - tz[k];
       DrawSprite(ball_rSCB);
       //SetPixel(80 + vx[i], 51 - vy[i], 15);
       //SetPixel(80 + tx[i] / tz[i], 51 - ty[i] / tz[i], 15);
       //SetPixel(i, 101 - k, 15);
    }
    // and display
    Vsync();
    SwapBuffers();
  }


// TODO: sort vertices to z before displaying
//       -> done, but may be bug
// TODO: show pixels in 3D, then sprite-blobs
// TODO: music/modplayer (v. simple!)
    
  for(;;);

}


