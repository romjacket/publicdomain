
                 ----------------------------------------
                    Super Fighter demo for Nintendo 64
                    Created by Halley's Comet Software
                      Music composed by Marcelo Reis
                 ----------------------------------------

   Thank-you for downloading this Super Fighter demo for use on the
   Nintendo (Ultra) 64. The demo was created using graphics from the
   original game, and a brand-new digital version of the title theme
   composed by Marcelo Reis. Special thanks to Halley's Comet Software
   for writing up this interesting and entertaining demo.

   This demo can of course be experienced on almost any Nintendo 64
   emulator. For best results however (especially regarding the stereo
   sound), we recommend trying the demo using the real console hardware.

    For more Super Fighter goodies, we invite you to please visit the
    Official Super Fighter website - [ http://www.superfighter.com/ ].

               - DEATH ADDER [deathadder@superfighter.com] -
