SH9654 by Orion_ [June 2017]

http://orionsoft.free.fr/

This little demo is a Tribute to the 'Big Border' screen by Delta Force.

This was made for the "Syntax Terror Big Border revisited" SommarHack 2017 compo !
More details about the compo here: http://dhs.nu/sommarhack/2017/compo.php

This should work on an Atari 520 ST.

96x54 screen

4 planes 1x1 c2p rotozoom

triple buffering (because too slow for vbl)

100 fully clipped 5x5 sprites on 2 planes rotating in 3D 6 DOF

reused to death sndh music by Big Alec

2 weeks of coding from scratch

100% asm

68000 forever
