Visual Unity

My latest and most advanced demo for the Atari STe. This demo took me 2 years of coding, it was at first done for a Megademo by Paradize and Cerebral Vortex, but due to lack of motivation from the other coders, the demo was never released. That's why I decided to pack all my screens together and send them as a contribution to the 20 Years Atari STE Megademo made by Paradox.

Full Credits:
Code and Animation: Orion_
Graphics: Orion_, Minz, Templeton
Music: 505
Line routine: GT Turbo, Azrael
Part of the polygon routine: Pmdata 


This is the stand alone version.



http://onorisoft.free.fr/




This is 5477 lines of pure assembly code baby !

and 16264 precalc lines for the hline stuff, but still damn slow :(
