//////////////////////////////////////////////////////////////////////////////
// MAIN.C                                                                   //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "gb.h"
#include "stdio.h"
#include "backgrnd.h"
#include "objects.h"
#include "level1.h"

//////////////////////////////////////////////////////////////////////////////
// defines                                                                  //
//////////////////////////////////////////////////////////////////////////////
#define OBJ 1+3           // total objects

//////////////////////////////////////////////////////////////////////////////
// variables                                                                //
//////////////////////////////////////////////////////////////////////////////
const u16 BackgroundPalette[] = CGBPALS(background);
const u16 ObjectsPalette[] = CGBPALS(objects);

u8 (*map)[][32];

s8 px[OBJ], py[OBJ];     // positions
s8 ix[OBJ], iy[OBJ];     // directions
s8 cd[OBJ], follow[OBJ]; // current direction (0=hor,1=ver), follow pacman?
u8 dots;				 // dots left
u16 score;               // total score
u16 safe;                // safe timeout
s8 contact;              // ghost contacted?
s8 lives;
s8 level;

//////////////////////////////////////////////////////////////////////////////
// sound                                                                    //
//////////////////////////////////////////////////////////////////////////////
extern u8 boom[];
extern u8 eatdot[];
extern u8 eatdot2[];
extern u8 eaten[];
extern u8 eatghost[];
extern u8 eatpil[];
extern u8 gameover[];
extern u8 start[];

//////////////////////////////////////////////////////////////////////////////
// getbkg                                                                   //
//////////////////////////////////////////////////////////////////////////////
// get background tile
u8 getbkg(s8 x, s8 y)
{
	u8 c;
	get_bkg_tiles(x&31,y, 1,1, &c);
	return c;
}

//////////////////////////////////////////////////////////////////////////////
// setbkg                                                                   //
//////////////////////////////////////////////////////////////////////////////
// set background tile
void setbkg(s8 x, s8 y, u8 c)
{
	set_bkg_tiles(x,y, 1,1, &c);
}

//////////////////////////////////////////////////////////////////////////////
// SetGhostColors                                                           //
//////////////////////////////////////////////////////////////////////////////
// set ghost colors on/off
void SetGhostColors(s8 colored)
{
	s8 o;
	if (colored)
		for (o=1; o<OBJ; o++) set_sprite_prop(o, o); // colors
	else
		for (o=1; o<OBJ; o++) set_sprite_prop(o, 7); // gray
}

//////////////////////////////////////////////////////////////////////////////
// Init                                                                     //
//////////////////////////////////////////////////////////////////////////////
// init tiles, palettes, sprites
void Init()
{
	s8 o;
	set_bkg_data(0, 128, background);
	set_sprite_data(0, 16, objects);
	set_bkg_palette(0, 8, BackgroundPalette);
	set_sprite_palette(0, 8, ObjectsPalette);
	//OBP0_REG = 0x1B; // compatible palette
	for (o=1; o<OBJ; o++) set_sprite_tile(o, 8); // ghost tiles
	set_sprite_prop(0, 4); // pacman color = yellow
	SHOW_SPRITES;
	SHOW_BKG;
}	

//////////////////////////////////////////////////////////////////////////////
// LoadLevel                                                                //
//////////////////////////////////////////////////////////////////////////////
void LoadLevel()
{
	switch (level)
	{
		case 1:
			map = (void*)level1PLN0;
			VBK_REG = 1; set_bkg_tiles(0,0, 32,32, level1PLN1);
			VBK_REG = 0; set_bkg_tiles(0,0, 32,32, level1PLN0);
			dots = 146;
			break;
	}
	lives = 3;
	score = 0;
}

//////////////////////////////////////////////////////////////////////////////
// Move_Ghost                                                               //
//////////////////////////////////////////////////////////////////////////////
void Move_Ghost(s8 n)
{
	if ((px[n]==px[0]) && (py[n]==py[0])) contact = n; // contact with ghost?

	Again: // try to move to somewhere...

	// turn ghost?
	if (cd[n]==0)
	{ // horizontal...
		if (follow[n])
		{ // follow
			if (py[n]>py[0]) iy[n] = -1;
			if (py[n]<py[0]) iy[n] = +1;
		}
		if (safe > 0)
		{ // walk away
			if (py[n]>py[0]) iy[n] = +1;
			if (py[n]<py[0]) iy[n] = -1;
		}
		if (iy[n] != 0)
		{ // turn?
			if (getbkg(px[n],py[n]+iy[n]) < 15)
				iy[n]=0; // blocked
			else
			{
				ix[n]=0; cd[n]=1; // go walk vertical
				follow[n] = 1; // follow pacman
			}
		}
	}
	else
	{        // vertical...
		if (follow[n])
		{ // follow
			if (px[n]>px[0]) ix[n] = -1;
			if (px[n]<px[0]) ix[n] = +1;
		}
		if (safe > 0)
		{ // walk away
			if (px[n]>px[0]) ix[n] = +1;
			if (px[n]<px[0]) ix[n] = -1;
		}
		if (ix[n] != 0)
		{ // turn?
			if (getbkg(px[n]+ix[n],py[n]) < 15)
				ix[n]=0; // blocked
			else
			{
				iy[n]=0; cd[n]=0; // go walk horizontal
				follow[n] = 1; // follow pacman
			}
		}
	}

	// move, randomize if blocked
	if (((ix[n]==0) && (iy[n]==0)) || (getbkg(px[n]+ix[n],py[n]+iy[n]) < 15))
	{
		ix[n]=0; iy[n]=0; // blocked, stop
		follow[n] = rand()%2;
		cd[n] = rand()&1; // random direction
		ix[n] = rand()%3-1; // "
		iy[n] = rand()%3-1; // "
		goto Again; // move again
	} else
		px[n]+=ix[n]; py[n]+=iy[n]; // ok, move
  
	if ((px[n]==px[0]) && (py[n]==py[0])) contact = n; // contact with ghost?
}

//////////////////////////////////////////////////////////////////////////////
// Move_Pacman                                                              //
//////////////////////////////////////////////////////////////////////////////
void Move_Pacman()
{
	static s8 ps, ps2;

	// direction = padstatus
	s8 pad = joypad();
	if (pad & J_LEFT)	ix[0]=-1;
	if (pad & J_RIGHT)	ix[0]=+1;
	if (pad & J_UP)		iy[0]=-1;
	if (pad & J_DOWN)	iy[0]=+1;

	// turn pacman?
	if (cd[0]==0) // horizontal
	{
		if (iy[0]!=0) // turn?
		{
			if (getbkg(px[0],py[0]+iy[0]) < 16)
			{
				iy[0]=0; // blocked
			}
			else
			{
				ix[0]=0; cd[0]=1; // go walk vertical
			}
		}
	}
	else // vertical
	{
		if (ix[0]!=0) // turn?
		{
			if (getbkg(px[0]+ix[0],py[0]) < 16)
			{
				ix[0]=0; // blocked
			}
			else
			{
				iy[0]=0; cd[0]=0; // go walk horizontal
			}
		}
	}

	// move
	if (((ix[0]==0) && (iy[0]==0)) || (getbkg(px[0]+ix[0],py[0]+iy[0]) < 16))
	{
		ix[0]=0; iy[0]=0; // blocked, stop
	}
	else
	{
		px[0]+=ix[0]; py[0]+=iy[0]; // ok, move
		ps2^=1; // tile adjustment
	}

	// set pacman tile
	if (ix[0]==-1) ps=0;
	if (ix[0]==+1) ps=2;
	if (iy[0]==-1) ps=4;
	if (iy[0]==+1) ps=6;
	set_sprite_tile(0, ps+ps2);
}

//////////////////////////////////////////////////////////////////////////////
// UpdateScore                                                              //
//////////////////////////////////////////////////////////////////////////////
void UpdateScore()
{
	gotoxy(6,17);
	printf("%lu", score);
	gotoxy(16,17);
	printf("%u", dots);
	if (dots<100) printf(" ");
}

//////////////////////////////////////////////////////////////////////////////
// PlayLevel                                                                //
//////////////////////////////////////////////////////////////////////////////
// load and play level (main game loop)
void PlayLevel()
{
	s8 i,o;
	static s8 seed;
	initrand(seed++);
	set_sprite_tile(0, 0); // pacman tile
	px[0]=10; py[0]=11; // pacman
	px[1]=10; py[1]=9;  // ghost1
	px[2]=10; py[2]=9;  // ghost2
	px[3]=10; py[3]=9;  // ghost3
	for (o=0; o<OBJ; o++) // init objects
	{
		move_sprite(o, (px[o]<<3)+8, (py[o]<<3)+16); // position
		ix[0]=0; iy[0]=0; // direction
	}
	safe = 30; // safe timeout
	SetGhostColors(0); // gray ghosts (safe>0)
	contact = 0; // no ghost contacted
	
	while (1)
	{
		Move_Pacman();
		for (o=1; o<OBJ; o++)
		{
			Move_Ghost(o);
		}

		for (i=0; i<8; i++)
		{ // move object sprites
			for (o=0; o<OBJ; o++)
			{
				scroll_sprite(o, ix[o],iy[o]);
			}
			delay(15);
			//wait_vbl_done();
		}


		for (o=0; o<OBJ; o++)
		{
			if (px[o] < 0) px[o]=20;
			else
			if (px[o] >= 20) px[o]=0;
			move_sprite(o, (px[o]<<3)+8, (py[o]<<3)+16); // position
		}

		if (dots == 0) // fake die
		{
			SysPlayWave(boom);
			safe = 0;
			contact = 1;
		}
		
		switch (getbkg(px[0],py[0]))
		{
			case 18:	// eat ghost-killer?
			{
				SysPlayWave(eatpil);
				safe = 70; // set safe timeout
				score += 5; // increase score
				//continue case as a dot...
			}
			case 17:	// eat a dot?
			{
				if (getbkg(px[0],py[0]) == 17) SysPlayWave(eatdot);

				setbkg(px[0],py[0],16); // remove
				score += 1; // increase score
				if (dots > 0) dots--;
				//if (dots == 0) return; // end of level
				UpdateScore();
				break;
			}
		}
		
		if (safe == 0) // dangerous ghosts?
		{
			if (contact!=0) // die!
			{
				SysPlayWave(eaten);
				for (o=1; o<OBJ; o++) move_sprite(o, 0,0);
				for (i=0; i<10; i++)
				{
					set_sprite_tile(0, 1); delay(50);
					set_sprite_tile(0, 5); delay(50);
					set_sprite_tile(0, 3); delay(50);
					set_sprite_tile(0, 7); delay(50);
				}
				return;
			}
		}
		else
		{
			if (contact!=0) // eat ghost!
			{
				SysPlayWave(eatghost);
				px[contact] = 10;
				py[contact] = 9;
				move_sprite(contact, (px[contact]<<3)+8, (py[contact]<<3)+16); // position
				score += 123; UpdateScore(); // increase score
				contact = 0;
			}
			if (safe < 20)
				SetGhostColors((s8)(1+safe&2)); // blink
			else
				SetGhostColors(0); // normal ghosts
			safe--;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
void main()
{
	while (1)
	{
		InitGB();
		Init();

		SysPlayWave(start);
		delay(2310);
	
		level = 1;
		LoadLevel();
		DISPLAY_ON;
		while ((lives--!=0) & (dots!=0))
		{
			PlayLevel();
		}
	
		if (dots == 0)
		{
			SysPlayWave(start);
		}
		else
		{
			SysPlayWave(gameover);
		}
	
		DISPLAY_OFF;
		delay(3000);
	}
}
