Hi all devrs... read till [EOF]...

This is my first NGPC game.
Know what? it's a port of my first GBC game ;-)
WHY you say...
well just GBC is a good basis to work from... <ahem>

v1.01:
	- now added some sounds (makes it slower, but hey I'm not using VBL int;-)

v1.00:
	- 2 planes used for 4 colors/tile. tile 511 for plane 2 is used for color 0.
	- change export options in GBTD/GBMB to consecutive colors.
		due the big endianess of GBTD output, this is converted in set_bkg_data.
	- palette conversion is also done in functions.
	- main.c just calls InitGB for initialisation.
	- removed sound/rumble (hmm) code.
	- added 'const' keyword to GBTD/GBMB output.
	- sprite tiles are 256 and up.

Enjoy our free stuff...
Join the NGPC dev'rs community!
All you need is the toshiba 900H compiler & a "Flash Linker".

Oh hey... when do people start crediting me?
or send money? I kinda need it to keep on studying.

Dark Fader / BlackThunder
www.bigfoot.com/~darkfader

[EOF]
